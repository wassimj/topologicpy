# Copyright (C) 2026
# Wassim Jabi <wassimj@gmail.com>
#
# Tests for public TopologicPy provenance.
#
# Exact Boolean provenance depends on PythonOCC/OCCT BRepTools_History.
# TopologicCore does not expose the native history required by this API.

import pytest

from topologicpy.Cell import Cell
from topologicpy.Provenance import Provenance
from topologicpy.TGraph import TGraph
from topologicpy.Topology import Topology
from topologicpy.Vertex import Vertex


pytestmark = pytest.mark.pythonocc_only


def _role_counts(graph):
    counts = {}
    for vertex in TGraph.Vertices(graph):
        dictionary = vertex.get("dictionary") or {}
        role = dictionary.get("role")
        counts[role] = counts.get(role, 0) + 1
    return counts


def _edge_relations(graph):
    relations = []
    for edge in TGraph.Edges(graph):
        dictionary = edge.get("dictionary") or {}
        relation = dictionary.get("relation")
        if relation is not None:
            relations.append(relation)
    return relations


def _make_overlapping_prisms():
    p1 = Cell.Prism(
        origin=Vertex.ByCoordinates(0, 0, 0)
    )
    p2 = Cell.Prism(
        origin=Vertex.ByCoordinates(0.6, 0.6, 0.6)
    )
    return p1, p2


def test_provenance_container_from_synthetic_records():
    source = Vertex.ByCoordinates(0, 0, 0)
    result = Vertex.ByCoordinates(1, 0, 0)

    provenance = Provenance.ByRecords(
        [
            {
                "operation": "Test",
                "relation": "modified",
                "source": source,
                "result": result,
                "sourceType": "Vertex",
                "resultType": "Vertex",
                "sourceRole": "self",
            }
        ],
        result=result,
    )

    history = provenance.History()
    assert len(history) == 1
    assert history[0]["relation"] == "modified"

    records = provenance.Records()
    assert len(records) == 1

    origins = provenance.Origins(result)
    assert len(origins) == 1
    assert Topology.IsSame(origins[0]["source"], source)

    descendants = provenance.Descendants(source)
    assert len(descendants) == 1
    assert Topology.IsSame(descendants[0]["result"], result)


def test_merge_returns_provenance_without_dictionary_transfer():
    p1, p2 = _make_overlapping_prisms()

    result, provenance = Topology.Merge(
        p1,
        p2,
        returnProvenance=True,
    )

    assert result is not None
    assert isinstance(provenance, Provenance)
    assert provenance.History()
    assert provenance.Records()


def test_merge_default_return_type_remains_backward_compatible():
    p1, p2 = _make_overlapping_prisms()

    result = Topology.Merge(
        p1,
        p2,
    )

    assert result is not None
    assert not isinstance(result, tuple)


def test_merge_face_graph_matches_authoritative_result():
    p1, p2 = _make_overlapping_prisms()

    result, provenance = Topology.Merge(
        p1,
        p2,
        returnProvenance=True,
    )

    result_faces = Topology.Faces(result)
    graph = provenance.Graph(topologyType="Face")
    counts = _role_counts(graph)

    assert counts.get("source", 0) == 12
    assert len(result_faces) == 18
    assert counts.get("result", 0) == len(result_faces)
    assert counts.get("intermediate", 0) == 0


def test_merge_unchanged_faces_are_explicit_source_to_result_states():
    p1, p2 = _make_overlapping_prisms()

    result, provenance = Topology.Merge(
        p1,
        p2,
        returnProvenance=True,
    )

    graph = provenance.Graph(topologyType="Face")
    relations = _edge_relations(graph)

    assert relations.count("unchanged") >= 6

    counts = _role_counts(graph)
    assert counts.get("source", 0) == 12
    assert counts.get("result", 0) == 18


def test_merge_every_semantic_result_face_belongs_to_returned_topology():
    p1, p2 = _make_overlapping_prisms()

    result, provenance = Topology.Merge(
        p1,
        p2,
        returnProvenance=True,
    )

    result_faces = Topology.Faces(result)
    graph = provenance.Graph(topologyType="Face")

    graph_result_faces = []
    for vertex in TGraph.Vertices(graph):
        dictionary = vertex.get("dictionary") or {}
        if dictionary.get("role") == "result":
            representation = vertex.get("representation")
            assert representation is not None
            graph_result_faces.append(representation)

    assert len(graph_result_faces) == len(result_faces)

    for graph_face in graph_result_faces:
        assert any(
            Topology.IsSame(graph_face, result_face)
            for result_face in result_faces
        )


def test_merge_origins_resolve_for_every_result_face():
    p1, p2 = _make_overlapping_prisms()

    result, provenance = Topology.Merge(
        p1,
        p2,
        returnProvenance=True,
    )

    for face in Topology.Faces(result):
        origins = provenance.Origins(face)
        assert origins
        assert all(record.get("source") is not None for record in origins)


def test_difference_face_graph_contains_only_contributing_sources():
    p1, p2 = _make_overlapping_prisms()

    result, provenance = Topology.Difference(
        p1,
        p2,
        returnProvenance=True,
    )

    assert result is not None

    graph = provenance.Graph(topologyType="Face")
    counts = _role_counts(graph)
    result_faces = Topology.Faces(result)

    assert counts.get("source", 0) == 9
    assert counts.get("result", 0) == len(result_faces)
    assert counts.get("intermediate", 0) == 0


def test_difference_does_not_require_dictionary_transfer_for_provenance():
    p1, p2 = _make_overlapping_prisms()

    result, provenance = Topology.Difference(
        p1,
        p2,
        tranDict=False,
        returnProvenance=True,
    )

    assert result is not None
    assert provenance.History()
    assert provenance.Records()

    graph = provenance.Graph(topologyType="Face")
    assert TGraph.Order(graph) > 0
    assert TGraph.Size(graph) > 0


def test_direct_boolean_graph_result_nodes_are_authoritative_for_difference():
    p1, p2 = _make_overlapping_prisms()

    result, provenance = Topology.Difference(
        p1,
        p2,
        returnProvenance=True,
    )

    result_faces = Topology.Faces(result)
    graph = provenance.Graph(topologyType="Face")

    graph_result_faces = []
    for vertex in TGraph.Vertices(graph):
        dictionary = vertex.get("dictionary") or {}
        if dictionary.get("role") == "result":
            graph_result_faces.append(vertex.get("representation"))

    assert len(graph_result_faces) == len(result_faces)

    for graph_face in graph_result_faces:
        assert graph_face is not None
        assert any(
            Topology.IsSame(graph_face, result_face)
            for result_face in result_faces
        )


def test_internal_unchanged_records_do_not_become_public_sources():
    source = Vertex.ByCoordinates(0, 0, 0)
    intermediate = Vertex.ByCoordinates(1, 0, 0)
    result = Vertex.ByCoordinates(2, 0, 0)

    def record(a, b, role, relation):
        return {
            "source": a, "result": b,
            "sourceType": "Vertex", "resultType": "Vertex",
            "sourceRole": role, "relation": relation,
            "operation": "Test",
        }

    provenance = Provenance.ByRecords([
        record(source, intermediate, "self", "modified"),
        record(intermediate, intermediate, "source", "unchanged"),
        record(intermediate, result, "source", "modified"),
        record(result, result, "source", "unchanged"),
    ], operation="Test", sources={"self": source}, result=result)

    records = provenance.Records(topologyType="Vertex")
    assert len(records) == 1
    assert Topology.IsSame(records[0]["source"], source)
    assert Topology.IsSame(records[0]["result"], result)
    assert records[0]["relation"] == "modified"
    assert len(provenance.History()) == 4
    assert _role_counts(provenance.Graph(topologyType="Vertex")) == {
        "source": 1, "result": 1,
    }
    assert len(provenance.Origins(result)) == 1
    assert len(provenance.Descendants(source)) == 1


def test_unresolved_internal_unchanged_record_is_not_a_public_origin():
    result = Vertex.ByCoordinates(0, 0, 0)
    provenance = Provenance.ByRecords([{
        "source": result, "result": result,
        "sourceType": "Vertex", "resultType": "Vertex",
        "sourceRole": "source", "relation": "unchanged",
    }], result=result)

    assert len(provenance.History()) == 1
    assert provenance.Records() == []
    assert provenance.Origins(result) == []


# Same face-only expectations and exact endpoint checks as the reviewer notebook.
import _boolean_cube_matrix as _cube_matrix


@pytest.mark.parametrize("state,operation", _cube_matrix.CASES, ids=_cube_matrix.CASE_IDS)
def test_boolean_cube_matrix_face_provenance(state, operation):
    a, b = _cube_matrix.make_inputs(state)
    inputs, source_extents = _cube_matrix.labelled_faces(a, b, state)
    result, provenance = _cube_matrix.run_operation(a, b, operation, return_provenance=True)
    outputs = {"R%02d" % i: face for i, face in enumerate(_cube_matrix.members(result, "Face"))}
    result_extents = {label: _cube_matrix.face_extent(face) for label, face in outputs.items()}
    eligible = _cube_matrix.EXPECTED_FACES[state][operation]
    expected = {(source, target) for source in eligible for target in outputs
                if _cube_matrix.plane_overlap(source_extents[source], result_extents[target])}
    assert {source for source, target in expected} == eligible, "Returned faces violate reference coverage"
    assert provenance.supported, "Unsupported capture is not a passing empty result"
    assert bool(outputs) == bool(eligible)

    observed = set()
    for record in provenance.Records(topologyType="Face"):
        if record.get("result") is None:
            continue  # Deleted records remain diagnostic, as in the notebook.
        observed.add((_cube_matrix.identity_label(record.get("source"), inputs),
                      _cube_matrix.identity_label(record.get("result"), outputs)))
    origins, descendants = set(), set()
    for target, face in outputs.items():
        for record in provenance.Origins(face):
            if record.get("sourceType") == "Face":
                origins.add((_cube_matrix.identity_label(record.get("source"), inputs), target))
    for source, face in inputs.items():
        for record in provenance.Descendants(face):
            if record.get("result") is not None and record.get("resultType") == "Face":
                descendants.add((source, _cube_matrix.identity_label(record.get("result"), outputs)))
    assert observed == expected, "Missing: %r; unexpected: %r" % (expected - observed, observed - expected)
    assert origins == expected, "Origins differ from independently expected face links"
    assert descendants == expected, "Descendants differ from independently expected face links"
    assert {source for source, target in observed} == eligible
    assert set(outputs) == {target for source, target in expected}, "Unexplained result face"


@pytest.mark.parametrize("deep", [False, True])
def test_compose_avoids_reseeding_and_preserves_reference_records(monkeypatch, deep):
    source = Cell.Prism()
    moved, p1 = Topology.Translate(source, x=1, returnProvenance=True)
    final, p2 = Topology.Copy(moved, deep=deep, returnProvenance=True)
    before1 = p1.History()
    before2 = p2.History()
    original = Provenance._topology_entities
    traversals = []
    def traced(cls, root):
        traversals.append(root)
        return original(root)
    # Warm semantic reduction separately: the assertion concerns redundant
    # constructor seeding, not traversal required by direct Records().
    semantic1, semantic2 = p1.Records(), p2.Records()
    original_records = Provenance.Records
    def semantic(self, **kwargs):
        if self is p1: return [dict(r) for r in semantic1]
        if self is p2: return [dict(r) for r in semantic2]
        return original_records(self, **kwargs)
    monkeypatch.setattr(Provenance, "Records", semantic)
    monkeypatch.setattr(Provenance, "_topology_entities", classmethod(traced))
    result = Provenance.Compose(p1, p2)
    assert len(traversals) == 1  # authoritative shared boundary only
    monkeypatch.setattr(Provenance, "_topology_entities", classmethod(lambda cls, root: original(root)))
    reference = Provenance.ByRecords(result.History(), operation="Compose", sources=result.sources,
                                    result=final, supported=result.supported, metadata=result.metadata)
    assert result.Records() == reference.Records()
    for face in Topology.Faces(final):
        assert result.Origins(face) == reference.Origins(face)
    for face in Topology.Faces(source):
        assert result.Descendants(face) == reference.Descendants(face)
    assert p1.History() == before1
    assert p2.History() == before2


@pytest.mark.parametrize("same", [True, False])
def test_provenance_native_identity_bypasses_public_validation(monkeypatch, same):
    class NativeShape:
        def IsNull(self): return False
        def IsSame(self, other): return same
    class Endpoint:
        def __init__(self): self.shape = NativeShape()
    def forbidden(*args, **kwargs):
        raise AssertionError("Public type validation must not run for native endpoints")
    monkeypatch.setattr(Topology, "IsSame", forbidden)
    assert Provenance._same(Endpoint(), Endpoint()) is same


def test_provenance_unavailable_native_identity_keeps_public_fallback(monkeypatch):
    calls = []
    def public(a, b, **kwargs):
        calls.append((a, b))
        return True
    monkeypatch.setattr(Topology, "IsSame", public)
    a, b = object(), object()
    assert Provenance._same(a, b)
    assert calls == [(a, b)]
