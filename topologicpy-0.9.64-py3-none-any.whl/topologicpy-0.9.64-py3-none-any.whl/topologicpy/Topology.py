# Copyright (C) 2026
# Wassim Jabi <wassim.jabi@gmail.com>
#
# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU Lesser General Public License as published by the Free Software
# Foundation, either version 3.0 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
# details.
#
# You should have received a copy of the GNU Lesser General Public License along with
# this program. If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

from topologicpy.Core import Core
import warnings
import uuid
import json
import os

import math
from collections import namedtuple, defaultdict
from multiprocessing import Process, Queue
from typing import Any, Dict, Iterable, List, Tuple

# This is for View3D as not to open new browser windows
opened_urls = set()

try:
    import numpy as np
    from numpy import arctan, pi, signbit
    from numpy.linalg import norm
except:
    print("Topology - Installing required numpy library.")
    try:
        os.system("pip install numpy")
    except:
        os.system("pip install numpy --user")
    try:
        import numpy as np
        from numpy import arctan, pi, signbit
        from numpy.linalg import norm
        print("Topology - numpy library installed successfully.")
    except:
        warnings.warn("Topology - Error: Could not import numpy.")

try:
    from scipy.spatial import ConvexHull
except:
    print("Topology - Installing required scipy library.")
    try:
        os.system("pip install scipy")
    except:
        os.system("pip install scipy --user")
    try:
        from scipy.spatial import ConvexHull
        print("Topology - scipy library installed successfully.")
    except:
        warnings.warn("Topology - Error: Could not import scipy.")

QueueItem = namedtuple('QueueItem', ['ID', 'sinkKeys', 'sinkValues'])
SinkItem = namedtuple('SinkItem', ['ID', 'sink_str'])

class WorkerProcessPool(object):
    """
    Create and manage a list of Worker processes. Each worker process
    transfers the dictionaries from a subset of sources to the list of sinks.
    """
    def __init__(self, num_workers, message_queue, sources, sinks, so_dicts, tolerance=0.0001):
        self.num_workers = num_workers
        self.message_queue = message_queue
        self.sources = sources
        self.sinks = sinks
        self.so_dicts = so_dicts
        self.tolerance = tolerance
        self.process_list = []

    def startProcesses(self):
        num_item_per_worker = len(self.sources) // self.num_workers
        for i in range(self.num_workers):
            if i == self.num_workers - 1:
                begin = i * num_item_per_worker
                sub_sources = self.sources[begin:]
                sub_dict = self.so_dicts[begin:]
            else:
                begin = i * num_item_per_worker
                end = begin + num_item_per_worker
                sub_sources = self.sources[begin : end]
                sub_dict = self.so_dicts[begin : end]
            wp = WorkerProcess(self.message_queue, sub_sources, self.sinks, sub_dict, self.tolerance)
            wp.start()
            self.process_list.append(wp)

    def stopProcesses(self):
        for p in self.process_list:
            p.join()
        self.process_list = []

    def join(self):
        for p in self.process_list:
            p.join()

class WorkerProcess(Process):
    """
    Transfers the dictionaries from a subset of sources to the list of sinks.
    """
    def __init__(self, message_queue, sources, sinks, so_dicts, tolerance=0.0001):
        Process.__init__(self, target=self.run)
        self.message_queue = message_queue
        self.sources = sources
        self.sinks = sinks
        self.so_dicts = so_dicts
        self.tolerance = tolerance

    def run(self):
        from topologicpy.Vertex import Vertex
        from topologicpy.Dictionary import Dictionary
        for sink_item in self.sinks:
            sink = Topology.ByBREPString(sink_item.sink_str)
            sinkKeys = []
            sinkValues = []
            iv = Topology.InternalVertex(sink, tolerance=self.tolerance)
            for j, source_str in enumerate(self.sources):
                source = Topology.ByBREPString(source_str)
                flag = False
                if Topology.IsInstance(source, "Vertex"):
                    flag = Vertex.IsInternal(source, sink, self.tolerance)
                else:
                    flag = Vertex.IsInternal(iv, source, self.tolerance)
                if flag:
                    d = Dictionary.ByPythonDictionary(self.so_dicts[j])
                    if d == None:
                        continue
                    stlKeys = Dictionary.Keys(d)
                    if len(stlKeys) > 0:
                        sourceKeys = Dictionary.Keys(d)
                        for aSourceKey in sourceKeys:
                            if aSourceKey not in sinkKeys:
                                sinkKeys.append(aSourceKey)
                                sinkValues.append("")
                        for i in range(len(sourceKeys)):
                            index = sinkKeys.index(sourceKeys[i])
                            sourceValue = Dictionary.ValueAtKey(d, sourceKeys[i])
                            if sourceValue != None:
                                if sinkValues[index] != "":
                                    if isinstance(sinkValues[index], list):
                                        sinkValues[index].append(sourceValue)
                                    else:
                                        sinkValues[index] = [sinkValues[index], sourceValue]
                                else:
                                    sinkValues[index] = sourceValue
                    break
            if len(sinkKeys) > 0 and len(sinkValues) > 0:
                self.message_queue.put(QueueItem(sink_item.ID, sinkKeys, sinkValues))

class MergingProcess(Process):
    """
    Receive message from other processes and merging the result
    """
    def __init__(self, message_queue, sources, sinks, so_dicts):
        Process.__init__(self, target=self.wait_message)
        self.message_queue = message_queue
        self.sources = sources
        self.sinks = sinks
        self.so_dicts = so_dicts
        self.sinkMap = self._init_sink_map()

    def _init_sink_map(self):
        sinkMap = {}
        for sink in self.sinks:
            sinkMap[sink.ID] = QueueItem(sink.ID, [], [])
        return sinkMap

    def wait_message(self):
        while True:
            try:
                item = self.message_queue.get()
                if item is None:
                    self.message_queue.put(self.sinkMap)
                    break
                mapItem = self.sinkMap[item.ID]
                mapItem.sinkKeys.extend(item.sinkKeys)
                mapItem.sinkValues.extend(item.sinkValues)
            except Exception as e:
                print(str(e))

class Topology():

    @staticmethod
    def _IsTopologicCoreBackend() -> bool:
        """
        Returns True if the active Core backend is TopologicCore.

        This helper is used to fence legacy workarounds that are required only
        because TopologicCore may return incorrect, incomplete, or poorly typed
        topology results.

        All other backends are assumed to return correct native results.

        Returns
        -------
        bool
            True if the active backend is TopologicCore. False otherwise.
        """
        try:
            backend = Core.Backend()

            if backend is None:
                return False

            return backend.__class__.__name__ == "TopologicCoreBackend"

        except Exception:
            return False

    @staticmethod
    def _OntologyAnnotate(topology,
                          ontology: bool = False,
                          ontologyClass: str = None,
                          category: str = None,
                          label: str = None,
                          uri: str = None,
                          source: str = None,
                          derivedFrom: str = None,
                          generatedBy: str = None,
                          annotateSubtopologies: bool = False,
                          silent: bool = True):
        """
        Annotates a topology with TopologicPy ontology metadata.

        This is an internal helper used by high-level constructors and importers.
        It deliberately does nothing unless ontology is True.
        """
        if ontology is not True:
            return topology
        if topology is None:
            return None
        try:
            try:
                from topologicpy.Ontology import Ontology
            except Exception:
                from Ontology import Ontology

            topology = Ontology.Annotate(
                topology,
                ontologyClass=ontologyClass,
                category=category,
                label=label,
                uri=uri,
                source=source,
                derivedFrom=derivedFrom,
                generatedBy=generatedBy,
                inferClass=(ontologyClass is None),
                silent=True,
            )
            if annotateSubtopologies:
                try:
                    topology = Ontology.AnnotateSubtopologies(
                        topology,
                        vertices=True,
                        edges=True,
                        wires=True,
                        faces=True,
                        shells=True,
                        cells=True,
                        cellComplexes=True,
                        inferClass=True,
                        silent=True,
                    )
                except Exception:
                    pass
            return topology
        except Exception as e:
            if not silent:
                print("Topology._OntologyAnnotate - Warning: Could not annotate topology. Returning input topology.")
                print("Error:", e)
            return topology

    @staticmethod
    def _OntologyAnnotateList(topologies,
                              ontology: bool = False,
                              generatedBy: str = None,
                              source: str = None,
                              annotateSubtopologies: bool = False,
                              silent: bool = True):
        """
        Annotates a list of topologies with TopologicPy ontology metadata.
        """
        if ontology is not True:
            return topologies
        if topologies is None:
            return None
        if not isinstance(topologies, list):
            return Topology._OntologyAnnotate(
                topologies,
                ontology=ontology,
                generatedBy=generatedBy,
                source=source,
                annotateSubtopologies=annotateSubtopologies,
                silent=silent,
            )
        return [
            Topology._OntologyAnnotate(
                t,
                ontology=ontology,
                generatedBy=generatedBy,
                source=source,
                annotateSubtopologies=annotateSubtopologies,
                silent=silent,
            ) for t in topologies
        ]

    @staticmethod
    def SetOntology(topology,
                    ontologyClass: str = None,
                    category: str = None,
                    label: str = None,
                    uri: str = None,
                    source: str = None,
                    derivedFrom: str = None,
                    generatedBy: str = None,
                    annotateSubtopologies: bool = False,
                    silent: bool = False):
        """
        Annotates the input topology with TopologicPy ontology metadata.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        ontologyClass : str , optional
            The ontology class, for example "top:Face", "top:Cell", or "top:Space".
            If set to None, the class is inferred from the Topologic type. Default is None.
        category : str , optional
            The semantic category. Default is None.
        label : str , optional
            A human-readable label. Default is None.
        uri : str , optional
            A stable URI or QName for the topology instance. Default is None.
        source : str , optional
            A source file, URI, or process identifier. Default is None.
        derivedFrom : str , optional
            The source entity from which this topology was derived. Default is None.
        generatedBy : str , optional
            The method or process that generated the topology. Default is None.
        annotateSubtopologies : bool , optional
            If True, vertices, edges, wires, faces, shells, cells, and cell complexes
            contained by the topology are also annotated. Default is False.
        silent : bool , optional
            If True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The annotated topology.
        """
        return Topology._OntologyAnnotate(
            topology,
            ontology=True,
            ontologyClass=ontologyClass,
            category=category,
            label=label,
            uri=uri,
            source=source,
            derivedFrom=derivedFrom,
            generatedBy=generatedBy,
            annotateSubtopologies=annotateSubtopologies,
            silent=silent,
        )

    @staticmethod
    def OntologyClass(topology, defaultValue=None, silent: bool = False):
        """
        Returns the ontology class assigned to the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        Ontology.Class
            The ontology class of the input topology
        """

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.OntologyClass - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        try:
            try:
                from topologicpy.Ontology import Ontology
            except Exception:
                from Ontology import Ontology
            return Ontology.Class(topology, defaultValue=defaultValue)
        except Exception:
            return defaultValue

    @staticmethod
    def OntologyURI(topology, defaultValue=None, silent: bool = False):
        """
        Returns the ontology URI assigned to the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        str
            The ontology URI of the input topology
        """
        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.OntologyURI- Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        try:
            try:
                from topologicpy.Ontology import Ontology
            except Exception:
                from Ontology import Ontology
            return Ontology._value(topology, Ontology.ONTOLOGY_URI_KEY, defaultValue)
        except Exception:
            return defaultValue

    @staticmethod
    def AddApertures(
        topology,
        apertures,
        exclusive: bool = False,
        subTopologyType: str = None,
        tolerance: float = 0.001,
        silent: bool = False
    ):
        """
        Adds the input list of apertures to the input topology or to its
        subtopologies based on the input subTopologyType.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        apertures : list
            The input list of apertures.
        exclusive : bool , optional
            If set to True, one (sub)topology will accept only one aperture.
            Otherwise, one (sub)topology can accept multiple apertures.
            Default is False.
        subTopologyType : str , optional
            The subtopology type to which to add the apertures. This can be
            "cell", "face", "edge", or "vertex". It is case insensitive. If
            set to None, the apertures will be added to the input topology.
            Default is None.
        tolerance : float , optional
            The desired tolerance. Default is 0.001.
        silent : bool , optional
            If True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with the apertures added to it.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Dictionary import Dictionary
        from topologicpy.BVH import BVH

        def best_candidate(aperture, candidates):
            try:
                ap_iv = Topology.InternalVertex(
                    aperture,
                    tolerance=tolerance
                )
            except Exception:
                ap_iv = None

            if not Topology.IsInstance(ap_iv, "Vertex"):
                try:
                    ap_iv = Topology.Centroid(aperture)
                except Exception:
                    ap_iv = None

            if not Topology.IsInstance(ap_iv, "Vertex"):
                return None

            for candidate in candidates:
                try:
                    if Vertex.IsInternal(
                        ap_iv,
                        candidate,
                        tolerance=tolerance
                    ):
                        return candidate
                except Exception:
                    continue

            return None

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print(
                    "Topology.AddApertures - Error: The input topology parameter "
                    "is not a valid topology. Returning None."
                )
            return None

        if not apertures:
            if not silent:
                print(
                    "Topology.AddApertures - Warning: The input apertures parameter "
                    "is empty. Returning the input topology."
                )
            return topology

        if not isinstance(apertures, list):
            if not silent:
                print(
                    "Topology.AddApertures - Error: The input apertures parameter "
                    "is not a list. Returning None."
                )
            return None

        apertures = [
            aperture
            for aperture in apertures
            if Topology.IsInstance(aperture, "Topology")
        ]

        if len(apertures) == 0:
            if not silent:
                print(
                    "Topology.AddApertures - Warning: The input apertures list "
                    "contains no valid topologies. Returning the input topology."
                )
            return topology

        if subTopologyType is None:
            subTopologyType = "self"

        if not isinstance(subTopologyType, str):
            if not silent:
                print(
                    "Topology.AddApertures - Error: The input subTopologyType "
                    "parameter is not a string. Returning None."
                )
            return None

        subTopologyType = subTopologyType.lower()

        if subTopologyType not in [
            "self",
            "cell",
            "face",
            "edge",
            "vertex",
        ]:
            if not silent:
                print(
                    "Topology.AddApertures - Error: The input subTopologyType "
                    "parameter is not a recognized type. Returning None."
                )
            return None

        cleaned_apertures = []

        for aperture in apertures:
            dictionary = Topology.Dictionary(aperture)
            dictionary = Dictionary.SetValueAtKey(
                dictionary,
                "type",
                "Aperture"
            )
            aperture = Topology.SetDictionary(
                aperture,
                dictionary
            )
            cleaned_apertures.append(aperture)

        apertures = cleaned_apertures

        if subTopologyType == "self":
            return Topology.AddContent(
                topology,
                apertures,
                subTopologyType="self",
                tolerance=tolerance,
                silent=silent
            )

        subTopologies = Topology.SubTopologies(
            topology,
            subTopologyType=subTopologyType
        ) or []

        if len(subTopologies) == 0:
            if not silent:
                print(
                    f"Topology.AddApertures - Warning: The input topology has no "
                    f"subtopologies of type '{subTopologyType}'. Returning the "
                    "input topology."
                )
            return topology

        try:
            bvh = BVH.ByTopologies(
                subTopologies,
                silent=True
            )
        except Exception:
            bvh = None

        used = []

        for aperture in apertures:
            if bvh is not None:
                try:
                    candidates = BVH.Clashes(
                        bvh,
                        aperture
                    )
                except Exception:
                    candidates = []
            else:
                candidates = list(subTopologies)

            if not isinstance(candidates, list) or len(candidates) == 0:
                continue

            if len(candidates) == 1:
                subTopology = candidates[0]
            else:
                subTopology = best_candidate(
                    aperture,
                    candidates
                )

            if not Topology.IsInstance(subTopology, "Topology"):
                continue

            if exclusive:
                already_used = False

                for used_topology in used:
                    try:
                        if Topology.IsSame(
                            subTopology,
                            used_topology,
                            silent=True
                        ):
                            already_used = True
                            break
                    except Exception:
                        continue

                if already_used:
                    continue

            result = Topology.AddContent(
                subTopology,
                [aperture],
                subTopologyType="self",
                tolerance=tolerance,
                silent=silent
            )

            if not Topology.IsInstance(result, "Topology"):
                continue

            if exclusive:
                used.append(result)

        return topology
    
    @staticmethod
    def AddContent(
        topology,
        contents=None,
        subTopologyType: str = None,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Adds the input contents to the input topology or to its subtopologies
        based on the input subTopologyType.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        contents : list or topologic_core.Topology
            The input content topology or list of content topologies.
        subTopologyType : str , optional
            The subtopology type to which to add the contents. This can be
            "cellcomplex", "cell", "shell", "face", "wire", "edge", or
            "vertex". It is case insensitive. If set to None, the contents are
            added to the input topology. Default is None.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with the contents added to it.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Context import Context

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print(
                    "Topology.AddContent - Error: The input topology parameter "
                    "is not a valid topology. Returning None."
                )
            return None

        if contents is None or contents == []:
            if not silent:
                print(
                    "Topology.AddContent - Warning: The input contents parameter "
                    "is empty. Returning the input topology unmodified."
                )
            return topology

        if not isinstance(contents, list):
            contents = [contents]

        contents = [
            content
            for content in contents
            if Topology.IsInstance(content, "Topology")
        ]

        if len(contents) == 0:
            if not silent:
                print(
                    "Topology.AddContent - Warning: The input contents parameter "
                    "contains no valid topologies. Returning the input topology "
                    "unmodified."
                )
            return topology

        if subTopologyType is None:
            subTopologyType = "self"

        if not isinstance(subTopologyType, str):
            if not silent:
                print(
                    "Topology.AddContent - Error: The input subTopologyType "
                    "parameter is not a string. Returning None."
                )
            return None

        subTopologyType = subTopologyType.lower()

        valid_types = [
            "self",
            "cellcomplex",
            "cell",
            "shell",
            "face",
            "wire",
            "edge",
            "vertex",
        ]

        if subTopologyType not in valid_types:
            if not silent:
                print(
                    "Topology.AddContent - Error: The input subTopologyType "
                    "parameter is not a recognized type. Returning None."
                )
            return None

        copy_contents = []

        for content in contents:
            try:
                copied_content = Topology.Copy(content)
            except Exception:
                copied_content = None

            if not Topology.IsInstance(copied_content, "Topology"):
                if not silent:
                    print(
                        "Topology.AddContent - Warning: Could not copy one input "
                        "content topology. Skipping it."
                    )
                continue

            dictionary = Topology.Dictionary(content)
            copied_content = Topology.SetDictionary(
                copied_content,
                dictionary
            )

            copy_contents.append(copied_content)

        if len(copy_contents) == 0:
            if not silent:
                print(
                    "Topology.AddContent - Warning: Could not copy any input "
                    "contents. Returning the input topology unmodified."
                )
            return topology

        if subTopologyType == "self":
            context = Context.ByTopologyParameters(topology)

            for content in copy_contents:
                if context is not None:
                    Core.InstanceCall(
                        content,
                        "AddContext",
                        context
                    )

                Core.InstanceCall(
                    topology,
                    "AddContent",
                    content
                )

            return topology

        if subTopologyType == "cellcomplex":
            subtopologies = Topology.CellComplexes(
                topology,
                silent=True
            ) or []
        elif subTopologyType == "cell":
            subtopologies = Topology.Cells(
                topology,
                silent=True
            ) or []
        elif subTopologyType == "shell":
            subtopologies = Topology.Shells(
                topology,
                silent=True
            ) or []
        elif subTopologyType == "face":
            subtopologies = Topology.Faces(
                topology,
                silent=True
            ) or []
        elif subTopologyType == "wire":
            subtopologies = Topology.Wires(
                topology,
                silent=True
            ) or []
        elif subTopologyType == "edge":
            subtopologies = Topology.Edges(
                topology,
                silent=True
            ) or []
        elif subTopologyType == "vertex":
            subtopologies = Topology.Vertices(
                topology,
                silent=True
            ) or []
        else:
            subtopologies = []

        if len(subtopologies) == 0:
            return topology

        for content in copy_contents:
            content_vertex = None

            try:
                content_vertex = Topology.InternalVertex(
                    content,
                    tolerance=tolerance
                )
            except Exception:
                content_vertex = None

            if not Topology.IsInstance(content_vertex, "Vertex"):
                try:
                    content_vertex = Topology.Centroid(content)
                except Exception:
                    content_vertex = None

            if not Topology.IsInstance(content_vertex, "Vertex"):
                continue

            for subtopology in subtopologies:
                try:
                    is_internal = Vertex.IsInternal(
                        content_vertex,
                        subtopology,
                        tolerance=tolerance
                    )
                except Exception:
                    is_internal = False

                if not is_internal:
                    continue

                try:
                    context = Context.ByTopologyParameters(
                        subtopology
                    )

                    if context is not None:
                        Core.InstanceCall(
                            content,
                            "AddContext",
                            context
                        )

                    Core.InstanceCall(
                        subtopology,
                        "AddContent",
                        content
                    )

                except Exception as error:
                    if not silent:
                        print(
                            "Topology.AddContent - Warning: Could not attach a "
                            f"content topology to the selected {subTopologyType}. "
                            f"Skipping it. ({error})"
                        )
                    continue

                break

        return topology
    
    @staticmethod
    def AddDictionary(topology, dictionary, silent: bool = True):
        """
        Adds the input dictionary to the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        dictionary : topologic_core.Dictionary
            The input dictionary.
        silent : bool , optional
            If True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with the input dictionary added to it.

        """
        from topologicpy.Dictionary import Dictionary

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.AddDictionary - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(dictionary, "Dictionary"):
            if not silent:
                print("Topology.AddDictionary - Error: the input dictionary parameter is not a dictionary. Returning None.")
            return None
        tDict = Topology.Dictionary(topology)
        if len(Dictionary.Keys(tDict)) < 1:
            # _ = topology.SetDictionary(dictionary) # H to Core
            _ = Core.InstanceCall(topology, 'SetDictionary', dictionary)
        else:
            newDict = Dictionary.ByMergedDictionaries([tDict, dictionary])
            if newDict:
                # _ = topology.SetDictionary(newDict) # H to Core
                _ = Core.InstanceCall(topology, 'SetDictionary', newDict)
        return topology
    
    @staticmethod
    def AdjacentTopologies(topology,
                           hostTopology,
                           topologyType: str = None,
                           silent: bool = False):
        """
        Returns the topologies, as specified by the input topology type, adjacent to the input topology within the input host topology.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph entity, TGraph vertex/edge index, or TGraph vertex/edge record
            The input topology or graph entity.
        hostTopology : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The host topology or graph in which to search.
        topologyType : str
            The type of topology for which to search. This can be one of "vertex", "edge", "wire", "face", "shell", "cell", "cellcomplex".
            It is case-insensitive. If it is set to None, the type will be inferred from the input topology where possible. Default is None.

        Returns
        -------
        adjacentTopologies : list
            The list of adjacent topologies or TGraph records.

        """

        from topologicpy.Graph import Graph

        try:
            from topologicpy.TGraph import TGraph
            is_tgraph_host = isinstance(hostTopology, TGraph)
        except Exception:
            TGraph = None
            is_tgraph_host = False

        # ------------------------------------------------------------------
        # TGraph path
        # ------------------------------------------------------------------

        if is_tgraph_host:
            def _is_valid_vertex_index(index):
                try:
                    return isinstance(index, int) and hostTopology._validate_vertex_index(index)
                except Exception:
                    return False

            def _is_valid_edge_index(index):
                try:
                    return isinstance(index, int) and hostTopology._validate_edge_index(index)
                except Exception:
                    return False

            def _record_index(item):
                if isinstance(item, int):
                    return item
                if isinstance(item, dict):
                    idx = item.get("index", None)
                    return idx if isinstance(idx, int) else None
                return None

            def _resolve_vertex_index(item):
                idx = _record_index(item)
                if _is_valid_vertex_index(idx):
                    return idx

                try:
                    for rec in hostTopology._vertices:
                        if not rec.get("active", True):
                            continue
                        rep = rec.get("representation", None)
                        if rep is item:
                            return rec.get("index")
                except Exception:
                    pass

                try:
                    from topologicpy.Topology import Topology
                    for rec in hostTopology._vertices:
                        if not rec.get("active", True):
                            continue
                        rep = rec.get("representation", None)
                        if rep is not None and Topology.IsSame(rep, item):
                            return rec.get("index")
                except Exception:
                    pass

                return None

            def _resolve_edge_index(item):
                idx = _record_index(item)
                if _is_valid_edge_index(idx):
                    return idx

                try:
                    for rec in hostTopology._edges:
                        if not rec.get("active", True):
                            continue
                        rep = rec.get("representation", None)
                        if rep is item:
                            return rec.get("index")
                except Exception:
                    pass

                try:
                    from topologicpy.Topology import Topology
                    for rec in hostTopology._edges:
                        if not rec.get("active", True):
                            continue
                        rep = rec.get("representation", None)
                        if rep is not None and Topology.IsSame(rep, item):
                            return rec.get("index")
                except Exception:
                    pass

                return None

            def _infer_input_type(item):
                if isinstance(item, dict):
                    if "src" in item and "dst" in item:
                        return "edge"
                    return "vertex"

                if isinstance(item, int):
                    if _is_valid_vertex_index(item):
                        return "vertex"
                    if _is_valid_edge_index(item):
                        return "edge"

                try:
                    if Topology.IsInstance(item, "Vertex"):
                        return "vertex"
                    if Topology.IsInstance(item, "Edge"):
                        return "edge"
                except Exception:
                    pass

                if _resolve_vertex_index(item) is not None:
                    return "vertex"
                if _resolve_edge_index(item) is not None:
                    return "edge"

                return None

            if not topologyType:
                topologyType = _infer_input_type(topology)

            if not isinstance(topologyType, str):
                if not silent:
                    print("Topology.AdjacentTopologies - Error: the input topologyType parameter is not a string. Returning None.")
                return None

            topologyType = topologyType.lower()

            if topologyType not in ["vertex", "edge", "wire", "face", "shell", "cell", "cellcomplex"]:
                if not silent:
                    print("Topology.AdjacentTopologies - Error: the input topologyType parameter is not a recognized type. Returning None.")
                return None

            input_type = _infer_input_type(topology)

            if input_type == "vertex":
                vertex_index = _resolve_vertex_index(topology)
                if vertex_index is None:
                    if not silent:
                        print("Topology.AdjacentTopologies - Error: Could not resolve the input topology as a TGraph vertex. Returning None.")
                    return None

                if topologyType == "vertex":
                    return TGraph.AdjacentVertices(hostTopology, vertex_index, mode="all")

                if topologyType == "edge":
                    return TGraph.IncidentEdges(hostTopology, vertex_index, mode="all")

                return []

            if input_type == "edge":
                edge_index = _resolve_edge_index(topology)
                if edge_index is None:
                    if not silent:
                        print("Topology.AdjacentTopologies - Error: Could not resolve the input topology as a TGraph edge. Returning None.")
                    return None

                if topologyType == "edge":
                    return TGraph.AdjacentEdges(hostTopology, edge_index)

                if topologyType == "vertex":
                    edge_record = TGraph.Edge(hostTopology, edge_index)
                    if not isinstance(edge_record, dict):
                        return []
                    src = edge_record.get("src", None)
                    dst = edge_record.get("dst", None)
                    result = []
                    if _is_valid_vertex_index(src):
                        result.append(TGraph.Vertex(hostTopology, src))
                    if _is_valid_vertex_index(dst) and dst != src:
                        result.append(TGraph.Vertex(hostTopology, dst))
                    return result

                return []
            if not silent:
                print("Topology.AdjacentTopologies - Error: Could not resolve the input topology as a TGraph vertex or edge. Returning None.")
            return None

        # ------------------------------------------------------------------
        # Legacy Topology / Graph path
        # ------------------------------------------------------------------

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.AdjacentTopologies - Error: the input topology parameter is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(hostTopology, "Topology") and not Topology.IsInstance(hostTopology, "Graph"):
            if not silent:
                print("Topology.AdjacentTopologies - Error: the input hostTopology parameter is not a valid topology or graph. Returning None.")
            return None

        if not topologyType:
            topologyType = Topology.TypeAsString(topology).lower()

        if not isinstance(topologyType, str):
            if not silent:
                print("Topology.AdjacentTopologies - Error: the input topologyType parameter is not a string. Returning None.")
            return None

        if not topologyType.lower() in ["vertex", "edge", "wire", "face", "shell", "cell", "cellcomplex"]:
            if not silent:
                print("Topology.AdjacentTopologies - Error: the input topologyType parameter is not a recognized type. Returning None.")
            return None

        adjacentTopologies = []
        error = False

        if Topology.IsInstance(topology, "Vertex"):
            if topologyType.lower() == "vertex":
                if Topology.IsInstance(hostTopology, "graph"):
                    adjacentTopologies = Graph.AdjacentVertices(hostTopology, topology)
                else:
                    try:
                        _ = Core.InstanceCall(topology, "AdjacentVertices", hostTopology, adjacentTopologies)
                    except:
                        try:
                            _ = Core.InstanceCall(topology, "Vertices", hostTopology, adjacentTopologies)
                        except:
                            error = True

            elif topologyType.lower() == "edge":
                if Topology.IsInstance(hostTopology, "graph"):
                    adjacentTopologies = Graph.Edges(hostTopology, [topology])
                else:
                    try:
                        _ = Core.VertexUtility.AdjacentEdges(topology, hostTopology, adjacentTopologies)
                    except:
                        try:
                            _ = Core.InstanceCall(topology, "Edges", hostTopology, adjacentTopologies)
                        except:
                            error = True

            elif topologyType.lower() == "wire":
                try:
                    _ = Core.VertexUtility.AdjacentWires(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Wires", hostTopology, adjacentTopologies)
                    except:
                        error = True

            elif topologyType.lower() == "face":
                try:
                    _ = Core.VertexUtility.AdjacentFaces(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Faces", hostTopology, adjacentTopologies)
                    except:
                        error = True

            elif topologyType.lower() == "shell":
                try:
                    _ = Core.VertexUtility.AdjacentShells(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Shells", hostTopology, adjacentTopologies)
                    except:
                        error = True

            elif topologyType.lower() == "cell":
                try:
                    _ = Core.VertexUtility.AdjacentCells(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Cells", hostTopology, adjacentTopologies)
                    except:
                        error = True

            elif topologyType.lower() == "cellcomplex":
                try:
                    _ = Core.VertexUtility.AdjacentCellComplexes(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "CellComplexes", hostTopology, adjacentTopologies)
                    except:
                        error = True

        elif Topology.IsInstance(topology, "Edge"):
            if topologyType.lower() == "vertex":
                try:
                    _ = Core.InstanceCall(topology, "Vertices", hostTopology, adjacentTopologies)
                except:
                    error = True

            elif topologyType.lower() == "edge":
                if Topology.IsInstance(hostTopology, "graph"):
                    adjacentTopologies = Graph.AdjacentEdges(hostTopology, topology)
                else:
                    try:
                        _ = Core.InstanceCall(topology, "AdjacentEdges", hostTopology, adjacentTopologies)
                    except:
                        error = True

            elif topologyType.lower() == "wire":
                try:
                    _ = Core.EdgeUtility.AdjacentWires(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Wires", hostTopology, adjacentTopologies)
                    except:
                        error = True

            elif topologyType.lower() == "face":
                try:
                    _ = Core.EdgeUtility.AdjacentFaces(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Faces", hostTopology, adjacentTopologies)
                    except:
                        error = True

            elif topologyType.lower() == "shell":
                try:
                    _ = Core.EdgeUtility.AdjacentShells(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Shells", hostTopology, adjacentTopologies)
                    except:
                        error = True

            elif topologyType.lower() == "cell":
                try:
                    _ = Core.EdgeUtility.AdjacentCells(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Cells", hostTopology, adjacentTopologies)
                    except:
                        error = True

            elif topologyType.lower() == "cellcomplex":
                try:
                    _ = Core.EdgeUtility.AdjacentCellComplexes(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "CellComplexes", hostTopology, adjacentTopologies)
                    except:
                        error = True

        elif Topology.IsInstance(topology, "Wire"):
            if topologyType.lower() == "vertex":
                try:
                    _ = Core.WireUtility.AdjacentVertices(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Vertices", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "edge":
                try:
                    _ = Core.WireUtility.AdjacentEdges(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Edges", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "wire":
                edges = Topology.Edges(topology, silent=True)
                if not isinstance(edges, list):
                    error = True
                else:
                    for edge in edges:
                        candidates = Topology.SuperTopologies(
                            edge,
                            hostTopology=hostTopology,
                            topologyType="wire",
                            silent=True,
                        )
                        if not isinstance(candidates, list):
                            continue

                        for candidate in candidates:
                            # Exclude the input wire itself.
                            if Topology.IsSame(candidate, topology, silent=True):
                                continue

                            # Avoid duplicates.
                            if any(
                                Topology.IsSame(candidate, existing, silent=True)
                                for existing in adjacentTopologies
                            ):
                                continue

                            adjacentTopologies.append(candidate)
            elif topologyType.lower() == "face":
                try:
                    _ = Core.WireUtility.AdjacentFaces(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Faces", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "shell":
                try:
                    _ = Core.WireUtility.AdjacentShells(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Shells", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "cell":
                try:
                    _ = Core.WireUtility.AdjacentCells(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Cells", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "cellcomplex":
                try:
                    _ = Core.WireUtility.AdjacentCellComplexes(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "CellComplexes", hostTopology, adjacentTopologies)
                    except:
                        error = True

        elif Topology.IsInstance(topology, "Face"):
            if topologyType.lower() == "vertex":
                try:
                    _ = Core.FaceUtility.AdjacentVertices(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Vertices", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "edge":
                try:
                    _ = Core.FaceUtility.AdjacentEdges(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Edges", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "wire":
                try:
                    _ = Core.FaceUtility.AdjacentWires(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Wires", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "face":
                _ = Core.InstanceCall(topology, "AdjacentFaces", hostTopology, adjacentTopologies)
            elif topologyType.lower() == "shell":
                try:
                    _ = Core.FaceUtility.AdjacentShells(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Shells", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "cell":
                try:
                    _ = Core.FaceUtility.AdjacentCells(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Cells", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "cellcomplex":
                try:
                    _ = Core.FaceUtility.AdjacentCellComplexes(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "CellComplexes", hostTopology, adjacentTopologies)
                    except:
                        error = True

        elif Topology.IsInstance(topology, "Shell"):
            if topologyType.lower() == "vertex":
                try:
                    _ = Core.ShellUtility.AdjacentVertices(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Vertices", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "edge":
                try:
                    _ = Core.ShellUtility.AdjacentEdges(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Edges", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "wire":
                try:
                    _ = Core.ShellUtility.AdjacentWires(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Wires", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "face":
                try:
                    _ = Core.ShellUtility.AdjacentFaces(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Faces", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "shell":
                try:
                    _ = Core.ShellUtility.AdjacentShells(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Shells", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "cell":
                try:
                    _ = Core.ShellUtility.AdjacentCells(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Cells", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "cellcomplex":
                try:
                    _ = Core.ShellUtility.AdjacentCellComplexes(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "CellComplexes", hostTopology, adjacentTopologies)
                    except:
                        error = True

        elif Topology.IsInstance(topology, "Cell"):
            if topologyType.lower() == "vertex":
                try:
                    _ = Core.CellUtility.AdjacentVertices(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Vertices", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "edge":
                try:
                    _ = Core.CellUtility.AdjacentEdges(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Edges", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "wire":
                try:
                    _ = Core.CellUtility.AdjacentWires(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Wires", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "face":
                try:
                    _ = Core.CellUtility.AdjacentFaces(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Faces", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "shell":
                try:
                    _ = Core.CellUtility.AdjacentShells(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Shells", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "cell":
                try:
                    _ = Core.InstanceCall(topology, "AdjacentCells", hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "Cells", hostTopology, adjacentTopologies)
                    except:
                        error = True
            elif topologyType.lower() == "cellcomplex":
                try:
                    _ = Core.CellUtility.AdjacentCellComplexes(topology, hostTopology, adjacentTopologies)
                except:
                    try:
                        _ = Core.InstanceCall(topology, "CellComplexes", hostTopology, adjacentTopologies)
                    except:
                        error = True

        elif Topology.IsInstance(topology, "CellComplex"):
            if topologyType.lower() == "vertex":
                try:
                    _ = Core.InstanceCall(topology, "Vertices", hostTopology, adjacentTopologies)
                except:
                    error = True
            elif topologyType.lower() == "edge":
                try:
                    _ = Core.InstanceCall(topology, "Edges", hostTopology, adjacentTopologies)
                except:
                    error = True
            elif topologyType.lower() == "wire":
                try:
                    _ = Core.InstanceCall(topology, "Wires", hostTopology, adjacentTopologies)
                except:
                    error = True
            elif topologyType.lower() == "face":
                try:
                    _ = Core.InstanceCall(topology, "Faces", hostTopology, adjacentTopologies)
                except:
                    error = True
            elif topologyType.lower() == "shell":
                try:
                    _ = Core.InstanceCall(topology, "Shells", hostTopology, adjacentTopologies)
                except:
                    error = True
            elif topologyType.lower() == "cell":
                try:
                    _ = Core.InstanceCall(topology, "Cells", hostTopology, adjacentTopologies)
                except:
                    error = True
            elif topologyType.lower() == "cellcomplex":
                if not silent:
                    print("Topology.AdjacentTopologies - Error: Cannot search for adjacent topologies of a CellComplex. Returning None.")
                return None

        elif Topology.IsInstance(topology, "Cluster"):
            if not silent:
                print("Topology.AdjacentTopologies - Error: Cannot search for adjacent topologies of a Cluster. Returning None.")
            return None

        if error:
            if not silent:
                print(f"Topology.AdjacentTopologies - Error: Failure in search for adjacent topologies of type {topologyType}. Returning None.")
            return None

        return adjacentTopologies

    @staticmethod
    def Analyze(topology, silent: bool = False):
        """
        Returns an analysis string that describes the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.

        Returns
        -------
        str
            The analysis string.

        """
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Analyze - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        return Core.Topology.Analyze(topology)
    
    @staticmethod
    def Apertures(topology, subTopologyType=None, silent: bool = False):
        """
        Returns the apertures of the input topology.
        
        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        subTopologyType : string , optional
            The subtopology type from which to retrieve the apertures. This can be "cell", "face", "edge", or "vertex" or "all". It is case insensitive. If set to "all", then all apertures will be returned. If set to None, the apertures will be retrieved only from the input topology. Default is None.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The list of apertures belonging to the input topology.

        """

        from topologicpy.Dictionary import Dictionary
        from topologicpy.Aperture import Aperture
        import inspect

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Apertures - Error: the input topology parameter is not a valid topology. Returning None.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return None
        
        apertures = []
        subTopologies = []
        if not subTopologyType:
            # _ = topology.Apertures(apertures) # H to Core
            _ = Core.InstanceCall(topology, 'Apertures', apertures)
            apertures = [Aperture.Topology(x) for x in apertures]
            contents = Topology.Contents(topology)
            for content in contents:
                d = Topology.Dictionary(content)
                if len(Dictionary.Keys(d)) > 0:
                    type = Dictionary.ValueAtKey(d,"type", "unknown")
                    if "aperture" in type.lower():
                        apertures.append(content)
        elif subTopologyType.lower() == "vertex":
            subTopologies = Topology.Vertices(topology, silent=True)
        elif subTopologyType.lower() == "edge":
            subTopologies = Topology.Edges(topology, silent=True)
        elif subTopologyType.lower() == "face":
            subTopologies = Topology.Faces(topology, silent=True)
        elif subTopologyType.lower() == "cell":
            subTopologies = Topology.Cells(topology, silent=True)
        elif subTopologyType.lower() == "all":
            # _ = topology.Apertures(apertures) # H to Core
            _ = Core.InstanceCall(topology, 'Apertures', apertures)
            apertures = [Aperture.Topology(x) for x in apertures]
            subTopologies = Topology.Vertices(topology, silent=True)
            subTopologies += Topology.Edges(topology, silent=True)
            subTopologies += Topology.Faces(topology, silent=True)
            subTopologies += Topology.Cells(topology, silent=True)
        else:
            if not silent:
                print("Topology.Apertures - Error: the input subtopologyType parameter is not a recognized type. Returning None.")
            return None
        for subTopology in subTopologies:
            apertures += Topology.Apertures(subTopology, subTopologyType=None, silent=silent)
        return apertures

    @staticmethod
    def ApertureTopologies(topology, subTopologyType: str = None, silent: bool = False):
        """
        Returns the aperture topologies of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        subTopologyType : string , optional
            The subtopology type from which to retrieve the apertures. This can be "cell", "face", "edge", or "vertex" or "all". It is case insensitive. If set to "all", then all apertures will be returned. If set to None, the apertures will be retrieved only from the input topology. Default is None.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The list of aperture topologies found in the input topology.

        """
        from topologicpy.Aperture import Aperture
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.ApertureTopologies - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        apertures = Topology.Apertures(topology=topology, subTopologyType=subTopologyType)
        apTopologies = []
        for aperture in apertures:
            apTopologies.append(Aperture.Topology(aperture))
        return apTopologies

    @staticmethod
    def BinByDictionaryKey(
        topologies: Iterable[Any],
        key: str,
        missing_label: str = "__MISSING__",
        return_counts: bool = False,
        silent: bool = False
    ) -> Tuple[Dict[Any, List[Any]], Dict[Any, int]]:
        """
        Bins a list of Topologic topologies into groups based on identical key/value
        pairs found in each topology's Dictionary. Topologies that do not have the key
        are binned together under `missing_label`.

        Parameters
        ----------
        topologies : Iterable[topologic_core.Topology]
            The input topologies to bin.
        key : str
            The dictionary key to group by.
        missing_label : str , optional
            Identifier used for the group of topologies that lack `key`.
            Default is "__MISSING__".
        return_counts : bool , optional
            If True, returns a second dictionary of group -> count.
            Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        groups : dict
            A mapping from group identifier to list of topologies.
            - For present keys, the identifier is the *original value* if it is hashable
            (str/int/float/bool) or a stable, hashable structural surrogate for complex
            types (lists/dicts) that preserves equality semantics.
            - For missing keys, the identifier is `missing_label`.
        counts : dict
            A mapping from group identifier to group size. Returned only if
            `return_counts=True`; otherwise an empty dict.

        Notes
        -----
        - This function avoids unnecessary method lookups and branches for speed.
        - Values that are lists/dicts are converted to stable, hashable surrogates so that
        "identical" (by structure/content) values end up in the same bin.
        - If you need the original (potentially unhashable) values back for complex keys,
        you can inspect any representative item's dictionary value in that group.

        Examples
        --------
        >>> groups, counts = BinByDictionaryKey(topologies, key="material", return_counts=True)
        >>> metal_group = groups.get("steel", [])
        >>> missing = groups.get("__MISSING__", [])
        """

        from topologicpy.Topology import Topology
        from topologicpy.Dictionary import Dictionary
        
        def _hashable_key(value: Any) -> Any:
            """
            Internal: convert arbitrary dictionary values to hashable keys for binning.
            Tries to preserve the original structure where possible.
            """
            if value is None:
                return ("__NONE__",)
            if isinstance(value, (str, int, float, bool)):
                return value
            if isinstance(value, (tuple, list)):
                return ("__SEQ__", tuple(_hashable_key(v) for v in value))
            if isinstance(value, dict):
                # Sort keys for stability
                return ("__MAP__", tuple(sorted((k, _hashable_key(v)) for k, v in value.items())))
            # Fallback to string representation (rare for custom objects)
            return ("__REPR__", repr(value))

        groups: Dict[Any, List[Any]] = defaultdict(list)
        counts: Dict[Any, int] = {}

        # Local bindings for speed
        _Dict = Dictionary
        _Topo = Topology
        _hk = _hashable_key
        _missing = missing_label

        topologies = [t for t in topologies if Topology.IsInstance(t, "topology")]
        if len(topologies) == 0:
            if not silent:
                print("Topology.BinByDictionary - Error: The input topologies list parameter does not contain any valid topologies. Returning None.")
            return None

        for t in topologies:
            d = _Topo.Dictionary(t)
            if not d:
                gid = _missing
            else:
                # Prefer checking key presence to distinguish "missing" from "present but None"
                try:
                    # Dictionary.Keys(d) expected to return an iterable of keys
                    keys = _Dict.Keys(d)
                    has_key = key in keys
                except Exception:
                    # If Keys not available or fails, fall back to retrieving the value
                    has_key = False

                if has_key:
                    v = _Dict.ValueAtKey(d, key)
                    # Preserve simple hashable types as-is; make complex ones hashable
                    if isinstance(v, (str, int, float, bool)) or v is None:
                        gid = v if v is not None else _hk(v)
                    else:
                        gid = _hk(v)
                else:
                    gid = _missing

            groups[gid].append(t)

        if return_counts:
            for gid, lst in groups.items():
                counts[gid] = len(lst)
            return dict(groups), counts

        return dict(groups), {}
    


    @staticmethod
    def Decompose(topology, tiltAngle: float = 10.0, tolerance: float = 0.0001, silent: bool = False) -> dict:
        """
        Decomposes the input topology into its logical components. This method assume:
        1. The input topology is either a cell, a CellComplex, or a Cluster containing at least one or more faces.
        2. That the positive Z direction is UP [0,0,1].

        Parameters
        ----------
        topology : topologic_core.Topology
            the input topology (cell, cellComplex, or Cluster with at least faces).
        tiltAngle : float , optional
            The threshold tilt angle in degrees to determine if a face is vertical, horizontal, or tilted. The tilt angle is measured from the nearest cardinal direction. Default is 10.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        dictionary
            A dictionary with the following keys and values:
            1. "cells": list of cells
            2. "externalVerticalFaces": list of external vertical faces
            3. "internalVerticalFaces": list of internal vertical faces
            4. "topHorizontalFaces": list of top horizontal faces
            5. "bottomHorizontalFaces": list of bottom horizontal faces
            6. "internalHorizontalFaces": list of internal horizontal faces
            7. "externalInclinedFaces": list of external inclined faces
            8. "internalInclinedFaces": list of internal inclined faces
            9. "externalVerticalApertures": list of apertures that belong to external vertical faces
            10. "internalVerticalApertures": list of apertures that belong to internal vertical faces
            11. "topHorizontalApertures": list of apertures that belong to top horizontal faces
            12. "bottomHorizontalApertures": list of apertures that belong to bottom horizontal faces
            13. "internalHorizontalApertures": list of aperttures that belong to internal horizontal faces
            14. "externalInclinedApertures": list of apertures that belong to external inclined faces
            15. "internalInclinedApertures": list of apertures that belong to internal inclined faces
            16. "freeVerticalFaces" : list of free vertical faces
            17. "freeHorizontalFaces" : list of free horizontal faces
            18. "freeInclinedFaces" : list of free inclined faces,
            19. "freeVerticalApertures" : list of apertures that belong to free vertical faces,
            20. "freeHorizontalApertures" : list of apertures that belong to free horiztontal faces
            21. "freeInclinedApertures" : list of apertures that belong to free inclined faces

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Vector import Vector
        from topologicpy.Topology import Topology

        def angleCode(f, up, tiltAngle):
            # 0 = Vertical
            # 1 = Horizontal bottom facing
            # 2 = Horizontal top facing
            # 3 = Inclined
            dirA = Face.Normal(f)
            ang = round(Vector.Angle(dirA, up), 2)
            if abs(ang - 90) < tiltAngle:
                code = 0
            elif abs(ang) < tiltAngle:
                code = 1
            elif abs(ang - 180) < tiltAngle:
                code = 2
            else:
                code = 3
            return code

        def getApertures(topology):
            return Topology.Apertures(topology)
        
        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.Decompose - Error: The input topology parameter is not a valid topology. Returning None.")
            return None

        if Topology.Type(topology) < 32:
            if not silent:
                print("Topology.Decompose - Error: The input topology parameter is not a valid topologic cell, cellcomplex, or cluster. Returning None.")
            return None
        
        faces = Topology.Faces(topology, silent=True)
        if len(faces) < 1:
            if not silent:
                print("Topology.Decompose - Error: The input topology parameter does not contain any valid topologic faces. Returning None.")
            return None

        externalVerticalFaces = []
        internalVerticalFaces = []
        topHorizontalFaces = []
        bottomHorizontalFaces = []
        internalHorizontalFaces = []
        externalInclinedFaces = []
        internalInclinedFaces = []
        externalVerticalApertures = []
        internalVerticalApertures = []
        topHorizontalApertures = []
        bottomHorizontalApertures = []
        internalHorizontalApertures = []
        externalInclinedApertures = []
        internalInclinedApertures = []

        freeVerticalFaces = []
        freeHorizontalFaces = []
        freeInclinedFaces = []

        freeVerticalApertures = []
        freeHorizontalApertures = []
        freeInclinedApertures = []

        tiltAngle = abs(tiltAngle)
        zList = []
        for f in faces:
            zList.append(Vertex.Z(Topology.Centroid(f)))
        zMin = min(zList)
        zMax = max(zList)
        up = [0, 0, 1]
        for aFace in faces:
            aCode = angleCode(aFace, up, tiltAngle)
            cells = Topology.SuperTopologies(aFace, hostTopology=topology, topologyType="cell")

            n = len(cells)
            if aCode == 0:
                if n == 0:
                    freeVerticalFaces.append(aFace)
                    freeVerticalApertures += getApertures(aFace)
                elif n == 1:
                    externalVerticalFaces.append(aFace)
                    externalVerticalApertures += getApertures(aFace)
                else:
                    internalVerticalFaces.append(aFace)
                    internalVerticalApertures += getApertures(aFace)
            elif aCode == 1:
                if n == 0:
                    freeHorizontalFaces.append(aFace)
                    freeHorizontalApertures += getApertures(aFace)
                elif n == 1:
                    if abs(Vertex.Z(Topology.Centroid(aFace)) - zMin) <= tolerance:
                        bottomHorizontalFaces.append(aFace)
                        bottomHorizontalApertures += getApertures(aFace)
                    else:
                        topHorizontalFaces.append(aFace)
                        topHorizontalApertures += getApertures(aFace)
                else:
                    internalHorizontalFaces.append(aFace)
                    internalHorizontalApertures += getApertures(aFace)
            elif aCode == 2:
                if n == 0:
                    freeHorizontalFaces.append(aFace)
                    freeHorizontalApertures += getApertures(aFace)
                elif n == 1:
                    if abs(Vertex.Z(Topology.Centroid(aFace)) - zMax) <= tolerance:
                        topHorizontalFaces.append(aFace)
                        topHorizontalApertures += getApertures(aFace)
                    else:
                        bottomHorizontalFaces.append(aFace)
                        bottomHorizontalApertures += getApertures(aFace)
                else:
                    internalHorizontalFaces.append(aFace)
                    internalHorizontalApertures += getApertures(aFace)
            elif aCode == 3:
                if n == 0:
                    freeInclinedFaces.append(aFace)
                    freeInclinedApertures += getApertures(aFace)
                elif n == 1:
                    externalInclinedFaces.append(aFace)
                    externalInclinedApertures += getApertures(aFace)
                else:
                    internalInclinedFaces.append(aFace)
                    internalInclinedApertures += getApertures(aFace)
        
        verticalFaces = externalVerticalFaces+internalVerticalFaces+freeVerticalFaces
        horizontalFaces = bottomHorizontalFaces+topHorizontalFaces+internalHorizontalFaces+freeHorizontalFaces
        inclinedFaces = externalInclinedFaces+internalInclinedFaces+freeInclinedFaces

        cells = Topology.Cells(topology, silent=True)
        d = {
            "cells" : cells,
            "externalVerticalFaces" : externalVerticalFaces,
            "internalVerticalFaces" : internalVerticalFaces,
            "topHorizontalFaces" : topHorizontalFaces,
            "bottomHorizontalFaces" : bottomHorizontalFaces,
            "internalHorizontalFaces" : internalHorizontalFaces,
            "externalInclinedFaces" : externalInclinedFaces,
            "internalInclinedFaces" : internalInclinedFaces,
            "externalVerticalApertures" : externalVerticalApertures,
            "internalVerticalApertures" : internalVerticalApertures,
            "topHorizontalApertures" : topHorizontalApertures,
            "bottomHorizontalApertures" : bottomHorizontalApertures,
            "internalHorizontalApertures" : internalHorizontalApertures,
            "externalInclinedApertures" : externalInclinedApertures,
            "internalInclinedApertures" : internalInclinedApertures,
            "freeVerticalFaces" : freeVerticalFaces,
            "freeHorizontalFaces" : freeHorizontalFaces,
            "freeInclinedFaces" : freeInclinedFaces,
            "freeVerticalApertures" : freeVerticalApertures,
            "freeHorizontalApertures" : freeHorizontalApertures,
            "freeInclinedApertures" : freeInclinedApertures,
            "verticalFaces" : verticalFaces,
            "horizontalFaces" : horizontalFaces,
            "inclinedFaces" : inclinedFaces
            }
        return d



    @staticmethod
    def Difference(topologyA, topologyB, tranDict: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Subtracts topologyB from topologyA. See https://en.wikipedia.org/wiki/Boolean_operation.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tranDict : bool , optional
            If set to True the dictionaries of the operands are merged and transferred to the result. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            the resultant topology.

        """
        if not Topology.IsInstance(topologyA, "topology"):
            if not silent:
                print("Topology.Difference - Error: The input topologyA parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(topologyB, "topology"):
            if not silent:
                print("Topology.Difference - Error: The input topologyB parameter is not a valid topology. Returning None.")
            return None
        return Topology._Boolean(topologyA=topologyA, topologyB=topologyB, operation="difference", tranDict=tranDict, tolerance=tolerance, silent=silent)
    
    @staticmethod
    def ExternalBoundary(topology, silent: bool = False):
        """
        Returns the external boundary of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The external boundary of the input topology.

        """
        from topologicpy.Topology import Topology
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Cluster import Cluster

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.ExternalBoundary - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        
        if Topology.IsInstance(topology, "Vertex"):
            return Vertex.ExternalBoundary(topology, silent=silent)
        elif Topology.IsInstance(topology, "Edge"):
            return Edge.ExternalBoundary(topology, silent=silent)
        elif Topology.IsInstance(topology, "Wire"):
            return Wire.ExternalBoundary(topology, silent=silent)
        elif Topology.IsInstance(topology, "Face"):
            return Face.ExternalBoundary(topology, silent=silent)
        elif Topology.IsInstance(topology, "Shell"):
            return Shell.ExternalBoundary(topology, silent=silent)
        elif Topology.IsInstance(topology, "Cell"):
            return Cell.ExternalBoundary(topology, silent=silent)
        elif Topology.IsInstance(topology, "CellComplex"):
            return CellComplex.ExternalBoundary(topology, silent=silent)
        elif Topology.IsInstance(topology, "Cluster"):
            return Cluster.ExternalBoundary(topology, silent=silent)
        else:
            return None


    @staticmethod
    def Inherit(targets, sources, keys: list = None, exclusive: bool = True, tolerance: float = 0.0001, silent: bool = False):
        """
        Transfers dictionary information from topologiesB to topologiesA based on co-location of internal vertices.

        Parameters
        ----------
        targets : list of topologic_core.Topology
            The list of target topologies that will inherit the dictionaries.
        sources : list of topologic_core. Topology
            The list of source topologies from which to inherit dictionary information.
        exclusive : bool , optional
            If set to True, a target will inherit information only from the first eligible source. Default is True.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The list of target topologies with the dictionary information inherited from the list of source topologies.

        """
        from topologicpy.Topology import Topology
        from topologicpy.Vertex import Vertex
        from topologicpy.Dictionary import Dictionary

        topologies_a = [a for a in targets if Topology.IsInstance(a, "Topology")]
        if len(topologies_a) == 0:
            if not silent:
                print("Topology.Inherit - Error: The list of targets does not contain any valid topologies. Returning None.")
            return None
        topologies_b = [b for b in sources if Topology.IsInstance(b, "Topology")]
        if len(topologies_b) == 0:
            if not silent:
                print("Topology.Inherit - Error: The list of sources does not contain any valid topologies. Returning None.")
            return None
        for i, top_a in enumerate(topologies_a):
            iv = Topology.InternalVertex(top_a, tolerance=tolerance, silent=silent)
            d_a = Topology.Dictionary(top_a, silent=silent)
            found = False
            for j, top_b in enumerate(topologies_b):
                if Vertex.IsInternal(iv, top_b, tolerance=tolerance, silent=silent):
                    d_b = Topology.Dictionary(top_b)
                    if isinstance(keys, list):
                        values = Dictionary.ValuesAtKeys(d_b, keys, silent=silent)
                        d_c = Dictionary.ByKeysValues(keys, values)
                        d_a = Dictionary.ByMergedDictionaries(d_a, d_c, silent=silent)
                    else:
                        d_a = Dictionary.ByMergedDictionaries(d_a, d_b, silent=silent)
                    top_a = Topology.SetDictionary(top_a, d_a, silent=silent)
                    found = True
                    if exclusive:
                        break
            if found == False:
                if not silent:
                    print("Topology.Inherit - Warning: Could not find a source for target number: "+str(i+1)+". Consider increasing the tolerance value.")
        return targets

    @staticmethod
    def Intersect(
        topologyA,
        topologyB,
        tranDict: bool = False,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Finds the intersection between the input operand topologies.
        See https://en.wikipedia.org/wiki/Boolean_operation.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tranDict : bool , optional
            If set to True the dictionaries of the operands are merged and
            transferred to the result. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Topology
            The resultant topology.
        """
        from topologicpy.Cluster import Cluster

        if not Topology.IsInstance(
            topologyA,
            "topology"
        ):
            if not silent:
                print(
                    "Topology.Intersect - Error: The topologyA input parameter "
                    "is not a valid Topology. Returning None."
                )
            return None

        if not Topology.IsInstance(
            topologyB,
            "topology"
        ):
            if not silent:
                print(
                    "Topology.Intersect - Error: The topologyB input parameter "
                    "is not a valid Topology. Returning None."
                )
            return None

        # --------------------------------------------------------------
        # Normal backend path
        #
        # Trust the backend result. Legacy repair logic below is required
        # only for TopologicCore.
        # --------------------------------------------------------------

        if not Topology._IsTopologicCoreBackend():
            return Core.InstanceCall(
                topologyA,
                "Intersect",
                topologyB,
                tranDict
            )

        # --------------------------------------------------------------
        # Legacy TopologicCore workaround
        # --------------------------------------------------------------

        # Sort the two topologies by their type from lower to higher so
        # comparison can be eased.
        if Topology.Type(topologyB) < Topology.Type(topologyA):
            temp = topologyA
            topologyA = topologyB
            topologyB = temp

        results = []

        if Topology.IsInstance(
            topologyA,
            "CellComplex"
        ):
            cellsA = Topology.Cells(
                topologyA
            )

        if Topology.IsInstance(
            topologyA,
            "Wire"
        ):
            cellsA = Topology.Edges(
                topologyA
            )

        elif Topology.IsInstance(
            topologyA,
            "Cluster"
        ):
            cellsA = Cluster.FreeTopologies(
                topologyA
            )

        else:
            cellsA = [
                topologyA
            ]

        if Topology.IsInstance(
            topologyB,
            "CellComplex"
        ):
            cellsB = Topology.Cells(
                topologyB
            )

        elif Topology.IsInstance(
            topologyB,
            "Wire"
        ):
            cellsB = Topology.Edges(
                topologyB
            )

        elif Topology.IsInstance(
            topologyB,
            "Cluster"
        ):
            cellsB = Cluster.FreeTopologies(
                topologyB
            )

        else:
            cellsB = [
                topologyB
            ]

        cellsA_2 = []
        cellsB_2 = []

        for cellA in cellsA:
            if Topology.IsInstance(
                cellA,
                "CellComplex"
            ):
                cellsA_2 += Topology.Cells(
                    cellA
                )

            elif Topology.IsInstance(
                cellA,
                "Shell"
            ):
                cellsA_2 += Topology.Faces(
                    cellA
                )

            elif Topology.IsInstance(
                cellA,
                "Wire"
            ):
                cellsA_2 += Topology.Edges(
                    cellA
                )

            else:
                cellsA_2.append(
                    cellA
                )

        for cellB in cellsB:
            if Topology.IsInstance(
                cellB,
                "CellComplex"
            ):
                cellsB_2 += Topology.Cells(
                    cellB
                )

            elif Topology.IsInstance(
                cellB,
                "Shell"
            ):
                cellsB_2 += Topology.Faces(
                    cellB
                )

            elif Topology.IsInstance(
                cellB,
                "Wire"
            ):
                cellsB_2 += Topology.Edges(
                    cellB
                )

            else:
                cellsB_2.append(
                    cellB
                )

        for cellA in cellsA_2:
            for cellB in cellsB_2:
                cellC = Core.InstanceCall(
                    cellA,
                    "Intersect",
                    cellB
                )

                results.append(
                    cellC
                )

        results = [
            result
            for result in results
            if result is not None
        ]

        if len(results) == 0:
            return None

        if len(results) == 1:
            return results[0]

        return Topology.SelfMerge(
            Topology.SelfMerge(
                Cluster.ByTopologies(
                    results
                )
            )
        )
        
    @staticmethod
    def Slice(topologyA, topologyB, tranDict: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Slices topologyA using topologyB. See https://en.wikipedia.org/wiki/Boolean_operation.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tranDict : bool , optional
            If set to True the dictionaries of the operands are merged and transferred to the result. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            the resultant topology.

        """
        if not Topology.IsInstance(topologyA, "topology") and not Topology.IsInstance(topologyB, "topology"):
            if not silent:
                print("Topology.Slice - Error: The inputs topologyA and topologyB are not valid topologies. Returning None.")
            return None

        if not Topology.IsInstance(topologyA, "topology"):
            if not silent:
                print("Topology.Slice - Error: The topologyA input parameter is not a valid topology. Returning None.")
            return topologyA
        
        if not Topology.IsInstance(topologyB, "topology"):
            if not silent:
                print("Topology.Slice - Warning: The topologyB input parameter is not a valid topology. Returning topologyA.")
            return topologyA

        return Topology._Boolean(topologyA=topologyA, topologyB=topologyB, operation="slice", tranDict=tranDict, tolerance=tolerance, silent=silent)
    
    @staticmethod
    def Impose(topologyA, topologyB, tranDict: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Imposes topologyB on topologyA. See https://en.wikipedia.org/wiki/Boolean_operation.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tranDict : bool , optional
            If set to True the dictionaries of the operands are merged and transferred to the result. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            the resultant topology.

        """
        if not Topology.IsInstance(topologyA, "topology") and not Topology.IsInstance(topologyB, "topology"):
            if not silent:
                print("Topology.Impose - Error: The inputs topologyA and topologyB are not valid topologies. Returning None.")
            return None

        if not Topology.IsInstance(topologyA, "topology"):
            if not silent:
                print("Topology.Impose - Error: The topologyA input parameter is not a valid topology. Returning None.")
            return topologyA
        
        if not Topology.IsInstance(topologyB, "topology"):
            if not silent:
                print("Topology.Impose - Warning: The topologyB input parameter is not a valid topology. Returning topologyA.")
            return topologyA
        return Topology._Boolean(topologyA=topologyA, topologyB=topologyB, operation="impose", tranDict=tranDict, tolerance=tolerance, silent=silent)
    
    @staticmethod
    def Imprint(topologyA, topologyB, tranDict: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Imprints topologyB on topologyA. See https://en.wikipedia.org/wiki/Boolean_operation.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tranDict : bool , optional
            If set to True the dictionaries of the operands are merged and transferred to the result. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            the resultant topology.

        """
        if not Topology.IsInstance(topologyA, "topology") and not Topology.IsInstance(topologyB, "topology"):
            if not silent:
                print("Topology.Imprint - Error: The inputs topologyA and topologyB are not valid topologies. Returning None.")
            return None

        if not Topology.IsInstance(topologyA, "topology"):
            if not silent:
                print("Topology.Imprint - Error: The topologyA input parameter is not a valid topology. Returning None.")
            return topologyA
        
        if not Topology.IsInstance(topologyB, "topology"):
            if not silent:
                print("Topology.Imprint - Warning: The topologyB input parameter is not a valid topology. Returning topologyA.")
            return topologyA
        return Topology._Boolean(topologyA=topologyA, topologyB=topologyB, operation="imprint", tranDict=tranDict, tolerance=tolerance, silent=silent)
    
    @staticmethod
    def _Boolean(
        topologyA,
        topologyB,
        operation: str = "union",
        tranDict: bool = False,
        ontology: bool = False,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Do NOT use this method directly.

        Executes the input Boolean operation on the input operand topologies
        and returns the result.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        operation : str , optional
            The Boolean operation. This can be one of "union", "difference",
            "intersect", "symdif", "merge", "slice", "impose", or "imprint".
            It is case insensitive. Default is "union".
        tranDict : bool , optional
            If set to True the dictionaries of the operands are transferred
            to the result. Default is False.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy
            ontology metadata. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Topology
            The resultant topology.
        """
        from topologicpy.Dictionary import Dictionary
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell

        def special_case(
            topologyA,
            topologyB,
            operation
        ):
            """
            Legacy TopologicCore Boolean recovery.

            This helper must only be invoked when TopologicCore is the active
            backend.
            """
            if operation == "union":
                merge_result = Topology.Merge(
                    topologyA,
                    topologyB
                )

                if merge_result is None:
                    return None

                eb = Topology.ExternalBoundary(
                    merge_result
                )

                if (
                    Topology.IsInstance(
                        eb,
                        "vertex"
                    )
                    or Topology.IsInstance(
                        eb,
                        "edge"
                    )
                    or Topology.IsInstance(
                        eb,
                        "face"
                    )
                ):
                    return eb

                if Topology.IsInstance(
                    eb,
                    "wire"
                ):
                    if Wire.IsClosed(
                        eb
                    ):
                        return Face.ByWire(
                            eb
                        )

                    return eb

                if Topology.IsInstance(
                    eb,
                    "shell"
                ):
                    if Shell.IsClosed(
                        eb
                    ):
                        return Cell.ByShell(
                            eb
                        )

                    return eb

            return None

        if not Topology.IsInstance(
            topologyA,
            "Topology"
        ):
            if not silent:
                print(
                    f"Topology.{operation.capitalize()} - Error: "
                    "the input topologyA parameter is not a valid topology. "
                    "Returning None."
                )
            return None

        if not Topology.IsInstance(
            topologyB,
            "Topology"
        ):
            if not silent:
                print(
                    f"Topology.{operation.capitalize()} - Error: "
                    "the input topologyB parameter is not a valid topology. "
                    "Returning None."
                )
            return None

        if not isinstance(
            operation,
            str
        ):
            if not silent:
                print(
                    "Topology._Boolean - Error: The input operation parameter "
                    "is not a valid string. Returning None."
                )
            return None

        operation = operation.lower()

        if operation not in [
            "union",
            "difference",
            "intersect",
            "symdif",
            "merge",
            "slice",
            "impose",
            "imprint"
        ]:
            if not silent:
                print(
                    f"Topology.{operation.capitalize()} - Error: "
                    "the input operation parameter is not recognized. "
                    "Returning None."
                )
            return None

        if not isinstance(
            tranDict,
            bool
        ):
            if not silent:
                print(
                    f"Topology.{operation.capitalize()} - Error: "
                    "the input tranDict parameter is not a valid boolean. "
                    "Returning None."
                )
            return None

        topologyC = None

        # --------------------------------------------------------------
        # Union
        # --------------------------------------------------------------

        if operation == "union":
            topologyC = Core.InstanceCall(
                topologyA,
                "Union",
                topologyB,
                False
            )

            # Only TopologicCore is permitted to substitute a reconstructed
            # result when its native Union fails.
            if (
                topologyC is None
                and Topology._IsTopologicCoreBackend()
            ):
                topologyC = special_case(
                    topologyA,
                    topologyB,
                    "union"
                )

        # --------------------------------------------------------------
        # Difference
        # --------------------------------------------------------------

        elif operation == "difference":
            if (
                topologyA == topologyB
                or topologyB is None
            ):
                topologyC = None

            else:
                topologyC = Core.InstanceCall(
                    topologyA,
                    "Difference",
                    topologyB,
                    False
                )

        # --------------------------------------------------------------
        # Intersection
        # --------------------------------------------------------------

        elif operation == "intersect":
            if (
                topologyA == topologyB
                or topologyB is None
            ):
                topologyC = topologyA

            elif Topology._IsTopologicCoreBackend():
                # Legacy TopologicCore workaround.
                topologyC = Topology.Intersect(
                    topologyA,
                    topologyB,
                    tranDict=False,
                    tolerance=tolerance,
                    silent=silent
                )

            else:
                topologyC = Core.InstanceCall(
                    topologyA,
                    "Intersect",
                    topologyB,
                    False
                )

        # --------------------------------------------------------------
        # Symmetric difference
        # --------------------------------------------------------------

        elif operation == "symdif":
            if topologyA == topologyB:
                topologyC = None

            elif topologyB is None:
                topologyC = topologyA

            elif topologyA is None:
                topologyC = topologyB

            else:
                topologyC = Core.InstanceCall(
                    topologyA,
                    "XOR",
                    topologyB,
                    False
                )

        # --------------------------------------------------------------
        # Merge
        # --------------------------------------------------------------

        elif operation == "merge":
            if topologyA == topologyB:
                topologyC = topologyA

            else:
                topologyC = Core.InstanceCall(
                    topologyA,
                    "Merge",
                    topologyB,
                    False
                )

        # --------------------------------------------------------------
        # Slice
        # --------------------------------------------------------------

        elif operation == "slice":
            if topologyA == topologyB:
                topologyC = topologyA

            else:
                topologyC = Core.InstanceCall(
                    topologyA,
                    "Slice",
                    topologyB,
                    False
                )

        # --------------------------------------------------------------
        # Impose
        # --------------------------------------------------------------

        elif operation == "impose":
            if topologyA == topologyB:
                topologyC = topologyA

            else:
                topologyC = Core.InstanceCall(
                    topologyA,
                    "Impose",
                    topologyB,
                    False
                )

        # --------------------------------------------------------------
        # Imprint
        # --------------------------------------------------------------

        elif operation == "imprint":
            if topologyA == topologyB:
                topologyC = topologyA

            else:
                topologyC = Core.InstanceCall(
                    topologyA,
                    "Imprint",
                    topologyB,
                    False
                )

        # --------------------------------------------------------------
        # Dictionary transfer
        # --------------------------------------------------------------

        if tranDict is True and Topology.IsInstance(
            topologyC,
            "Topology"
        ):
            sourceVertices = []
            sourceEdges = []
            sourceFaces = []
            sourceCells = []

            sinkVertices = []
            sinkEdges = []
            sinkFaces = []
            sinkCells = []

            hidimA = Topology.HighestType(
                topologyA
            )

            hidimB = Topology.HighestType(
                topologyB
            )

            hidimC = Topology.HighestType(
                topologyC
            )

            # ----------------------------------------------------------
            # Vertices
            # ----------------------------------------------------------

            if Topology.Type(
                topologyA
            ) == Topology.TypeID(
                "Vertex"
            ):
                sourceVertices += [
                    topologyA
                ]

            elif hidimA >= Topology.TypeID(
                "Vertex"
            ):
                sourceVertices += Topology.Vertices(
                    topologyA
                )

            if Topology.Type(
                topologyB
            ) == Topology.TypeID(
                "Vertex"
            ):
                sourceVertices += [
                    topologyB
                ]

            elif hidimB >= Topology.TypeID(
                "Vertex"
            ):
                sourceVertices += Topology.Vertices(
                    topologyB
                )

            if Topology.Type(
                topologyC
            ) == Topology.TypeID(
                "Vertex"
            ):
                sinkVertices = [
                    topologyC
                ]

            elif hidimC >= Topology.TypeID(
                "Vertex"
            ):
                sinkVertices = Topology.Vertices(
                    topologyC,
                    silent=True
                )

            if (
                len(sourceVertices) > 0
                and len(sinkVertices) > 0
            ):
                Topology.TransferDictionaries(
                    sourceVertices,
                    sinkVertices,
                    tolerance=tolerance
                )

            # ----------------------------------------------------------
            # Edges
            # ----------------------------------------------------------

            if Topology.Type(
                topologyA
            ) == Topology.TypeID(
                "Edge"
            ):
                sourceEdges += [
                    topologyA
                ]

            elif hidimA >= Topology.TypeID(
                "Edge"
            ):
                sourceEdges += Topology.Edges(
                    topologyA
                )

            if Topology.Type(
                topologyB
            ) == Topology.TypeID(
                "Edge"
            ):
                sourceEdges += [
                    topologyB
                ]

            elif hidimB >= Topology.TypeID(
                "Edge"
            ):
                sourceEdges += Topology.Edges(
                    topologyB
                )

            if Topology.Type(
                topologyC
            ) == Topology.TypeID(
                "Edge"
            ):
                sinkEdges = [
                    topologyC
                ]

            elif hidimC >= Topology.TypeID(
                "Edge"
            ):
                sinkEdges = Topology.Edges(
                    topologyC
                )

            if (
                len(sourceEdges) > 0
                and len(sinkEdges) > 0
            ):
                Topology.TransferDictionaries(
                    sourceEdges,
                    sinkEdges,
                    tolerance=tolerance
                )

            # ----------------------------------------------------------
            # Faces
            # ----------------------------------------------------------

            if Topology.Type(
                topologyA
            ) == Topology.TypeID(
                "Face"
            ):
                sourceFaces += [
                    topologyA
                ]

            elif hidimA >= Topology.TypeID(
                "Face"
            ):
                sourceFaces += Topology.Faces(
                    topologyA
                )

            if Topology.Type(
                topologyB
            ) == Topology.TypeID(
                "Face"
            ):
                sourceFaces += [
                    topologyB
                ]

            elif hidimB >= Topology.TypeID(
                "Face"
            ):
                sourceFaces += Topology.Faces(
                    topologyB
                )

            if Topology.Type(
                topologyC
            ) == Topology.TypeID(
                "Face"
            ):
                sinkFaces += [
                    topologyC
                ]

            elif hidimC >= Topology.TypeID(
                "Face"
            ):
                sinkFaces += Topology.Faces(
                    topologyC
                )

            if (
                len(sourceFaces) > 0
                and len(sinkFaces) > 0
            ):
                Topology.TransferDictionaries(
                    sourceFaces,
                    sinkFaces,
                    tolerance=tolerance
                )

            # ----------------------------------------------------------
            # Cells
            # ----------------------------------------------------------

            if Topology.Type(
                topologyA
            ) == Topology.TypeID(
                "Cell"
            ):
                sourceCells += [
                    topologyA
                ]

            elif hidimA >= Topology.TypeID(
                "Cell"
            ):
                sourceCells += Topology.Cells(
                    topologyA
                )

            if Topology.Type(
                topologyB
            ) == Topology.TypeID(
                "Cell"
            ):
                sourceCells += [
                    topologyB
                ]

            elif hidimB >= Topology.TypeID(
                "Cell"
            ):
                sourceCells += Topology.Cells(
                    topologyB
                )

            if Topology.Type(
                topologyC
            ) == Topology.TypeID(
                "Cell"
            ):
                sinkCells = [
                    topologyC
                ]

            elif hidimC >= Topology.TypeID(
                "Cell"
            ):
                sinkCells = Topology.Cells(
                    topologyC
                )

            if (
                len(sourceCells) > 0
                and len(sinkCells) > 0
            ):
                Topology.TransferDictionaries(
                    sourceCells,
                    sinkCells,
                    tolerance=tolerance
                )

        return Topology._OntologyAnnotate(
            topologyC,
            ontology=ontology,
            generatedBy=f"Topology.{operation.capitalize()}",
            annotateSubtopologies=True,
            silent=True
        )

    
    @staticmethod
    def BoundingBox(topology, optimize: int = 0, axes: str ="xyz", mantissa: int = 6, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns a cell representing a bounding box of the input topology. The returned cell contains a dictionary with keys "xrot", "yrot", and "zrot" that represents rotations around the X, Y, and Z axes. If applied in the order of Z, Y, X, the resulting box will become axis-aligned.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        optimize : int , optional
            If set to an integer from 1 (low optimization) to 10 (high optimization), the method will attempt to optimize the bounding box so that it reduces its surface area. Default is 0 which will result in an axis-aligned bounding box. Default is 0.
        axes : str , optional
            Sets what axes are to be used for rotating the bounding box. This can be any permutation or substring of "xyz". It is not case sensitive. Default is "xyz".
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell or topologic_core.Face
            The bounding box of the input topology.

        """
        import math
        from topologicpy.Topology import Topology
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Cell import Cell
        from topologicpy.Cluster import Cluster
        from topologicpy.Dictionary import Dictionary

        def bounds_from_points(points):
            xmin = ymin = zmin = float("inf")
            xmax = ymax = zmax = float("-inf")
            for x, y, z in points:
                if x < xmin:
                    xmin = x
                if y < ymin:
                    ymin = y
                if z < zmin:
                    zmin = z
                if x > xmax:
                    xmax = x
                if y > ymax:
                    ymax = y
                if z > zmax:
                    zmax = z
            return [xmin, ymin, zmin, xmax, ymax, zmax]

        def rotate_points(points, origin_xyz, x_angle=0.0, y_angle=0.0, z_angle=0.0):
            ox, oy, oz = origin_xyz
            xr = math.radians(x_angle)
            yr = math.radians(y_angle)
            zr = math.radians(z_angle)

            cx = math.cos(xr)
            sx = math.sin(xr)
            cy = math.cos(yr)
            sy = math.sin(yr)
            cz = math.cos(zr)
            sz = math.sin(zr)

            rotated = []
            for px, py, pz in points:
                x = px - ox
                y = py - oy
                z = pz - oz

                # Rotate around Z
                if z_angle != 0:
                    x, y = x * cz - y * sz, x * sz + y * cz

                # Rotate around Y
                if y_angle != 0:
                    x, z = x * cy + z * sy, -x * sy + z * cy

                # Rotate around X
                if x_angle != 0:
                    y, z = y * cx - z * sx, y * sx + z * cx

                rotated.append((x + ox, y + oy, z + oz))
            return rotated

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.BoundingBox - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        if not isinstance(axes, str):
            if not silent:
                print("Topology.BoundingBox - Error: the input axes parameter is not a valid string. Returning None.")
            return None

        axes = axes.lower()
        x_flag = "x" in axes
        y_flag = "y" in axes
        z_flag = "z" in axes

        if not x_flag and not y_flag and not z_flag:
            if not silent:
                print("Topology.BoundingBox - Error: the input axes parameter is not a recognized string. Returning None.")
            return None

        if Topology.IsInstance(topology, "Vertex"):
            x_min = Vertex.X(topology, mantissa=mantissa)
            y_min = Vertex.Y(topology, mantissa=mantissa)
            z_min = Vertex.Z(topology, mantissa=mantissa)
            dictionary = Dictionary.ByKeysValues(
                ["xrot","yrot","zrot", "xmin", "ymin", "zmin", "xmax", "ymax", "zmax", "width", "length", "height"],
                [0, 0, 0, x_min, y_min, z_min, x_min, y_min, z_min, 0, 0, 0]
            )
            box = Vertex.ByCoordinates(x_min, y_min, z_min)
            box = Topology.SetDictionary(box, dictionary)
            return box

        vertices = Topology.SubTopologies(topology, subTopologyType="vertex")
        if not isinstance(vertices, list) or len(vertices) == 0:
            if not silent:
                print("Topology.BoundingBox - Error: Could not extract vertices from the input topology. Returning None.")
            return None

        if len(vertices) == 1:  # A Cluster made of one vertex. Rare, but can happen!
            x_min = Vertex.X(vertices[0], mantissa=mantissa)
            y_min = Vertex.Y(vertices[0], mantissa=mantissa)
            z_min = Vertex.Z(vertices[0], mantissa=mantissa)
            dictionary = Dictionary.ByKeysValues(
                ["xrot","yrot","zrot", "xmin", "ymin", "zmin", "xmax", "ymax", "zmax", "width", "length", "height"],
                [0, 0, 0, x_min, y_min, z_min, x_min, y_min, z_min, 0, 0, 0]
            )
            box = Vertex.ByCoordinates(x_min, y_min, z_min)
            box = Topology.SetDictionary(box, dictionary)
            return box

        temp_topology = Cluster.ByTopologies(vertices)
        origin = Topology.Centroid(temp_topology)
        ox, oy, oz = Vertex.Coordinates(origin, mantissa=mantissa)

        points = []
        for v in vertices:
            x, y, z = Vertex.Coordinates(v, mantissa=mantissa)
            points.append((x, y, z))

        boundingBox = bounds_from_points(points)
        x_min, y_min, z_min, x_max, y_max, z_max = boundingBox
        w = abs(x_max - x_min)
        l = abs(y_max - y_min)
        h = abs(z_max - z_min)

        best_area = 2*l*w + 2*l*h + 2*w*h
        orig_area = best_area
        best_x = 0
        best_y = 0
        best_z = 0
        best_bb = boundingBox

        optimize = min(max(optimize, 0), 10)
        if optimize > 0:
            factor = round(((11 - optimize) / 30 + 0.57), 2)
            flag = False

            for n in range(10, 0, -1):
                if flag:
                    break

                if x_flag:
                    xa = n
                    xb = 90 + n
                    xc = n
                else:
                    xa = 0
                    xb = 1
                    xc = 1

                if y_flag:
                    ya = n
                    yb = 90 + n
                    yc = n
                else:
                    ya = 0
                    yb = 1
                    yc = 1

                if z_flag:
                    za = n
                    zb = 90 + n
                    zc = n
                else:
                    za = 0
                    zb = 1
                    zc = 1

                for x in range(xa, xb, xc):
                    if flag:
                        break
                    for y in range(ya, yb, yc):
                        if flag:
                            break
                        for z in range(za, zb, zc):
                            rotated_points = rotate_points(points, (ox, oy, oz), x_angle=x, y_angle=y, z_angle=z)
                            x_min, y_min, z_min, x_max, y_max, z_max = bounds_from_points(rotated_points)
                            w = abs(x_max - x_min)
                            l = abs(y_max - y_min)
                            h = abs(z_max - z_min)
                            area = 2*l*w + 2*l*h + 2*w*h

                            if area < orig_area * factor:
                                best_area = area
                                best_x = x
                                best_y = y
                                best_z = z
                                best_bb = [x_min, y_min, z_min, x_max, y_max, z_max]
                                flag = True
                                break

                            if area < best_area:
                                best_area = area
                                best_x = x
                                best_y = y
                                best_z = z
                                best_bb = [x_min, y_min, z_min, x_max, y_max, z_max]
        else:
            best_bb = boundingBox

        x_min, y_min, z_min, x_max, y_max, z_max = best_bb
        vb1 = Vertex.ByCoordinates(x_min, y_min, z_min)
        vb2 = Vertex.ByCoordinates(x_max, y_min, z_min)
        vb3 = Vertex.ByCoordinates(x_max, y_max, z_min)
        vb4 = Vertex.ByCoordinates(x_min, y_max, z_min)

        baseWire = Wire.ByVertices([vb1, vb2, vb3, vb4], close=True, tolerance=tolerance, silent=silent)
        baseFace = Face.ByWire(baseWire, tolerance=tolerance)

        if abs(z_max - z_min) <= tolerance:
            box = baseFace
        else:
            box = Cell.ByThickenedFace(baseFace, thickness=abs(z_max - z_min), bothSides=False, reverse=False)

        box = Topology.Rotate(box, origin=origin, axis=[1, 0, 0], angle=-best_x)
        box = Topology.Rotate(box, origin=origin, axis=[0, 1, 0], angle=-best_y)
        box = Topology.Rotate(box, origin=origin, axis=[0, 0, 1], angle=-best_z)

        dictionary = Topology.Dictionary(topology)
        dictionary = Dictionary.SetValuesAtKeys(dictionary,
            ["xrot","yrot","zrot", "xmin", "ymin", "zmin", "xmax", "ymax", "zmax", "width", "length", "height"],
            [best_x, best_y, best_z, x_min, y_min, z_min, x_max, y_max, z_max, (x_max - x_min), (y_max - y_min), (z_max - z_min)]
        )
        box = Topology.SetDictionary(box, dictionary)
        return box

    @staticmethod
    def BREPString(topology, version: int = 3, silent: bool = False):
        """
        Returns the BRep string of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        version : int , optional
            The desired BRep version number. Default is 3.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        str
            The BREP string.

        """
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.BREPString - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        st = None
        try:
            st = Core.Topology.String(topology, version)
        except:
            try:
                st = Core.Topology.BREPString(topology, version)
            except:
                st = None
        return st
    
    @staticmethod
    def ByGeometry(vertices=[], edges=[], faces=[], topologyType: str = None, tolerance: float = 0.0001, ontology: bool = False, silent: bool = False):
        """
        Create a topology by the input lists of vertices, edges, and faces.

        Parameters
        ----------
        vertices : list
            The input list of vertices in the form of [x, y, z].
        edges : list , optional
            The input list of edges in the form of [i, j] where i and j are vertex indices.
        faces : list , optional
            The input list of faces in the form of [i, j, k, l, ...] where the items in the list are vertex indices.
            The face is assumed to be closed, so the last vertex is connected to the first vertex automatically.
        topologyType : str , optional
            The desired highest topology type. The options are: "Vertex", "Edge", "Wire", "Face", "Shell",
            "Cell", "CellComplex". It is case insensitive. If any of these options are selected, the returned
            topology will only contain this type either as a single topology or as a Cluster of these types of
            topologies. If set to None, a Cluster will be returned of vertices, edges, and/or faces. Default is None.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topology : topologic_core.Topology
            The created topology.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Cluster import Cluster

        # -------------------------------------------------------------------------
        # Fast local method bindings
        # -------------------------------------------------------------------------
        Vertex_ByCoordinates = Vertex.ByCoordinates
        Edge_ByVertices = Edge.ByVertices
        Wire_ByEdges = Wire.ByEdges
        Face_ByWire = Face.ByWire
        Face_ByVertices = getattr(Face, "ByVertices", None)
        Shell_ByFaces = Shell.ByFaces
        Cell_ByFaces = Cell.ByFaces
        CellComplex_ByFaces = CellComplex.ByFaces
        CellComplex_ExternalBoundary = CellComplex.ExternalBoundary
        Cluster_ByTopologies = Cluster.ByTopologies

        Topology_IsInstance = Topology.IsInstance
        Topology_SelfMerge = Topology.SelfMerge
        Topology_Cells = Topology.Cells

        # -------------------------------------------------------------------------
        # Clean inputs
        # -------------------------------------------------------------------------
        vertices = [v for v in vertices if v]
        edges = [e for e in edges if e]
        faces = [f for f in faces if f]

        if not vertices:
            return None

        n_vertices = len(vertices)

        if topologyType is not None:
            topologyType = topologyType.lower()

        # -------------------------------------------------------------------------
        # Lazy vertex construction
        # -------------------------------------------------------------------------
        topVerts = [None] * n_vertices

        def _vertex_at(i):
            if i < 0 or i >= n_vertices:
                return None

            v = topVerts[i]
            if v is not None:
                return v

            xyz = vertices[i]
            try:
                v = Vertex_ByCoordinates(xyz[0], xyz[1], xyz[2])
            except Exception:
                return None

            topVerts[i] = v
            return Topology._OntologyAnnotate(v, ontology=ontology, generatedBy="Topology.ByGeometry", annotateSubtopologies=True, silent=True)

        def _all_vertices():
            result = []
            for i in range(n_vertices):
                v = _vertex_at(i)
                if v is not None:
                    result.append(v)
            return Topology._OntologyAnnotate(result, ontology=ontology, generatedBy="Topology.ByGeometry", annotateSubtopologies=True, silent=True)

        # -------------------------------------------------------------------------
        # Cached edge construction
        # -------------------------------------------------------------------------
        edge_cache = {}

        def _edge_by_indices(i, j):
            key = (i, j)
            e = edge_cache.get(key, None)
            if e is not None:
                return e

            v1 = _vertex_at(i)
            v2 = _vertex_at(j)

            if v1 is None or v2 is None:
                return None

            try:
                e = Edge_ByVertices([v1, v2], tolerance=tolerance, silent=True)
            except Exception:
                e = None

            if e is not None:
                edge_cache[key] = e

            return Topology._OntologyAnnotate(e, ontology=ontology, generatedBy="Topology.ByGeometry", annotateSubtopologies=True, silent=True)

        def _edges_from_indices(edge_indices):
            result = []

            for e in edge_indices:
                if len(e) < 2:
                    continue

                top_edge = _edge_by_indices(e[0], e[1])
                if top_edge is not None:
                    result.append(top_edge)

            return Topology._OntologyAnnotate(result, ontology=ontology, generatedBy="Topology.ByGeometry", annotateSubtopologies=True, silent=True)

        # -------------------------------------------------------------------------
        # Helper: build topology from already-created faces
        # -------------------------------------------------------------------------
        def topologyByFaces(topFaces, topologyType, tolerance=0.0001):
            if len(topFaces) == 1:
                return topFaces[0]

            output = None

            if topologyType == "cell":
                c = Cell_ByFaces(topFaces, tolerance=tolerance)
                if Topology_IsInstance(c, "Cell"):
                    output = c
                else:
                    cc = CellComplex_ByFaces(topFaces, tolerance=tolerance)
                    if Topology_IsInstance(cc, "CellComplex"):
                        output = CellComplex_ExternalBoundary(cc)

            elif topologyType == "cellcomplex":
                output = CellComplex_ByFaces(topFaces, tolerance=tolerance, silent=silent)
                if Topology_IsInstance(output, "CellComplex"):
                    cells = Topology_Cells(output)
                    if len(cells) == 1:
                        output = cells[0]
                else:
                    output = Cluster_ByTopologies(topFaces)

            elif topologyType == "shell":
                output = Shell_ByFaces(topFaces, tolerance=tolerance)
                if Topology_IsInstance(output, "Shell"):
                    return output

            elif topologyType is None or topologyType == "face":
                output = Cluster_ByTopologies(topFaces)

            return Topology._OntologyAnnotate(output, ontology=ontology, generatedBy="Topology.ByGeometry", annotateSubtopologies=True, silent=True)

        # -------------------------------------------------------------------------
        # Helper: build topology from already-created edges
        # -------------------------------------------------------------------------
        def topologyByEdges(topEdges, topologyType):
            if len(topEdges) == 1:
                return topEdges[0]

            output = Cluster_ByTopologies(topEdges)

            if topologyType == "wire":
                output = Topology_SelfMerge(output, tolerance=tolerance)
                if Topology_IsInstance(output, "Wire"):
                    return output
                return None

            return Topology._OntologyAnnotate(output, ontology=ontology, generatedBy="Topology.ByGeometry", annotateSubtopologies=True, silent=True)

        # -------------------------------------------------------------------------
        # Vertex-only request
        # -------------------------------------------------------------------------
        if topologyType == "vertex":
            topVertsAll = _all_vertices()

            if len(topVertsAll) == 0:
                return None

            if len(topVertsAll) == 1:
                return topVertsAll[0]

            return Topology._OntologyAnnotate(Cluster_ByTopologies(topVertsAll), ontology=ontology, generatedBy="Topology.ByGeometry", annotateSubtopologies=True, silent=True)

        # -------------------------------------------------------------------------
        # Edge-only request
        # -------------------------------------------------------------------------
        if topologyType == "edge":
            if not edges:
                return None

            if len(edges) == 1 and len(edges[0]) >= 2:
                return _edge_by_indices(edges[0][0], edges[0][1])

            topEdges = _edges_from_indices(edges)

            if not topEdges:
                return None

            return Topology._OntologyAnnotate(Cluster_ByTopologies(topEdges), ontology=ontology, generatedBy="Topology.ByGeometry", annotateSubtopologies=True, silent=True)

        # -------------------------------------------------------------------------
        # Wire request from explicit edges
        # -------------------------------------------------------------------------
        if topologyType == "wire" and edges:
            topEdges = _edges_from_indices(edges)

            if topEdges:
                return topologyByEdges(topEdges, topologyType)

            return None

        # -------------------------------------------------------------------------
        # Faces
        # -------------------------------------------------------------------------
        if faces:
            topFaces = []

            for aFace in faces:
                if len(aFace) < 3:
                    continue

                # -----------------------------------------------------------------
                # Fast path: Face.ByVertices, if available.
                # This avoids creating all boundary edges and a wire first.
                # -----------------------------------------------------------------
                topFace = None

                if Face_ByVertices is not None:
                    try:
                        face_vertices = []
                        ok = True

                        for vi in aFace:
                            v = _vertex_at(vi)
                            if v is None:
                                ok = False
                                break
                            face_vertices.append(v)

                        if ok and len(face_vertices) > 2:
                            topFace = Face_ByVertices(face_vertices, tolerance=tolerance, silent=True)

                    except TypeError:
                        # Some older versions may not support silent.
                        try:
                            topFace = Face_ByVertices(face_vertices, tolerance=tolerance)
                        except Exception:
                            topFace = None

                    except Exception:
                        topFace = None

                # -----------------------------------------------------------------
                # Fallback path: original edge -> wire -> face construction.
                # -----------------------------------------------------------------
                if topFace is None:
                    try:
                        faceEdges = []

                        last_index = len(aFace) - 1
                        for i in range(last_index):
                            e = _edge_by_indices(aFace[i], aFace[i + 1])
                            if e is not None:
                                faceEdges.append(e)

                        e = _edge_by_indices(aFace[-1], aFace[0])
                        if e is not None:
                            faceEdges.append(e)

                        if len(faceEdges) > 2:
                            faceWire = Wire_ByEdges(faceEdges, tolerance=tolerance)
                            topFace = Face_ByWire(faceWire, tolerance=tolerance, silent=True)

                    except Exception:
                        topFace = None

                # -----------------------------------------------------------------
                # Store result
                # -----------------------------------------------------------------
                if Topology_IsInstance(topFace, "Face"):
                    topFaces.append(topFace)

                elif isinstance(topFace, list):
                    for f in topFace:
                        if Topology_IsInstance(f, "Face"):
                            topFaces.append(f)

            if topFaces:
                return topologyByFaces(topFaces, topologyType=topologyType, tolerance=tolerance)

            return None

        # -------------------------------------------------------------------------
        # Edges, if no faces
        # -------------------------------------------------------------------------
        if edges:
            topEdges = _edges_from_indices(edges)

            if topEdges:
                return topologyByEdges(topEdges, topologyType)

            return None

        # -------------------------------------------------------------------------
        # Vertices fallback
        # -------------------------------------------------------------------------
        topVertsAll = _all_vertices()

        if not topVertsAll:
            return None

        return Cluster_ByTopologies(topVertsAll)
    
    @staticmethod
    def ByBIMPath(path,
                  guidKey: str = "guid",
                  colorKey: str = "color",
                  typeKey: str = "type",
                  defaultColor: list = [255,255,255,1],
                  defaultType: str = "Structure",
                  authorKey="author",
                  dateKey="date",
                  mantissa: int = 6,
                  angTolerance: float = 0.001,
                  tolerance: float = 0.0001,
                  silent: bool = False):
        """
        Imports topologies from the input BIM file. See https://dotbim.net/

        Parameters
        ----------
        path :str
            The path to the .bim file.
        guidKey : str , optional
            The key to use to store the the guid of the topology. Default is "guid".
        colorKey : str , optional
            The key to use to find the the color of the topology. Default is "color". If no color is found, the defaultColor parameter is used.
        typeKey : str , optional
            The key to use to find the the type of the topology. Default is "type". If no type is found, the defaultType parameter is used.
        defaultColor : list , optional
            The default color to use for the topology. Default is [255,255,255,1] which is opaque white.
        defaultType : str , optional
            The default type to use for the topology. Default is "Structure".
        authorKey : str , optional
            The key to use to store the author of the topology. Default is "author".
        dateKey : str , optional
            The key to use to store the creation date of the topology. This should be in the formate "DD.MM.YYYY". If no date is found the date of import is used.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        angTolerance : float , optional
                The angle tolerance in degrees under which no rotation is carried out. Default is 0.001 degrees.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of imported topologies

        """
        import json
        if not path:
            if not silent:
                print("Topology.ByBIMPath - Error: the input path parameter is not a valid path. Returning None.")
            return None
        topologies = None
        with open(path, "r") as bim_file:
                json_string = str(bim_file.read())
                topologies = Topology.ByBIMString(string=json_string, guidKey=guidKey, colorKey=colorKey, typeKey=typeKey,
                            defaultColor=defaultColor, defaultType=defaultType,
                            authorKey=authorKey, dateKey=dateKey, mantissa=mantissa, angTolerance=angTolerance, tolerance=tolerance, silent=silent)
        try:
            with open(path, "r") as bim_file:
                json_string = str(bim_file.read())
                topologies = Topology.ByBIMString(string=json_string, guidKey=guidKey, colorKey=colorKey, typeKey=typeKey,
                            defaultColor=defaultColor, defaultType=defaultType,
                            authorKey=authorKey, dateKey=dateKey, mantissa=mantissa, angTolerance=angTolerance, tolerance=tolerance, silent=silent)
        except:
            print("Topology.ByBIMPath - Error: the BIM file is not a valid file. Returning None.")
        return topologies
    
    @staticmethod
    def ByBIMString(string,
                    guidKey: str = "guid",
                    colorKey: str = "color",
                    typeKey: str = "type",
                    defaultColor: list = [255,255,255,1],
                    defaultType: str = "Structure",
                    authorKey: str = "author",
                    dateKey: str = "date",
                    mantissa: int = 6,
                    angTolerance: float = 0.001,
                    tolerance: float = 0.0001,
                    silent: bool = False):
        """
        Imports topologies from the input BIM file. See https://dotbim.net/

        Parameters
        ----------
        string :str
            The input dotbim str (in JSON format).
        guidKey : str , optional
            The key to use to store the the guid of the topology. Default is "guid".
        colorKey : str , optional
            The key to use to find the the color of the topology. Default is "color". If no color is found, the defaultColor parameter is used.
        typeKey : str , optional
            The key to use to find the the type of the topology. Default is "type". If no type is found, the defaultType parameter is used.
        defaultColor : list , optional
            The default color to use for the topology. Default is [255,255,255,1] which is opaque white.
        defaultType : str , optional
            The default type to use for the topology. Default is "Structure".
        authorKey : str , optional
            The key to use to store the author of the topology. Default is "author".
        dateKey : str , optional
            The key to use to store the creation date of the topology. This should be in the formate "DD.MM.YYYY". If no date is found the date of import is used.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        angTolerance : float , optional
                The angle tolerance in degrees under which no rotation is carried out. Default is 0.001 degrees.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of imported topologies

        """
        def convert_JSON_to_file(json_dictionary):
            import dotbimpy
            schema_version = json_dictionary["schema_version"]
            elements = json_dictionary["elements"]
            meshes = json_dictionary["meshes"]
            created_info = json_dictionary["info"]

            created_meshes = []
            for i in meshes:
                created_meshes.append(dotbimpy.Mesh(
                    mesh_id=i["mesh_id"],
                    coordinates=i["coordinates"],
                    indices=i["indices"]
                ))

            created_elements = []
            for i in elements:
                new_element = dotbimpy.Element(
                    mesh_id=i["mesh_id"],
                    vector=dotbimpy.Vector(x=i["vector"]["x"],
                                y=i["vector"]["y"],
                                z=i["vector"]["z"]),
                    rotation=dotbimpy.Rotation(qx=i["rotation"]["qx"],
                                    qy=i["rotation"]["qy"],
                                    qz=i["rotation"]["qz"],
                                    qw=i["rotation"]["qw"]),
                    info=i["info"],
                    color=dotbimpy.Color(r=i["color"]["r"],
                                g=i["color"]["g"],
                                b=i["color"]["b"],
                                a=i["color"]["a"]),
                    type=i["type"],
                    guid=i["guid"]
                )
                try:
                    new_element.face_colors = i["face_colors"]
                except KeyError as e:
                    if str(e) == "'face_colors'":
                        pass
                    else:
                        raise
                created_elements.append(new_element)

            file = dotbimpy.File(schema_version=schema_version, meshes=created_meshes, elements=created_elements, info=created_info)
            return file
        json_dictionary = json.loads(string)
        file = convert_JSON_to_file(json_dictionary)
        return Topology.ByBIMFile(file,
                                  guidKey=guidKey,
                                  colorKey=colorKey,
                                  typeKey=typeKey,
                                  defaultColor=defaultColor,
                                  defaultType=defaultType,
                                  authorKey=authorKey,
                                  dateKey=dateKey,
                                  mantissa=mantissa,
                                  angTolerance=angTolerance,
                                  tolerance=tolerance,
                                  silent=silent)
    @staticmethod
    def ByBIMFile(file,
                  guidKey: str = "guid",
                  colorKey: str = "color",
                  typeKey: str = "type",
                  defaultColor: list = [255,255,255,1],
                  defaultType: str = "Structure",
                  authorKey="author",
                  dateKey="date",
                  mantissa: int = 6,
                  angTolerance: float = 0.001,
                  tolerance: float = 0.0001,
                  silent: bool = False):
        """
        Imports topologies from the input BIM (dotbimpy.file.File) file object. See https://dotbim.net/

        Parameters
        ----------
        file : dotbimpy.file.File
            The input dotbim file.
        guidKey : str , optional
            The key to use to store the the guid of the topology. Default is "guid".
        colorKey : str , optional
            The key to use to find the the color of the topology. Default is "color". If no color is found, the defaultColor parameter is used.
        typeKey : str , optional
            The key to use to find the the type of the topology. Default is "type". If no type is found, the defaultType parameter is used.
        defaultColor : list , optional
            The default color to use for the topology. Default is [255,255,255,1] which is opaque white.
        defaultType : str , optional
            The default type to use for the topology. Default is "Structure".
        authorKey : str , optional
            The key to use to store the author of the topology. Default is "author".
        dateKey : str , optional
            The key to use to store the creation date of the topology. This should be in the formate "DD.MM.YYYY". If no date is found the date of import is used.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        angTolerance : float , optional
                The angle tolerance in degrees under which no rotation is carried out. Default is 0.001 degrees.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of imported topologies

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Topology import Topology
        from topologicpy.Dictionary import Dictionary
        import datetime

        file_info = file.info
        elements = file.elements
        meshes = file.meshes
        final_topologies = []
        topologies = []
        id_list = []
        for mesh in meshes:
            id_list.append(mesh.mesh_id)
            coordinates = mesh.coordinates
            indices = mesh.indices
            coordinates = [coordinates[i:i + 3] for i in range(0, len(coordinates),3)]
            indices = [indices[i:i + 3] for i in range(0, len(indices),3)]
            topology = Topology.ByGeometry(vertices=coordinates, faces=indices, tolerance=tolerance)
            topologies.append(topology)
        
        for element in elements:
            element_info = element.info
            element_info[typeKey] = element.type
            element_info[colorKey] = [element.color.r, element.color.g, element.color.b, float(element.color.a)/float(255)]
            try:
                element_info[guidKey] = element.guid
            except:
                element_info[guidKey] = str(uuid.uuid4())
            try:
                element_info[authorKey] = file_info['author']
            except:
                element_info[authorKey] = "topologicpy"
            # Get the current date
            current_date = datetime.datetime.now()
            # Format the date as a string in DD.MM.YYYY format
            formatted_date = current_date.strftime("%d.%m.%Y")
            try:
                element_info[dateKey] = file_info['date']
            except:
                element_info[dateKey] = formatted_date
            d = Dictionary.ByPythonDictionary(element_info)
            mesh_id = element.mesh_id
            quat = element.rotation
            quaternion = [quat.qx, quat.qy, quat.qz, quat.qw]
            #roll, pitch, yaw = quaternion_to_euler([rot.qx, rot.qy, rot.qz, rot.qw])
            vector = element.vector
            topology = topologies[mesh_id]
            if not Topology.IsInstance(topology, "Topology"):
                if not silent:
                    print("Topology.ByBIMFile - Warning: Could not create topology. Skipping.")
                continue
            else:
                topology = Topology.RotateByQuaternion(topology=topology, origin=Vertex.Origin(), quaternion=quaternion, angTolerance=angTolerance, tolerance=tolerance)
                topology = Topology.Translate(topology, vector.x, vector.y, vector.z)
                topology = Topology.SetDictionary(topology, d)
                final_topologies.append(topology)
        return final_topologies
    
    @staticmethod
    def ByBREPFile(file, ontology: bool = False, silent: bool = False):
        """
        Imports a topology from a BREP file.

        Parameters
        ----------
        file : file object
            The BREP file.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The imported topology.

        """
        topology = None
        if not file:
            if not silent:
                print("Topology.ByBREPFile - Error: the input file parameter is not a valid file. Returning None.")
            return None
        brep_string = file.read()
        topology = Topology.ByBREPString(brep_string, ontology=ontology, silent=silent)
        file.close()
        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.ByBREPFile - Error: Could not create the topology. Returning None.")
            return None
        return topology
    
    @staticmethod
    def ByBREPPath(path, ontology: bool = False, silent: bool = False):
        """
        Imports a topology from a BREP file path.

        Parameters
        ----------
        path : str
            The path to the BREP file.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The imported topology.

        """
        if not path:
            if not silent:
                print("Topology.ByBREPPath - Error: the input path parameter is not a valid path. Returning None.")
            return None
        try:
            file = open(path)
        except:
            if not silent:
                print("Topology.ByBREPPath - Error: the BREP file is not a valid file. Returning None.")
            return None
        return Topology.ByBREPFile(file, ontology=ontology, silent=silent)

    @staticmethod
    def ByDXFFile(file, sides: int = 16, tolerance: float = 0.0001, silent: bool = False):
        """
        Imports a list of topologies from a DXF file.
        This is an experimental method with limited capabilities.

        Parameters
        ----------
        file : a DXF file object
            The DXF file object.
        sides : int , optional
            The desired number of sides of splines. Default is 16.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of imported topologies.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Topology import Topology
        from topologicpy.Dictionary import Dictionary


        try:
            import ezdxf
        except:
            print("Topology.ByDXFFile - Information: Installing required ezdxf library.")
            try:
                os.system("pip install ezdxf")
            except:
                os.system("pip install ezdxf --user")
            try:
                import ezdxf
                print("Topology.ByDXFFile - Information: ezdxf library installed successfully.")
            except:
                warnings.warn("Topology.ByDXFFile - Error: Could not import ezdxf library. Please install it manually. Returning None.")
                return None

        if not file:
            print("Topology.ByDXFFile - Error: the input file parameter is not a valid file. Returning None.")
            return None
        
        import ezdxf



        def get_layer_color(layers, layer_name):
            # iteration
            for layer in layers:
                if layer_name == layer.dxf.name:
                    if not layer.rgb == None:
                        r,g,b = layer.rgb
                        return [r,g,b]
            return 

        def convert_entity(entity, file, sides=36):
            e = None
            entity_type = entity.dxftype()
            python_dict = entity.dxf.all_existing_dxf_attribs()
            keys = python_dict.keys()
            for key in keys:
                if python_dict[key].__class__ == ezdxf.acc.vector.Vec3:
                    python_dict[key] = list(python_dict[key])
            rgb_list = None
            try:
                rgb_list = entity.rgb   
            except:
                rgb_list = get_layer_color(file.layers, entity.dxf.layer)
            if rgb_list == None:
                rgb_list = [0,0,0]
            python_dict['color'] = rgb_list
            python_dict['type'] = entity_type
            d = Dictionary.ByPythonDictionary(python_dict)
            
            if entity_type == 'POINT':
                point = entity.dxf.location.xyz
                e = Vertex.ByCoordinates(point[0], point[1], point[2])
                e = Topology.SetDictionary(e, d)
            
            elif entity_type == 'LINE':
                sp = entity.dxf.start.xyz
                ep = entity.dxf.end.xyz
                sv = Vertex.ByCoordinates(sp[0], sp[1], sp[2])
                ev = Vertex.ByCoordinates(ep[0], ep[1], ep[2])
                e = Edge.ByVertices(sv,ev)
                e = Topology.SetDictionary(e, d)
        
            elif entity_type == 'POLYLINE':
                if entity.dxf.flags == 1:
                    closed = True
                else:
                    closed = False
                vertices = []
                for vertex in entity.vertices:
                    point = vertex.dxf.location.xyz
                    vertices.append(Vertex.ByCoordinates(point[0], point[1], point[2]))
                if entity.dxf.hasattr("closed"):
                    closed = entity.closed
                e = Wire.ByVertices(vertices, close=closed, tolerance=tolerance, silent=silent)
                e = Topology.SetDictionary(e, d)

            elif entity_type == 'LWPOLYLINE':
                vertices = []
                for point in entity.get_points():
                    vertices.append(Vertex.ByCoordinates(point[0], point[1], 0))
                if entity.dxf.hasattr("closed"):
                    close = entity.closed
                else:
                    close = False
                e = Wire.ByVertices(vertices, close=close, tolerance=tolerance, silent=silent)
                e = Topology.SetDictionary(e, d)
        
            elif entity_type == 'CIRCLE':
                center = entity.dxf.center.xyz
                radius = entity.dxf.radius
                num_points = 36  # Approximate the circle with 36 points
                vertices = []
                for i in range(sides):
                    angle = 2 * np.pi * i / num_points
                    x = center[0] + radius * np.cos(angle)
                    y = center[1] + radius * np.sin(angle)
                    z = center[2]
                    vertices.append(Vertex.ByCoordinates(x,y,z))
                e = Wire.ByVertices(vertices, close=True, tolerance=tolerance, silent=silent)
                e = Topology.SetDictionary(e, d)
            
            elif entity_type == 'ARC':
                center = entity.dxf.center.xyz
                radius = entity.dxf.radius
                start_angle = np.deg2rad(entity.dxf.start_angle)
                end_angle = np.deg2rad(entity.dxf.end_angle)
                vertices = []
                for i in range(sides+1):
                    angle = start_angle + (end_angle - start_angle) * i / (num_points - 1)
                    x = center[0] + radius * np.cos(angle)
                    y = center[1] + radius * np.sin(angle)
                    z = center[2]
                    vertices.append(Vertex.ByCoordinates(x,y,z))
                e = Wire.ByVertices(vertices, close=False, tolerance=tolerance, silent=silent)
                e = Topology.SetDictionary(e, d)

            elif entity_type == 'SPLINE':
                # draw the curve tangents as red lines:
                ct = entity.construction_tool()
                vertices = []
                for t in np.linspace(0, ct.max_t, 64):
                    point, derivative = ct.derivative(t, 1)
                    vertices.append(Vertex.ByCoordinates(list(point)))
                converted_entity = Wire.ByVertices(vertices, close=entity.closed, tolerance=tolerance, silent=silent)
                vertices = []
                for i in range(sides+1):
                    if i == 0:
                        u = 0
                    elif i == sides:
                        u = 1
                    else:
                        u = float(i)/float(sides)
                    vertices.append(Wire.VertexByParameter(converted_entity, u))

                e = Wire.ByVertices(vertices, close=entity.closed, tolerance=tolerance, silent=silent)
                e = Topology.SetDictionary(e, d)
            
            elif entity_type == 'MESH':
                vertices = [list(v) for v in entity.vertices]
                faces = [list(face) for face in entity.faces]
                converted_entity = Topology.SelfMerge(Topology.ByGeometry(vertices=vertices, faces=faces))
                # Try Cell
                temp = Cell.ByFaces(Topology.Faces(converted_entity), silent=True)
                if not Topology.IsInstance(temp, "Cell"):
                    temp = CellComplex.ByFaces(Topology.Faces(converted_entity))
                    if not Topology.IsInstance(temp, "CellComplex"):
                        temp = Shell.ByFaces(Topology.Faces(converted_entity))
                        if not Topology.IsInstance(temp, "Shell"):
                            temp = converted_entity
                e = temp
                e = Topology.SetDictionary(e, d)
            return e

        def convert_insert(entity, file, sides=16):
            block_name = entity.dxf.name
            block = file.blocks.get(block_name)
            converted_entities = []

            for block_entity in block:
                converted_entity = convert_entity(block_entity, file, sides=sides)
                if converted_entity is not None:
                    converted_entities.append(converted_entity)

            x, y, z = [entity.dxf.insert.x, entity.dxf.insert.y, entity.dxf.insert.z]
            return [Topology.Translate(obj, x, y, z) for obj in converted_entities]

        def convert_dxf_to_custom_types(file):
            # Read the DXF file
            msp = file.modelspace()

            # Store the converted entities
            converted_entities = []

            # Process each entity in the model space
            for entity in msp:
                entity_type = entity.dxftype()
                if entity_type in ['TEXT', 'MTEXT']:
                    continue  # Ignore TEXT and MTEXT

                if entity_type == 'INSERT':
                    converted_entities.extend(convert_insert(entity, file, sides=sides))
                else:
                    converted_entity = convert_entity(entity, file, sides=sides)
                    if converted_entity is not None:
                        converted_entities.append(converted_entity)

            return converted_entities
        converted_entities = convert_dxf_to_custom_types(file)
        return converted_entities

    @staticmethod
    def ByDXFPath(path, sides: int = 16, tolerance: float = 0.0001, silent: bool = False):
        """
        Imports a list of topologies from a DXF file path.
        This is an experimental method with limited capabilities.

        Parameters
        ----------
        path : str
            The path to the DXF file.
        sides : int , optional
            The desired number of sides of splines. Default is 16.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of imported topologies.

        """
        try:
            import ezdxf
        except:
            print("Topology.ByDXFPath - Information: Installing required ezdxf library.")
            try:
                os.system("pip install ezdxf")
            except:
                os.system("pip install ezdxf --user")
            try:
                import ezdxf
                print("Topology.ByDXFPath - Information: ezdxf library installed successfully.")
            except:
                warnings.warn("Topology.ByDXFPath - Error: Could not import ezdxf library. Please install it manually. Returning None.")
                return None
        if not path:
            if not silent:
                print("Topology.ByDXFPath - Error: the input path parameter is not a valid path. Returning None.")
            return None
        try:
            file = ezdxf.readfile(path)
        except:
            file = None
        if not file:
            if not silent:
                print("Topology.ByDXFPath - Error: the input file parameter is not a valid file. Returning None.")
            return None
        return Topology.ByDXFFile(file, sides=sides, tolerance=tolerance, silent=silent)

    @staticmethod
    def ByIFCFile(file,
                  includeTypes: list = [],
                  excludeTypes: list = [],
                  dictionaryMode: str = "basic",
                  clean: bool = False,
                  scale: float = 1.0,
                  topologyType: str = None,
                  circleSides: int = 24,
                  ontology: bool = True,
                  epsilon: float = 0.01,
                  angTolerance: float = 0.1,
                  tolerance: float = 0.0001,
                  silent: bool = False) -> list:
        """
        Import an IFC file into a list of TopologicPy topologies using the
        Bonsai triangulation pipeline. See IFC.TopologiesByFile.

        Parameters
        ----------
        file : str or ifcopenshell.file-like object
            Prefer passing a path string. If an ifcopenshell file-like object is
            supplied, this method attempts to serialise it to STEP text.
        includeTypes : list , optional
            The list of IFC entity types to include. If empty, all supported types are
            included. Default is [].
        excludeTypes : list , optional
            The list of IFC entity types to exclude. Default is [].
        dictionaryMode : str , optional
            The dictionary import mode. Options are "none", "basic", and "full".
            Default is "basic".
        clean : bool , optional
            If set to True, the imported topologies are cleaned. Default is False.
        scale : float , optional
            The scale factor applied to imported coordinates. Default is 1.0.
        topologyType : str , optional
            The desired output topology type. If set to None, the method returns the
            most appropriate topology type for each imported product. Default is None.
        circleSides : int , optional
            The number of sides used to approximate circular geometry. Default is 24.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        epsilon : float , optional
            The geometric epsilon used during import. Default is 0.01.
        angTolerance : float , optional
            The angular tolerance used during import. Default is 0.1.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The created TopologicPy topologies.
        """

        from topologicpy.IFC import IFC
        return IFC.TopologiesByFile(file = file,
                                    includeTypes = includeTypes,
                                    excludeTypes = excludeTypes,
                                    dictionaryMode = dictionaryMode,
                                    clean = clean,
                                    scale = scale,
                                    topologyType = topologyType,
                                    circleSides = circleSides,
                                    ontology = ontology,
                                    epsilon = epsilon,
                                    angTolerance = angTolerance,
                                    tolerance = tolerance,
                                    silent = silent)

    @staticmethod
    def ByIFCPath(path: str,
                  includeTypes: list = [],
                  excludeTypes: list = [],
                  dictionaryMode: str = "basic",
                  clean: bool = False,
                  scale: float = 1.0,
                  topologyType: str = None,
                  circleSides: int = 24,
                  ontology: bool = True,
                  epsilon: float = 0.01,
                  angTolerance: float = 0.1,
                  tolerance: float = 0.0001,
                  silent: bool = False) -> list:
        """
        Imports the topologies from an IFC file path. See IFC.TopologiesByPath

        Parameters
        ----------
        path : str
            The path to the input IFC file.
        includeTypes : list , optional
            The list of IFC entity types to include. If empty, all supported types are
            included. Default is [].
        excludeTypes : list , optional
            The list of IFC entity types to exclude. Default is [].
        dictionaryMode : str , optional
            The dictionary import mode. Options are "none", "basic", and "full".
            Default is "basic".
        clean : bool , optional
            If set to True, the imported topologies are cleaned. Default is False.
        scale : float , optional
            The scale factor applied to imported coordinates. Default is 1.0.
        topologyType : str , optional
            The desired output topology type. If set to None, the method returns the
            most appropriate topology type for each imported product. Default is None.
        circleSides : int , optional
            The number of sides used to approximate circular geometry. Default is 24.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        epsilon : float , optional
            The geometric epsilon used during import. Default is 0.01.
        angTolerance : float , optional
            The angular tolerance used during import. Default is 0.1.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The created list of topologies.
        
        """
        
        from topologicpy.IFC import IFC
        return IFC.TopologiesByPath(path = path,
                                    includeTypes = includeTypes,
                                    excludeTypes = excludeTypes,
                                    dictionaryMode = dictionaryMode,
                                    clean = clean,
                                    scale = scale,
                                    topologyType = topologyType,
                                    circleSides = circleSides,
                                    ontology = ontology,
                                    epsilon = epsilon,
                                    angTolerance = angTolerance,
                                    tolerance = tolerance,
                                    silent = silent)

    '''
    @staticmethod
    def ByImportedIPFS(hash_, url, port):
        """
        NOT DONE YET.

        Parameters
        ----------
        hash : TYPE
            DESCRIPTION.
        url : TYPE
            DESCRIPTION.
        port : TYPE
            DESCRIPTION.

        Returns
        -------
        topology : TYPE
            DESCRIPTION.

        """
        # hash, url, port = item
        url = url.replace('http://','')
        url = '/dns/'+url+'/tcp/'+port+'/https'
        client = ipfshttpclient.connect(url)
        brepString = client.cat(hash_).decode("utf-8")
        topology = Topology.ByBREPString(brepString)
        return topology
    '''
    @staticmethod
    def ByJSONFile(file, ontology: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Imports the topology from a JSON file.

        Parameters
        ----------
        file : file object
            The input JSON file.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of imported topologies (Warning: the list could contain 0, 1, or many topologies, but this method will always return a list)

        """
        import json
        if not file:
            if not silent:
                print("Topology.ByJSONFile - Error: the input file parameter is not a valid file. Returning None.")
            return None
        try:
            json_dict = json.load(file)
        except Exception as e:
            if not silent:
                print("Topology.ByJSONFile - Error: Could not load the JSON file: {e}. Returning None.")
            return None
        return Topology.ByJSONDictionary(json_dict, ontology=ontology, tolerance=tolerance, silent=silent)
    
    @staticmethod
    def ByJSONPath(path, ontology: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Imports the topology from a JSON file.

        Parameters
        ----------
        path : str
            The file path to the json file.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of imported topologies.

        """
        import json
        if not path:
            if not silent:
                print("Topology.ByJSONPath - Error: the input path parameter is not a valid path. Returning None.")
            return None
        try:
            with open(path) as file:
                json_dict = json.load(file)
        except Exception as e:
            if not silent:
                print("Topology.ByJSONPath - Error: Could not load file: {e}. Returning None.")
            return None
        return Topology.ByJSONDictionary(json_dict, ontology=ontology, tolerance=tolerance, silent=silent)

    @staticmethod
    def ByJSONDictionary(jsonDictionary: dict, ontology: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Imports the topology from a JSON dictionary.

        Parameters
        ----------
        jsonDictionary : dict
            The input JSON dictionary.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of imported topologies. The list can contain 0, 1, or many topologies,
            but this method always returns a list.
        """
        from collections import defaultdict, deque

        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Cluster import Cluster
        from topologicpy.Dictionary import Dictionary

        if not isinstance(jsonDictionary, list):
            records = [jsonDictionary]
            # if not silent:
            #     print("Topology.ByJSONDictionary - Error: The input JSON dictionary is not a valid list. Returning [].")
            # return []

        records = jsonDictionary
        records_by_uuid = {}
        top_level_uuids = set()
        cluster_key_by_uuid = {}

        # Reverse dependency map:
        # child_uuid -> set(parent_uuid)
        parents_by_child = defaultdict(set)

        for record in records:
            uuid = record.get("uuid", None)
            if uuid is None:
                continue

            records_by_uuid[uuid] = record

            raw_dictionary = record.get("dictionary", {}) or {}
            if raw_dictionary.get("toplevel", None) == 1:
                top_level_uuids.add(uuid)

            cluster_key_by_uuid[uuid] = raw_dictionary.get("__cluster__", "__MISSING__")

            entity_type = record.get("type", None)

            if entity_type == "Edge":
                for child_uuid in record.get("vertices", []):
                    parents_by_child[child_uuid].add(uuid)

            elif entity_type == "Wire":
                for child_uuid in record.get("edges", []):
                    parents_by_child[child_uuid].add(uuid)

            elif entity_type == "Face":
                for child_uuid in record.get("wires", []):
                    parents_by_child[child_uuid].add(uuid)

            elif entity_type == "Shell":
                for child_uuid in record.get("faces", []):
                    parents_by_child[child_uuid].add(uuid)

            elif entity_type == "Cell":
                for child_uuid in record.get("shells", []):
                    parents_by_child[child_uuid].add(uuid)

            elif entity_type == "CellComplex":
                for child_uuid in record.get("cells", []):
                    parents_by_child[child_uuid].add(uuid)

        def _dictionary_from_json(raw_dictionary):
            if not isinstance(raw_dictionary, dict):
                raw_dictionary = {}
            return Dictionary.ByKeysValues(
                keys=list(raw_dictionary.keys()),
                values=list(raw_dictionary.values())
            )

        def _set_dictionary(topology, raw_dictionary):
            dictionary = _dictionary_from_json(raw_dictionary)
            return Topology.SetDictionary(topology, dictionary, silent=silent)

        def _top_level_ancestors(uuid):
            """
            Returns the top-level ancestor UUIDs for the supplied UUID.
            If the UUID itself is top-level, it is returned directly.
            """
            if uuid in top_level_uuids:
                return [uuid]

            result = []
            visited = set()
            queue = deque([uuid])

            while queue:
                current_uuid = queue.popleft()
                if current_uuid in visited:
                    continue
                visited.add(current_uuid)

                for parent_uuid in parents_by_child.get(current_uuid, []):
                    if parent_uuid in top_level_uuids:
                        result.append(parent_uuid)
                    else:
                        queue.append(parent_uuid)

            return result

        vertices = {}
        edges = {}
        wires = {}
        faces = {}
        shells = {}
        cells = {}
        cell_complexes = {}
        created_by_uuid = {}

        # top_level_uuid -> aperture subtopology type -> list of apertures
        apertures_by_top_level = defaultdict(lambda: defaultdict(list))

        def _build_aperture_group(aperture_list, ap_vertices, ap_edges, ap_wires, ap_faces):
            """
            Builds one aperture group and returns only the highest-dimensional aperture
            entities in that group, matching the behaviour of the original method.
            """
            types = {aperture_data.get("type", None) for aperture_data in aperture_list}

            if "Face" in types:
                save_type = "Face"
            elif "Wire" in types:
                save_type = "Wire"
            elif "Edge" in types:
                save_type = "Edge"
            elif "Vertex" in types:
                save_type = "Vertex"
            else:
                return []

            apertures = []

            for aperture_data in aperture_list:
                aperture_type = aperture_data.get("type", None)
                aperture_uuid = aperture_data.get("uuid", None)
                raw_dictionary = aperture_data.get("dictionary", {}) or {}

                if aperture_type == "Vertex":
                    aperture_entity = Vertex.ByCoordinates(*aperture_data["coordinates"])
                    aperture_entity = _set_dictionary(aperture_entity, raw_dictionary)
                    ap_vertices[aperture_uuid] = aperture_entity

                elif aperture_type == "Edge":
                    vertex1 = ap_vertices[aperture_data["vertices"][0]]
                    vertex2 = ap_vertices[aperture_data["vertices"][1]]
                    aperture_entity = Edge.ByVertices([vertex1, vertex2], tolerance=tolerance, silent=silent)
                    aperture_entity = _set_dictionary(aperture_entity, raw_dictionary)
                    ap_edges[aperture_uuid] = aperture_entity

                elif aperture_type == "Wire":
                    aperture_edges = [ap_edges[edge_uuid] for edge_uuid in aperture_data["edges"]]
                    aperture_entity = Wire.ByEdges(aperture_edges, tolerance=tolerance, silent=silent)
                    aperture_entity = _set_dictionary(aperture_entity, raw_dictionary)
                    ap_wires[aperture_uuid] = aperture_entity

                elif aperture_type == "Face":
                    aperture_wires = [ap_wires[wire_uuid] for wire_uuid in aperture_data["wires"]]
                    if len(aperture_wires) > 1:
                        aperture_entity = Face.ByWires(
                            aperture_wires[0],
                            aperture_wires[1:],
                            tolerance=tolerance,
                            silent=silent
                        )
                    else:
                        aperture_entity = Face.ByWire(
                            aperture_wires[0],
                            tolerance=tolerance,
                            silent=silent
                        )
                    aperture_entity = _set_dictionary(aperture_entity, raw_dictionary)
                    ap_faces[aperture_uuid] = aperture_entity

                else:
                    continue

                if aperture_type == save_type:
                    apertures.append(aperture_entity)

            return apertures

        for entity in records:
            entity_type = entity.get("type", None)
            uuid = entity.get("uuid", None)
            raw_dictionary = entity.get("dictionary", {}) or {}

            parent_entity = None

            if entity_type == "Vertex":
                parent_entity = Vertex.ByCoordinates(*entity["coordinates"])
                parent_entity = _set_dictionary(parent_entity, raw_dictionary)
                vertices[uuid] = parent_entity

            elif entity_type == "Edge":
                vertex1 = vertices[entity["vertices"][0]]
                vertex2 = vertices[entity["vertices"][1]]
                parent_entity = Edge.ByVertices([vertex1, vertex2], tolerance=tolerance, silent=silent)
                parent_entity = _set_dictionary(parent_entity, raw_dictionary)
                edges[uuid] = parent_entity

            elif entity_type == "Wire":
                wire_edges = [edges[edge_uuid] for edge_uuid in entity["edges"]]
                parent_entity = Wire.ByEdges(wire_edges, tolerance=tolerance, silent=silent)
                parent_entity = _set_dictionary(parent_entity, raw_dictionary)
                wires[uuid] = parent_entity

            elif entity_type == "Face":
                face_wires = [wires[wire_uuid] for wire_uuid in entity["wires"]]
                if len(face_wires) > 1:
                    parent_entity = Face.ByWires(face_wires[0], face_wires[1:], tolerance=tolerance, silent=silent)
                else:
                    parent_entity = Face.ByWire(face_wires[0], tolerance=tolerance, silent=silent)
                parent_entity = _set_dictionary(parent_entity, raw_dictionary)
                faces[uuid] = parent_entity

            elif entity_type == "Shell":
                shell_faces = [faces[face_uuid] for face_uuid in entity["faces"]]
                parent_entity = Shell.ByFaces(shell_faces, tolerance=tolerance, silent=silent)
                parent_entity = _set_dictionary(parent_entity, raw_dictionary)
                shells[uuid] = parent_entity

            elif entity_type == "Cell":
                cell_shells = [shells[shell_uuid] for shell_uuid in entity["shells"]]
                if len(cell_shells) > 1:
                    parent_entity = Cell.ByShells(cell_shells[0], cell_shells[1:], tolerance=tolerance, silent=silent)
                else:
                    parent_entity = Cell.ByShell(cell_shells[0])
                parent_entity = _set_dictionary(parent_entity, raw_dictionary)
                cells[uuid] = parent_entity

            elif entity_type == "CellComplex":
                complex_cells = [cells[cell_uuid] for cell_uuid in entity["cells"]]
                parent_entity = CellComplex.ByCells(complex_cells)
                parent_entity = _set_dictionary(parent_entity, raw_dictionary)
                cell_complexes[uuid] = parent_entity

            else:
                continue

            created_by_uuid[uuid] = parent_entity

            # Build apertures, but do not globally apply them to every top-level topology.
            if "apertures" in entity:
                if entity_type in ("Vertex", "Edge", "Face"):
                    sub_topology_type = entity_type
                    owner_top_level_uuids = _top_level_ancestors(uuid)

                    if owner_top_level_uuids:
                        ap_vertices = {}
                        ap_edges = {}
                        ap_wires = {}
                        ap_faces = {}

                        for aperture_list in entity["apertures"]:
                            apertures = _build_aperture_group(
                                aperture_list,
                                ap_vertices,
                                ap_edges,
                                ap_wires,
                                ap_faces
                            )

                            if apertures:
                                for top_level_uuid in owner_top_level_uuids:
                                    apertures_by_top_level[top_level_uuid][sub_topology_type].extend(apertures)

        # Apply apertures once, and only to the top-level topology that owns them.
        top_level_topologies_by_uuid = {}

        for uuid in top_level_uuids:
            topology = created_by_uuid.get(uuid, None)
            if topology is None:
                continue

            aperture_groups = apertures_by_top_level.get(uuid, None)

            if aperture_groups:
                face_apertures = aperture_groups.get("Face", [])
                edge_apertures = aperture_groups.get("Edge", [])
                vertex_apertures = aperture_groups.get("Vertex", [])

                if face_apertures:
                    topology = Topology.AddApertures(
                        topology,
                        face_apertures,
                        subTopologyType="Face",
                        tolerance=tolerance
                    )

                if edge_apertures:
                    topology = Topology.AddApertures(
                        topology,
                        edge_apertures,
                        subTopologyType="Edge",
                        tolerance=0.001
                    )

                if vertex_apertures:
                    topology = Topology.AddApertures(
                        topology,
                        vertex_apertures,
                        subTopologyType="Vertex",
                        tolerance=0.001
                    )

            top_level_topologies_by_uuid[uuid] = topology

        # Group directly from the raw JSON dictionary instead of traversing Topologic
        # dictionaries again through Topology.BinByDictionaryKey.
        bins = defaultdict(list)

        for uuid, topology in top_level_topologies_by_uuid.items():
            cluster_key = cluster_key_by_uuid.get(uuid, "__MISSING__")
            bins[cluster_key].append(topology)

        return_topologies = []

        for key, topologies in bins.items():
            if key == "__MISSING__":
                return_topologies.extend(topologies)
            else:
                cluster = Cluster.ByTopologies(topologies)
                return_topologies.append(cluster)

        return Topology._OntologyAnnotateList(return_topologies, ontology=ontology, generatedBy="Topology.ByJSONDictionary", annotateSubtopologies=True, silent=True)
    
    @staticmethod
    def ByJSONString(string: str, ontology: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Imports the topology from a JSON string.

        Parameters
        ----------
        string : str
            The input JSON string.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of imported topologies (Warning: the list could contain 0, 1, or many topologies, but this method will always return a list)

        """
        import inspect
        try:
            json_dict = json.loads(string)
        except Exception as e:
            if not silent:
                print(f"Topology.ByJSONString - Error: Could not read the input string: {e}. Returning None.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return None 
        return Topology.ByJSONDictionary(json_dict, tolerance=tolerance, ontology=ontology, silent=silent)

    @staticmethod
    def ByMeshData(dictionary,
                   transferDictionaries: bool = False,
                   ontology: bool = False,
                   mantissa: int = 6,
                   tolerance: float = 0.0001,
                   silent: bool = False):
        """
        Create a cluster by the input python dictionary of vertices, edges, faces, and cells.

        Parameters
        ----------
        dictionary : dict
            The input python dictionary of vertices, edges, faces, and cells in the form of:
            { 'mode': int,  The expected mode of input face data:
                                0: The faces list is indexed into the vertices list.
                                1: The faces list is indexesd into the edges list.
            'vertices': list, (list of coordinates)
            'edges': list,   (list of indices into the list of vertices)
            'faces': list,   (list of indices into the list of edges)
            'cells': list,   (list of indices into the list of faces)
            'vertex_dict': list of dicts,
            'edge_dicts': list of dicts,
            'face_dicts', list of dicts,
            'cell_dicts', list of dicts
            }
        transferDictionaries : bool , optional
            If set to True, the python dictionaries will be transferred to the coorespoding topologies. Default is False.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cluster
            The created cluster of vertices, edges, faces, and cells.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Cell import Cell
        from topologicpy.Cluster import Cluster
        from topologicpy.Dictionary import Dictionary
        from topologicpy.Helper import Helper

        if not type(dictionary) == type({}):
            if not silent:
                print("Topology.ByMeshData - Error: The input dictionary parameter is not a valid dictionary. Returning None.")
            return None
        
        vertices = dictionary.get('vertices', [])
        edges = dictionary.get('edges', [])
        faces = dictionary.get('faces', [])
        cells = dictionary.get('cells', [])
        if not 'mode' in dictionary.keys():
            mode = 0
        else:
            mode = dictionary.get('mode', 0)
        if transferDictionaries == True:
            vertex_dicts = dictionary.get('vertex_dicts', [{}]*len(vertices))
            edge_dicts = dictionary.get('edge_dicts', [{}]*len(edges))
            face_dicts = dictionary. get('face_dicts', [{}]*len(faces))
            cell_dicts = dictionary.get('cell_dicts', [{}]*len(cells))
        else:
            vertex_dicts = [{}]*len(vertices)
            edge_dicts = [{}]*len(edges)
            face_dicts = [{}]*len(faces)
            cell_dicts = [{}]*len(cells)
                
        top_verts = []
        for i, vertex in enumerate(vertices):
            top_vertex = Vertex.ByCoordinates(round(vertex[0], mantissa), round(vertex[1], mantissa), round(vertex[2], mantissa))
            if Topology.IsInstance(top_vertex, "Vertex"):
                if transferDictionaries:
                    d = Dictionary.ByPythonDictionary(vertex_dicts[i])
                    top_vertex = Topology.SetDictionary(top_vertex, d, silent=True)
                top_verts.append(top_vertex)
        
        top_edges = []
        for i, edge in enumerate(edges):
            top_edge = Edge.ByVertices(top_verts[edge[0]], top_verts[edge[1]], tolerance=tolerance, silent=silent)
            if Topology.IsInstance(top_edge, "Edge"):
                if transferDictionaries:
                    d = Dictionary.ByPythonDictionary(edge_dicts[i])
                    top_edge = Topology.SetDictionary(top_edge, d, silent=True)
                top_edges.append(top_edge)
        
        top_faces = []
        for i, face in enumerate(faces):
            if mode == 0:
                face_vertices = [top_verts[v] for v in face]
                top_face = Face.ByVertices(face_vertices, tolerance=tolerance, silent=silent)
                if not top_face:
                    temp_wire = Wire.ByVertices(top_face, tolerance=tolerance, silent=silent)
                    temp = Face.ByWire(temp_wire, tolerance=tolerance, silent=silent)
                    if isinstance(temp, list):
                        for temp_face in temp:
                            if transferDictionaries:
                                d = Dictionary.ByPythonDictionary(face_dicts[i])
                                temp_face = Topology.SetDictionary(temp_face, d, silent=True)
                                top_faces.append(temp_face)
            else:
                face_edges = [top_edges[e] for e in face]
                top_face = Face.ByEdges(face_edges, tolerance=tolerance, silent=silent)
            if Topology.IsInstance(top_face, "Face"):
                if transferDictionaries:
                    d = Dictionary.ByPythonDictionary(face_dicts[i])
                    top_face = Topology.SetDictionary(top_face, d, silent=True)
                top_faces.append(top_face)

        top_cells = []
        for i, cell in enumerate(cells):
            cell_faces = [top_faces[f] for f in cell]
            top_cell = Cell.ByFaces(cell_faces, tolerance=tolerance, silent=silent)
            if Topology.IsInstance(top_cell, "Cell"):
                if transferDictionaries:
                    d = Dictionary.ByPythonDictionary(cell_dicts[i])
                    top_cell = Topology.SetDictionary(top_cell, d, silent=True)
                top_cells.append(top_cell)
        
        return Topology._OntologyAnnotate(Cluster.ByTopologies(top_verts+top_edges+top_faces+top_cells), ontology=ontology, generatedBy="Topology.ByMeshData", annotateSubtopologies=True, silent=True)

    @staticmethod
    def ByOBJFile(objFile, mtlFile = None,
                defaultColor: list = [255,255,255],
                defaultOpacity: float = 1.0,
                transposeAxes: bool = True,
                removeCoplanarFaces: bool = False,
                selfMerge: bool = True,
                ontology: bool = False,
                mantissa : int = 6,
                tolerance: float = 0.0001):
        """
        Imports a topology from an OBJ file and an associated materials file.
        This method is basic and does not support textures and vertex normals.

        Parameters
        ----------
        objFile : file object
            The OBJ file.
        mtlFile : file object , optional
            The MTL file. Default is None.
        defaultColor : list , optional
            The default color to use if none is specified in the file. Default is [255, 255, 255] (white).
        defaultOpacity : float , optional
            The default opacity to use if none is specified in the file. Default is 1.0 (fully opaque).
        transposeAxes : bool , optional
            If set to True the Z and Y axes are transposed. Otherwise, they are not. Default is True.
        removeCoplanarFaces : bool , optional
            If set to True, coplanar faces are merged. Default is True.
        selfMerge : bool , optional
            If set to True, the faces of the imported topologies will each be self-merged to create higher-dimensional objects. Otherwise, they remain a cluster of faces. Default is False.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001

        Returns
        -------
        list
            The imported topologies.

        """
        from os.path import dirname, join, exists


        def find_next_word_after_mtllib(text):
            words = text.split()
            for i, word in enumerate(words):
                if word == 'mtllib' and i + 1 < len(words):
                    return words[i + 1]
            return None

        obj_string = objFile.read()
        mtl_filename = find_next_word_after_mtllib(obj_string)
        mtl_string = None
        if mtlFile:
            mtl_string = mtlFile.read()
        return Topology.ByOBJString(obj_string,
                                    mtl_string,
                                    defaultColor = defaultColor,
                                    defaultOpacity = defaultOpacity,
                                    transposeAxes = transposeAxes,
                                    removeCoplanarFaces = removeCoplanarFaces,
                                    selfMerge = selfMerge,
                                    ontology = ontology,
                                    mantissa = mantissa,
                                    tolerance = tolerance)

    @staticmethod
    def ByOBJPath(objPath,
                  defaultColor: list = [255,255,255],
                  defaultOpacity: float = 1.0,
                  transposeAxes: bool = True,
                  removeCoplanarFaces: bool = False,
                  selfMerge: bool = False,
                  ontology: bool = False,
                  mantissa : int = 6,
                  tolerance: float = 0.0001):
        """
        Imports a topology from an OBJ file path and an associated materials file.
        This method is basic and does not support textures and vertex normals.

        Parameters
        ----------
        objPath : str
            The path to the OBJ file.
        defaultColor : list , optional
            The default color to use if none is specified in the file. Default is [255, 255, 255] (white).
        defaultOpacity : float , optional
            The default opacity to use if none is specified in the file. Default is 1.0 (fully opaque).
        transposeAxes : bool , optional
            If set to True the Z and Y axes are transposed. Otherwise, they are not. Default is True.
        removeCoplanarFaces : bool , optional
            If set to True, coplanar faces are merged. Default is True.
        selfMerge : bool , optional
            If set to True, the faces of the imported topologies will each be self-merged to create higher-dimensional objects. Otherwise, they remain a cluster of faces. Default is False.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001

        Returns
        -------
        list
            The imported topologies.

        """
        from os.path import dirname, join, exists

        if not objPath:
            print("Topology.ByOBJPath - Error: the input OBJ path parameter is not a valid path. Returning None.")
            return None
        if not exists(objPath):
            print("Topology.ByOBJPath - Error: the input OBJ path does not exist. Returning None.")
            return None

        def find_next_word_after_mtllib(text):
            words = text.split()
            for i, word in enumerate(words):
                if word == 'mtllib' and i + 1 < len(words):
                    return words[i + 1]
            return None

        with open(objPath, 'r') as obj_file:
            obj_string = obj_file.read()
            mtl_filename = find_next_word_after_mtllib(obj_string)
            mtl_string = None
            if mtl_filename:
                parent_folder = dirname(objPath)
                mtl_path = join(parent_folder, mtl_filename)
                if exists(mtl_path):
                    with open(mtl_path, 'r') as mtl_file:
                        mtl_string = mtl_file.read()
        return Topology.ByOBJString(obj_string,
                                    mtl_string,
                                    defaultColor=defaultColor,
                                    defaultOpacity=defaultOpacity,
                                    transposeAxes=transposeAxes,
                                    removeCoplanarFaces=removeCoplanarFaces,
                                    selfMerge = selfMerge,
                                    ontology = ontology,
                                    mantissa=mantissa,
                                    tolerance=tolerance)

    @staticmethod
    def ByOBJString(objString: str,
                    mtlString: str = None,
                    defaultColor=None,
                    defaultOpacity: float = 1.0,
                    transposeAxes: bool = True,
                    removeCoplanarFaces: bool = False,
                    selfMerge: bool = False,
                    ontology: bool = False,
                    mantissa: int = 6,
                    tolerance: float = 0.0001):
        """
        Imports a TopologicPy hierarchy from OBJ and optional MTL strings.

        Supported OBJ primitives
        - v   : vertices
        - l   : polylines (edges-only / wire-only models)
        - f   : faces (tri/quad/ngon; may be self-merged)
        - p   : points

        Grouping
        - g / o : groups/objects become separate returned topologies (one per group/object)

        Materials
        - usemtl + MTL Kd/d/Tr are used to set:
            color   : [R,G,B] in 0..255
            opacity : 0..1

        Parameters
        ----------
        objString : str
            The OBJ file contents as a string.
        mtlString : str , optional
            The MTL file contents as a string.
        defaultColor : list , optional
            The default color to use if none is specified in the file.
            Default is [255, 255, 255].
        defaultOpacity : float , optional
            The default opacity to use if none is specified in the file.
            Default is 1.0.
        transposeAxes : bool , optional
            If set to True, converts OBJ coordinates from (x, y, z) to (x, -z, y).
            Default is True.
        removeCoplanarFaces : bool , optional
            If set to True, coplanar faces are merged. Default is False.
        selfMerge : bool , optional
            If set to True, imported face clusters are self-merged. Default is False.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        mantissa : int , optional
            The number of decimal places to round coordinates to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.

        Returns
        -------
        list
            One TopologicPy topology per OBJ group/object:
            - If a group has faces: returns a Cluster of faces, or a self-merged topology.
            - Else if a group has polylines/edges: returns a Cluster of Wires/Edges.
            - Else if a group has only points: returns a Cluster of Vertices.
            - If mixed: returns a Cluster containing the appropriate mix.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Cluster import Cluster
        from topologicpy.Dictionary import Dictionary
        from topologicpy.Topology import Topology

        if defaultColor is None:
            defaultColor = [255, 255, 255]

        # -------------------------------------------------------------------------
        # Cache TopologicPy method lookups
        # -------------------------------------------------------------------------
        Vertex_ByCoordinates = Vertex.ByCoordinates
        Edge_ByVertices = Edge.ByVertices
        Wire_ByVertices = Wire.ByVertices
        Cluster_ByTopologies = Cluster.ByTopologies
        Dictionary_ByKeysValues = Dictionary.ByKeysValues
        Topology_ByGeometry = Topology.ByGeometry
        Topology_SetDictionary = Topology.SetDictionary
        Topology_SelfMerge = Topology.SelfMerge

        # -------------------------------------------------------------------------
        # MTL parsing
        # -------------------------------------------------------------------------
        def _clamp01(x):
            if x < 0.0:
                return 0.0
            if x > 1.0:
                return 1.0
            return x

        def _load_materials(mtl_string):
            materials = {}
            if not mtl_string:
                return materials

            current = None

            for raw in mtl_string.splitlines():
                if not raw:
                    continue

                line = raw.strip()
                if not line or line[0] == "#":
                    continue

                parts = line.split()
                if not parts:
                    continue

                tag = parts[0]

                if tag == "newmtl" and len(parts) > 1:
                    current = parts[1]
                    materials[current] = {}
                    continue

                if current is None:
                    continue

                mat = materials[current]

                try:
                    if tag in ("Kd", "Ka", "Ks") and len(parts) >= 4:
                        mat[tag] = [float(parts[1]), float(parts[2]), float(parts[3])]

                    elif tag == "Ns" and len(parts) >= 2:
                        mat["Ns"] = float(parts[1])

                    elif tag == "d" and len(parts) >= 2:
                        mat["d"] = float(parts[1])

                    elif tag == "Tr" and len(parts) >= 2:
                        mat["d"] = 1.0 - float(parts[1])

                    elif tag == "map_Kd" and len(parts) >= 2:
                        mat["map_Kd"] = " ".join(parts[1:])

                except Exception:
                    continue

            return materials

        materials = _load_materials(mtlString)

        material_cache = {}

        def _material_to_color_opacity(mat_name):
            if mat_name in material_cache:
                return material_cache[mat_name]

            color = defaultColor
            opacity = defaultOpacity

            if mat_name and mat_name in materials:
                m = materials[mat_name]

                kd = m.get("Kd", None)
                if isinstance(kd, list) and len(kd) >= 3:
                    color = [
                        int(round(_clamp01(kd[0]) * 255.0, 0)),
                        int(round(_clamp01(kd[1]) * 255.0, 0)),
                        int(round(_clamp01(kd[2]) * 255.0, 0)),
                    ]

                if "d" in m:
                    try:
                        opacity = float(m["d"])
                    except Exception:
                        opacity = defaultOpacity

            result = (color, opacity)
            material_cache[mat_name] = result
            return result

        # -------------------------------------------------------------------------
        # Dictionary caching
        # -------------------------------------------------------------------------
        dict_cache = {}

        def _dictionary_for(group_name, mat_name):
            key = (group_name, mat_name)
            d = dict_cache.get(key, None)
            if d is not None:
                return d

            color, opacity = _material_to_color_opacity(mat_name)
            d = Dictionary_ByKeysValues(
                ["name", "group", "material", "color", "opacity"],
                [group_name, group_name, mat_name if mat_name else "", color, opacity]
            )
            dict_cache[key] = d
            return d

        def _set_dict(topo, group_name, mat_name):
            return Topology_SetDictionary(topo, _dictionary_for(group_name, mat_name))

        # -------------------------------------------------------------------------
        # OBJ parsing
        # -------------------------------------------------------------------------
        verts_xyz = []
        groups = {}

        current_group = "default"
        current_material = None

        def _new_group_record():
            return {"faces": [], "lines": [], "points": []}

        def _ensure_group(name):
            if not name:
                name = "default"
            if name not in groups:
                groups[name] = _new_group_record()
            return name

        current_group = _ensure_group(current_group)
        current_rec = groups[current_group]

        def _resolve_index(idx, n):
            z = idx - 1 if idx > 0 else n + idx
            if z < 0 or z >= n:
                return None
            return z

        do_round = isinstance(mantissa, int)

        for raw in objString.splitlines():
            if not raw:
                continue

            c0 = raw[0]

            if c0 == "#":
                continue

            # ---------------------------------------------------------------------
            # Vertex: v x y z
            # Avoids matching vt and vn.
            # ---------------------------------------------------------------------
            if c0 == "v" and len(raw) > 1 and raw[1].isspace():
                parts = raw.split()
                if len(parts) < 4:
                    continue

                try:
                    x = float(parts[1])
                    y = float(parts[2])
                    z = float(parts[3])
                except Exception:
                    continue

                if do_round:
                    x = round(x, mantissa)
                    y = round(y, mantissa)
                    z = round(z, mantissa)

                if transposeAxes:
                    verts_xyz.append([x, -z, y])
                else:
                    verts_xyz.append([x, y, z])

            # ---------------------------------------------------------------------
            # Face: f v1 v2 v3 ...
            # Supports v, v/vt, v//vn, v/vt/vn.
            # Stores only resolved vertex indices.
            # ---------------------------------------------------------------------
            elif c0 == "f" and len(raw) > 1 and raw[1].isspace():
                parts = raw.split()
                if len(parts) < 4:
                    continue

                n_verts = len(verts_xyz)
                idxs = []
                ok = True

                for token in parts[1:]:
                    slash = token.find("/")
                    if slash >= 0:
                        token = token[:slash]

                    if not token:
                        ok = False
                        break

                    try:
                        vi = _resolve_index(int(token), n_verts)
                    except Exception:
                        ok = False
                        break

                    if vi is None:
                        ok = False
                        break

                    idxs.append(vi)

                if ok and len(idxs) >= 3:
                    current_rec["faces"].append((idxs, current_material))

            # ---------------------------------------------------------------------
            # Line/polyline: l v1 v2 ...
            # Supports v and v/vt.
            # ---------------------------------------------------------------------
            elif c0 == "l" and len(raw) > 1 and raw[1].isspace():
                parts = raw.split()
                if len(parts) < 3:
                    continue

                n_verts = len(verts_xyz)
                idxs = []
                ok = True

                for token in parts[1:]:
                    slash = token.find("/")
                    if slash >= 0:
                        token = token[:slash]

                    if not token:
                        ok = False
                        break

                    try:
                        vi = _resolve_index(int(token), n_verts)
                    except Exception:
                        ok = False
                        break

                    if vi is None:
                        ok = False
                        break

                    idxs.append(vi)

                if ok and len(idxs) >= 2:
                    current_rec["lines"].append((idxs, current_material))

            # ---------------------------------------------------------------------
            # Point list: p v1 v2 ...
            # ---------------------------------------------------------------------
            elif c0 == "p" and len(raw) > 1 and raw[1].isspace():
                parts = raw.split()
                if len(parts) < 2:
                    continue

                n_verts = len(verts_xyz)

                for token in parts[1:]:
                    try:
                        vi = _resolve_index(int(token), n_verts)
                    except Exception:
                        vi = None

                    if vi is not None:
                        current_rec["points"].append((vi, current_material))

            # ---------------------------------------------------------------------
            # Object/group: o name / g name
            # ---------------------------------------------------------------------
            elif (c0 == "g" or c0 == "o") and len(raw) > 1 and raw[1].isspace():
                parts = raw.split()
                name = " ".join(parts[1:]).strip() if len(parts) > 1 else "default"
                current_group = _ensure_group(name)
                current_rec = groups[current_group]

            # ---------------------------------------------------------------------
            # Material switch: usemtl material_name
            # ---------------------------------------------------------------------
            elif raw.startswith("usemtl") and (len(raw) == 6 or raw[6].isspace()):
                parts = raw.split(maxsplit=1)
                current_material = parts[1].strip() if len(parts) > 1 else None

            # ---------------------------------------------------------------------
            # Ignore mtllib, vt, vn, s, comments with leading whitespace, etc.
            # ---------------------------------------------------------------------
            else:
                stripped = raw.lstrip()
                if not stripped or stripped[0] == "#":
                    continue

        if not groups:
            _ensure_group("default")

        # -------------------------------------------------------------------------
        # Build Topologic hierarchy
        # -------------------------------------------------------------------------
        imported = []
        merge_faces = bool(selfMerge or removeCoplanarFaces)

        for group_name, rec in groups.items():
            faces_rec = rec["faces"]
            lines_rec = rec["lines"]
            points_rec = rec["points"]

            topologies = []

            # ---------------------------------------------------------------------
            # Faces
            #
            # IMPORTANT SPEED CHANGE:
            # Each face is built using only its local vertices rather than passing
            # the full OBJ vertex list to Topology.ByGeometry for every face.
            # ---------------------------------------------------------------------
            if faces_rec:
                face_topos = []

                for face_indices, mat in faces_rec:
                    try:
                        local_vertices = [verts_xyz[i] for i in face_indices]
                        local_face = list(range(len(local_vertices)))

                        topo_face = Topology_ByGeometry(
                            vertices=local_vertices,
                            edges=[],
                            faces=[local_face]
                        )
                    except Exception:
                        topo_face = None

                    if topo_face is None:
                        continue

                    topo_face = _set_dict(topo_face, group_name, mat)
                    face_topos.append(topo_face)

                if face_topos:
                    face_cluster = Cluster_ByTopologies(face_topos)
                    face_cluster = _set_dict(face_cluster, group_name, faces_rec[0][1])

                    if merge_faces:
                        try:
                            merged = Topology_SelfMerge(face_cluster, tolerance=tolerance)
                        except Exception:
                            merged = None

                        if merged is not None:
                            face_cluster = _set_dict(merged, group_name, faces_rec[0][1])

                    topologies.append(face_cluster)

            # ---------------------------------------------------------------------
            # Lines / Wires / Edges
            # ---------------------------------------------------------------------
            if lines_rec:
                line_topos = []
                vertex_cache = {}

                def _vertex_at_index(i):
                    v = vertex_cache.get(i, None)
                    if v is not None:
                        return v
                    v = Vertex_ByCoordinates(*verts_xyz[i])
                    vertex_cache[i] = v
                    return v

                for idxs, mat in lines_rec:
                    try:
                        v_objs = [_vertex_at_index(i) for i in idxs]

                        if len(v_objs) == 2:
                            topo = Edge_ByVertices(
                                v_objs[0],
                                v_objs[1],
                                tolerance=tolerance
                            )
                        else:
                            topo = Wire_ByVertices(
                                v_objs,
                                close=False,
                                tolerance=tolerance
                            )

                    except Exception:
                        topo = None

                    if topo is None:
                        continue

                    topo = _set_dict(topo, group_name, mat)
                    line_topos.append(topo)

                if line_topos:
                    line_cluster = Cluster_ByTopologies(line_topos)
                    line_cluster = _set_dict(line_cluster, group_name, lines_rec[0][1])
                    topologies.append(line_cluster)

            # ---------------------------------------------------------------------
            # Explicit OBJ points
            # ---------------------------------------------------------------------
            if points_rec:
                point_topos = []
                vertex_cache = {}

                for vi, mat in points_rec:
                    try:
                        v = vertex_cache.get(vi, None)
                        if v is None:
                            v = Vertex_ByCoordinates(*verts_xyz[vi])
                            vertex_cache[vi] = v

                        v = _set_dict(v, group_name, mat)
                        point_topos.append(v)

                    except Exception:
                        continue

                if point_topos:
                    point_cluster = Cluster_ByTopologies(point_topos)
                    point_cluster = _set_dict(point_cluster, group_name, points_rec[0][1])
                    topologies.append(point_cluster)

            # ---------------------------------------------------------------------
            # Original fallback:
            # If this group has no faces/lines/points but the OBJ has vertices,
            # return all vertices as a cluster.
            # ---------------------------------------------------------------------
            if not topologies and verts_xyz:
                all_vs = []

                for xyz in verts_xyz:
                    try:
                        all_vs.append(Vertex_ByCoordinates(*xyz))
                    except Exception:
                        continue

                if all_vs:
                    v_cluster = Cluster_ByTopologies(all_vs)
                    v_cluster = _set_dict(v_cluster, group_name, None)
                    topologies.append(v_cluster)

            # ---------------------------------------------------------------------
            # Decide group output
            # ---------------------------------------------------------------------
            if not topologies:
                continue

            if len(topologies) == 1:
                group_topo = topologies[0]
            else:
                group_topo = Cluster_ByTopologies(topologies)

                hint_mat = None
                if faces_rec:
                    hint_mat = faces_rec[0][1]
                elif lines_rec:
                    hint_mat = lines_rec[0][1]
                elif points_rec:
                    hint_mat = points_rec[0][1]

                group_topo = _set_dict(group_topo, group_name, hint_mat)

            imported.append(group_topo)
        return Topology._OntologyAnnotateList(imported, ontology=ontology, generatedBy="Topology.ByOBJString", annotateSubtopologies=True, silent=True)

    @staticmethod
    def ByOCCTShape(occtShape, ontology: bool = False, silent: bool = False):
        """
        Creates a topology from the input OCCT shape. See https://dev.opencascade.org/doc/overview/html/occt_user_guides__modeling_data.html.

        Parameters
        ----------
        occtShape : topologic_core.TopoDS_Shape
            The inoput OCCT Shape.

        Returns
        -------
        topologic_core.Topology
            The created topology.

        """
        topology = Core.Topology.ByOcctShape(occtShape, "")
        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.ByOCCTShape - Error: Could not create the topology. Returning None")
            return None
        return Topology._OntologyAnnotate(topology, ontology=ontology, generatedBy="Topology.ByOOCTShape", annotateSubtopologies=True, silent=True)

    @staticmethod
    def ByPDFFile(file,
                  wires=False,
                  faces=False,
                  includeTypes: list = [],
                  excludeTypes: list = [],
                  edgeColorKey: str = "edge_color",
                  edgeWidthKey: str = "edge_width",
                  faceColorKey: str = "face_color",
                  faceOpacityKey: str = "face_opacity",
                  ontology: bool = False,
                  tolerance=0.0001,
                  silent=False):
        """
        Import PDF file and convert its entities to topologies.

        Parameters
        ----------
        file : file
            The input PDF file
        wires : bool , optional
            If set to True, wires will be constructed when possible. Default is True.
        faces : bool , optional
            If set to True, faces will be constructed when possible. Default is True.
        includeTypes : list , optional
            A list of PDF object types to include in the returned result. Default is [] which means all PDF objects will be included.
            The possible strings to include in this list are: ["line", "curve", "rectangle", "quadrilateral"]
        excludeTypes : list , optional
            A list of PDF object types to exclude from the returned result. Default is [] which mean no PDF object type will be excluded.
            The possible strings to include in this list are: ["line", "curve", "rectangle", "quadrilateral"]
        edgeColorKey : str , optional
            The dictionary key under which to store the edge color. Default is None.
        edgeWidthKey : str , optional
            The dictionary key under which to store the edge width. Default is None.
        faceColorKey : str , optional
            The dictionary key under which to store the face color. Default is None.
        faceOpacityKey : str , optional
            The dictionary key under which to store the face opacity. Default is None.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
        A list of Topologic entities (edges, wires, faces, clusters) with attached dictionaries.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Cluster import Cluster
        from topologicpy.Dictionary import Dictionary
        import os
        import warnings

        def interpolate_bezier(control_points, num_points=50):
            """
            Interpolate a cubic Bezier curve given control points.

            Args:
                control_points (list): List of control points (pymupdf.Point objects).
                num_points (int): Number of points to interpolate along the curve.

            Returns:
                list: A list of interpolated points (pymupdf.Point objects).
            """
            p0, p1, p2, p3 = control_points
            points = [
                pymupdf.Point(
                    (1 - t)**3 * p0.x + 3 * (1 - t)**2 * t * p1.x + 3 * (1 - t) * t**2 * p2.x + t**3 * p3.x,
                    (1 - t)**3 * p0.y + 3 * (1 - t)**2 * t * p1.y + 3 * (1 - t) * t**2 * p2.y + t**3 * p3.y
                )
                for t in (i / num_points for i in range(num_points + 1))
            ]
            return points

        def map_types(type_list):
            type_mapping = {
                "line": "l",
                "curve": "c",
                "rect": "re",
                "quad": "qu"
            }
            return [type_mapping[key] for key in type_mapping if any(key in item for item in type_list)]

        def remove_overlap(list1, list2):
            set1, set2 = set(list1), set(list2)
            # Remove common elements from both sets
            set1 -= set2
            set2 -= set(list1)
            return list(set1), list(set2)
        
        try:
            import pymupdf  # PyMuPDF
        except:
            if not silent:
                print("Topology.ByPDFFile - Warning: Installing required PyMuPDF library.")
            try:
                os.system("pip install PyMuPDF")
            except:
                os.system("pip install PyMuPDF --user")
            try:
                import pymupdf
                if not silent:
                    print("Topology.ByPDFFile - Information: PyMUDF library installed correctly.")
            except:
                if not silent:
                    warnings.warn("Topology.ByPDFFile - Error: Could not import PyMuPDF. Please try to install PyMuPDF manually. Returning None.")
                return None
        if not file:
            if not silent:
                print("Topology.ByPDFFile - Error: Could not open the PDF file. Returning None.")
            return None
        
        if includeTypes == None:
            includeTypes = []
        if excludeTypes == None:
            excludeTypes = []
        includeTypes = [item for item in includeTypes if isinstance(item, str)]
        excludeTypes = [item for item in excludeTypes if isinstance(item, str)]
        in_types = map_types([c.lower() for c in includeTypes])
        ex_types = map_types([c.lower() for c in excludeTypes])
        in_types_1, ex_types_1 = remove_overlap(in_types, ex_types)
        if not len(in_types_1) == len(in_types) or not len(ex_types_1) == len(ex_types):
            if not silent:
                print("Topology.ByPDFFile - Warning: The includeTypes and excludeTypes input parameters contain overlapping elements. These have been excluded.")
        in_types = in_types_1

        topologic_entities = []
        for page_num, page in enumerate(file, 1):
            matrix = pymupdf.Matrix(1, 1)  # Identity matrix for default transformation
            paths = page.get_drawings()
            for path in paths:
                if not path.get("stroke_opacity") == 0:
                    close = path.get("closePath")
                    components = []
                    edge_color = path.get("color", [0, 0, 0]) or [0, 0, 0]
                    edge_color = [int(255 * c) for c in edge_color] # Convert stroke color to 0-255 range
                    edge_width = path.get("width", 1) or 1
                    face_color = path.get("fill", [1, 1, 1]) or [1,1,1]
                    face_color = [int(255 * c) for c in face_color]
                    face_opacity = path.get("fill_opacity", 1) or 1

                    # Create the dictionary for line width, color, fill color, and fill opacity
                    keys = [edgeWidthKey, edgeColorKey, faceColorKey, faceOpacityKey]
                    values = [
                        edge_width,
                        edge_color,  # Convert stroke color to 0-255 range
                        face_color,     # Convert fill color to 0-255 range
                        face_opacity
                    ]
                    dictionary = Dictionary.ByKeysValues(keys, values)
                    items = path.get("items") or []
                    for it, item in enumerate(items):
                        if (item[0] in in_types or len(in_types) == 0) and (not item[0] in ex_types):
                            if item[0] == "l":  # Line
                                start_point = pymupdf.Point(item[1][0], item[1][1]).transform(matrix)
                                end_point = pymupdf.Point(item[2][0], item[2][1]).transform(matrix)
                                start_vertex = Vertex.ByCoordinates(start_point.x, -start_point.y, 0)
                                end_vertex = Vertex.ByCoordinates(end_point.x, -end_point.y, 0)
                                d = Vertex.Distance(start_vertex, end_vertex)
                                if d > tolerance:
                                    edge = Edge.ByStartVertexEndVertex(start_vertex, end_vertex, tolerance=tolerance, silent=silent)
                                    if not edge == None:
                                        edge = Topology.SetDictionary(edge, dictionary)  # Set dictionary
                                        components.append(edge)
                                if it == 0:
                                    v_f_p = pymupdf.Point(item[1][0], item[1][1]).transform(matrix)
                                    very_first_vertex = Vertex.ByCoordinates(v_f_p.x, -v_f_p.y, 0)
                                if it == len(items)-1 and path.get("closePath", False) == True:
                                    v_l_p = pymupdf.Point(item[2][0], item[2][1]).transform(matrix)
                                    very_last_vertex = Vertex.ByCoordinates(v_l_p.x, -v_l_p.y, 0)
                                    edge = Edge.ByStartVertexEndVertex(very_last_vertex, very_first_vertex, tolerance=tolerance, silent=True)
                                    if not edge == None:
                                        edge = Topology.SetDictionary(edge, dictionary)  # Set dictionary
                                        components.append(edge)
                                
                            elif item[0] == "c":  # Bezier curve (approximated by segments)
                                control_points = [pymupdf.Point(p[0], p[1]).transform(matrix) for p in item[1:]]
                                bezier_points = interpolate_bezier(control_points)
                                vertices = [Vertex.ByCoordinates(pt.x, -pt.y, 0) for pt in bezier_points]
                                for i in range(len(vertices)-1):
                                    start_vertex = vertices[i]
                                    end_vertex = vertices[i+1]
                                    edge = Edge.ByStartVertexEndVertex(start_vertex, end_vertex, tolerance=tolerance, silent=False)
                                    if not edge == None:
                                        edge = Topology.SetDictionary(edge, dictionary)  # Set dictionary
                                        components.append(edge)
                            elif item[0] == "re":  # Rectangle
                                x0, y0, x1, y1 = item[1]
                                vertices = [
                                    Vertex.ByCoordinates(x0, -y0, 0),
                                    Vertex.ByCoordinates(x1, -y0, 0),
                                    Vertex.ByCoordinates(x1, -y1, 0),
                                    Vertex.ByCoordinates(x0, -y1, 0)
                                ]
                                for i in range(len(vertices)-1):
                                    start_vertex = vertices[i]
                                    end_vertex = vertices[i+1]
                                    edge = Edge.ByStartVertexEndVertex(start_vertex, end_vertex, tolerance=tolerance, silent=False)
                                    if not edge == None:
                                        edge = Topology.SetDictionary(edge, dictionary)  # Set dictionary
                                        components.append(edge)
                                    edge = Edge.ByStartVertexEndVertex(vertices[-1], vertices[0], tolerance=tolerance, silent=False)
                                    if not edge == None:
                                        edge = Topology.SetDictionary(edge, dictionary)  # Set dictionary
                                        components.append(edge)

                            elif item[0] == "qu":  # Quadrilateral
                                quad_points = [pymupdf.Point(pt[0], pt[1]).transform(matrix) for pt in item[1]]
                                vertices = [Vertex.ByCoordinates(pt.x, -pt.y, 0) for pt in quad_points]
                                for i in range(len(vertices)-1):
                                    start_vertex = vertices[i]
                                    end_vertex = vertices[i+1]
                                    edge = Edge.ByStartVertexEndVertex(start_vertex, end_vertex, tolerance=tolerance, silent=False)
                                    if not edge == None:
                                        edge = Topology.SetDictionary(edge, dictionary)  # Set dictionary
                                        components.append(edge)
                                    edge = Edge.ByStartVertexEndVertex(vertices[-1], vertices[0], tolerance=tolerance, silent=False)
                                    if not edge == None:
                                        edge = Topology.SetDictionary(edge, dictionary)  # Set dictionary
                                        components.append(edge)

                    if len(components) > 0:
                        if len(components) == 1:
                            tp_object = components[0]
                        elif len(components) > 1:
                            tp_object = Cluster.ByTopologies(components)
                            if wires == True or faces == True:
                                tp_object = Topology.SelfMerge(tp_object)
                        if faces == True:
                            if Topology.IsInstance(tp_object, "wire"):
                                if Wire.IsClosed(tp_object):
                                    tp_object = Face.ByWire(tp_object, silent=True) or tp_object
                        tp_object = Topology.SetDictionary(tp_object, dictionary)
                        edges = Topology.Edges(tp_object)
                        for edge in edges:
                            edge = Topology.SetDictionary(edge, dictionary)
                        topologic_entities.append(tp_object)

        return Topology._OntologyAnnotateList(topologic_entities, ontology=ontology, generatedBy="Topology.ByPDFFile", annotateSubtopologies=True, silent=True)

    @staticmethod
    def ByPDFPath(path, wires=False, faces=False, includeTypes=[], excludeTypes=[], edgeColorKey="edge_color", edgeWidthKey="edge_width", faceColorKey="face_color", faceOpacityKey="face_opacity", tolerance=0.0001, silent=False):
        """
        Import PDF file and convert its entities to topologies.

        Parameters
        ----------
        path : path
            The input path to the PDF file
        wires : bool , optional
            If set to True, wires will be constructed when possible. Default is True.
        faces : bool , optional
            If set to True, faces will be constructed when possible. Default is True.
        includeTypes : list , optional
            A list of PDF object types to include in the returned result. Default is [] which means all PDF objects will be included.
            The possible strings to include in this list are: ["line", "curve", "rectangle", "quadrilateral"]
        excludeTypes : list , optional
            A list of PDF object types to exclude from the returned result. Default is [] which mean no PDF object type will be excluded.
            The possible strings to include in this list are: ["line", "curve", "rectangle", "quadrilateral"]
        edgeColorKey : str , optional
            The dictionary key under which to store the edge color. Default is None.
        edgeWidthKey : str , optional
            The dictionary key under which to store the edge width. Default is None.
        faceColorKey : str , optional
            The dictionary key under which to store the face color. Default is None.
        faceOpacityKey : str , optional
            The dictionary key under which to store the face opacity. Default is None.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
        A list of Topologic entities (edges, wires, faces, clusters) with attached dictionaries.

        """
        import os
        import warnings
        try:
            import pymupdf  # PyMuPDF
        except:
            if not silent:
                print("Topology.ByPDFPath - Warning: Installing required PyMuPDF library.")
            try:
                os.system("pip install PyMuPDF")
            except:
                os.system("pip install PyMuPDF --user")
            try:
                import pymupdf
                if not silent:
                    print("Topology.ByPDFPath - Information: PyMUDF library installed correctly.")
            except:
                if not silent:
                    warnings.warn("Topology.ByPDFPath - Error: Could not import PyMuPDF. Please try to install PyMuPDF manually. Returning None.")
                return None
        if not isinstance(path, str):
            if not silent:
                print("Topology.ByPDFPath - Error: the input path is not a valid path. Returning None.")
            return None
        if not os.path.exists(path):
            if not silent:
                print("Topology.ByPDFPath - Error: The specified path does not exist. Returning None.")
            return None
        pdf_file = pymupdf.open(path)
        if not pdf_file:
            if not silent:
                print("Topology.ByPDFPath - Error: Could not open the PDF file. Returning None.")
            return None

        topologies = Topology.ByPDFFile(file=pdf_file,
                            wires=wires,
                            faces=faces,
                            includeTypes = includeTypes,
                            excludeTypes = excludeTypes,
                            edgeColorKey=edgeColorKey,
                            edgeWidthKey=edgeWidthKey,
                            faceColorKey=faceColorKey,
                            faceOpacityKey=faceOpacityKey,
                            tolerance=tolerance,
                            silent=silent)
        pdf_file.close()
        return topologies

    @staticmethod
    def ByBREPString(string, ontology: bool = False, silent: bool = False):
        """
        Creates a topology from the input brep string

        Parameters
        ----------
        string : str
            The input brep string.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The created topology.

        """

        import inspect
        if not isinstance(string, str):
            if not silent:
                print("Topology.ByBREPString - Error: the input string parameter is not a valid string. Returning None.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return None
        returnTopology = None
        try:
            returnTopology = Core.Topology.ByString(string)
        except:
            if not silent:
                print("Topology.ByBREPString - Error: the input string parameter is not a valid string. Returning None.")
            returnTopology = None
        return Topology._OntologyAnnotate(returnTopology, ontology=ontology, generatedBy="Topology.ByBREPString", annotateSubtopologies=True, silent=True)
    
    @staticmethod
    def ByXYZFile(file, frameIdKey="id", vertexIdKey="id"):
        """
        Imports the topology from an XYZ file path. This is a very experimental method. While variants of the format exist, topologicpy reads XYZ files that conform to the following:
        An XYZ file can be made out of one or more frames. Each frame will be stored in a sepatate topologic cluster.
        First line: total number of vertices in the frame. This must be an integer. No other words or characters are allowed on this line.
        Second line: frame label. This is free text and will be stored in the dictionary of each frame (topologic_core.Cluster)
        All other lines: vertex_label, x, y, and z coordinates, separated by spaces, tabs, or commas. The vertex label must be one word with no spaces. It is stored in the dictionary of each vertex.

        Example:
        3
        Frame 1
        A 5.67 -3.45 2.61
        B 3.91 -1.91 4
        A 3.2 1.2 -12.3
        4
        Frame 2
        B 5.47 -3.45 2.61
        B 3.91 -1.93 3.1
        A 3.2 1.2 -22.4
        A 3.2 1.2 -12.3
        3
        Frame 3
        A 5.67 -3.45 2.61
        B 3.91 -1.91 4
        C 3.2 1.2 -12.3

        Parameters
        ----------
        file : file object
            The input XYZ file.
        frameIdKey : str , optional
            The desired id key to use to store the ID of each frame in its dictionary. Default is "id".
        vertexIdKey : str , optional
            The desired id key to use to store the ID of each point in its dictionary. Default is "id".

        Returns
        -------
        list
            The list of frames (topologic_core.Cluster).

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Cluster import Cluster
        from topologicpy.Dictionary import Dictionary

        def parse(lines):
            frames = []
            line_index = 0
            while line_index < len(lines):
                try:
                    n_vertices = int(lines[line_index])
                except:
                    return frames
                frame_label = lines[line_index+1][:-1]
                vertices = []
                for i in range(n_vertices):
                    one_line = lines[line_index+2+i]
                    s = one_line.split()
                    vertex_label = s[0]
                    v = Vertex.ByCoordinates(float(s[1]), float(s[2]), float(s[3]))
                    vertex_dict = Dictionary.ByKeysValues([vertexIdKey], [vertex_label])
                    v = Topology.SetDictionary(v, vertex_dict)
                    vertices.append(v)
                frame = Cluster.ByTopologies(vertices)
                frame_dict = Dictionary.ByKeysValues([frameIdKey], [frame_label])
                frame = Topology.SetDictionary(frame, frame_dict)
                frames.append(frame)
                line_index = line_index + 2 + n_vertices
            return frames
        
        if not file:
            print("Topology.ByXYZFile - Error: the input file parameter is not a valid file. Returning None.")
            return None
        lines = []
        for lineo, line in enumerate(file):
                lines.append(line)
        if len(lines) > 0:
            frames = parse(lines)
        file.close()
        return frames
    
    @staticmethod
    def ByXYZPath(path, frameIdKey="id", vertexIdKey="id"):
        """
        Imports the topology from an XYZ file path. This is a very experimental method. While variants of the format exist, topologicpy reads XYZ files that conform to the following:
        An XYZ file can be made out of one or more frames. Each frame will be stored in a sepatate topologic cluster.
        First line: total number of vertices in the frame. This must be an integer. No other words or characters are allowed on this line.
        Second line: frame label. This is free text and will be stored in the dictionary of each frame (topologic_core.Cluster)
        All other lines: vertex_label, x, y, and z coordinates, separated by spaces, tabs, or commas. The vertex label must be one word with no spaces. It is stored in the dictionary of each vertex.

        Example:
        3
        Frame 1
        A 5.67 -3.45 2.61
        B 3.91 -1.91 4
        A 3.2 1.2 -12.3
        4
        Frame 2
        B 5.47 -3.45 2.61
        B 3.91 -1.93 3.1
        A 3.2 1.2 -22.4
        A 3.2 1.2 -12.3
        3
        Frame 3
        A 5.67 -3.45 2.61
        B 3.91 -1.91 4
        C 3.2 1.2 -12.3

        Parameters
        ----------
        path : str
            The input XYZ file path.
        frameIdKey : str , optional
            The desired id key to use to store the ID of each frame in its dictionary. Default is "id".
        vertexIdKey : str , optional
            The desired id key to use to store the ID of each point in its dictionary. Default is "id".

        Returns
        -------
        list
            The list of frames (topologic_core.Cluster).

        """
        if not path:
            print("Topology.ByXYZPath - Error: the input path parameter is not a valid path. Returning None.")
            return None
        try:
            file = open(path)
        except:
            print("Topology.ByXYZPath - Error: the XYZ file is not a valid file. Returning None.")
            return None
        return Topology.ByXYZFile(file, frameIdKey=frameIdKey, vertexIdKey=vertexIdKey)
    
    def CanonicalMatrix(topology, n: int = 10, normalize: bool = False, mantissa: int = 6, silent: bool = False):
        """
        Returns the canonical matrix of the input topology.
        The canonical matrix refers to a transformation matrix that maps an object's
        coordinate system to a canonical coordinate frame, where:
        . The origin of the object aligns with the world origin
        . The principal axes of the object align with the world axes
        This transformation is computed using Principal Component Analysis (PCA),
        leveraging the eigenvectors of the covariance matrix of the object's vertices
        and thus can give erroneous results. The transformation matrix may not yield an object oriented as expected.
        
        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        n : int , optional
            The number of segments to use to increase the number of points on each face. Default is 10.
        normalize : bool , optional
            If set to True, the longest edge in the input topology is scaled to become of length 1. Default is False.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The 4X4 canonical matrix.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Topology import Topology
        from topologicpy.Grid import Grid
        from topologicpy.Matrix import Matrix
        import numpy as np
        from itertools import permutations

        def generate_floats(n):
            if n < 2:
                return [0.0] if n == 1 else []
            return [i / (n - 1) for i in range(n)]

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.CanonicalMatrix - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        
        faces = Topology.Faces(topology)
        if len(faces) == 0:
            if not silent:
                print("Topology.CanonicalMatrix - Error: The input topology parameter does not contain any faces. Returning None.")
            return None
        
        # Step 1: Derive a copy topology to work with.
        if Topology.IsInstance(topology, "CellComplex"):
            top = CellComplex.ExternalBoundary(topology)
        else:
            top = Topology.Copy(topology)
        
        # Step 2: Create a Translation Matrix to translate to origin
        centroid = Topology.Centroid(top)
        translation_matrix = Matrix.ByTranslation(-Vertex.X(centroid, mantissa=mantissa), -Vertex.Y(centroid, mantissa=mantissa), -Vertex.Z(centroid, mantissa=mantissa))
        translated_top = Topology.Translate(top, -Vertex.X(centroid, mantissa=mantissa), -Vertex.Y(centroid, mantissa=mantissa), -Vertex.Z(centroid, mantissa=mantissa))

        # Step 3: Create a Scaling matrix to normalize size (e.g., largest edge length to 1)
        if normalize == False:
            scale_factor = 1.0
        else:
            #edges = Topology.Edges(translated_top)
            #max_edge_length = max([Edge.Length(edge, mantissa=mantissa) for edge in edges])
            longest_edges = Topology.LongestEdges(translated_top, removeCoplanarFaces=True)
            max_edge_length = Edge.Length(longest_edges[0])
            scale_factor = 1.0 / max_edge_length if max_edge_length != 0 else 1.0
        scaling_matrix = Matrix.ByScaling(scaleX=scale_factor, scaleY=scale_factor, scaleZ=scale_factor)
        scaled_top = Topology.Scale(translated_top, origin=Vertex.Origin(), x=scale_factor, y=scale_factor, z=scale_factor)

        # Step 4: Increase the number of vertices by adding a grid of points on each face.
        faces = Topology.Faces(scaled_top)
        vertices = Topology.Vertices(scaled_top)
        r = generate_floats(n)
        for face in faces:
            vertices += Topology.Vertices(Grid.VerticesByParameters(face=face, uRange=r, vRange=r, clip=True))
        points = np.array([[Vertex.X(v, mantissa=mantissa), Vertex.Y(v, mantissa=mantissa), Vertex.Z(v, mantissa=mantissa)] for v in vertices])

        # Step 5: Align orientation using PCA
        # Compute PCA
        mean = points.mean(axis=0)
        centered_points = points - mean
        covariance_matrix = np.cov(centered_points.T)
        eigenvalues, eigenvectors = np.linalg.eigh(covariance_matrix)

        # Step 6: Sort eigenvectors by eigenvalues (largest first)
        sorted_indices = np.argsort(-eigenvalues)
        eigenvectors = eigenvectors[:, sorted_indices]

        # Step 7: Enforce consistent orientation by flipping eigenvectors
        for i in range(3):  # Ensure each eigenvector points in a positive direction
            if np.dot(eigenvectors[:, i], [1, 0, 0]) < 0:
                eigenvectors[:, i] *= -1
        
        # Step 8: Generate all permutations of aligning principal axes to world axes
        world_axes = np.eye(3)  # X, Y, Z unit vectors
        permutations_axes = list(permutations(world_axes))

        # Create a list to hold all canonical matrices
        canonical_matrices = []

        for perm in permutations_axes:
            # Construct the rotation matrix for this permutation
            rotation_matrix = np.eye(4)
            rotation_matrix[:3, :3] = np.array(perm).T @ eigenvectors.T  # Align points to axes for this permutation

            # Combine transformations: scale -> translate -> rotate
            combined_matrix = Matrix.Multiply(rotation_matrix.tolist(), scaling_matrix)
            combined_matrix = Matrix.Multiply(combined_matrix, translation_matrix)

            # Add the combined matrix to the list
            canonical_matrices.append(combined_matrix)
        # # Step 8: Create the rotation matrix
        # rotation_matrix = np.eye(4)
        # rotation_matrix[:3, :3] = eigenvectors.T  # Use transpose to align points to axes
        
        # # Step 9: Rotate the object to align it 
        # transformation_matrix = Matrix.Multiply(scaling_matrix, translation_matrix)
        # transformation_matrix = Matrix.Multiply(rotation_matrix.tolist(), transformation_matrix)

        # Step 10: Return the resulting matrix
        return canonical_matrices

    @staticmethod
    def CellComplexes(topology, silent: bool = False):
        """
        Returns the cellcomplexes of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of cellcomplexes.

        """
        
        import inspect

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.CellComplexes - Error: The input is not a valid topology. Returning None")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return None
        
        if Topology.IsInstance(topology, "CellComplex"):
            if not silent:
                print("Topology.CellComplexes - Warning: The input is a CellComplex. Returning the same cell embedded in a list.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return [topology]
        
        if Topology.IsInstance(topology, "Cell") or Topology.IsInstance(topology, "Shell") or Topology.IsInstance(topology, "Face") or Topology.IsInstance(topology, "Wire") or Topology.IsInstance(topology, "Edge") or Topology.IsInstance(topology, "Vertex"):
            if not silent:
                print("Topology.CellComplexes - Warning: The input is a lower dimension than a cellComplex. Returning an empty list.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return []
        
        return Topology.SubTopologies(topology=topology, subTopologyType="cellcomplex")
    
    @staticmethod
    def Cells(topology, silent: bool = False):
        """
        Returns the cells of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The list of cells.

        """
        import inspect

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Cells - Error: The input is not a valid topology. Returning None")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return None
        
        if Topology.IsInstance(topology, "Cell"):
            if not silent:
                print("Topology.Cells - Warning: The input is a Cell. Returning the same cell embedded in a list.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return [topology]
        
        if Topology.IsInstance(topology, "Shell") or Topology.IsInstance(topology, "Face") or Topology.IsInstance(topology, "Wire") or Topology.IsInstance(topology, "Edge") or Topology.IsInstance(topology, "Vertex"):
            if not silent:
                print("Topology.Cells - Warning: The input is a lower dimension than a cell. Returning an empty list.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return []
        
        return Topology.SubTopologies(topology=topology, subTopologyType="cell")
    
    @staticmethod
    def CenterOfMass(topology, silent: bool = False):
        """
        Returns the center of mass of the input topology. See https://en.wikipedia.org/wiki/Center_of_mass.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Vertex
            The center of mass of the input topology.

        """
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.CenterofMass - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        # return topology.CenterOfMass() # H to Core
        return Core.InstanceCall(topology, 'CenterOfMass')
    
    @staticmethod
    def VerticesCentroid(topology, mantissa: int = 6, silent: bool = False):
        """
        Returns the centroid of the vertices of the input topology.

        This method computes the arithmetic mean of the coordinates of all vertices
        found in the input topology. It does not compute the geometric centroid by
        length, area, or volume.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        mantissa : int , optional
            The number of decimal places to round the output coordinates to.
            Default is 6.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Vertex or None
            The centroid of the vertices of the input topology.
        """

        from topologicpy.Vertex import Vertex
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.VerticesCentroid - Error: The input topology is not a valid topology. Returning None.")
            return None

        try:
            vertices = Topology.Vertices(topology)
        except:
            vertices = []

        if not isinstance(vertices, list) or len(vertices) == 0:
            if not silent:
                print("Topology.VerticesCentroid - Error: Could not retrieve any vertices from the input topology. Returning None.")
            return None

        x_sum = 0.0
        y_sum = 0.0
        z_sum = 0.0
        n = 0

        for vertex in vertices:
            try:
                x_sum += Vertex.X(vertex)
                y_sum += Vertex.Y(vertex)
                z_sum += Vertex.Z(vertex)
                n += 1
            except:
                continue

        if n == 0:
            if not silent:
                print("Topology.VerticesCentroid - Error: Could not retrieve valid coordinates from the input vertices. Returning None.")
            return None

        return Vertex.ByCoordinates(
            round(x_sum / n, mantissa),
            round(y_sum / n, mantissa),
            round(z_sum / n, mantissa)
        )
    
    @staticmethod
    def Centroid(topology, silent: bool = False):
        """
        Returns the true geometric centroid of the input topology. This is an alias for Topology.CenterOfMass().

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Vertex or None
            The centroid of the input topology.
        """

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.Centroid - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        return Topology.CenterOfMass(topology)

    @staticmethod
    def ClusterByKeys(topologies, *keys, silent: bool = False):
        """
        Clusters the input list of topologies based on the input key or keys.

        Parameters
        ----------
        topologies : list
            The input list of topologies.
        keys : str or list or comma-separated str input parameters
            The key or keys in the topology dictionaries to use for clustering.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            A nested list of topologies where each element is a list of topologies
            with the same key values.

        """

        from topologicpy.Dictionary import Dictionary
        from topologicpy.Helper import Helper
        import inspect

        def _hashable(value):
            if isinstance(value, (str, int, float, bool)) or value is None:
                return value

            if isinstance(value, (list, tuple)):
                return tuple(_hashable(v) for v in value)

            if isinstance(value, dict):
                return tuple(sorted((k, _hashable(v)) for k, v in value.items()))

            try:
                hash(value)
                return value
            except Exception:
                return repr(value)

        if Topology.IsInstance(topologies, "Topology"):
            if not silent:
                print("Topology.ClusterByKeys - Warning: The input topologies parameter is a single topology. Returning one cluster.")
            return [[topologies]]

        if not isinstance(topologies, list):
            if not silent:
                print("Topology.ClusterByKeys - Error: The input topologies parameter is not a valid list. Returning None.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print("caller name:", calframe[1][3])
            return None

        topologies_list = Helper.Flatten(topologies)
        topologies_list = [t for t in topologies_list if Topology.IsInstance(t, "Topology")]

        if len(topologies_list) == 0:
            if not silent:
                print("Topology.ClusterByKeys - Error: The input topologies parameter does not contain any valid topologies. Returning None.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print("caller name:", calframe[1][3])
            return None

        raw_keys = Helper.Flatten(list(keys))
        keys_list = []

        for key in raw_keys:
            if isinstance(key, str):
                keys_list.extend([k.strip() for k in key.split(",") if k.strip()])

        if len(keys_list) == 0:
            if not silent:
                print("Topology.ClusterByKeys - Error: The input keys parameter does not contain any valid strings. Returning None.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print("caller name:", calframe[1][3])
            return None

        groups = {}
        missing_marker = "__MISSING__"

        for topology in topologies_list:
            d = Topology.Dictionary(topology)
            d_keys = Dictionary.Keys(d)

            if not isinstance(d_keys, list):
                d_keys = []

            values = []

            for key in keys_list:
                if key in d_keys:
                    values.append(_hashable(Dictionary.ValueAtKey(d, key)))
                else:
                    values.append(missing_marker)

            group_key = tuple(values)
            groups.setdefault(group_key, []).append(topology)

        return list(groups.values())

    @staticmethod
    def ClusterFaces(topology, angTolerance=2, tolerance=0.0001, silent: bool = False):
        """
        Clusters the faces of the input topology by their direction.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        angTolerance : float , optional
            The desired angular tolerance. Default is 0.1.
        tolerance : float, optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of clusters of faces where faces in the same cluster have the same direction.

        """
        from topologicpy.Vector import Vector
        from topologicpy.Face import Face
        from topologicpy.Cluster import Cluster

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.ClusterFaces - Error: The input topology parameter is not a valid topology. Returning None.")
            return None

        faces = Topology.SubTopologies(topology, subTopologyType="face")
        face_normals = []
        for face in faces:
            face_normals.append(Face.Normal(face))
        bins = []
        for face_normal in face_normals:
            minAngle = angTolerance * 100
            for bin in bins:
                ang = Vector.Angle(bin, face_normal)
                if ang < minAngle:
                    minAngle = ang
            if minAngle > angTolerance:
                bins.append(face_normal)
        num_bins = len(bins)
        # Convert face_normals to a numpy array for efficient computation
        face_normals_array = np.array(face_normals)

        # Compute the bounds for each bin along each dimension
        bin_bounds = [np.linspace(-1, 1, num_bins + 1) for _ in range(3)]

        # Assign each face to a bin based on its normal
        bin_indices = [np.digitize(face_normal, bounds) - 1 for face_normal, bounds in zip(face_normals_array.T, bin_bounds)]
        # Combine the indices along the three dimensions to get a single bin index for each face
        cluster_labels = bin_indices[0] * (num_bins**2) + bin_indices[1] * num_bins + bin_indices[2]
        cluster_labels = list(cluster_labels)
        bins = list(set(cluster_labels))
        clusters = []
        for bin in bins:
            clusters.append([])
        for i, face in enumerate(faces):
            ind = bins.index(cluster_labels[i])
            clusters[ind].append(face)
        final_clusters = []
        for cluster in clusters:
            final_clusters.append(Topology.SelfMerge(Cluster.ByTopologies(cluster), tolerance=tolerance, silent=silent))
        return final_clusters

    @staticmethod
    def Clusters(topology, silent: bool = False):
        """
        Returns the clusters of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of clusters.

        """
        import inspect

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Clusters - Error: The input is not a valid topology. Returning None")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return None
        
        if Topology.IsInstance(topology, "CellComplex") or Topology.IsInstance(topology, "Cell") or Topology.IsInstance(topology, "Shell") or Topology.IsInstance(topology, "Face") or Topology.IsInstance(topology, "Wire") or Topology.IsInstance(topology, "Edge") or Topology.IsInstance(topology, "Vertex"):
            if not silent:
                print("Topology.Clusters - Warning: The input is a lower dimension than a cluster. Returning an empty list.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return []

        return Topology.SubTopologies(topology=topology, subTopologyType="cluster")
    

    @staticmethod
    def Contents(topology, silent: bool = False):
        """
        Returns the contents of the input topology

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of contents of the input topology.

        """
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                    print("Topology.Contents - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        contents = []
        # _ = topology.Contents(contents) # H to Core
        _ = Core.InstanceCall(topology, 'Contents', contents)
        return contents
    
    @staticmethod
    def Contexts(topology, silent: bool = False):
        """
        Returns the list of contexts of the input topology

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of contexts of the input topology.

        """
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Contexts - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        contexts = []
        # _ = topology.Contexts(contexts) # H to Core
        _ = Core.InstanceCall(topology, 'Contexts', contexts)
        return contexts

    @staticmethod
    def ConvexHull(topology, mantissa: int = 6, tolerance: float = 0.0001, silent: bool = False):
        """
        Computes the convex hull of the input topology.
        Returns a Face in 2D (even embedded in 3D), or a Cell/Shell in 3D.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input Topology.
        mantissa : int, optional
            Precision of the coordinates. Default is 6.
        tolerance : float, optional
            Tolerance value for geometric operations. Default is 0.0001.
        silent : bool, optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The convex hull of the topology as a Face (2D) or Cell/Shell (3D).
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Cell import Cell
        from topologicpy.Shell import Shell
        from topologicpy.Cluster import Cluster
        from topologicpy.Topology import Topology

        import numpy as np
        from scipy.spatial import ConvexHull as SciPyConvexHull

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.ConvexHull - Error: Input is not a valid topology. Returning None.")
            return None

        def convexHull_2d(vertices, mantissa: int = 6, tolerance: float = 0.0001, silent: bool = False):
            from topologicpy.Vertex import Vertex
            from topologicpy.Edge import Edge
            from topologicpy.Wire import Wire
            from topologicpy.Face import Face
            from topologicpy.Cluster import Cluster
            from topologicpy.Topology import Topology

            import numpy as np
            from scipy.spatial import ConvexHull as SciPyConvexHull

            cluster = Cluster.ByTopologies(vertices)
            normal = Vertex.Normal(vertices)
            centroid = Topology.Centroid(cluster)
            flat_cluster = Topology.Flatten(cluster, origin=centroid, direction=normal)
            flat_verts = Topology.Vertices(flat_cluster)
            coords = np.array([[Vertex.X(v, mantissa=mantissa), Vertex.Y(v, mantissa=mantissa)] for v in flat_verts])
            try:
                hull = SciPyConvexHull(coords)
            except:
                if not silent:
                    print("Topology.ConvexHull - Error computing 2D hull. Returning None.")
                return None

            # Reconstruct 3D points from 2D hull
            hull_indices = hull.vertices
            sorted_coords = coords[hull_indices]

            edges = []
            for i in range(len(sorted_coords)):
                p1 = sorted_coords[i]
                p2 = sorted_coords[(i + 1) % len(sorted_coords)]
                v1 = Vertex.ByCoordinates(*p1)
                v2 = Vertex.ByCoordinates(*p2)
                edges.append(Edge.ByVertices([v1, v2], tolerance=tolerance))
            convex_hull = Wire.ByEdges(edges, tolerance=tolerance)
            if Topology.IsInstance(convex_hull, "wire"):
                convex_hull_2 = Face.ByWire(convex_hull, tolerance=tolerance, silent=True)
            if not Topology.IsInstance(convex_hull_2, "face"):
                convex_hull_2 = convex_hull
            convex_hull = Topology.Unflatten(convex_hull_2, origin=centroid, direction=normal)
            return convex_hull
        
        vertices = Topology.Vertices(topology, silent=True)
        if len(vertices) < 3:
            if not silent:
                print("Topology.ConvexHull - Error: Need at least 3 points to compute a convex hull.")
            return None
        
        coords = np.array([Vertex.Coordinates(v, mantissa=mantissa) for v in vertices])

        if Vertex.AreCoplanar(vertices, mantissa=mantissa, tolerance=tolerance, silent=silent):
            # Planar case
            return convexHull_2d(vertices, mantissa=mantissa, tolerance=tolerance, silent=silent)
        else:
            # Non-planar case
            try:
                hull = SciPyConvexHull(coords)
            except:
                try:
                    hull = SciPyConvexHull(coords, qhull_options="QJ")
                except Exception as e:
                    if not silent:
                        print(f"Topology.ConvexHull - 3D hull failed even with QJ: {e}")
                    return None
            faces = []
            for simplex in hull.simplices:
                points = coords[simplex]
                edges = []
                for i in range(len(points)):
                    p1 = points[i]
                    p2 = points[(i + 1) % len(points)]
                    v1 = Vertex.ByCoordinates(*p1)
                    v2 = Vertex.ByCoordinates(*p2)
                    edges.append(Edge.ByVertices([v1, v2], tolerance=tolerance))
                wire = Wire.ByEdges(edges, tolerance=tolerance)
                face = Face.ByWire(wire, tolerance=tolerance)
                faces.append(face)

            convex_hull = Cell.ByFaces(faces, tolerance=tolerance, silent=True)
            if convex_hull:
                convex_hull_2 = Topology.RemoveCoplanarFaces(convex_hull, tolerance=tolerance, silent=True)
                if not convex_hull_2:
                    return convex_hull
            else:
                convex_hull = Shell.ByFaces(faces, tolerance=tolerance, silent=True)
                if convex_hull:
                    convex_hull_2 = Topology.RemoveCoplanarFaces(convex_hull, tolerance=tolerance, silent=True)
                    if not convex_hull_2:
                        return convex_hull
                else:
                    convex_hull = Cluster.ByTopologies(faces)
            return convex_hull
    
    @staticmethod
    def Copy(
        topology,
        deep: bool = False,
        silent: bool = False
    ):
        """
        Returns a copy of the input topology.

        For non-TopologicCore backends, copying is delegated directly to the
        active backend. A shallow copy duplicates the native topology and parent
        dictionary. A deep copy additionally preserves dictionaries associated
        with native subtopologies.

        The legacy BREP and JSON serialization mechanisms are retained only for
        the TopologicCore backend.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        deep : bool , optional
            If set to True, a deep copy is performed, including dictionaries
            associated with subtopologies. Otherwise, a shallow native copy is
            performed. Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Topology
            A copy of the input topology, or None if the operation fails.
        """
        import copy as pycopy

        from topologicpy.Dictionary import Dictionary

        # ------------------------------------------------------------------
        # Validate input.
        # ------------------------------------------------------------------

        if not Topology.IsInstance(
            topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.Copy - Error: The input topology parameter "
                    "is not a valid topology. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Non-TopologicCore backends
        #
        # Trust the backend to provide genuine copy semantics.
        # ------------------------------------------------------------------

        if not Topology._IsTopologicCoreBackend():

            method_name = (
                "DeepCopy"
                if deep
                else "Copy"
            )

            try:
                return_topology = Core.InstanceCall(
                    topology,
                    method_name
                )
            except Exception:
                return_topology = None

            if not Topology.IsInstance(
                return_topology,
                "Topology"
            ):
                if not silent:
                    print(
                        "Topology.Copy - Error: The active backend could not "
                        f"perform a {'deep' if deep else 'shallow'} copy. "
                        "Returning None."
                    )
                return None

            return return_topology

        # ------------------------------------------------------------------
        # Legacy TopologicCore deep copy.
        # ------------------------------------------------------------------

        if deep:

            try:
                json_string = Topology.JSONString(
                    [topology],
                    silent=silent
                )
            except Exception:
                json_string = None

            if not isinstance(
                json_string,
                str
            ):
                if not silent:
                    print(
                        "Topology.Copy - Error: Could not serialize the input "
                        "topology for deep copying. Returning None."
                    )
                return None

            try:
                copied_topologies = Topology.ByJSONString(
                    json_string,
                    silent=silent
                )
            except Exception:
                copied_topologies = None

            if (
                not isinstance(
                    copied_topologies,
                    list
                )
                or len(copied_topologies) != 1
                or not Topology.IsInstance(
                    copied_topologies[0],
                    "Topology"
                )
            ):
                if not silent:
                    print(
                        "Topology.Copy - Error: Could not reconstruct the "
                        "deep copy. Returning None."
                    )
                return None

            return copied_topologies[0]

        # ------------------------------------------------------------------
        # Legacy TopologicCore shallow copy.
        # ------------------------------------------------------------------

        try:
            source_dictionary = Topology.Dictionary(
                topology,
                silent=True
            )
        except Exception:
            source_dictionary = None

        try:
            brep_string = Topology.BREPString(
                topology
            )
        except Exception:
            brep_string = None

        if not isinstance(
            brep_string,
            str
        ):
            if not silent:
                print(
                    "Topology.Copy - Error: Could not serialize the input "
                    "topology. Returning None."
                )
            return None

        try:
            return_topology = Topology.ByBREPString(
                brep_string,
                silent=silent
            )
        except Exception:
            return_topology = None

        if not Topology.IsInstance(
            return_topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.Copy - Error: Could not copy the topology. "
                    "Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Restore an independent parent dictionary.
        # ------------------------------------------------------------------

        if source_dictionary is not None:

            try:
                python_dictionary = Dictionary.PythonDictionary(
                    source_dictionary
                )

                copied_dictionary = Dictionary.ByPythonDictionary(
                    pycopy.deepcopy(
                        python_dictionary
                    )
                )

                if copied_dictionary is not None:
                    return_topology = Topology.SetDictionary(
                        return_topology,
                        copied_dictionary,
                        silent=True
                    )

            except Exception:
                pass

        return return_topology


    @staticmethod
    def Degree(topology, hostTopology, silent: bool = False):
        """
        Returns the number of immediate super topologies that use the input topology

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        hostTopology : topologic_core.Topology
            The input host topology to which the input topology belongs
        silent : bool, optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        int
            The degree of the topology (the number of immediate super topologies that use the input topology).
        
        """
        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.Degree - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(hostTopology, "topology"):
            if not silent:
                print("Topology.Degree - Error: the input hostTopology parameter is not a valid topology. Returning None.")
            return None
        
        hostTopologyType = Topology.TypeAsString(hostTopology).lower()
        topology_type = Topology.TypeAsString(topology).lower()

        superType = None

        if topology_type == "vertex":
            if hostTopologyType in ["edge", "wire", "face", "shell", "cell", "cellcomplex", "cluster"]:
                superType = "edge"

        elif topology_type == "edge":
            if hostTopologyType in ["wire"]:
                superType = "wire"
            elif hostTopologyType in ["face", "shell", "cell", "cellcomplex", "cluster"]:
                superType = "face"

        elif topology_type == "wire":
            if hostTopologyType in ["face", "shell", "cell", "cellcomplex", "cluster"]:
                superType = "face"

        elif topology_type == "face":
            if hostTopologyType in ["shell"]:
                superType = "shell"
            elif hostTopologyType in ["cell", "cellcomplex", "cluster"]:
                superType = "cell"

        elif topology_type == "shell":
            if hostTopologyType in ["cell", "cellcomplex", "cluster"]:
                superType = "cell"

        elif topology_type == "cell":
            if hostTopologyType in ["cellcomplex", "cluster"]:
                superType = "cellcomplex"

        if superType is None:
            return 0

        superTopologies = Topology.SuperTopologies(
            topology,
            hostTopology=hostTopology,
            topologyType=superType,
            silent=silent,
        )

        if not superTopologies:
            return 0

        return len(superTopologies)
    
    @staticmethod
    def Diameter(topology, mantissa: int = 6, tolerance: float = 0.0001, silent: bool = False):
        """
        Computes the diameter of the convex hull of the given topology.
        The diameter is the maximum distance between any two vertices on the convex hull.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        float
            The diameter of the convex hull of the topology.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Diameter - Error: The input topology parameter is not a valid Topology. Returning None.")
            return None
        if Topology.IsInstance(topology, "Vertex"):
            return 0.0
        if Topology.IsInstance(topology, "Edge"):
            sv = Edge.StartVertex(topology)
            ev = Edge.EndVertex(topology)
            return Vertex.Distance(sv, ev, mantissa=mantissa)

        # Step 1: Get the convex hull
        hull = Topology.ConvexHull(topology, tolerance=tolerance, mantissa=mantissa, silent=silent)
        if not hull:
            return 0.0

        # Step 2: Get all unique vertices of the hull
        vertices = Topology.Vertices(hull)
        num_vertices = len(vertices)
        if num_vertices < 2:
            return 0.0

        # Step 3: Find the furthest pair
        max_distance = 0.0
        for i in range(num_vertices):
            for j in range(i + 1, num_vertices):
                dist = Vertex.Distance(vertices[i], vertices[j], mantissa=mantissa)
                if dist > max_distance:
                    max_distance = dist

        return round(max_distance, mantissa)
    
    @staticmethod
    def Dictionary(topology, silent: bool = False):
        """
        Returns the dictionary of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The input topology or graph.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Dictionary
            The dictionary of the input topology or graph.

        """

        import inspect

        is_tgraph = False
        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            is_tgraph = False

        if is_tgraph:
            try:
                from topologicpy.Dictionary import Dictionary
                d = TGraph.Dictionary(topology)
                if isinstance(d, dict):
                    if len(d) == 0:
                        return None
                    return Dictionary.ByKeysValues(list(d.keys()), [d[k] for k in d.keys()])
                return d
            except Exception:
                return None

        if not Topology.IsInstance(topology, "Topology") and not Topology.IsInstance(topology, "Graph"):
            if not silent:
                print("Topology.Dictionary - Error: the input topology parameter is not a valid topology. Returning None.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print("caller name:", calframe[1][3])
            return None

        return Core.InstanceCall(topology, "GetDictionary")
    
    @staticmethod
    def Dimensionality(topology, silent: bool = False):
        """
        Returns the dimensionality of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The input topology or graph.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        int
            The dimensionality of the input topology or graph.

        """

        from topologicpy.Graph import Graph
        from topologicpy.Cluster import Cluster

        is_tgraph = False
        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            is_tgraph = False

        if is_tgraph:
            return 1 if TGraph.Size(topology) > 0 else 0

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Dimensionality - Error: the input topology parameter is not a valid topology. Returning None.")
            return None

        if Topology.IsInstance(topology, "Vertex"):
            return 0

        if Topology.IsInstance(topology, "Edge") or Topology.IsInstance(topology, "Wire"):
            return 1

        if Topology.IsInstance(topology, "Face") or Topology.IsInstance(topology, "Shell"):
            return 2

        if Topology.IsInstance(topology, "Cell") or Topology.IsInstance(topology, "CellComplex"):
            return 3

        if Topology.IsInstance(topology, "Graph"):
            edges = Graph.Edges(topology)
            return 1 if len(edges) > 0 else 0

        if Topology.IsInstance(topology, "Cluster"):
            if len(Cluster.CellComplexes(topology)) > 0 or len(Cluster.Cells(topology)) > 0:
                return 3
            if len(Cluster.Shells(topology)) > 0 or len(Cluster.Faces(topology)) > 0:
                return 2
            if len(Cluster.Wires(topology)) > 0 or len(Cluster.Edges(topology)) > 0:
                return 1
            return 0

        return 3
    
    @staticmethod
    def Divide(topologyA, topologyB, transferDictionary=False, addNestingDepth=False, silent: bool = False):
        """
        Divides the input topology by the input tool and places the results in the contents of the input topology.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The input topology to be divided.
        topologyB : topologic_core.Topology
            the tool used to divide the input topology.
        transferDictionary : bool , optional
            If set to True the dictionary of the input topology is transferred to the divided topologies.
        addNestingDepth : bool , optional
            If set to True the nesting depth of the division is added to the dictionaries of the divided topologies.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with the divided topologies added to it as contents.

        """
        from topologicpy.Dictionary import Dictionary

        if not Topology.IsInstance(topologyA, "Topology"):
            if not silent:
                print("Topology.Divide - Error: the input topologyA parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(topologyB, "Topology"):
            if not silent:
                print("Topology.Divide - Error: the input topologyB parameter is not a valid topology. Returning None.")
            return None
        try:
            # _ = topologyA.Divide(topologyB, False) # Don't transfer dictionaries just yet # H to Core
            _ = Core.InstanceCall(topologyA, 'Divide', topologyB, False)
        except:
            raise Exception("TopologyDivide - Error: Divide operation failed.")
        nestingDepth = "1"
        keys = ["nesting_depth"]
        values = [nestingDepth]

        if not addNestingDepth and not transferDictionary:
            return topologyA

        contents = Topology.Contents(topologyA)
        for i in range(len(contents)):
            if not addNestingDepth and transferDictionary:
                parentDictionary = Topology.Dictionary(topologyA)
                if parentDictionary != None:
                    _ = Topology.SetDictionary(contents[i], parentDictionary)
            if addNestingDepth and transferDictionary:
                parentDictionary = Topology.Dictionary(topologyA)
                if parentDictionary != None:
                    keys = Dictionary.Keys(parentDictionary)
                    values = Dictionary.Values(parentDictionary)
                    if ("nesting_depth" in keys):
                        nestingDepth = Dictionary.ValueAtKey(parentDictionary, "nesting_depth", nestingDepth)
                    else:
                        keys.append("nesting_depth")
                        values.append(nestingDepth)
                    parentDictionary = Dictionary.ByKeysValues(keys, values)
                else:
                    keys = ["nesting_depth"]
                    values = [nestingDepth]
                parentDictionary = Dictionary.ByKeysValues(keys, values)
                _ = Topology.SetDictionary(topologyA, parentDictionary)
                values[keys.index("nesting_depth")] = nestingDepth+"_"+str(i+1)
                d = Dictionary.ByKeysValues(keys, values)
                _ = Topology.SetDictionary(contents[i], d)
            if addNestingDepth and  not transferDictionary:
                parentDictionary = Topology.Dictionary(topologyA)
                if parentDictionary != None:
                    keys = Dictionary.Keys(parentDictionary)
                    values = Dictionary.Values(parentDictionary)
                    if ("nesting_depth" in keys):
                        nestingDepth = Dictionary.ValueAtKey(parentDictionary, "nesting_depth")
                    else:
                        keys.append("nesting_depth")
                        values.append(nestingDepth)
                    parentDictionary = Dictionary.ByKeysValues(keys, values)
                else:
                    keys = ["nesting_depth"]
                    values = [nestingDepth]
                parentDictionary = Dictionary.ByKeysValues(keys, values)
                _ = Topology.SetDictionary(topologyA, parentDictionary)
                keys = ["nesting_depth"]
                v = nestingDepth+"_"+str(i+1)
                values = [v]
                d = Dictionary.ByKeysValues(keys, values)
                _ = Topology.SetDictionary(contents[i], d)
        return topologyA
    
    @staticmethod
    def Edges(topology, silent: bool = False):
        """
        Returns the edges of the input topology or graph.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The input topology or graph.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of edges.

        """

        from topologicpy.Graph import Graph

        is_tgraph = False
        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            is_tgraph = False

        if is_tgraph:
            return TGraph.Edges(topology)

        if Topology.IsInstance(topology, "Graph"):
            return Graph.Edges(topology)

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Edges - Error: The input is not a valid topology or graph. Returning None")
            return None

        if Topology.IsInstance(topology, "Edge"):
            if not silent:
                print("Topology.Edges - Warning: The input is an Edge. Returning the same edge embedded in a list.")
            return [topology]

        if Topology.IsInstance(topology, "Vertex"):
            if not silent:
                print("Topology.Edges - Warning: The input is a lower dimension than an edge. Returning an empty list.")
            return []

        return Topology.SubTopologies(topology=topology, subTopologyType="edge", silent=silent)
    
    @staticmethod
    def Explode(topology, origin=None, scale: float = 1.25, typeFilter: str = None, axes: str = "xyz", transferDictionaries: bool = False, mantissa: int = 6, tolerance: float = 0.0001, silent: bool = False):
        """
        Explodes the input topology. See https://en.wikipedia.org/wiki/Exploded-view_drawing.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The input topology or graph.
        origin : topologic_core.Vertex , optional
            The origin of the explosion. If set to None, the centroid of the input topology will be used. Default is None.
        scale : float , optional
            The scale factor of the explosion. Default is 1.25.
        typeFilter : str , optional
            The type of the subtopologies to explode. This can be any of "vertex", "edge", "face", or "cell". If set to None, a subtopology one level below the type of the input topology will be used. Default is None.
        axes : str , optional
            Sets what axes are to be used for exploding the topology. This can be any permutation or substring of "xyz". It is not case sensitive. Default is "xyz".
        transferDictionaries : bool , optional
            If set to True, the dictionaries of the original subTopologies are transferred to the exploded topologies. Otherwise, they are not. Default is False.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cluster
            The exploded topology.

        """

        from topologicpy.Vertex import Vertex
        from topologicpy.Cluster import Cluster
        from topologicpy.Graph import Graph

        is_tgraph = False
        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            TGraph = None
            is_tgraph = False

        def processClusterTypeFilter(cluster):
            if len(Cluster.CellComplexes(cluster)) > 0:
                return "cell"
            elif len(Cluster.Cells(cluster)) > 0:
                return "face"
            elif len(Cluster.Shells(cluster)) > 0:
                return "face"
            elif len(Cluster.Faces(cluster)) > 0:
                return "edge"
            elif len(Cluster.Wires(cluster)) > 0:
                return "edge"
            elif len(Cluster.Edges(cluster)) > 0:
                return "vertex"
            else:
                return "self"

        def getTypeFilter(topology):
            typeFilter = "self"

            if is_tgraph:
                return "edge"

            if Topology.IsInstance(topology, "Vertex"):
                typeFilter = "self"
            elif Topology.IsInstance(topology, "Edge"):
                typeFilter = "vertex"
            elif Topology.IsInstance(topology, "Wire"):
                typeFilter = "edge"
            elif Topology.IsInstance(topology, "Face"):
                typeFilter = "edge"
            elif Topology.IsInstance(topology, "Shell"):
                typeFilter = "face"
            elif Topology.IsInstance(topology, "Cell"):
                typeFilter = "face"
            elif Topology.IsInstance(topology, "CellComplex"):
                typeFilter = "cell"
            elif Topology.IsInstance(topology, "Cluster"):
                typeFilter = processClusterTypeFilter(topology)
            elif Topology.IsInstance(topology, "Graph"):
                typeFilter = "edge"
            return typeFilter

        if is_tgraph:
            topology = TGraph.Topology(
                topology,
                includeVertices=True,
                includeEdges=True,
                useRepresentations=True,
                segmentCurves=True,
                tolerance=tolerance,
                silent=silent,
            )
        elif Topology.IsInstance(topology, "Graph"):
            topology = Graph.Topology(topology)

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Explode - Error: the input topology parameter is not a valid topology or graph. Returning None.")
            return None

        if not Topology.IsInstance(origin, "Vertex"):
            origin = Topology.CenterOfMass(topology)

        if not typeFilter:
            typeFilter = getTypeFilter(topology)

        if not isinstance(typeFilter, str):
            if not silent:
                print("Topology.Explode - Error: the input typeFilter parameter is not a valid string. Returning None.")
            return None

        if not isinstance(axes, str):
            if not silent:
                print("Topology.Explode - Error: the input axes parameter is not a valid string. Returning None.")
            return None

        axes = axes.lower()
        x_flag = "x" in axes
        y_flag = "y" in axes
        z_flag = "z" in axes

        if not x_flag and not y_flag and not z_flag:
            if not silent:
                print("Topology.Explode - Error: the input axes parameter is not a valid string. Returning None.")
            return None

        if typeFilter.lower() == "self":
            topologies = [topology]
        else:
            topologies = Topology.SubTopologies(topology, subTopologyType=typeFilter.lower(), silent=silent)

        newTopologies = []

        for aTopology in topologies:
            c = Topology.InternalVertex(aTopology, tolerance=tolerance)

            oldX = Vertex.X(c, mantissa=mantissa)
            oldY = Vertex.Y(c, mantissa=mantissa)
            oldZ = Vertex.Z(c, mantissa=mantissa)

            if x_flag:
                newX = (oldX - Vertex.X(origin, mantissa=mantissa)) * scale + Vertex.X(origin, mantissa=mantissa)
            else:
                newX = oldX

            if y_flag:
                newY = (oldY - Vertex.Y(origin, mantissa=mantissa)) * scale + Vertex.Y(origin, mantissa=mantissa)
            else:
                newY = oldY

            if z_flag:
                newZ = (oldZ - Vertex.Z(origin, mantissa=mantissa)) * scale + Vertex.Z(origin, mantissa=mantissa)
            else:
                newZ = oldZ

            xT = newX - oldX
            yT = newY - oldY
            zT = newZ - oldZ

            newTopology = Topology.Copy(aTopology)
            newTopology = Topology.Translate(newTopology, xT, yT, zT)

            if transferDictionaries == True:
                newTopology = Topology.SetDictionary(newTopology, Topology.Dictionary(aTopology))

            newTopologies.append(newTopology)

        return Cluster.ByTopologies(newTopologies, silent=silent)
    
    @staticmethod
    def ExportToBIM(topologies,
                    path : str,
                    overwrite: bool = False,
                    version: str = "1.0.0",
                    guidKey: str = "guid",
                    colorKey: str = "color",
                    typeKey: str = "type",
                    defaultColor: list = [255,255,255,1],
                    defaultType: str = "Structure",
                    author: str = "topologicpy",
                    mantissa: int = 6,
                    tolerance: float = 0.0001,
                    silent: bool = False):
        """
        Exports the input topology to a BIM file. See https://dotbim.net/

        Parameters
        ----------
        topologies : list or topologic_core.Topology
            The input list of topologies or a single topology. The .bim format is restricted to triangulated meshes. No wires, edges, or vertices are supported.
        path : str
            The input file path.
        overwrite : bool , optional
            If set to True the ouptut file will overwrite any pre-existing file. Otherwise, it won't. Default is False.
        version : str , optional
            The desired version number for the BIM file. Default is "1.0.0".
        guidKey : str , optional
            The key to use to find the the guid of the topology. It is case insensitive. Default is "guid". If no guid is found, one is generated automatically.
        colorKey : str , optional
            The key to use to find the the color of the topology. It is case insensitive. Default is "color". If no color is found, the defaultColor parameter is used.
        typeKey : str , optional
            The key to use to find the the type of the topology. It is case insensitive. Default is "type". If no type is found, the defaultType parameter is used.
        defaultColor : list , optional
            The default color to use for the topology. Default is [255,255,255,1] which is opaque white.
        defaultType : str , optional
            The default type to use for the topology. Default is "Structure".
        author : str , optional
            The author of the topology. Default is "topologicpy".
        date : str , optional
            The creation date of the topology. This should be in the formate "DD.MM.YYYY". Default is None which uses the date of export.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if the export operation is successful. False otherwise.

        """
        from topologicpy.Topology import Topology
        from topologicpy.Helper import Helper
        from topologicpy.Dictionary import Dictionary
        from topologicpy.Cluster import Cluster
        import datetime
        from os.path import exists
        
        try:
            import dotbimpy
        except:
            print("Topology - Installing required dotbimpy library.")
            try:
                os.system("pip install dotbimpy")
            except:
                os.system("pip install dotbimpy --user")
            try:
                import dotbimpy
                print("Topology - dotbimpy library installed successfully.")
            except:
                warnings.warn("Topology - Error: Could not import dotbimpy. Please install the dotbimpy library manually. Returning None.")
                return None
        # Make sure the file extension is .brep
        ext = path[len(path)-4:len(path)]
        if ext.lower() != ".bim":
            path = path+".bim"
        if not overwrite and exists(path):
            print("Topology.ExportToBIM - Error: a file already exists at the specified path and overwrite is set to False. Returning None.")
            return None
        
        # Get the current date
        current_date = datetime.datetime.now()

        # Format the date as a string in DD.MM.YYYY format
        formatted_date = current_date.strftime("%d.%m.%Y")
        
        if Topology.IsInstance(topologies, "Topology"):
            topologies = [topologies]
        topologies = [t for t in topologies if Topology.IsInstance(t, "topology")]
        if len(topologies) == 0:
            if not silent:
                print("Topology.ExportToBIM - Error: The input list of topologies does not contain any valid topologies. Returning None.")
            return None
        # Prepare input data
        final_topologies = []
        for topology in topologies:
            d = Topology.Dictionary(topology)
            topology = Topology.SelfMerge(Topology.Triangulate(topology, tolerance=tolerance), tolerance=tolerance)
            topology = Topology.SetDictionary(topology, d)
            if Topology.IsInstance(topology, "Cluster"):
                final_topologies += Cluster.CellComplexes(topology) + Cluster.FreeCells(topology, tolerance=tolerance) + Cluster.FreeShells(topology, tolerance=tolerance) + Cluster.FreeFaces(topology, tolerance=tolerance)
            elif Topology.IsInstance(topology, "CellComplex") or Topology.IsInstance(topology, "Cell") or Topology.IsInstance(topology, "Shell") or Topology.IsInstance(topology, "Face"):
                final_topologies.append(topology)
        elements = []
        meshes = []
        for i, topology in enumerate(final_topologies):
            geo_dict = Topology.Geometry(topology, mantissa=mantissa)
            coordinates = Helper.Flatten(geo_dict['vertices'])
            indices = Helper.Flatten(geo_dict['faces'])
            d = Topology.Dictionary(topology)
            color = Dictionary.ValueAtKey(d, colorKey)
            r, g, b, a = defaultColor
            if isinstance(color, list):
                if len(color) > 2:
                    r = color[0]
                    g = color[1]
                    b = color[2]
                if len(color) == 4:
                    a = color[3]
            color = dotbimpy.Color(r=r, g=g, b=b, a=int(a*255))
            guid = Dictionary.ValueAtKey(d, guidKey)
            if not guid:
                guid = str(uuid.uuid4())

            type = Dictionary.ValueAtKey(d, typeKey)
            if not type:
                type = defaultType
            info = Dictionary.PythonDictionary(d)
            info['color'] = str([r,g,b,a])
            info['guid'] = guid
            info['type'] = type
            rotation = dotbimpy.Rotation(qx=0, qy=0, qz=0, qw=1.0)
            vector = dotbimpy.Vector(x=0, y=0, z=0)
            
            # Instantiate Mesh object
            mesh = dotbimpy.Mesh(mesh_id=i, coordinates=coordinates, indices=indices)
            meshes.append(mesh)
            # Instantiate Element object
            element = dotbimpy.Element(mesh_id=i,
                            vector=vector,
                            guid=guid,
                            info=info,
                            rotation=rotation,
                            type=type,
                            color=color)
            elements.append(element)

        # File meta data
        file_info = {
            "Author": author,
            "Date": formatted_date
        }

        # Instantiate and save File object
        file = dotbimpy.File(version, meshes=meshes, elements=elements, info=file_info)
        try:
            file.save(path)
            if not silent:
                print("Topology.ExportToBIM - Information: File saved successfully. Returning True.")
            return True
        except:
            if not silent:
                print("Topology.ExportToBIM - Error: Could not save the file. Returning False.")
            return False

    @staticmethod
    def ExportToBREP(topology, path, overwrite=False, version=3, silent: bool = False):
        """
        Exports the input topology to a BREP file. See https://dev.opencascade.org/doc/occt-6.7.0/overview/html/occt_brep_format.html.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        path : str
            The input file path.
        overwrite : bool , optional
            If set to True the ouptut file will overwrite any pre-existing file. Otherwise, it won't. Default is False.
        version : int , optional
            The desired version number for the BREP file. Default is 3.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if the export operation is successful. False otherwise.

        """
        from os.path import exists
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.ExportToBREP - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        if not isinstance(path, str):
            if not silent:
                print("Topology.ExportToBREP - Error: the input path parameter is not a valid string. Returning None.")
            return None
        # Make sure the file extension is .brep
        ext = path[len(path)-5:len(path)]
        if ext.lower() != ".brep":
            path = path+".brep"
        if not overwrite and exists(path):
            if not silent:
                print("Topology.ExportToBREP - Error: a file already exists at the specified path and overwrite is set to False. Returning None.")
            return None
        f = None
        try:
            if overwrite == True:
                f = open(path, "w")
            else:
                f = open(path, "x") # Try to create a new File
        except:
            if not silent:
                print(f"Topology.ExportToBREP - Error: Could not create a new file at the following location: {path}. Returning None.")
            return None
        if (f):
            s = Topology.BREPString(topology, version)
            f.write(s)
            f.close()    
            if not silent:
                print(f"Topology.ExportToBREP - Information: File save successfully. Returning True.")
            return True
        if not silent:
            print(f"Topology.ExportToBREP - Error: Could not save the file at the following location: {path}. Returning None.")
        return None

    def ExportToDXF(topologies, path: str,  overwrite: bool = False, mantissa: int = 6, silent: bool = False):
        """
        Exports the input topology to a DXF file. See https://en.wikipedia.org/wiki/AutoCAD_DXF.
        THe DXF version is 'R2010'
        This is experimental and only geometry is exported.

        Parameters
        ----------
        topologies : list or topologic_core.Topology
            The input list of topologies. This can also be a single topologic_core.Topology.
        path : str
            The input file path.
        overwrite : bool , optional
            If set to True the ouptut file will overwrite any pre-existing file. Otherwise, it won't. Default is False.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if the export operation is successful. False otherwise.

        """
        import os
        import warnings

        try:
            import ezdxf
        except:
            print("Topology.ExportToDXF - Information: Installing required ezdxf library.")
            try:
                os.system("pip install ezdxf")
            except:
                os.system("pip install ezdxf --user")
            try:
                import ezdxf
                print("Topology.ExportToDXF - Information: ezdxf library installed successfully.")
            except:
                warnings.warn("Topology.ExportToDXF - Error: Could not import ezdxf library. Please install it manually. Returning None.")
                return None
        
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Cluster import Cluster
        from topologicpy.Topology import Topology

        from os.path import exists
        if not isinstance(topologies, list):
            topologies = [topologies]
        topologies = [topology for topology in topologies if Topology.IsInstance(topology, "Topology")]
        if len(topologies) < 1:
            if not silent:
                print("Topology.ExportToDXF - Error: The inupt list parameter topologies does not contain any valid topologies. Returning None.")
            return None
        # Make sure the file extension is .brep
        ext = path[len(path)-4:len(path)]
        if ext.lower() != ".dxf":
            path = path+".dxf"
        if not overwrite and exists(path):
            if not silent:
                print("Topology.ExportToDXF - Error: a file already exists at the specified path and overwrite is set to False. Returning False.")
            return False
        
        def add_vertices(vertices, msp):
            for v in vertices:
                if Topology.IsInstance(v, "Vertex"):
                    msp.add_point((Vertex.X(v, mantissa=mantissa), Vertex.Y(v, mantissa=mantissa), Vertex.Z(v, mantissa=mantissa)))
        def add_edges(edges, msp):
            for e in edges:
                if Topology.IsInstance(e, "Edge"):
                    sv = Edge.StartVertex(e)
                    ev = Edge.EndVertex(e)
                    start = (Vertex.X(sv, mantissa=mantissa), Vertex.Y(sv, mantissa=mantissa), Vertex.Z(sv, mantissa=mantissa))
                    end = (Vertex.X(ev, mantissa=mantissa), Vertex.Y(ev, mantissa=mantissa), Vertex.Z(ev, mantissa=mantissa))
                    msp.add_line(start, end)
        def add_wires(wires, msp):
            for i, w in enumerate(wires):
                if Topology.IsInstance(w, "Wire"):
                    block_name = "Wire_"+str(i+1).zfill(3)
                    block = doc.blocks.new(name=block_name)
                    # Add edges to the block
                    edges = Topology.Edges(w)
                    for edge in edges:
                        sv = Edge.StartVertex(edge)
                        ev = Edge.EndVertex(edge)
                        start = (Vertex.X(sv, mantissa=mantissa), Vertex.Y(sv, mantissa=mantissa), Vertex.Z(sv, mantissa=mantissa))
                        end = (Vertex.X(ev, mantissa=mantissa), Vertex.Y(ev, mantissa=mantissa), Vertex.Z(ev, mantissa=mantissa))
                        block.add_line(start, end)
                    # Insert the block into the model space
                    msp.add_blockref(block_name, insert=(0, 0, 0))
        def add_meshes(meshes, msp):
            for m in meshes:
                data = Topology.Geometry(m)
                vertices = data['vertices']
                faces = data['faces']
                mesh = msp.add_mesh()
                mesh.dxf.subdivision_levels = 0
                with mesh.edit_data() as mesh_data:
                    mesh_data.vertices = vertices
                    mesh_data.faces = faces
        # Create a new DXF document
        doc = ezdxf.new(dxfversion='R2010')
        msp = doc.modelspace()
        i = 1
        for topology in topologies:
            if Topology.IsInstance(topology, "Vertex"):
                add_vertices([topology], msp)
            elif Topology.IsInstance(topology, "Edge"):
                add_edges([topology], msp)
            elif Topology.IsInstance(topology, "Wire"):
                add_wires([topology], msp)
            elif Topology.IsInstance(topology, "Face"):
                add_meshes([topology], msp)
            elif Topology.IsInstance(topology, "Shell"):
                add_meshes([topology], msp)
            elif Topology.IsInstance(topology, "Cell"):
                add_meshes([topology], msp)
            elif Topology.IsInstance(topology, "CellComplex"):
                add_meshes([topology], msp)
            elif Topology.IsInstance(topology, "Cluster"):
                cellComplexes = Topology.CellComplexes(topology)
                add_meshes(cellComplexes, msp)
                cells = Cluster.FreeCells(topology)
                add_meshes(cells, msp)
                shells = Cluster.FreeShells(topology)
                add_meshes(shells, msp)
                faces = Cluster.FreeFaces(topology)
                add_meshes(faces, msp)
                wires = Cluster.FreeWires(topology)
                add_wires(wires, msp)
                edges = Cluster.FreeEdges(topology)
                add_edges(edges, msp)
                vertices = Cluster.FreeVertices(topology)
                add_vertices(vertices, msp)
        
        # Save the DXF document
        status = False
        try:
            doc.saveas(path)
            status = True
        except:
            status = False
        return status

    '''
    @staticmethod
    def ExportToIPFS(topology, url, port, user, password):
        """
        NOT DONE YET

        Parameters
        ----------
        topology : TYPE
            DESCRIPTION.
        url : TYPE
            DESCRIPTION.
        port : TYPE
            DESCRIPTION.
        user : TYPE
            DESCRIPTION.
        password : TYPE
            DESCRIPTION.

        Returns
        -------
        TYPE
            DESCRIPTION.

        """
        # topology, url, port, user, password = item
        
        def exportToBREP(topology, path, overwrite):
            # Make sure the file extension is .brep
            ext = path[len(path)-5:len(path)]
            if ext.lower() != ".brep":
                path = path+".brep"
            f = None
            try:
                if overwrite == True:
                    f = open(path, "w")
                else:
                    f = open(path, "x") # Try to create a new File
            except:
                raise Exception("Error: Could not create a new file at the following location: "+path)
            if (f):
                topString = Topology.BREPString(topology)
                f.write(topString)
                f.close()	
                return True
            return False
        
        path = os.path.expanduser('~')+"/tempFile.brep"
        if exportToBREP(topology, path, True):
            url = url.replace('http://','')
            url = '/dns/'+url+'/tcp/'+port+'/https'
            client = ipfshttpclient.connect(url, auth=(user, password))
            newfile = client.add(path)
            os.remove(path)
            return newfile['Hash']
        return ''
    '''
    @staticmethod
    def ExportToJSON(topologies, path, overwrite: bool = False, silent: bool = False):
        """
        Exports the input list of topologies to a JSON file.

        Parameters
        ----------
        topologies : list
            The input list of topologies.
        path : str
            The path to the JSON file.
        overwrite : bool , optional
            If set to True the ouptut file will overwrite any pre-existing file. Otherwise, it won't. Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            The status of exporting the JSON file. If True, the operation was successful. Otherwise, it was unsuccesful.

        """
        from os.path import exists
        # Make sure the file extension is .json
        ext = path[len(path)-5:len(path)]
        if ext.lower() != ".json":
            path = path+".json"
        if not overwrite and exists(path):
            if not silent:
                print("Topology.ExportToJSON - Error: a file already exists at the specified path and overwrite is set to False. Returning None.")
            return None
        f = None
        try:
            if overwrite == True:
                f = open(path, "w")
            else:
                f = open(path, "x") # Try to create a new File
        except:
            f = None
            pass
        
        if (f):
            jsondata = json.loads(Topology.JSONString(topologies, silent=silent))
            if jsondata != None:
                json.dump(jsondata, f, indent=4, sort_keys=True)
                f.close()
                return True
            else:
                f.close()
                if not silent:
                    print(f"Topology.ExportToJSON - Error: Could not writre to the file at the following location: {path}. Returning False.")
                return False
        else:
            if not silent:
                print(f"Topology.ExportToJSON - Error: Could not create a new file at the following location: {path}. Returning None.")
            return None

    @staticmethod
    def Faces(topology, silent: bool = False):
        """
        Returns the faces of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of faces.

        """

        import inspect

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Faces - Error: The input is not a valid topology. Returning None")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return None
        
        if Topology.IsInstance(topology, "Face"):
            if not silent:
                print("Topology.Faces - Warning: The input is a Face. Returning the same face embedded in a list.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return [topology]
        
        if Topology.IsInstance(topology, "Wire") or Topology.IsInstance(topology, "Edge") or Topology.IsInstance(topology, "Vertex"):
            if not silent:
                print("Topology.Faces - Warning: The input is a lower dimension than a face. Returning an empty list.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return []
        
        return Topology.SubTopologies(topology=topology, subTopologyType="face", silent=silent)

    @staticmethod
    def Fix(topology, topologyType: str = "CellComplex", tolerance: float = 0.0001, silent: bool = False):
        """
        Attempts to fix the input topology to matched the desired output type.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology
        topologyType : str , optional
            The desired output topology type. This must be one of "vertex", "edge", "wire", "face", "shell", "cell", "cellcomplex", "cluster". It is case insensitive. Default is "CellComplex"
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        topologic_core.Topology
            The output topology in the desired type.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Cluster import Cluster

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.Fix - Error: The input topology parameter is not a valid topology. Returning None.")
            return None

        topology = Cluster.ByTopologies([topology])
        a_type = Topology.TypeAsString(topology).lower()
        b_type = topologyType.lower()
        if b_type not in ["vertex", "edge", "wire", "face", "shell", "cell", "cellcomplex", "cluster"]:
            print("Topology.Fix - Error: The input topologyType parameter is not recognized. Returning original topology.")
            return topology
        if a_type == b_type:
            return topology
        if b_type == "cluster":
            topology = Topology.SelfMerge(topology, tolerance=tolerance)
            return Cluster.ByTopologies([topology])
        if b_type == "cellcomplex":
            topology = Topology.SelfMerge(topology, tolerance=tolerance)
            if Topology.TypeAsString(topology).lower() == "cellcomplex":
                return topology
            cells = Topology.Cells(topology)
            if len(cells) < 2:
                print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                return topology
            return_topology = CellComplex.ByCells(cells)
            if return_topology == None:
                print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                return topology
            if Topology.TypeAsString(topology).lower() == "cellcomplex":
                return return_topology
            faces = Topology.Faces(topology)
            if len(faces) < 3:
                print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                return topology
            return_topology = CellComplex.ByFaces(faces, tolerance=tolerance)
            if return_topology == None:
                print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                return topology
            if Topology.TypeAsString(return_topology).lower() == "cellcomplex":
                return return_topology
            print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
            return topology
        if b_type == "cell":
            topology = Topology.SelfMerge(topology, tolerance=tolerance)
            if Topology.TypeAsString(topology).lower() == "cell":
                return topology
            if Topology.TypeAsString(topology).lower() == "cellComplex":
                return CellComplex.ExternalBoundary(topology)
            faces = Topology.Faces(topology)
            if len(faces) < 3:
                print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                return topology
            return_topology = Cell.ByFaces(faces, tolerance=tolerance)
            if return_topology == None:
                return_topology = CellComplex.ByFaces(faces, tolerance=tolerance)
                if return_topology == None:
                    print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                    return topology
                elif len(Topology.Cells(return_topology)) < 1:
                    print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                    return topology
                return_topology = CellComplex.ExternalBoundary(return_topology)
            if return_topology == None:
                print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                return topology
            if Topology.TypeAsString(return_topology).lower() == "cell":
                return return_topology
            print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
            return topology
        if b_type == "shell":
            topology = Topology.SelfMerge(topology, tolerance=tolerance)
            if Topology.TypeAsString(topology).lower() == "shell":
                return topology
            faces = Topology.Faces(topology)
            if len(faces) < 2:
                print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                return topology
            return_topology = Shell.ByFaces(faces)
            if Topology.TypeAsString(return_topology).lower() == "shell":
                return return_topology
            print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
            return topology
        if b_type == "face":
            topology = Topology.SelfMerge(topology, tolerance=tolerance)
            if Topology.TypeAsString(topology).lower() == "face":
                return topology
            wires = Topology.Wires(topology)
            if len(wires) < 1:
                print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                return topology
            return_topology = Face.ByWire(wires[0], tolerance=tolerance)
            if Topology.TypeAsString(return_topology).lower() == "face":
                return return_topology
            print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
            return topology
        if b_type == "wire":
            topology = Topology.SelfMerge(topology, tolerance=tolerance)
            if Topology.TypeAsString(topology).lower() == "wire":
                return topology
            edges = Topology.Edges(topology)
            if len(edges) < 2:
                print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                return topology
            return_topology = Wire.ByEdges(edges, tolerance=tolerance)
            if Topology.TypeAsString(return_topology).lower() == "wire":
                return return_topology
            print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
            return topology
        if b_type == "edge":
            topology = Topology.SelfMerge(topology, tolerance=tolerance)
            if Topology.TypeAsString(topology).lower() == "edge":
                return topology
            vertices = Topology.Vertices(topology, silent=True)
            if len(vertices) < 2:
                print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                return topology
            return_topology = Edge.ByVertices(vertices, tolerance=tolerance)
            if Topology.TypeAsString(return_topology).lower() == "edge":
                return return_topology
            print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
            return topology
        if b_type == "vertex":
            topology = Topology.SelfMerge(topology, tolerance=tolerance)
            if Topology.TypeAsString(topology).lower() == "vertex":
                return topology
            vertices = Topology.Vertices(topology,silent=True)
            if len(vertices) < 1:
                print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
                return topology
            return_topology = vertices[0]
            if Topology.TypeAsString(return_topology).lower() == "vertex":
                return return_topology
            print("Topology.Fix - Error: Desired topologyType cannot be achieved. Returning original topology.")
            return topology
        return topology

    @staticmethod
    def JSONString(topologies, mantissa: int = 6, silent: bool = False):
        """
        Exports the input list of topologies to a JSON string

        Parameters
        ----------
        topologies : list or topologic_core.Topology
            The input list of topologies or a single topology.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        
        Returns
        -------
        bool
            The status of exporting the JSON file. If True, the operation was successful. Otherwise, it was unsuccesful.

        """

        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Face import Face
        from topologicpy.Cell import Cell
        from topologicpy.Cluster import Cluster
        from topologicpy.Dictionary import Dictionary

        # Geometry-stable uuid cache. The PythonOCC backend re-wraps shared
        # sub-topologies (a vertex/edge common to two adjacent faces) into NEW
        # Python objects on each extraction, so a per-wrapper uuid (stored in
        # the dictionary) differs between copies and a Cell's faces->wires->
        # edges->vertices references can point at uuids that were never emitted
        # as records -- corrupting ByJSONDictionary with a KeyError. Keying the
        # uuid on geometry instead (rounded to the project tolerance, 1e-4)
        # makes every copy of the same entity agree.
        _geo_uuid_cache = {}

        def _geometry_key(topology, uuidKey="uuid"):
            try:
                if Topology.IsInstance(topology, "vertex"):
                    try:
                        return ("vertex", tuple(round(float(c), 4) for c in Vertex.Coordinates(topology)))
                    except Exception:
                        return None
                if Topology.IsInstance(topology, "edge"):
                    ends = []
                    for v in Topology.Vertices(topology) or []:
                        try:
                            ends.append(tuple(round(float(c), 4) for c in Vertex.Coordinates(v)))
                        except Exception:
                            return None
                    if len(ends) == 2:
                        return ("edge", tuple(sorted(ends)))
                    return None
                if Topology.IsInstance(topology, "wire"):
                    keys = []
                    for e in Topology.Edges(topology) or []:
                        k = _geometry_key(e, uuidKey)
                        if k is None:
                            return None
                        keys.append(k)
                    return ("wire", tuple(sorted(keys)))
                if Topology.IsInstance(topology, "face"):
                    keys = []
                    for w in Topology.Wires(topology) or []:
                        k = _geometry_key(w, uuidKey)
                        if k is None:
                            return None
                        keys.append(k)
                    return ("face", tuple(sorted(keys)))
            except Exception:
                return None
            return None

        def getUUID(topology, uuidKey="uuid"):
            gkey = _geometry_key(topology, uuidKey)
            if gkey is not None:
                cached = _geo_uuid_cache.get(gkey)
                if cached is not None:
                    return cached
            d = Topology.Dictionary(topology)
            if uuidKey not in Dictionary.Keys(d):
                uuidOne = str(uuid.uuid1())
                d = Dictionary.SetValueAtKey(d, uuidKey, uuidOne)
                topology = Topology.SetDictionary(topology, d)
            else:
                uuidOne = Dictionary.ValueAtKey(d, uuidKey)
            if gkey is not None:
                _geo_uuid_cache[gkey] = uuidOne
            return uuidOne

        def getVertex(topology, uuidKey="uuid"):
            returnDict = {}
            uuidOne = getUUID(topology, uuidKey=uuidKey)
            returnDict['type'] = "Vertex"
            returnDict['uuid'] = uuidOne
            returnDict['coordinates'] = Vertex.Coordinates(topology, mantissa=mantissa)
            returnDict['dictionary'] = Dictionary.PythonDictionary(Topology.Dictionary(topology))
            return returnDict

        def getEdge(topology, uuidKey="uuid"):
            returnDict = {}
            uuidOne = getUUID(topology, uuidKey=uuidKey)
            returnDict['type'] = "Edge"
            returnDict['uuid'] = uuidOne
            returnDict['vertices'] = [getUUID(v, uuidKey=uuidKey) for v in Topology.Vertices(topology)]
            returnDict['dictionary'] = Dictionary.PythonDictionary(Topology.Dictionary(topology))
            return returnDict

        def getWire(topology, uuidKey="uuid"):
            returnDict = {}
            uuidOne = getUUID(topology, uuidKey="uuid")
            returnDict['type'] = "Wire"
            returnDict['uuid'] = uuidOne
            returnDict['edges'] = [getUUID(e, uuidKey=uuidKey) for e in Topology.Edges(topology)]
            returnDict['dictionary'] = Dictionary.PythonDictionary(Topology.Dictionary(topology))
            return returnDict

        def getFace(topology, uuidKey="uuid"):
            returnDict = {}
            uuidOne = getUUID(topology, uuidKey=uuidKey)
            returnDict['type'] = "Face"
            returnDict['uuid'] = uuidOne
            wires = []
            wires.append(getUUID(Face.ExternalBoundary(topology), uuidKey=uuidKey))
            internal_boundaries = [getUUID(ib, uuidKey=uuidKey) for ib in Face.InternalBoundaries(topology)]
            wires += internal_boundaries
            returnDict['wires'] = wires
            dictionary = Dictionary.PythonDictionary(Topology.Dictionary(topology))
            returnDict['dictionary'] = dictionary
            return returnDict

        def getShell(topology, uuidKey="uuid"):
            returnDict = {}
            uuidOne = getUUID(topology, uuidKey=uuidKey)
            returnDict['type'] = "Shell"
            returnDict['uuid'] = uuidOne
            returnDict['faces'] = [getUUID(f, uuidKey=uuidKey) for f in Topology.Faces(topology)]
            returnDict['dictionary'] = Dictionary.PythonDictionary(Topology.Dictionary(topology))
            return returnDict

        def getCell(topology, uuidKey="uuid"):
            returnDict = {}
            uuidOne = getUUID(topology, uuidKey=uuidKey)
            returnDict['type'] = "Cell"
            returnDict['uuid'] = uuidOne
            shells = []
            external_boundary = Cell.ExternalBoundary(topology)
            shells.append(getUUID(external_boundary, uuidKey=uuidKey))
            internal_boundaries = [getUUID(ib, uuidKey=uuidKey) for ib in Cell.InternalBoundaries(topology)]
            shells += internal_boundaries
            returnDict['shells'] = shells
            dictionary = Dictionary.PythonDictionary(Topology.Dictionary(topology))
            returnDict['dictionary'] = dictionary
            return returnDict

        def getCellComplex(topology, uuidKey="uuid"):
            returnDict = {}
            uuidOne = getUUID(topology, uuidKey=uuidKey)
            returnDict['type'] = "CellComplex"
            returnDict['uuid'] = uuidOne
            returnDict['cells'] = [getUUID(c, uuidKey=uuidKey) for c in Topology.Cells(topology)]
            returnDict['dictionary'] = Dictionary.PythonDictionary(Topology.Dictionary(topology))
            return returnDict

        def getApertureData(topology, topLevel="False", uuidKey="uuid"):
            json_data = []
            json_data += getSubTopologyData(topology, uuidKey=uuidKey)
            json_data[-1]['dictionary']['toplevel'] = topLevel
            return json_data

        def getSubTopologyData(topology, uuidKey="uuid"):
            json_data = []
            vertices = Topology.Vertices(topology, silent=True)
            for v in vertices:
                d = getVertex(v, uuidKey=uuidKey)
                d['dictionary']['toplevel'] = False
                apertures = Topology.Apertures(v, silent=True)
                aperture_data = []
                for ap in apertures:
                    aperture_data.append(getApertureData(ap, topLevel=False, uuidKey=uuidKey))
                d['apertures'] = aperture_data
                json_data.append(d)
            edges = Topology.Edges(topology, silent=True)
            for e in edges:
                d = getEdge(e, uuidKey=uuidKey)
                d['dictionary']['toplevel'] = False
                apertures = Topology.Apertures(e, silent=True)
                aperture_data = []
                for ap in apertures:
                    aperture_data.append(getApertureData(ap, topLevel=False, uuidKey=uuidKey))
                d['apertures'] = aperture_data
                json_data.append(d)
            wires = Topology.Wires(topology, silent=True)
            for w in wires:
                d = getWire(w, uuidKey=uuidKey)
                d['dictionary']['toplevel'] = False
                apertures = Topology.Apertures(w, silent=True)
                aperture_data = []
                for ap in apertures:
                    aperture_data.append(getApertureData(ap, topLevel=False, uuidKey=uuidKey))
                d['apertures'] = aperture_data
                json_data.append(d)
            faces = Topology.Faces(topology, silent=True)
            for f in faces:
                d = getFace(f, uuidKey=uuidKey)
                d['dictionary']['toplevel'] = False
                apertures = Topology.Apertures(f, silent=True)
                aperture_data = []
                for ap in apertures:
                    aperture_data.append(getApertureData(ap, topLevel=False, uuidKey=uuidKey))
                d['apertures'] = aperture_data
                json_data.append(d)
            shells = Topology.Shells(topology, silent=True)
            for s in shells:
                d = getShell(s, uuidKey=uuidKey)
                d['dictionary']['toplevel'] = False
                apertures = Topology.Apertures(s, silent=True)
                aperture_data = []
                for ap in apertures:
                    aperture_data.append(getApertureData(ap, topLevel=False, uuidKey=uuidKey))
                d['apertures'] = aperture_data
                json_data.append(d)
            cells = Topology.Cells(topology, silent=True)
            for c in cells:
                d = getCell(c, uuidKey=uuidKey)
                d['dictionary']['toplevel'] = False
                apertures = Topology.Apertures(c, silent=True)
                aperture_data = []
                for ap in apertures:
                    aperture_data.append(getApertureData(ap, topLevel=False, uuidKey=uuidKey))
                d['apertures'] = aperture_data
                json_data.append(d)
            cellComplexes = Topology.CellComplexes(topology, silent=True)
            for cc in cellComplexes:
                d = getCellComplex(cc, uuidKey=uuidKey)
                d['dictionary']['toplevel'] = False
                apertures = Topology.Apertures(cc, silent=True)
                aperture_data = []
                for ap in apertures:
                    aperture_data.append(getApertureData(ap, topLevel=False, uuidKey=uuidKey))
                d['apertures'] = aperture_data
                json_data.append(d)
            return json_data

        def getJSONData(topology, topLevel=False, uuidKey="uuid"):
            json_data = []
            json_data += getSubTopologyData(topology, uuidKey=uuidKey)
            json_data[-1]['dictionary']['toplevel'] = topLevel #assign top level to the last topology
            return json_data
        
        def addClusterKey(cluster):
            c_uuid = Topology.UUID(cluster)
            c_topologies = Cluster.Topologies(cluster)
            for c_topology in c_topologies:
                if Topology.IsInstance(c_topology, "Cluster"):
                    c_topologies += addClusterKey(c_topology)
                else:
                    d = Topology.Dictionary(c_topology)
                    d = Dictionary.SetValueAtKey(d, "__cluster__", c_uuid)
                    c_topology = Topology.SetDictionary(c_topology, d)
            return c_topologies
            
        json_data = []
        if not isinstance(topologies, list):
            topologies = [topologies]
        clean_topologies = []
        for topology in topologies:
            if Topology.IsInstance(topology, "Topology"):
                if Topology.IsInstance(topology, "Cluster"):
                    c_topologies = addClusterKey(topology)
                    clean_topologies += c_topologies
                else:
                    clean_topologies.append(topology)
        
        if len(clean_topologies) == 0:
            if not silent:
                print("Topology.JSONString - Error: The input topologies parameter does not contain any valid topologies. Returning None.")
            return None

        for topology in clean_topologies:
            json_data += getJSONData(topology, topLevel=True, uuidKey="uuid")
        json_string = json.dumps(json_data, indent=4, sort_keys=False)
        return json_string
    

    @staticmethod
    def _OBJString(topology,
                   color,
                   vertexIndex,
                   transposeAxes: bool = True,
                   triangulate: bool = False,
                   mode: int = 0,
                   meshSize: float = None,
                   mantissa: int = 6,
                   tolerance: float = 0.0001,
                   silent: bool = False):
        """
        Returns the Wavefront OBJ string of the input topology. This is very experimental and outputs a simple solid topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        color : str
            The desired material name to assign to the topology.
        vertexIndex : int
            The vertex index to use as the starting index.
        transposeAxes : bool , optional
            If set to True the Z and Y coordinates are transposed so that Y points "up". Default is True.
        triangulate : bool , optional
            If set to True, all faces of the input geometry are triangulated. Otherwise, only faces with holes are triangulated. Default is False.
        mode : int , optional
            The desired mode of meshing algorithm (for triangulation). Several options are available:
            0: Classic
            1: MeshAdapt
            3: Initial Mesh Only
            5: Delaunay
            6: Frontal-Delaunay
            7: BAMG
            8: Fontal-Delaunay for Quads
            9: Packing of Parallelograms
            All options other than 0 (Classic) use the gmsh library. See https://gmsh.info/doc/texinfo/gmsh.html#Mesh-options
            WARNING: The options that use gmsh can be very time consuming and can create very heavy geometry.
        meshSize : float , optional
            The desired size of the mesh when using the "mesh" option. If set to None, it will be
            calculated automatically and set to 10% of the overall size of the face.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.

        Returns
        -------
        tuple
            The Wavefront OBJ string and the number of vertices exported.

        """

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology._OBJString - Error: The input topology parameter is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology._OBJString - Error: Could not triangulate the input topology. Returning None.")
            return None

        d = Topology.Geometry(topology,
                              triangulate = triangulate,
                              mode = mode,
                              meshSize = meshSize,
                              mantissa = mantissa,
                              tolerance = tolerance,
                              silent = silent)

        if not isinstance(d, dict):
            if not silent:
                print("Topology._OBJString - Error: Could not extract geometry from the input topology. Returning None.")
            return None

        vertices = d.get("vertices", [])
        faces = d.get("faces", [])

        lines = []

        if transposeAxes:
            lines.extend(
                "v " + str(v[0]) + " " + str(-v[2]) + " " + str(v[1])
                for v in vertices
            )
        else:
            lines.extend(
                "v " + str(v[0]) + " " + str(v[1]) + " " + str(v[2])
                for v in vertices
            )

        if len(faces) > 0:
            lines.append("usemtl " + str(color))

            vi = vertexIndex
            lines.extend(
                "f " + " ".join(str(j + vi) for j in f)
                for f in faces
            )

        return "\n".join(lines), len(vertices)
    

    @staticmethod
    def ExportToOBJ(*topologies,
                    path,
                    nameKey="name",
                    colorKey="color",
                    opacityKey="opacity",
                    defaultColor=[256,256,256],
                    defaultOpacity=0.5,
                    transposeAxes: bool = True,
                    triangulate: bool = False,
                    mode: int = 0,
                    meshSize: float = None,
                    overwrite: bool = False,
                    mantissa: int = 6,
                    tolerance: float = 0.0001,
                    silent: bool = False):
        """
        Exports the input topology to a Wavefront OBJ file. This is very experimental and outputs a simple solid topology.

        Parameters
        ----------
        topologies : list or comma separated topologies
            The input list of topologies.
        path : str
            The input file path.
        nameKey : str , optional
            The topology dictionary key under which to find the name of the topology. Default is "name".
        colorKey : str, optional
            The topology dictionary key under which to find the color of the topology. Default is "color".
        opacityKey : str , optional
            The topology dictionary key under which to find the opacity of the topology. Default is "opacity".
        defaultColor : list , optional
            The default color to use if no color is stored in the topology dictionary. Default is [255,255, 255] (white).
        defaultOpacity : float , optional
            The default opacity to use of no opacity is stored in the topology dictionary. This must be between 0 and 1. Default is 1 (fully opaque).
        transposeAxes : bool , optional
            If set to True the Z and Y coordinates are transposed so that Y points "up"
        triangulate : bool , optional
            If set to True, all faces of the input geometry are triangulated. Otherwise, only faces with holes are triangulated. Default is False.
        mode : int , optional
            The desired mode of meshing algorithm (for triangulation). Several options are available:
            0: Classic
            1: MeshAdapt
            3: Initial Mesh Only
            5: Delaunay
            6: Frontal-Delaunay
            7: BAMG
            8: Fontal-Delaunay for Quads
            9: Packing of Parallelograms
            All options other than 0 (Classic) use the gmsh library. See https://gmsh.info/doc/texinfo/gmsh.html#Mesh-options
            WARNING: The options that use gmsh can be very time consuming and can create very heavy geometry.
        meshSize : float , optional
            The desired size of the mesh when using the "mesh" option. If set to None, it will be
            calculated automatically and set to 10% of the overall size of the face.
        overwrite : bool , optional
            If set to True the ouptut file will overwrite any pre-existing file. Otherwise, it won't. Default is False.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        

        Returns
        -------
        bool
            True if the export operation is successful. False otherwise.

        """
        from topologicpy.Helper import Helper
        from os.path import exists

        if isinstance(topologies, tuple):
            topologies = Helper.Flatten(list(topologies))
        if isinstance(topologies, list):
            new_topologies = [d for d in topologies if Topology.IsInstance(d, "Topology")]
        if len(new_topologies) == 0:
            if not silent:
                print("Topology.ExportToOBJ - Error: the input topologies parameter does not contain any valid topologies. Returning None.")
            return None
        if not isinstance(new_topologies, list):
            if not silent:
                print("Topology.ExportToOBJ - Error: The input topologies parameter is not a valid list. Returning None.")
            return None

        if not overwrite and exists(path):
            if not silent:
                print("Topology.ExportToOBJ - Error: a file already exists at the specified path and overwrite is set to False. Returning None.")
            return None
        
        # Make sure the file extension is .obj
        ext = path[len(path)-4:len(path)]
        if ext.lower() != ".obj":
            path = path+".obj"
        status = False
       
        mtl_path = path[:-4] + ".mtl"

        obj_string, mtl_string = Topology.OBJString(new_topologies,
                                                    nameKey=nameKey,
                                                    colorKey=colorKey,
                                                    opacityKey=opacityKey,
                                                    defaultColor=defaultColor,
                                                    defaultOpacity=defaultOpacity,
                                                    transposeAxes=transposeAxes,
                                                    triangulate=triangulate,
                                                    mode=mode,
                                                    meshSize=meshSize,
                                                    mantissa=mantissa,
                                                    tolerance=tolerance,
                                                    silent=silent)
        # Write out the material file
        with open(mtl_path, "w") as mtl_file:
            mtl_file.write(mtl_string)
        # Write out the obj file
        with open(path, "w") as obj_file:
            obj_file.write(obj_string)
        return True

    @staticmethod
    def Filter(topologies,
               topologyType: str = "any",
               searchType: str = "any",
               key: str = None,
               value=None,
               silent: bool = None):
        """
        Filters the input list of topologies based on the input parameters.

        Parameters
        ----------
        topologies : list
            The input list of topologies.
        topologyType : str , optional
            The type of topology to filter by. This can be one of "any", "vertex",
            "edge", "wire", "face", "shell", "cell", "cellcomplex", or "cluster".
            It is case insensitive. Default is "any".
        searchType : str , optional
            The type of search query to conduct in the topology's dictionary. This can
            be one of "any", "equal to", "contains", "starts with", "ends with",
            "not equal to", or "does not contain". It is case insensitive.
            Wildcard matching using shell-style patterns is supported in all search
            types through the use of "*" and "?".
            Default is "any".
        key : str , optional
            The dictionary key to search within. Default is None which means it will
            filter by topology type only.
        value : any , optional
            The value to search for at the specified key. Default is None which means
            it will filter by topology type only.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        dict
            A dictionary with the following keys:
            - "filtered": the filtered topologies.
            - "other": the other topologies that did not meet the filter criteria.

        """
        import fnmatch
        from topologicpy.Topology import Topology
        from topologicpy.Dictionary import Dictionary

        def normalize_string(item):
            """
            Converts the input item to a normalized lower-case string.
            Lists are converted to a stable concatenated representation.
            """
            if item is None:
                return None
            if isinstance(item, list):
                try:
                    return " ".join([str(x) for x in sorted(item)]).lower()
                except Exception:
                    return " ".join([str(x) for x in item]).lower()
            return str(item).lower()

        def has_wildcards(s):
            """
            Returns True if the input string contains shell-style wildcard characters.
            """
            if not isinstance(s, str):
                return False
            return ("*" in s) or ("?" in s) or ("[" in s and "]" in s)

        def wildcard_equal(pattern, candidate):
            """
            Case-insensitive shell-style wildcard equality.
            """
            if pattern is None or candidate is None:
                return False
            return fnmatch.fnmatch(candidate, pattern)

        def wildcard_contains(pattern, candidate):
            """
            Case-insensitive shell-style wildcard containment.
            If the pattern contains wildcards, match against all substrings by wrapping
            the pattern in leading and trailing '*', unless already present.
            """
            if pattern is None or candidate is None:
                return False
            if has_wildcards(pattern):
                test_pattern = pattern
                if not test_pattern.startswith("*"):
                    test_pattern = "*" + test_pattern
                if not test_pattern.endswith("*"):
                    test_pattern = test_pattern + "*"
                return fnmatch.fnmatch(candidate, test_pattern)
            return pattern in candidate

        def wildcard_startswith(pattern, candidate):
            """
            Case-insensitive shell-style wildcard starts-with matching.
            """
            if pattern is None or candidate is None:
                return False
            if has_wildcards(pattern):
                return fnmatch.fnmatch(candidate, pattern + "*")
            return candidate.startswith(pattern)

        def wildcard_endswith(pattern, candidate):
            """
            Case-insensitive shell-style wildcard ends-with matching.
            """
            if pattern is None or candidate is None:
                return False
            if has_wildcards(pattern):
                return fnmatch.fnmatch(candidate, "*" + pattern)
            return candidate.endswith(pattern)
        
        # Input validation
        if not isinstance(topologies, list):
            if not silent:
                print("Topology.Filter - Error: The input topologies parameter is not a valid list. Returning None.")
            return None
        
        topologies = [t for t in topologies if Topology.IsInstance(t, "topology")]
        
        if len(topologies) == 0:
            if not silent:
                print("Topology.Filter - Error: The input topologies parameter does not contain any valid topologies. Returning None.")
            return None

        filteredTopologies = []
        otherTopologies = []

        topologyType = "any" if topologyType is None else str(topologyType).lower()
        searchType = "any" if searchType is None else str(searchType).lower()

        for aTopology in topologies:
            if not aTopology:
                continue

            # Filter by topology type first
            try:
                aTopologyType = Topology.TypeAsString(aTopology).lower()
            except Exception:
                otherTopologies.append(aTopology)
                continue

            if topologyType != "any" and aTopologyType != topologyType:
                otherTopologies.append(aTopology)
                continue

            # If no key/value is supplied, filter by topology type only
            if key is None or key == "" or value is None or value == "":
                filteredTopologies.append(aTopology)
                continue

            # Get dictionary safely
            try:
                d = Topology.Dictionary(aTopology)
            except Exception:
                d = None

            if not d:
                otherTopologies.append(aTopology)
                continue

            try:
                dictValue = Dictionary.ValueAtKey(d, key)
            except Exception:
                dictValue = None

            if dictValue is None:
                otherTopologies.append(aTopology)
                continue

            valueString = normalize_string(value)
            dictValueString = normalize_string(dictValue)

            if valueString is None or dictValueString is None:
                otherTopologies.append(aTopology)
                continue

            if searchType == "any":
                searchResult = True
            elif searchType == "equal to" or searchType == "equal" or searchType == "equals" or searchType == "equals to":
                if has_wildcards(valueString):
                    searchResult = wildcard_equal(valueString, dictValueString)
                else:
                    searchResult = (valueString == dictValueString)
            elif searchType == "contains":
                searchResult = wildcard_contains(valueString, dictValueString)
            elif searchType == "starts with":
                searchResult = wildcard_startswith(valueString, dictValueString)
            elif searchType == "ends with":
                searchResult = wildcard_endswith(valueString, dictValueString)
            elif searchType == "not equal to":
                if has_wildcards(valueString):
                    searchResult = not wildcard_equal(valueString, dictValueString)
                else:
                    searchResult = (valueString != dictValueString)
            elif searchType == "does not contain":
                searchResult = not wildcard_contains(valueString, dictValueString)
            else:
                searchResult = False

            if searchResult:
                filteredTopologies.append(aTopology)
            else:
                otherTopologies.append(aTopology)

        return {"filtered": filteredTopologies, "other": otherTopologies}

    @staticmethod
    def Flatten(topology, origin=None, direction: list = [0, 0, 1], transferDictionaries=True, mantissa: int = 6, silent: bool = False):
        """
        Flattens the input topology such that the input origin is located at the world origin and the input topology is rotated such that the input vector is pointed in the Up direction (see Vector.Up()).

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        origin : topologic_core.Vertex , optional
            The input origin. If set to None, The object's centroid will be used to place the world origin. Default is None.
        direction : list , optional
            The input direction vector. The input topology will be rotated such that this vector is pointed in the positive Z axis.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        transferDictionaries : bool , optional
            If set to True, the dictionaries are transfered from the original object to the translated object. Default is True.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The flattened topology.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Vector import Vector
        
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Flatten - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(origin, "Vertex"):
            origin = Topology.Centroid(topology)
        up = Vector.Up()
        flat_topology = Topology.Translate(topology,
                                           x = -Vertex.X(origin, mantissa=mantissa),
                                           y = -Vertex.Y(origin, mantissa=mantissa),
                                           z = -Vertex.Z(origin, mantissa=mantissa),
                                           transferDictionaries = False,
                                           silent=True)
        tran_mat = Vector.TransformationMatrix(direction, up)
        flat_topology = Topology.Transform(flat_topology,
                                           tran_mat,
                                           transferDictionaries = transferDictionaries,
                                           silent=True)
        return flat_topology
    
    @staticmethod
    def Geometry(topology,
                transferDictionaries: bool = False,
                triangulate: bool = False,
                mode : int = 0,
                meshSize : float = None,
                mantissa: int = 6,
                tolerance: float = 0.0001,
                silent: bool = False):
        """
        Returns the geometry (mesh data format) of the input topology as a dictionary of vertices, edges, and faces.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The input topology or graph.
        transferDictionaries : bool , optional
            If set to True, vertex, edge, and face dictionaries will be included in the output. Otherwise, they are not. Default is False.
        triangulate : bool , optional
            If set to True, all faces of the input geometry are triangulated. Otherwise, only faces with holes are triangulated. Default is False.
                mode : int , optional
            The desired mode of meshing algorithm (for triangulation). Several options are available:
            0: Classic
            1: MeshAdapt
            3: Initial Mesh Only
            5: Delaunay
            6: Frontal-Delaunay
            7: BAMG
            8: Fontal-Delaunay for Quads
            9: Packing of Parallelograms
            All options other than 0 (Classic) use the gmsh library. See https://gmsh.info/doc/texinfo/gmsh.html#Mesh-options
            WARNING: The options that use gmsh can be very time consuming and can create very heavy geometry.
        meshSize : float , optional
            The desired size of the mesh when using the "mesh" option. If set to None, it will be
            calculated automatically and set to 10% of the overall size of the face. Default is None.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        dict
            A dictionary containing the vertices, edges, and faces data. The keys found in the dictionary are "vertices", "edges", and "faces".

        """

        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Face import Face
        from topologicpy.Dictionary import Dictionary

        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            TGraph = None
            is_tgraph = False

        # ------------------------------------------------------------------
        # TGraph path.
        # ------------------------------------------------------------------
        if is_tgraph:
            vertices = []
            edges = []
            faces = []
            vertex_dicts = []
            edge_dicts = []
            face_dicts = []

            index_map = {}

            records = TGraph.Vertices(topology, asTopologic=False, active=True)
            n = max(1, len(records))

            for i, record in enumerate(records):
                if not isinstance(record, dict):
                    continue

                old_index = record.get("index", i)
                d = dict(record.get("dictionary", {}))
                coords = TGraph.Coordinates(topology, old_index, default=None)

                if coords is None:
                    angle = 2.0 * math.pi * float(i) / float(n)
                    coords = [math.cos(angle), math.sin(angle), 0.0]

                coords = [
                    round(float(coords[0]), mantissa),
                    round(float(coords[1]), mantissa),
                    round(float(coords[2]), mantissa),
                ]

                index_map[old_index] = len(vertices)
                vertices.append(coords)

                if transferDictionaries == True:
                    vertex_dicts.append(d)

            edge_records = TGraph.Edges(topology, asTopologic=False, active=True)

            for edge_record in edge_records:
                if not isinstance(edge_record, dict):
                    continue

                src = edge_record.get("src", None)
                dst = edge_record.get("dst", None)

                if src not in index_map or dst not in index_map:
                    continue

                edges.append([index_map[src], index_map[dst]])

                if transferDictionaries == True:
                    edge_dicts.append(dict(edge_record.get("dictionary", {})))

            return {
                "vertices": vertices,
                "edges": edges,
                "faces": faces,
                "vertex_dicts": vertex_dicts,
                "edge_dicts": edge_dicts,
                "face_dicts": face_dicts,
            }

        # ------------------------------------------------------------------
        # Legacy Graph path.
        # ------------------------------------------------------------------
        if Topology.IsInstance(topology, "Graph"):
            from topologicpy.Graph import Graph

            vertices = []
            edges = []
            faces = []
            vertex_dicts = []
            edge_dicts = []
            face_dicts = []

            graph_vertices = Graph.Vertices(topology)
            graph_edges = Graph.Edges(topology)

            for aVertex in graph_vertices:
                py_dict = {}
                if transferDictionaries == True:
                    d = Topology.Dictionary(aVertex)
                    if len(Dictionary.Keys(d)) > 0:
                        py_dict = Dictionary.PythonDictionary(d)

                try:
                    vertices.index(Vertex.Coordinates(aVertex, mantissa=mantissa))
                except:
                    vertices.append(Vertex.Coordinates(aVertex, mantissa=mantissa))
                    vertex_dicts.append(py_dict)

            for anEdge in graph_edges:
                e = []
                sv = Edge.StartVertex(anEdge)
                ev = Edge.EndVertex(anEdge)

                try:
                    svIndex = vertices.index(Vertex.Coordinates(sv, mantissa=mantissa))
                except:
                    vertices.append(Vertex.Coordinates(sv, mantissa=mantissa))
                    svIndex = len(vertices) - 1

                try:
                    evIndex = vertices.index(Vertex.Coordinates(ev, mantissa=mantissa))
                except:
                    vertices.append(Vertex.Coordinates(ev, mantissa=mantissa))
                    evIndex = len(vertices) - 1

                e.append(svIndex)
                e.append(evIndex)
                edges.append(e)

                py_dict = {}
                if transferDictionaries == True:
                    d = Topology.Dictionary(anEdge)
                    if len(Dictionary.Keys(d)) > 0:
                        py_dict = Dictionary.PythonDictionary(d)
                    edge_dicts.append(py_dict)

            return {
                "vertices": vertices,
                "edges": edges,
                "faces": faces,
                "vertex_dicts": vertex_dicts,
                "edge_dicts": edge_dicts,
                "face_dicts": face_dicts,
            }

        # ------------------------------------------------------------------
        # Topology path.
        # ------------------------------------------------------------------
        vertices = []
        edges = []
        faces = []
        vertex_dicts = []
        edge_dicts = []
        face_dicts = []

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.Geometry - Error: The input topology parameter is not a valid topology or graph. Returning None.")
            return None

        topVerts = []
        # Tolerance-aware vertex dedup. Shared vertices re-derived by the
        # PythonOCC backend carry float noise (5th-7th decimal), so exact
        # list.index(Vertex.Coordinates(...)) equality leaves duplicates that
        # the TopologicCore kernel would have merged (e.g. a Dodecahedron
        # reports 45 vertices instead of 20, corrupting consequent rebuilds).
        vertex_threshold = max(1e-4, 10 ** (-(max(int(mantissa), 3) - 1)))

        def _find_vertex_index(coords):
            for i, c in enumerate(vertices):
                if (abs(c[0]-coords[0]) <= vertex_threshold and
                        abs(c[1]-coords[1]) <= vertex_threshold and
                        abs(c[2]-coords[2]) <= vertex_threshold):
                    return i
            return -1

        if Topology.Type(topology) == Topology.TypeID("Vertex"): #input is a vertex, just add it and process it
            topVerts.append(topology)
        else:
            topVerts = Topology.Vertices(topology)

        for aVertex in topVerts:
            py_dict = {}
            if transferDictionaries == True:
                d = Topology.Dictionary(aVertex)
                if len(Dictionary.Keys(d)) > 0:
                    py_dict = Dictionary.PythonDictionary(d)
            idx = _find_vertex_index(Vertex.Coordinates(aVertex, mantissa=mantissa))
            if idx < 0:
                vertices.append(Vertex.Coordinates(aVertex, mantissa=mantissa))
                vertex_dicts.append(py_dict)

        topEdges = []
        if (Topology.Type(topology) == Topology.TypeID("Edge")): #Input is an Edge, just add it and process it
            topEdges.append(topology)
        elif (Topology.Type(topology) > Topology.TypeID("Vertex")):
            topEdges = Topology.Edges(topology)

        for anEdge in topEdges:
            e = []
            sv = Edge.StartVertex(anEdge)
            ev = Edge.EndVertex(anEdge)

            svIndex = _find_vertex_index(Vertex.Coordinates(sv, mantissa=mantissa))
            if svIndex < 0:
                vertices.append(Vertex.Coordinates(sv, mantissa=mantissa))
                svIndex = len(vertices)-1

            evIndex = _find_vertex_index(Vertex.Coordinates(ev, mantissa=mantissa))
            if evIndex < 0:
                vertices.append(Vertex.Coordinates(ev, mantissa=mantissa))
                evIndex = len(vertices)-1

            e.append(svIndex)
            e.append(evIndex)
            edges.append(e)

            py_dict = {}
            if transferDictionaries == True:
                d = Topology.Dictionary(anEdge)
                if len(Dictionary.Keys(d)) > 0:
                    py_dict = Dictionary.PythonDictionary(d)
                edge_dicts.append(py_dict)

        topFaces = []
        if (Topology.Type(topology) == Topology.TypeID("Face")): # Input is a Face, just add it and process it
            topFaces.append(topology)
        elif (Topology.Type(topology) > Topology.TypeID("Face")):
            topFaces = Topology.Faces(topology)

        for aFace in topFaces:
            ib = []
            ib = Face.InternalBoundaries(aFace)

            if(len(ib) > 0 or triangulate == True):
                triFaces = Face.Triangulate(aFace,
                                            mode=mode,
                                            meshSize=meshSize,
                                            mantissa=mantissa,
                                            tolerance=tolerance,
                                            silent=silent)
                for aTriFace in triFaces:
                    wire = Face.ExternalBoundary(aTriFace)
                    faceVertices = Topology.Vertices(wire)
                    f = []

                    for aVertex in faceVertices:
                        fVertexIndex = _find_vertex_index(Vertex.Coordinates(aVertex, mantissa=mantissa))
                        if fVertexIndex < 0:
                            vertices.append(Vertex.Coordinates(aVertex, mantissa=mantissa))
                            fVertexIndex = len(vertices)-1
                        f.append(fVertexIndex)

                    faces.append(f)
            else:
                wire =  Face.ExternalBoundary(aFace)
                faceVertices = Topology.Vertices(wire)
                f = []

                for aVertex in faceVertices:
                    fVertexIndex = _find_vertex_index(Vertex.Coordinates(aVertex, mantissa=mantissa))
                    if fVertexIndex < 0:
                        vertices.append(Vertex.Coordinates(aVertex, mantissa=mantissa))
                        fVertexIndex = len(vertices)-1
                    f.append(fVertexIndex)

                faces.append(f)

            py_dict = {}
            if transferDictionaries == True:
                d = Topology.Dictionary(aFace)
                if len(Dictionary.Keys(d)) > 0:
                    py_dict = Dictionary.PythonDictionary(d)
                face_dicts.append(py_dict)

        return {
            "vertices": vertices,
            "edges": edges,
            "faces": faces,
            "vertex_dicts": vertex_dicts,
            "edge_dicts": edge_dicts,
            "face_dicts": face_dicts,
        }

    @staticmethod
    def HighestType(topology, silent: bool = False):
        """
        Returns the highest topology type found in the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.

        Returns
        -------
        int
            The highest type found in the input topology.

        """
        from topologicpy.Cluster import Cluster

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.HighestType - Error: The input topology parameter is not a valid topology. Returning None.")
            return None

        if (Topology.Type(topology) == Topology.TypeID("Cluster")):
            return Cluster.HighestType(topology)
        else:
            return Topology.Type(topology)

    @staticmethod
    def _InternalVertex(
        topology,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Returns a vertex guaranteed to be inside the input topology.

        For Faces and closed Wires, candidate points are verified to be strictly
        internal and not within tolerance of any boundary edge. If the primary
        Face.InternalVertex method does not return a strict internal point, the
        Face is triangulated and triangle centroids are tested until a verified
        internal point is found.

        No generic centroid fallback is used because a centroid is not guaranteed
        to be internal to concave, holed, disconnected, or otherwise non-convex
        topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Vertex
            A vertex guaranteed to be inside the input topology, or None if such
            a vertex cannot be computed.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Face import Face
        from topologicpy.Wire import Wire
        from topologicpy.Cell import Cell
        from topologicpy.Cluster import Cluster
        from topologicpy.Aperture import Aperture

        # ------------------------------------------------------------------
        # Helpers
        # ------------------------------------------------------------------

        def _strictly_internal_to_face(vertex, face):
            """
            Returns True only if the vertex is strictly inside the Face and is
            farther than tolerance from every boundary edge.
            """
            if not Topology.IsInstance(vertex, "Vertex"):
                return False

            if not Topology.IsInstance(face, "Face"):
                return False

            try:
                if not Vertex.IsInternal(
                    vertex,
                    face,
                    tolerance=tolerance,
                    silent=True
                ):
                    return False
            except Exception:
                return False

            edges = Topology.Edges(
                face,
                silent=True
            ) or []

            if len(edges) == 0:
                return False

            for edge in edges:
                distance = Topology.ShortestDistance(
                    vertex,
                    edge,
                    mantissa=12,
                    tolerance=tolerance,
                    silent=True
                )

                if distance is None:
                    return False

                if distance <= tolerance:
                    return False

            return True

        def _verified_face_internal_vertex(face):
            """
            Returns a verified strict internal vertex of the Face.

            First tries Face.InternalVertex. If that candidate lies on or too
            close to a boundary, triangulates the Face and tests the centroids
            of the resulting triangles.
            """
            if not Topology.IsInstance(face, "Face"):
                return None

            # --------------------------------------------------------------
            # Primary Face internal-point method.
            # --------------------------------------------------------------

            try:
                candidate = Face.InternalVertex(
                    face,
                    tolerance=tolerance,
                    silent=True
                )
            except Exception:
                candidate = None

            if _strictly_internal_to_face(
                candidate,
                face
            ):
                return candidate

            # --------------------------------------------------------------
            # Verified triangulation fallback.
            #
            # A triangle centroid lies strictly inside a non-degenerate
            # triangle. We still verify it against the original Face so that
            # holes and concave boundaries are respected.
            # --------------------------------------------------------------

            try:
                triangles = Face.Triangulate(
                    face,
                    tolerance=tolerance,
                    silent=True
                )
            except Exception:
                triangles = None

            if Topology.IsInstance(
                triangles,
                "Face"
            ):
                triangles = [
                    triangles
                ]

            if not isinstance(
                triangles,
                list
            ):
                return None

            for triangle in triangles:

                if not Topology.IsInstance(
                    triangle,
                    "Face"
                ):
                    continue

                candidate = Topology.Centroid(
                    triangle
                )

                if _strictly_internal_to_face(
                    candidate,
                    face
                ):
                    return candidate

            return None

        def _cluster_constituents(cluster):
            """
            Returns the direct constituent topologies of a Cluster.
            """
            try:
                result = Core.InstanceCall(
                    cluster,
                    "Topologies"
                )

                if isinstance(
                    result,
                    list
                ):
                    result = [
                        item
                        for item in result
                        if Topology.IsInstance(
                            item,
                            "Topology"
                        )
                    ]

                    if len(result) > 0:
                        return result

            except Exception:
                pass

            try:
                result = []

                Core.InstanceCall(
                    cluster,
                    "Topologies",
                    result
                )

                result = [
                    item
                    for item in result
                    if Topology.IsInstance(
                        item,
                        "Topology"
                    )
                ]

                if len(result) > 0:
                    return result

            except Exception:
                pass

            try:
                result = []

                Core.InstanceCall(
                    cluster,
                    "Topologies",
                    None,
                    result
                )

                result = [
                    item
                    for item in result
                    if Topology.IsInstance(
                        item,
                        "Topology"
                    )
                ]

                if len(result) > 0:
                    return result

            except Exception:
                pass

            try:
                result = Cluster.Topologies(
                    cluster
                )

                if isinstance(
                    result,
                    list
                ):
                    result = [
                        item
                        for item in result
                        if Topology.IsInstance(
                            item,
                            "Topology"
                        )
                    ]

                    if len(result) > 0:
                        return result

            except Exception:
                pass

            return []

        # ------------------------------------------------------------------
        # Aperture
        # ------------------------------------------------------------------

        if Topology.IsInstance(
            topology,
            "Aperture"
        ):
            try:
                aperture_topology = Aperture.Topology(
                    topology
                )
            except Exception:
                aperture_topology = None

            if not Topology.IsInstance(
                aperture_topology,
                "Topology"
            ):
                if not silent:
                    print(
                        "Topology.InternalVertex - Error: Could not retrieve the "
                        "topology of the input Aperture. Returning None."
                    )
                return None

            return Topology._InternalVertex(
                aperture_topology,
                tolerance=tolerance,
                silent=silent
            )

        # ------------------------------------------------------------------
        # Validate input
        # ------------------------------------------------------------------

        if not Topology.IsInstance(
            topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.InternalVertex - Error: The input topology parameter "
                    "is not a valid topology. Returning None."
                )
            return None

        # Internal-point operations are queries and do not require a copy.
        top = topology

        # ------------------------------------------------------------------
        # CellComplex
        # ------------------------------------------------------------------

        if Topology.IsInstance(
            top,
            "CellComplex"
        ):
            cells = Topology.Cells(
                top,
                silent=True
            ) or []

            for cell in cells:
                try:
                    candidate = Cell.InternalVertex(
                        cell,
                        tolerance=tolerance,
                        silent=True
                    )
                except Exception:
                    candidate = None

                if Topology.IsInstance(
                    candidate,
                    "Vertex"
                ):
                    return candidate

            if not silent:
                print(
                    "Topology.InternalVertex - Error: Could not compute an internal "
                    "vertex for any Cell of the input CellComplex. Returning None."
                )

            return None

        # ------------------------------------------------------------------
        # Cell
        # ------------------------------------------------------------------

        if Topology.IsInstance(
            top,
            "Cell"
        ):
            try:
                candidate = Cell.InternalVertex(
                    top,
                    tolerance=tolerance,
                    silent=True
                )
            except Exception:
                candidate = None

            if Topology.IsInstance(
                candidate,
                "Vertex"
            ):
                return candidate

            if not silent:
                print(
                    "Topology.InternalVertex - Error: Could not compute an internal "
                    "vertex for the input Cell. Returning None."
                )

            return None

        # ------------------------------------------------------------------
        # Shell
        # ------------------------------------------------------------------

        if Topology.IsInstance(
            top,
            "Shell"
        ):
            faces = Topology.Faces(
                top,
                silent=True
            ) or []

            for face in faces:
                candidate = _verified_face_internal_vertex(
                    face
                )

                if Topology.IsInstance(
                    candidate,
                    "Vertex"
                ):
                    return candidate

            if not silent:
                print(
                    "Topology.InternalVertex - Error: Could not compute a strict "
                    "internal vertex for any Face of the input Shell. Returning None."
                )

            return None

        # ------------------------------------------------------------------
        # Face
        # ------------------------------------------------------------------

        if Topology.IsInstance(
            top,
            "Face"
        ):
            candidate = _verified_face_internal_vertex(
                top
            )

            if Topology.IsInstance(
                candidate,
                "Vertex"
            ):
                return candidate

            if not silent:
                print(
                    "Topology.InternalVertex - Error: Could not compute a strict "
                    "internal vertex for the input Face. Returning None."
                )

            return None

        # ------------------------------------------------------------------
        # Wire
        # ------------------------------------------------------------------

        if Topology.IsInstance(
            top,
            "Wire"
        ):
            try:
                is_closed = Wire.IsClosed(
                    top
                )
            except Exception:
                is_closed = None

            if is_closed is None:
                if not silent:
                    print(
                        "Topology.InternalVertex - Error: Could not determine whether "
                        "the input Wire is closed. Returning None."
                    )
                return None

            # --------------------------------------------------------------
            # Closed Wire
            # --------------------------------------------------------------

            if is_closed:
                try:
                    temp_face = Core.Face.ByExternalInternalBoundaries(
                        top,
                        []
                    )
                except Exception as error:
                    if not silent:
                        print(
                            "Topology.InternalVertex - Error: Could not construct a "
                            "Face from the closed input Wire. Returning None."
                        )
                        print(
                            "Error:",
                            error
                        )
                    return None

                if not Topology.IsInstance(
                    temp_face,
                    "Face"
                ):
                    if not silent:
                        print(
                            "Topology.InternalVertex - Error: Could not construct a "
                            "valid Face from the closed input Wire. Returning None."
                        )
                    return None

                candidate = _verified_face_internal_vertex(
                    temp_face
                )

                if Topology.IsInstance(
                    candidate,
                    "Vertex"
                ):
                    return candidate

                if not silent:
                    print(
                        "Topology.InternalVertex - Error: Could not compute a strict "
                        "internal vertex for the closed input Wire. Returning None."
                    )

                return None

            # --------------------------------------------------------------
            # Open Wire
            # --------------------------------------------------------------

            edges = Topology.Edges(
                top,
                silent=True
            ) or []

            if len(edges) == 0:
                if not silent:
                    print(
                        "Topology.InternalVertex - Error: The input Wire contains "
                        "no valid Edges. Returning None."
                    )
                return None

            try:
                candidate = Edge.VertexByParameter(
                    edges[0],
                    0.5
                )
            except Exception:
                candidate = None

            if Topology.IsInstance(
                candidate,
                "Vertex"
            ):
                return candidate

            return None

        # ------------------------------------------------------------------
        # Edge
        # ------------------------------------------------------------------

        if Topology.IsInstance(
            top,
            "Edge"
        ):
            try:
                candidate = Edge.VertexByParameter(
                    top,
                    0.5
                )
            except Exception:
                candidate = None

            if Topology.IsInstance(
                candidate,
                "Vertex"
            ):
                return candidate

            return None

        # ------------------------------------------------------------------
        # Vertex
        # ------------------------------------------------------------------

        if Topology.IsInstance(
            top,
            "Vertex"
        ):
            return top

        # ------------------------------------------------------------------
        # Cluster
        # ------------------------------------------------------------------

        if Topology.IsInstance(
            top,
            "Cluster"
        ):
            constituents = _cluster_constituents(
                top
            )

            if len(constituents) == 0:
                if not silent:
                    print(
                        "Topology.InternalVertex - Error: Could not retrieve any "
                        "constituent topologies from the input Cluster. Returning None."
                    )
                return None

            def _rank(item):
                try:
                    value = Topology.Type(
                        item,
                        silent=True
                    )
                except Exception:
                    value = None

                if isinstance(
                    value,
                    int
                ):
                    return value

                return -1

            constituents = sorted(
                constituents,
                key=_rank,
                reverse=True
            )

            for constituent in constituents:
                candidate = Topology._InternalVertex(
                    constituent,
                    tolerance=tolerance,
                    silent=True
                )

                if Topology.IsInstance(
                    candidate,
                    "Vertex"
                ):
                    return candidate

            if not silent:
                print(
                    "Topology.InternalVertex - Error: Could not compute an internal "
                    "vertex for any constituent of the input Cluster. Returning None."
                )

            return None

        # ------------------------------------------------------------------
        # No generic centroid fallback
        # ------------------------------------------------------------------

        if not silent:
            print(
                "Topology.InternalVertex - Error: The input topology type is not "
                "supported for guaranteed internal-point computation. Returning None."
            )

        return None

    @staticmethod
    def InternalVertex(topology, timeout: int = 30, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns a vertex guaranteed to be inside the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        timeout : int , optional
            The amount of seconds to wait before timing out. Default is 30 seconds.
        tolerance : float , ptional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Vertex
            A vertex guaranteed to be inside the input topology.

        """
        import concurrent.futures
        import time
        # Wrapper function with timeout. The backend implementations
        # (CellUtility/FaceUtility.InternalVertex) are synchronous and normally
        # return in milliseconds; the original 30s cap fired spuriously under
        # full-suite load (thread/GC contention during the ~2min run),
        # returning None and breaking InternalVertex. Keep a generous floor
        # to guard against genuine pathological-geometry hangs without
        # penalising legitimate calls.
        def run_with_timeout(func, topology, tolerance=0.0001, silent=False, timeout=300):
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(func, topology, tolerance=tolerance, silent=silent)
                try:
                    result = future.result(timeout=timeout)
                    return result
                except concurrent.futures.TimeoutError:
                    return None

        result = run_with_timeout(Topology._InternalVertex, topology=topology, tolerance=tolerance, silent=silent, timeout=max(timeout, 300))  # Generous floor; caller may still lower it
        if result is None:
            # Handle failure case (e.g., try a different solution)
            if not silent:
                print("Topology.InternalVertex - Warning: Operation took too long. Returning None")
            return None
        return result

    @staticmethod
    def IsInstance(topology, type: str, silent: bool = True):
        """
        Returns True if the input topology is an instance of the class specified by the input type string.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        type : str
            The topology type string to compare against. Acceptable values are "vertex", "edge", "wire", "face", "shell", "cell", "cellcomplex", "cluster", "topology", "context", "aperture", "dictionary", "graph", "tgraph". It is case insensitive.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Vertex
            A vertex guaranteed to be inside the input topology.

        """

        from topologicpy.Core import Core

        if not isinstance(type, str):
            if not silent:
                print("Topology.IsInstance - Error: The input type parameter is not a valid string. Returning None.")
            return None

        t = type.lower()

        if not t in ["vertex", "edge", "wire", "face", "shell", "cell", "cellcomplex", "cluster", "topology", "context", "aperture", "dictionary", "graph", "tgraph"]:
            if not silent:
                print("Topology.IsInstance - Error: The input type parameter is not a recognised topology type. Returning None.")
            return None

        is_tgraph = False
        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            is_tgraph = False

        # Check TGraph before Graph. Otherwise "tgraph" could be accidentally
        # captured by broad graph-related logic elsewhere.
        if "tgraph" in t:
            return is_tgraph

        # Treat TGraph as a graph for transparent Graph/TGraph compatibility.
        if "graph" in t:
            if is_tgraph:
                return True
            return isinstance(topology, Core.Namespace("Graph"))

        if "cellcomplex" in t:
            return isinstance(topology, Core.Namespace("CellComplex"))
        elif "vertex" in t:
            return isinstance(topology, Core.Namespace("Vertex"))
        elif "edge" in t:
            return isinstance(topology, Core.Namespace("Edge"))
        elif "wire" in t:
            return isinstance(topology, Core.Namespace("Wire"))
        elif "face" in t:
            return isinstance(topology, Core.Namespace("Face"))
        elif "shell" in t:
            return isinstance(topology, Core.Namespace("Shell"))
        elif "cell" in t:
            return isinstance(topology, Core.Namespace("Cell"))
        elif "cluster" in t:
            return isinstance(topology, Core.Namespace("Cluster"))
        elif "topology" in t:
            return isinstance(topology, Core.Namespace("Topology"))
        elif "aperture" in t:
            return isinstance(topology, Core.Namespace("Aperture"))
        elif "dictionary" in t:
            return isinstance(topology, Core.Namespace("Dictionary"))
        elif "context" in t:
            return isinstance(topology, Core.Namespace("Context"))

        return False
    
    @staticmethod
    def IsPlanar(topology, mantissa: int = 6, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns True if all the vertices of the input topology are co-planar. Returns False otherwise.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        mantissa : int , optional
            The desired length of the mantissa. Default is 6
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if all the vertices of the input topology are co-planar. False otherwise.

        """
        from topologicpy.Vertex import Vertex

        def isOnPlane(v, plane, tolerance=0.0001):
            x, y, z = v
            a, b, c, d = plane
            if math.fabs(a*x + b*y + c*z + d) <= tolerance:
                return True
            return False

        def plane(v1, v2, v3):
            a1 = Vertex.X(v2, mantissa=mantissa) - Vertex.X(v1, mantissa=mantissa)
            b1 = Vertex.Y(v2, mantissa=mantissa) - Vertex.Y(v1, mantissa=mantissa)
            c1 = Vertex.Z(v2, mantissa=mantissa) - Vertex.Z(v1, mantissa=mantissa)
            a2 = Vertex.X(v3, mantissa=mantissa) - Vertex.X(v1, mantissa=mantissa)
            b2 = Vertex.Y(v3, mantissa=mantissa) - Vertex.Y(v1, mantissa=mantissa)
            c2 = Vertex.Z(v3, mantissa=mantissa) - Vertex.Z(v1, mantissa=mantissa)
            a = b1 * c2 - b2 * c1 
            b = a2 * c1 - a1 * c2 
            c = a1 * b2 - b1 * a2 
            d = (- a * Vertex.X(v1, mantissa=mantissa) - b * Vertex.Y(v1, mantissa=mantissa) - c * Vertex.Z(v1, mantissa=mantissa))
            return [a, b, c, d]

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.IsPlanar - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        vertices = Topology.Vertices(topology, silent=True)

        result = True
        if len(vertices) <= 3:
            result = True
        else:
            p = plane(vertices[0], vertices[1], vertices[2])
            for i in range(len(vertices)):
                if isOnPlane([Vertex.X(vertices[i], mantissa=mantissa), Vertex.Y(vertices[i], mantissa=mantissa), Vertex.Z(vertices[i], mantissa=mantissa)], p, tolerance=tolerance) == False:
                    result = False
                    break
        return result
    
    @staticmethod
    def IsSame(topologyA, topologyB, silent: bool = False):
        """
        Returns True if the input topologies are the same topology. Returns False otherwise.

        Parameters
        ----------
        topologyA : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The first input topology or graph.
        topologyB : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The second input topology or graph.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if the input topologies or graphs are the same. False otherwise.

        """

        try:
            from topologicpy.TGraph import TGraph
            a_is_tgraph = isinstance(topologyA, TGraph)
            b_is_tgraph = isinstance(topologyB, TGraph)
        except Exception:
            TGraph = None
            a_is_tgraph = False
            b_is_tgraph = False

        if a_is_tgraph or b_is_tgraph:
            if a_is_tgraph and b_is_tgraph:
                return topologyA is topologyB

            if not silent:
                print("Topology.IsSame - Warning: Cannot compare TGraph with non-TGraph using Core.Topology.IsSame. Returning False.")
            return False

        valid_types = [
            "Vertex", "Edge", "Wire", "Face", "Shell",
            "Cell", "CellComplex", "Cluster", "Aperture", "Graph"
        ]

        if not any(Topology.IsInstance(topologyA, t) for t in valid_types):
            if not silent:
                print("Topology.IsSame - Error: the input topologyA parameter is not a valid topology. Returning None.")
            return None

        if not any(Topology.IsInstance(topologyB, t) for t in valid_types):
            if not silent:
                print("Topology.IsSame - Error: the input topologyB parameter is not a valid topology. Returning None.")
            return None

        return Core.Topology.IsSame(topologyA, topologyB)

    @staticmethod
    def IsSimilar(topologyA, topologyB, removeCoplanarFaces: bool = False, mantissa: int = 6, epsilon: float = 0.1, tolerance: float = 0.0001, silent: bool = False):
        """
        Calculates if the input topologies are similar. See https://en.wikipedia.org/wiki/Similarity_(geometry).

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        removeCoplanarFaces : bool , optional
            If set to True, coplanar faces are removed. Otherwise they are not. Default is False.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        epsilon : float , optional
            The desired epsilon (another form of percentage tolerance) for finding if two objects are similar. Should be in the range 0 to 1. Default is 0.1 (10%).
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        [bool, list]
            True if the input topologies are similar, False otherwise and the matrix needed to tranform topologyA to match topologyB.
            If the topologies are not similar, the transformation matrix is None.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Face import Face
        from topologicpy.Cell import Cell
        from topologicpy.Matrix import Matrix
        from topologicpy.Vector import Vector
        from topologicpy.Dictionary import Dictionary

        if not Topology.IsInstance(topologyA, "topology"):
            if not silent:
                print("Topology.IsSimilar - Error: The input topologyA parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(topologyB, "topology"):
            if not silent:
                print("Topology.IsSimilar - Error: The input topologyB parameter is not a valid topology. Returning None.")
            return None
        if removeCoplanarFaces == True:
            topologyA = Topology.RemoveCoplanarFaces(topologyA, epsilon=epsilon, tolerance=tolerance)
            topologyB = Topology.RemoveCoplanarFaces(topologyB, epsilon=epsilon, tolerance=tolerance)
        len_vertices_a = len(Topology.Vertices(topologyA))
        if len_vertices_a < 1 and not Topology.IsInstance(topologyA, "vertex"):
            if not silent:
                print("Topology.IsSimilar - Error: The input topologyA parameter is not a valid topology. Returning None.")
            return None
        len_vertices_b = len(Topology.Vertices(topologyB))
        if len_vertices_b < 1 and not Topology.IsInstance(topologyB, "vertex"):
            if not silent:
                print("Topology.IsSimilar - Error: The input topologyB parameter is not a valid topology. Returning None.")
            return None
        if not isinstance(epsilon, int) and not isinstance(epsilon, float):
            if not silent:
                print("Topology.IsSimilar - Error: The input epsilon parameter is not a valid float. Returning None.")
            return None
        if not (0 <= epsilon <= 1):
            if not silent:
                print("Topology.IsSimilar - Error: The input epsilon parameter is not within a valid range. Returning None.")
            return None
        # Trivial cases - All vertices are similar to each other.
        if Topology.IsInstance(topologyA, "vertex") and Topology.IsInstance(topologyB, "vertex"):
            centroid_a = Topology.Centroid(topologyA)
            centroid_b = Topology.Centroid(topologyB)
            trans_matrix_a = Matrix.ByTranslation(-Vertex.X(centroid_a), -Vertex.Y(centroid_a), -Vertex.Z(centroid_a))
            trans_matrix_b = Matrix.ByTranslation(Vertex.X(centroid_b), Vertex.Y(centroid_b), Vertex.Z(centroid_b))
            combined_matrix = Matrix.Multiply(trans_matrix_b, trans_matrix_a)
            return True, combined_matrix
        
        # EXCLUSION TESTS
        # Topology Type
        if Topology.Type(topologyA) != Topology.Type(topologyB):
            return False, None
        # Number of vertices
        max_len = max([len_vertices_a, len_vertices_b])
        if abs(len_vertices_a - len_vertices_b)/max_len > epsilon:
            if not silent:
                print("Topology.IsSimilar - Info: Failed number of vertices check. Returning False.")
            return False, None
        # Number of edges
        len_edges_a = len(Topology.Edges(topologyA))
        len_edges_b = len(Topology.Edges(topologyB))
        max_len = max([len_edges_a, len_edges_b])
        if max_len > 0: # Check only if the topologies do actually have edges
            if abs(len_edges_a - len_edges_b)/max_len > epsilon:
                if not silent:
                    print("Topology.IsSimilar - Info: Failed number of edges check. Returning False.")
                return False, None
        # Number of faces
        len_faces_a = len(Topology.Faces(topologyA))
        len_faces_b = len(Topology.Faces(topologyB))
        max_len = max([len_faces_a, len_faces_b])
        if max_len > 0: # Check only if the topologies do actually have faces
            if abs(len_faces_a - len_faces_b)/max_len > epsilon:
                if not silent:
                    print("Topology.IsSimilar - Info: Failed number of faces check. Returning False.")
                return False, None
        # Number of cells
        len_cells_a = len(Topology.Cells(topologyA))
        len_cells_b = len(Topology.Cells(topologyB))
        max_len = max([len_cells_a, len_cells_b])
        if max_len > 0: # Check only if the topologies do actually have cells
            if abs(len_cells_a - len_cells_b)/max_len > epsilon:
                if not silent:
                    print("Topology.IsSimilar - Info: Failed number of cells check. Returning False.")
                return False, None
        if Topology.IsInstance(topologyA, "face"):
            compactness_a = Face.Compactness(topologyA, mantissa=mantissa)
            compactness_b = Face.Compactness(topologyB, mantissa=mantissa)
            max_compactness = max([compactness_a, compactness_b])
            if max_compactness > 0: # Check only if the topologies do actually have compactness
                if abs(compactness_a - compactness_b)/max_compactness >= epsilon:
                    if not silent:
                        print("Topology.IsSimilar - Info: Failed compactness check. Returning False.")
                    return False, None
        if Topology.IsInstance(topologyA, "cell"):
            compactness_a = Cell.Compactness(topologyA, mantissa=mantissa)
            compactness_b = Cell.Compactness(topologyB, mantissa=mantissa)
            max_compactness = max([compactness_a, compactness_b])
            if max_compactness > 0: # Check only if the topologies do actually have compactness
                if abs(compactness_a - compactness_b)/max_compactness > epsilon:
                    if not silent:
                        print("Topology.IsSimilar - Info: Failed compactness check. Returning False.")
                    return False, None
        # Done with Exclusion Tests.

        if Topology.IsInstance(topologyA, "face"):
            largest_faces_a = [topologyA]
            largest_faces_b = [topologyB]
        else:
            faces_a = Topology.Faces(topologyA)
            faces_b = Topology.Faces(topologyB)
            if len(faces_a) > 0 and len(faces_b) > 0:
                largest_faces_a = Topology.LargestFaces(topologyA)
                largest_faces_b = Topology.LargestFaces(topologyB)
            else:
                if not silent:
                    print("Topology.IsSimilar - Error: The topologies do not have faces. Returning None.")
                return False, None

    # Process largest faces
        for face_a in largest_faces_a:
            l_edge_a = Topology.LongestEdges(face_a)[0]
            length_a = Edge.Length(l_edge_a)
            centroid_a = Topology.Centroid(face_a)
            origin_a = Vertex.Coordinates(centroid_a)
            zaxis_a = Face.Normal(face_a)
            third_vertex_a = Face.ThirdVertex(face_a)  # Pick a third vertex for orientation
            xaxis_a = Vector.Normalize(Vector.ByVertices(centroid_a, third_vertex_a))
            yaxis_a = Vector.Cross(xaxis_a, zaxis_a)
            # Build Coordinate System matrix. The origin will be (0,0,0) once the trans matrix is applied.
            cs_a = [[0,0,0]]+[xaxis_a]+[yaxis_a]+[zaxis_a]
            tran_matrix_a = Matrix.ByTranslation(translateX=-origin_a[0], translateY=-origin_a[1], translateZ=-origin_a[2])

            # Check against the faces of B:
            for face_b in largest_faces_b:
                l_edge_b = Topology.LongestEdges(face_b)[0]
                length_b = Edge.Length(l_edge_b)
                scale_factor = length_b/length_a
                scale_matrix = Matrix.ByScaling(scaleX=scale_factor, scaleY=scale_factor, scaleZ=scale_factor)
                centroid_b = Topology.Centroid(face_b)
                origin_b = Vertex.Coordinates(centroid_b)
                zaxis_b = Face.Normal(face_b)
                third_vertex_b = Face.ThirdVertex(face_b)
                xaxis_b = Vector.Normalize(Vector.ByVertices(centroid_b, third_vertex_b))
                yaxis_b = Vector.Cross(xaxis_b, zaxis_b)
                cs_b = [origin_b]+[xaxis_b]+[yaxis_b]+[zaxis_b]
                # Compute transformation matrix
                # translate to origin, scale, then transform coordinate systems
                combined_matrix = Matrix.Multiply(scale_matrix, tran_matrix_a)
                matching_matrix = Matrix.ByCoordinateSystems(cs_a, cs_b)
                combined_matrix = Matrix.Multiply(matching_matrix, combined_matrix)
                # Apply transformation and compare
                try:
                    transformedA = Topology.Transform(topologyA, combined_matrix)
                    status = Topology.IsVertexCongruent(transformedA, topologyB, mantissa=mantissa, epsilon=epsilon, tolerance=tolerance, silent=silent)
                    if status:
                        return True, combined_matrix
                except:
                    pass

        return False, None

    @staticmethod
    def IsVertexCongruent(topologyA, topologyB, mantissa: int = 6, epsilon: float = 0.1, tolerance: float = 0.0001, silent : bool = False):
        """
        Returns True if the input topologies are vertex congruent (have same number of vertices and all vertices are congruent within a tolerance). Returns False otherwise.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        epsilon : float , optional
            The desired accepted tolerance for the number of matched number of vertices. For example, an epsilon of 0.1 indicates that
            the algorithm will return True even if 10% of the vertices do not match. Default is 0.1.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True of the input topologies are vertex congruent. False otherwise.

        """
        from topologicpy.Vertex import Vertex

    
        def coordinates_unmatched_ratio(list1, list2, mantissa, tolerance):
            """
            Optimized version using KDTree for faster nearest-neighbor search.
            """
            from scipy.spatial import KDTree
            import numpy as np
            rounded_list1 = [np.round(coord, mantissa) for coord in list1]
            rounded_list2 = [np.round(coord, mantissa) for coord in list2]
            
            tree = KDTree(rounded_list2)
            unmatched_count = 0
            
            for coord in rounded_list1:
                distances, indices = tree.query(coord, k=1)
                if distances > tolerance:
                    unmatched_count += 1
            
            total_coordinates = len(list1)
            unmatched_ratio = unmatched_count / total_coordinates
            return round(unmatched_ratio, mantissa)

        if not Topology.IsInstance(topologyA, "topology"):
            if not silent:
                print("Topology.IsVertexCongruent - Error: The input topologyA parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(topologyB, "topology"):
            if not silent:
                print("Topology.IsVertexCongruent - Error: The input topologyB parameter is not a valid topology. Returning None.")
            return None
        
        vertices_a = Topology.Vertices(topologyA)
        len_vertices_a = len(vertices_a)
        if len_vertices_a < 1:
            if not silent:
                print("Topology.IsVertexCongruent - Error: The input topologyA parameter is not a valid topology. Returning None.")
            return None
        vertices_b = Topology.Vertices(topologyB)
        len_vertices_b = len(vertices_b)
        if len_vertices_b < 1:
            if not silent:
                print("Topology.IsVertexCongruent - Error: The input topologyB parameter is not a valid topology. Returning None.")
            return None
        # Number of vertices
        max_len = max([len_vertices_a, len_vertices_b])
        ratio = round(float(abs(len_vertices_a - len_vertices_b))/float(max_len), mantissa)
        if ratio > epsilon:
            return False
        coords_a = [Vertex.Coordinates(v, mantissa=mantissa) for v in vertices_a]
        coords_b = [Vertex.Coordinates(v, mantissa=mantissa) for v in vertices_b]
        unmatched_ratio = coordinates_unmatched_ratio(coords_a, coords_b, mantissa=mantissa, tolerance=tolerance)
        if unmatched_ratio <= epsilon:
            return True
        return False

    @staticmethod
    def LargestFaces(topology, removeCoplanarFaces: bool = False, epsilon: float = 0.001, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns the list of the largest faces found in the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        removeCoplanarFaces : bool , optional
            If set to True, coplanar faces are removed to find the true largest faces. Otherwise they are not. Default is False.
        epsilon : float , optional
            The desired epsilon (another form of tolerance) for finding if two faces are coplanar. Default is 0.01.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        Returns
        -------
        list
            The list of the largest faces found in the input topology.
        
        """
        from topologicpy.Face import Face

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.LaregestFaces - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        faces = Topology.Faces(topology)
        if len(faces) == 0:
            if not silent:
                print("Topology.LargestFaces - Error: The input topology parameter does not contain any faces. Returning None.")
            return None
        if len(faces) == 1:
            return faces
        
        if removeCoplanarFaces == True:
            simple_topology = Topology.RemoveCoplanarFaces(topology)
            simple_topology = Topology.RemoveCollinearEdges(simple_topology)
            faces = Topology.Faces(simple_topology)
        face_areas = [Face.Area(face) for face in faces]
        max_area = max(face_areas)
        max_faces = []
        for i, face_area in enumerate(face_areas):
            if abs(max_area - face_area) <= tolerance:
                max_faces.append(faces[i])
        return max_faces

    @staticmethod
    def LongestEdges(topology, removeCoplanarFaces: bool = False, epsilon: float = 0.001, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns the list of the longest edges found in the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        removeCoplanarFaces : bool , optional
            If set to True, coplanar faces are removed to find the true longest straight edges. Otherwise they are not. Default is False.
        epsilon : float , optional
            The desired epsilon (another form of tolerance) for finding if two faces are coplanar. Default is 0.01.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        Returns
        -------
        list
            The list of of the longest edges found in the input topology.
        
        """
        from topologicpy.Edge import Edge

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.LongestEdges - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        edges = Topology.Edges(topology)
        if len(edges) == 0:
            if not silent:
                print("Topology.LongestEdges - Error: The input topology parameter does not contain any edges. Returning None.")
            return None
        if len(edges) == 1:
            return edges
        
        if removeCoplanarFaces == True:
            simple_topology = Topology.RemoveCoplanarFaces(topology)
            simple_topology = Topology.RemoveCollinearEdges(simple_topology)

            edges = Topology.Edges(simple_topology)
        edge_lengths = [Edge.Length(edge) for edge in edges]
        max_length = max(edge_lengths)
        max_edges = []
        for i, edge_length in enumerate(edge_lengths):
            if abs(max_length - edge_length) <= tolerance:
                max_edges.append(edges[i])
        return max_edges

    @staticmethod
    def Merge(topologyA, topologyB, tranDict: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Merges the input operand topologies. See https://en.wikipedia.org/wiki/Boolean_operation.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tranDict : bool , optional
            If set to True the dictionaries of the operands are merged and transferred to the result. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            the resultant topology.

        """
        return Topology._Boolean(topologyA=topologyA, topologyB=topologyB, operation="merge", tranDict=tranDict, tolerance=tolerance, silent=silent)

    @staticmethod
    def MergeAll(*topologies, tolerance: float = 0.0001, silent: bool = False):
        """
        Merge all the input topologies.

        Parameters
        ----------
        *topologies : list
            The list of input topologies.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The resulting merged Topology

        """
        from topologicpy.Cluster import Cluster
        from topologicpy.Helper import Helper

        # if not isinstance(topologies, list):
        #     print("Topology.MergeAll - Error: the input topologies parameter is not a valid list. Returning None.")
        #     return None
        
        topologyList = Helper.Flatten(list(topologies))
        
        topologyList = [t for t in topologyList if Topology.IsInstance(t, "Topology")]

        if len(topologyList) < 1:
            if not silent:
                print("Topology.MergeAll - Error: the input topologyList does not contain any valid topologies. Returning None.")
            return None
        if len(topologyList) == 1:
            if not silent:
                print("Topology.MergeAll - Warning: The input list of topologies does not contains only one valid topology. Returning that topology.")
            return topologyList[0]
        result = topologyList[0]
        for t in topologyList[1:]:
            result = Topology.Merge(result, t, tolerance=tolerance)
        return result

    @staticmethod
    def Mesh(
        topology,
        minSize: float = 0.1,
        maxSize: float = 1.0,
        algorithm2D: int = 1,
        algorithm3D: int = 1,
        refineEdges: bool = True,
        refineFaces: bool = True,
        optimize: bool = True,
        meshDim: int = None,  # None = auto (3 if has cells, else 2)
        mantissa: int = 6,
        silent: bool = False,
    ):
        """
        Use gmsh to create a variable-resolution mesh of a Topologic topology and
        return mesh data as:

            vertices: List[(x, y, z)]
            faces   : List[(i0, i1, i2)]      # unique triangular faces, 0-based
            tets    : List[(i0, i1, i2, i3)]  # tetrahedra (3D only; [] for 2D, 0-based)

        * If the topology has cells (Cell / CellComplex), does a 3D mesh (tets)
        and derives unique triangle faces from tetrahedra.
        * Otherwise (Face / Shell / etc.), does a 2D surface mesh and returns
        triangular surface elements as faces; tets = [].

        Parameters
        ----------
        topology : topologic_core.Topology
            Input topology (Face, Shell, Cell, CellComplex, etc.).
        minSize : float, optional
            Target smallest element size near boundaries.
        maxSize : float, optional
            Target largest element size away from boundaries.
        algorithm2D : int , optional
            The desired mode of 2D meshing algorithm. Several options are available:
            1: MeshAdapt,
            2: Automatic,
            3: Initial mesh only,
            4: Delaunay,
            5: Frontal-Delaunay ,
            6: BAMG,
            7: Frontal-Delaunay for Quads,
            8: Packing of Parallelograms,
            9: Quasi-structured Quad
            Default is 1.
            WARNING: The options that use gmsh can be very time consuming and can create very heavy geometry.

        algorithm3D : int , optional
            The desired mode of 3D meshing algorithm. Several options are available:
            1: Delaunay
            2: Initial mesh only
            3: Frontal
            4: MMG3D
            5: R-tree
            6: HXT
            Default is 1
            WARNING: The options that use gmsh can be very time consuming and can create very heavy geometry.
        refineEdges : bool, optional
            If True, refine near model edges (gmsh 1D entities).
        refineFaces : bool, optional
            If True, refine near model faces (gmsh 2D entities).
        optimize : bool, optional
            If True, run gmsh mesh optimizer.
        meshDim : int or None, optional
            If 3, force 3D mesh. If 2, force 2D surface mesh.
            If None, auto: 3 if Topology.Cells(topology) non-empty, else 2.
        mantissa : int , optional
            The desired size of the mantissa. Default is 6.
        silent : bool, optional
            If set to True, warning and error messages are suppressed. Default is False.

        Returns
        -------
        dict
            "verts": List[(x, y, z)]
            "tris": List[(i0, i1, i2)]      # triangles
            "tets": List[(i0, i1, i2, i3)]  # tetrahedra (3D) or [] (2D)
        """
        import tempfile
        import os
        import uuid

        try:
            import gmsh
        except:
            if not silent:
                print("Topology.Mesh - Information: Installing required gmsh library.")
            try:
                os.system("pip install gmsh")
            except:
                os.system("pip install gmsh --user")
            try:
                import gmsh
                if not silent:
                    print("Topology.Mesh - Information: gmsh library installed correctly.")
            except:
                if not silent:
                    print("Topology.Mesh - Error: Could not import gmsh. Please try to install gmsh manually. Returning None.")
                return None

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.Mesh - Error: The input topology parameter is not a valid topology. Returning None.")
            return None

        if minSize <= 0 or maxSize <= 0 or minSize >= maxSize:
            if not silent:
                print("Topology.Mesh - Error: Bad minSize/maxSize values. Returning None.")
            return None
        
        if not algorithm2D in [1,2,3,4,5,6,7,8,9]:
            if not silent:
                print("Topology.Mesh - Error: Bad algorithm2D number. Returning None.")
            return None
        
        if not algorithm3D in [1,2,3,4,5,6]:
            if not silent:
                print("Topology.Mesh - Error: Bad algorithm3D number. Returning None.")
            return None

        # --- Meshing Algorithm mapping ------------------------------------------
        algorithm_mapping_2d = {1:1,
                                2:2,
                                3:3,
                                4:5,
                                5:6,
                                6:7,
                                7:8,
                                8:9,
                                9:11
                                }
        algorithm_mapping_3d = {1:1,
                                2:3,
                                3:4,
                                4:7,
                                5:9,
                                6:10
                                }

        # --- decide mesh dimension (2D vs 3D) -----------------------------------
        if meshDim is None:
            has_cells = False
            try:
                cells = Topology.Cells(topology, silent=True)
                has_cells = bool(cells)
            except Exception:
                has_cells = False
            meshDim = 3 if has_cells else 2

        if meshDim not in (2, 3):
            if not silent:
                print("Topology.Mesh - Error: meshDim must be 2 or 3. Returning None.")
            return None

        # --- export Topologic topology to temp BREP ------------------------------
        try:
            brep_str = Topology.BREPString(topology)
        except Exception as e:
            if not silent:
                print(f"Topology.Mesh - Error: Could not get BREPString: {e}. Returning None.")
            return None

        tmp_in = None
        try:
            with tempfile.NamedTemporaryFile(suffix=".brep", delete=False) as f:
                f.write(brep_str.encode("utf-8"))
                tmp_in = f.name
        except Exception as e:
            if not silent:
                print(f"Topology.Mesh - Error: Could not write BREP: {e}. Returning None.")
            return None

        # --- gmsh: init + import -------------------------------------------------
        try:
            gmsh.initialize()
        except Exception:
            # already initialized
            pass

        model_name = f"topologic_mesh_{uuid.uuid4().hex}"
        gmsh.model.add(model_name)
        gmsh.option.setNumber("Mesh.Algorithm", algorithm_mapping_2d.get(algorithm2D, 1))
        gmsh.option.setNumber("Mesh.Algorithm3D", algorithm_mapping_3d.get(algorithm3D, 1))

        if not silent:
            print(f"Topology.Mesh - Information: Importing BREP into gmsh (dim={meshDim})...")

        occ = gmsh.model.occ
        occ.importShapes(tmp_in)
        occ.synchronize()

        # --- define variable size field (Distance + Threshold) -------------------
        if not silent:
            print("Topology.Mesh - Information: Setting up size fields...")

        field = gmsh.model.mesh.field
        fid_dist = 1
        field.add("Distance", fid_dist)

        if refineEdges:
            edges = gmsh.model.getEntities(1)
            if edges:
                field.setNumbers(fid_dist, "EdgesList", [e[1] for e in edges])

        if refineFaces:
            faces_ent = gmsh.model.getEntities(2)
            if faces_ent:
                field.setNumbers(fid_dist, "FacesList", [f[1] for f in faces_ent])

        fid_thresh = 2
        field.add("Threshold", fid_thresh)
        field.setNumber(fid_thresh, "InField", fid_dist)
        field.setNumber(fid_thresh, "SizeMin", minSize)
        field.setNumber(fid_thresh, "SizeMax", maxSize)
        field.setNumber(fid_thresh, "DistMin", minSize * 2.0)
        field.setNumber(fid_thresh, "DistMax", maxSize * 2.0)

        field.setAsBackgroundMesh(fid_thresh)

        # --- generate mesh (2D or 3D) -------------------------------------------
        if not silent:
            print(f"Topology.Mesh - Information: Generating {meshDim}D mesh...")

        gmsh.model.mesh.generate(meshDim)

        if optimize:
            gmsh.model.mesh.optimize("Netgen")

        # --- extract nodes -------------------------------------------------------
        node_tags, node_coords, _ = gmsh.model.mesh.getNodes()
        if len(node_coords) == 0:
            if not silent:
                print("Topology.Mesh - Error: No mesh nodes. Returning None.")
            gmsh.finalize()
            if tmp_in and os.path.exists(tmp_in):
                os.remove(tmp_in)
            return None

        # tag -> index and vertex list
        tag_to_index = {}
        vertices = []
        for i, tag in enumerate(node_tags):
            x = round(node_coords[3*i], mantissa)
            y = round(node_coords[3*i + 1], mantissa)
            z = round(node_coords[3*i + 2], mantissa)
            tag_to_index[tag] = len(vertices)
            vertices.append((x, y, z))

        faces = []
        tets = []

        # --- extract elements & build faces/tets --------------------------------
        if meshDim == 3:
            # 3D: get tetrahedra, derive unique triangle faces
            types, _, elem_data = gmsh.model.mesh.getElements(3)

            raw_tets = []
            for etype, conn in zip(types, elem_data):
                if etype == 4:  # 4-node tets
                    for i in range(0, len(conn), 4):
                        t0 = conn[i]
                        t1 = conn[i+1]
                        t2 = conn[i+2]
                        t3 = conn[i+3]
                        try:
                            a = tag_to_index[t0]
                            b = tag_to_index[t1]
                            c = tag_to_index[t2]
                            d = tag_to_index[t3]
                            raw_tets.append((a, b, c, d))
                        except KeyError:
                            continue

            if not raw_tets:
                if not silent:
                    print("Topology.Mesh - Error: No tetra elements. Returning None.")
                gmsh.finalize()
                if tmp_in and os.path.exists(tmp_in):
                    os.remove(tmp_in)
                return None

            tets = raw_tets

            if not silent:
                print(f"Topology.Mesh - Information: 3D mesh: {len(vertices)} vertices, {len(tets)} tets.")
                print("Topology.Mesh - Information: Building unique faces from tets...")

            face_set = set()
            for (a, b, c, d) in tets:
                faces_tet = [
                    (a, b, c),
                    (a, b, d),
                    (a, c, d),
                    (b, c, d),
                ]
                for f in faces_tet:
                    key = tuple(sorted(f))  # orientation-insensitive
                    face_set.add(key)

            faces = list(face_set)

        else:
            # 2D: get triangular surface elements; tets = []
            types, _, elem_data = gmsh.model.mesh.getElements(2)

            face_set = set()
            for etype, conn in zip(types, elem_data):
                if etype == 2:  # 3-node triangles
                    for i in range(0, len(conn), 3):
                        t0 = conn[i]
                        t1 = conn[i+1]
                        t2 = conn[i+2]
                        try:
                            a = tag_to_index[t0]
                            b = tag_to_index[t1]
                            c = tag_to_index[t2]
                            key = tuple(sorted((a, b, c)))
                            face_set.add(key)
                        except KeyError:
                            continue

            if not face_set:
                if not silent:
                    print("Topology.Mesh - Error: No triangular surface elements. Returning None.")
                gmsh.finalize()
                if tmp_in and os.path.exists(tmp_in):
                    os.remove(tmp_in)
                return None

            faces = list(face_set)
            tets = []

            if not silent:
                print(f"Topology.Mesh - Information: 2D mesh: {len(vertices)} vertices, {len(faces)} triangles.")

        if not silent:
            print("Topology.Mesh - Information: Done.")

        # --- cleanup -------------------------------------------------------------
        gmsh.finalize()
        if tmp_in and os.path.exists(tmp_in):
            try:
                os.remove(tmp_in)
            except OSError:
                pass
        
        d = {
            "verts": vertices,
            "tris": faces,
            "tets": tets
        }
        return d

    @staticmethod
    def MeshToTopologies(vertices: list, faces: list = [], tets: list = [], tolerance: float = 0.0001, silent: bool = False):
        """
        Converts mesh data in the form of:

            vertices: List[(x, y, z)]
            faces   : List[(i0, i1, i2)]      # unique triangular faces, 0-based
            tets    : List[(i0, i1, i2, i3)]  # tetrahedra (3D only; [] for 2D, 0-based)
        
        into a list of topologic vertices, faces, and cells.
        This method is designed to work in conjunction with the Topology.Mesh method.

        Parameters
        ----------
        vertices : list
            The list of vertices coordinates in the form: List[(x, y, z)].
        faces : list , optional
            The list of unique triangular faces in the form: List[(i0, i1, i2)]
        tets : list , optional
            The list of tetrahedral cells in the form: List[i0, i1, ,i2, i3, i4]
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool, optional
            If set to True, warning and error messages are suppressed. Default is False.

        Returns
        -------
        dict
            "vertices": List[topologic_core.Vertex]
            "faces"   : List[topologic_core.Face]      # triangles
            "cells"    : List[topologicy_core.Cell]  # tetrahedra (3D) or [] (2D)
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Cell import Cell

        t_verts = [Vertex.ByCoordinates(coords) for coords in vertices]
        t_faces = [Face.ByVertices([t_verts[a], t_verts[b], t_verts[c]], tolerance=tolerance, silent=silent) for a,b,c in faces]
        t_cells = []
        for (a,b,c,d) in tets:
            faces_tet = [
                        (a, b, c),
                        (a, b, d),
                        (a, c, d),
                        (b, c, d),
                    ]
            triangles = []
            for face_tet in faces_tet:
                verts = [t_verts[i] for i in face_tet]
                triangles.append(Face.ByVertices(verts, tolerance=tolerance, silent=silent))
            t_cells.append(Cell.ByFaces(triangles, tolerance=tolerance, silent=silent))
        
        d = {
            "vertices": t_verts,
            "faces": t_faces,
            "cells": t_cells
        }
        return d

    @staticmethod
    def MeshData(topology, mode: int = 1, transferDictionaries: bool = False, mantissa: int = 6, silent: bool = False):
        """
        Creates a mesh data python dictionary from the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        mode : int , optional
            The desired mode of conversion:
            0: The faces list indexes into the vertices list.
            1: The faces list indexes into the edges list.
            The default is 1.
        transferDictionaries : bool , optional
            If set to True, the python dictionaries will be transferred to the coorespoding topologies. Default is False.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        dict
            The created mesh data python dictionary of vertices, edges, faces, and cells in the form of:
            { 'mode' : int (the mode of the face data)
            'vertices': list, (list of coordinates)
            'edges': list,   (list of indices into the list of vertices)
            'faces': list,   (list of indices into the list of edges or list of vertices based on mode)
            'cells': list,   (list of indices into the list of faces)
            'vertex_dict': list of dicts,
            'edge_dicts': list of dicts,
            'face_dicts', list of dicts,
            'cell_dicts', list of dicts
            }

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Dictionary import Dictionary

        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            TGraph = None
            is_tgraph = False

        # ------------------------------------------------------------------
        # TGraph path
        # ------------------------------------------------------------------
        if is_tgraph:
            vertex_dicts = []
            edge_dicts = []
            face_dicts = []
            cell_dicts = []

            m_verts = []
            m_edges = []
            m_faces = []
            m_cells = []

            index_map = {}

            vertex_records = TGraph.Vertices(topology, asTopologic=False, active=True)
            n = max(1, len(vertex_records))

            for i, v_record in enumerate(vertex_records):
                if not isinstance(v_record, dict):
                    continue

                old_index = v_record.get("index", i)
                d = dict(v_record.get("dictionary", {}))

                coords = TGraph.Coordinates(topology, old_index, default=None)
                if coords is None:
                    angle = 2.0 * math.pi * float(i) / float(n)
                    coords = [math.cos(angle), math.sin(angle), 0.0]

                coords = [
                    round(float(coords[0]), mantissa),
                    round(float(coords[1]), mantissa),
                    round(float(coords[2]), mantissa),
                ]

                index_map[old_index] = len(m_verts)
                m_verts.append(coords)
                vertex_dicts.append(d)

            edge_records = TGraph.Edges(topology, asTopologic=False, active=True)

            for e_record in edge_records:
                if not isinstance(e_record, dict):
                    continue

                src = e_record.get("src", None)
                dst = e_record.get("dst", None)

                if src not in index_map or dst not in index_map:
                    continue

                m_edges.append([index_map[src], index_map[dst]])
                edge_dicts.append(dict(e_record.get("dictionary", {})))

            return {
                "mode": mode,
                "vertices": m_verts,
                "edges": m_edges,
                "faces": m_faces,
                "cells": m_cells,
                "vertex_dicts": vertex_dicts,
                "edge_dicts": edge_dicts,
                "face_dicts": face_dicts,
                "cell_dicts": cell_dicts
            }

        # ------------------------------------------------------------------
        # Legacy Graph path
        # ------------------------------------------------------------------
        if Topology.IsInstance(topology, "Graph"):
            from topologicpy.Graph import Graph

            vertex_dicts = []
            edge_dicts = []
            face_dicts = []
            cell_dicts = []

            m_verts = []
            m_edges = []
            m_faces = []
            m_cells = []

            graph_vertices = Graph.Vertices(topology)
            graph_edges = Graph.Edges(topology)

            coord_to_index = {}

            def _coord_key(vertex):
                return tuple(Vertex.Coordinates(vertex, mantissa=mantissa))

            for v in graph_vertices:
                coords = Vertex.Coordinates(v, mantissa=mantissa)
                key = tuple(coords)

                if key not in coord_to_index:
                    coord_to_index[key] = len(m_verts)
                    m_verts.append(coords)

                    d = Topology.Dictionary(v)
                    try:
                        vertex_dicts.append(Dictionary.PythonDictionary(d))
                    except Exception:
                        vertex_dicts.append({})

            for e in graph_edges:
                sv = Edge.StartVertex(e)
                ev = Edge.EndVertex(e)

                sv_key = _coord_key(sv)
                ev_key = _coord_key(ev)

                if sv_key not in coord_to_index:
                    coord_to_index[sv_key] = len(m_verts)
                    m_verts.append(list(sv_key))
                    vertex_dicts.append({})

                if ev_key not in coord_to_index:
                    coord_to_index[ev_key] = len(m_verts)
                    m_verts.append(list(ev_key))
                    vertex_dicts.append({})

                m_edges.append([coord_to_index[sv_key], coord_to_index[ev_key]])

                d = Topology.Dictionary(e)
                try:
                    edge_dicts.append(Dictionary.PythonDictionary(d))
                except Exception:
                    edge_dicts.append({})

            return {
                "mode": mode,
                "vertices": m_verts,
                "edges": m_edges,
                "faces": m_faces,
                "cells": m_cells,
                "vertex_dicts": vertex_dicts,
                "edge_dicts": edge_dicts,
                "face_dicts": face_dicts,
                "cell_dicts": cell_dicts
            }

        # ------------------------------------------------------------------
        # Topologic topology path
        # ------------------------------------------------------------------
        vertex_dicts = []
        edge_dicts = []
        face_dicts = []
        cell_dicts = []

        top = Topology.Copy(topology)
        top = Topology.Triangulate(top, transferDictionaries=transferDictionaries)

        vertices = Topology.Vertices(top)
        edges = Topology.Edges(top)
        faces = Topology.Faces(top)

        if Topology.IsInstance(top, "Vertex"):
            vertices = [top]
            edges = []
            faces = []
            cells = []
        elif Topology.IsInstance(top, "Edge"):
            vertices = Topology.Vertices(top)
            edges = [top]
            faces = []
            cells = []
        elif Topology.IsInstance(top, "Wire"):
            vertices = Topology.Vertices(top)
            edges = Topology.Edges(top)
            faces = []
            cells = []
        elif Topology.IsInstance(top, "Face"):
            vertices = Topology.Vertices(top)
            edges = Topology.Edges(top)
            faces = [top]
            cells = []
        elif Topology.IsInstance(top, "Shell"):
            vertices = Topology.Vertices(top)
            edges = Topology.Edges(top)
            faces = Topology.Faces(top)
            cells = []
        elif Topology.IsInstance(top, "Cell"):
            vertices = Topology.Vertices(top)
            edges = Topology.Edges(top)
            faces = Topology.Faces(top)
            cells = [top]
        elif Topology.IsInstance(top, "CellComplex"):
            vertices = Topology.Vertices(top)
            edges = Topology.Edges(top)
            faces = Topology.Faces(top)
            cells = Topology.Cells(top)
        elif Topology.IsInstance(top, "Cluster"):
            vertices = Topology.Vertices(top)
            edges = Topology.Edges(top)
            faces = Topology.Faces(top)
            cells = Topology.Cells(top)
        else:
            if not silent:
                print("Topology.MeshData - Error: The input topology parameter is not a valid topology. Returning None.")
            return None

        m_verts = []
        m_edges = []
        m_faces = []
        m_cells = []
        key = "_n_"

        for i, v in enumerate(vertices):
            d = Topology.Dictionary(v)
            v = Topology.SetDictionary(v, Dictionary.ByKeyValue(key, i))
            m_verts.append(Vertex.Coordinates(v, mantissa=mantissa))
            vertex_dicts.append(Dictionary.PythonDictionary(d))

        for i, e in enumerate(edges):
            d = Topology.Dictionary(e)
            e = Topology.SetDictionary(e, Dictionary.ByKeyValue(key, i), silent=True)
            sv, ev = Topology.Vertices(e)
            sv_n = Dictionary.ValueAtKey(Topology.Dictionary(sv), key)
            ev_n = Dictionary.ValueAtKey(Topology.Dictionary(ev), key)
            m_edges.append([sv_n, ev_n])
            edge_dicts.append(Dictionary.PythonDictionary(d))

        for i, f in enumerate(faces):
            d = Topology.Dictionary(f)
            f = Topology.SetDictionary(f, Dictionary.ByKeyValue(key, i), silent=True)
            if mode == 1:
                f_edges = Topology.Edges(f)
                edge_indices = []
                for f_edge in f_edges:
                    edge_indices.append(Dictionary.ValueAtKey(Topology.Dictionary(f_edge), key))
                m_faces.append(edge_indices)
            else:
                f_vertices = Topology.Vertices(f)
                vertex_indices = []
                for f_vertex in f_vertices:
                    vertex_indices.append(Dictionary.ValueAtKey(Topology.Dictionary(f_vertex), key))
                m_faces.append(vertex_indices)
            face_dicts.append(Dictionary.PythonDictionary(d))

        for i, c in enumerate(cells):
            d = Topology.Dictionary(c)
            c = Topology.SetDictionary(c, Dictionary.ByKeyValue(key, i), silent=True)
            c_faces = Topology.Faces(c)
            face_indices = []
            for c_face in c_faces:
                face_indices.append(Dictionary.ValueAtKey(Topology.Dictionary(c_face), key))
            m_cells.append(face_indices)
            cell_dicts.append(Dictionary.PythonDictionary(d))

        return {
            "mode": mode,
            "vertices": m_verts,
            "edges": m_edges,
            "faces": m_faces,
            "cells": m_cells,
            "vertex_dicts": vertex_dicts,
            "edge_dicts": edge_dicts,
            "face_dicts": face_dicts,
            "cell_dicts": cell_dicts
        }

    @staticmethod
    def Move(topology, x=0, y=0, z=0, transferDictionaries: bool = True, silent: bool = False):
        """
        Moves the input topology.

        Parameters
        ----------
        topology : topologic_core.topology
            The input topology.
        x : float , optional
            The x distance value. Default is 0.
        y : float , optional
            The y distance value. Default is 0.
        z : float , optional
            The z distance value. Default is 0.
        transferDictionaries : bool , optional
            If set to True, the dictionaries are transfered from the original object to the translated object. Default is True.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The moved topology.

        """
        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.Move - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        
        topology_type = Topology.TypeAsString(topology)
        if not topology_type.lower() in ["vertex", "edge", "wire", "face", "shell", "cell", "cellcomplex", "cluster"]:
            if not silent:
                print("Topology.Move - Error: The input topology parameter is not a valid topology for moving. Returning None.")
            return None
        
        return Topology.Translate(topology, x=x, y=y, z=z, transferDictionaries = transferDictionaries, silent = silent)
    
    @staticmethod
    def NonPlanarFaces(topology, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns any nonplanar faces in the input topology
        
        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The list of nonplanar faces.
        
        """
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.NonPlanarFaces - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        faces = Topology.SubTopologies(topology, subTopologyType="face", silent=silent)
        return [f for f in faces if not Topology.IsPlanar(f, tolerance=tolerance, silent=silent)]
    
    @staticmethod
    def OBJString(*topologies,
                nameKey="name",
                colorKey="color",
                opacityKey="opacity",
                defaultColor=[255, 255, 255],
                defaultOpacity=0.5,
                transposeAxes: bool = True,
                triangulate: bool = False,
                mode: int = 0,
                meshSize: float = None,
                mantissa: int = 6,
                tolerance: float = 0.0001,
                silent: bool = False):
        """
        Exports the input topology to Wavefront OBJ and MTL strings.

        Parameters
        ----------
        topologies : list or comma separated topologies
            The input topology or list of topologies.
        nameKey : str , optional
            The topology dictionary key under which to find the name of the topology. Default is "name".
        colorKey : str, optional
            The topology dictionary key under which to find the color of the topology. Default is "color".
        opacityKey : str , optional
            The topology dictionary key under which to find the opacity of the topology. Default is "opacity".
        defaultColor : list , optional
            The default color to use if no color is stored in the topology dictionary. Default is [255, 255, 255].
        defaultOpacity : float , optional
            The default opacity to use if no opacity is stored in the topology dictionary. Default is 0.5.
        transposeAxes : bool , optional
            If set to True, the Z and Y coordinates are transposed so that Y points up. Default is True.
        triangulate : bool , optional
            If set to True, all faces of the input geometry are triangulated. Otherwise, only faces with holes are triangulated. Default is False.
        mode : int , optional
            The desired mode of meshing algorithm (for triangulation). Several options are available:
            0: Classic
            1: MeshAdapt
            3: Initial Mesh Only
            5: Delaunay
            6: Frontal-Delaunay
            7: BAMG
            8: Fontal-Delaunay for Quads
            9: Packing of Parallelograms
            All options other than 0 (Classic) use the gmsh library. See https://gmsh.info/doc/texinfo/gmsh.html#Mesh-options
            WARNING: The options that use gmsh can be very time consuming and can create very heavy geometry.
        meshSize : float , optional
            The desired size of the mesh when using the "mesh" option. If set to None, it will be
            calculated automatically and set to 10% of the overall size of the face.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        tuple
            Returns the OBJ and MTL strings as a tuple.
        """

        from topologicpy.Helper import Helper
        from topologicpy.Dictionary import Dictionary

        def _safe_name(value, fallback):
            if value is None:
                value = fallback
            value = str(value).strip()
            if not value:
                value = fallback
            return value.replace(" ", "_")

        def _safe_color(value, fallback):
            if value is None:
                value = fallback

            if not isinstance(value, (list, tuple)) or len(value) < 3:
                value = fallback

            result = []
            for c in value[:3]:
                try:
                    c = float(c)
                except Exception:
                    c = 255.0
                c = max(0.0, min(255.0, c))
                result.append(c / 255.0)

            return result

        def _safe_opacity(value, fallback):
            if value is None:
                value = fallback
            try:
                value = float(value)
            except Exception:
                value = fallback
            return max(0.0, min(1.0, value))

        if isinstance(topologies, tuple):
            topologies = Helper.Flatten(list(topologies))
        else:
            topologies = [topologies]

        new_topologies = []
        cached_data = []

        for topology in topologies:
            if not Topology.IsInstance(topology, "Topology"):
                continue

            d = Topology.Dictionary(topology)

            name = Dictionary.ValueAtKey(d, nameKey, None)
            color = Dictionary.ValueAtKey(d, colorKey, None)
            opacity = Dictionary.ValueAtKey(d, opacityKey, None)

            new_topologies.append(topology)
            cached_data.append((name, color, opacity))

        if len(new_topologies) == 0:
            if not silent:
                print("Topology.OBJString - Error: The input topologies parameter does not contain any valid topologies. Returning None.")
            return None

        n = max(len(str(len(new_topologies))), 3)

        obj_parts = [
            "# topologicpy " + Helper.Version() + "\n",
            "mtllib example.mtl\n"
        ]

        mtl_parts = []

        for i, (_, color, opacity) in enumerate(cached_data):
            material_name = "color_" + str(i).zfill(n)
            color = _safe_color(color, defaultColor)
            opacity = _safe_opacity(opacity, defaultOpacity)

            mtl_parts.append("newmtl " + material_name + "\n")
            mtl_parts.append("Kd " + " ".join(str(c) for c in color) + "\n")
            mtl_parts.append("d " + str(opacity) + "\n")

        vertex_index = 1

        for i, topology in enumerate(new_topologies):
            name, _, _ = cached_data[i]

            fallback_name = "Untitled_" + str(i).zfill(n)
            name = _safe_name(name, fallback_name)

            material_name = "color_" + str(i).zfill(n)

            obj_parts.append("\ng " + name + "\n")

            result = Topology._OBJString(
                topology,
                material_name,
                vertex_index,
                transposeAxes=transposeAxes,
                triangulate=triangulate,
                mode=mode,
                meshSize=meshSize,
                mantissa=mantissa,
                tolerance=tolerance,
                silent=silent
            )

            if result is None:
                continue

            obj_parts.append(result[0])
            vertex_index += result[1]

        return "".join(obj_parts), "".join(mtl_parts)
    
    @staticmethod
    def OCCTShape(topology, silent: bool = False):
        """
        Returns the occt shape of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.TopoDS_Shape
            The OCCT Shape.

        """
        if not Topology.IsInstance(topology, "Topology"):
            print("Topology.OCCTShape - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        topology_type = Topology.TypeAsString(topology)
        if not topology_type.lower() in ["vertex", "edge", "wire", "face", "shell", "cell", "cellcomplex", "cluster"]:
            if not silent:
                print("Topology.OCCTShape - Error: The input topology parameter does not have an OCCTShape. Returning None.")
            return None
        return Core.InstanceCall(topology, 'GetOcctShape')

    @staticmethod
    def OpenFaces(topology, silent: bool = False):
        """
        Returns the faces that border no cells.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The list of open edges.
        
        """

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.OpenFaces - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        topology_type = Topology.TypeAsString(topology)
        if not topology_type.lower() in ["face", "shell", "cell", "cellcomplex", "cluster"]:
            if not silent:
                print("Topology.OpenFaces - Error: The input topology parameter is not a suitable topology for this function. Returning None.")
            return None
        
        return [f for f in Topology.SubTopologies(topology, subTopologyType="face", silent=silent) if Topology.Degree(f, hostTopology=topology, silent=silent) < 1]
    
    @staticmethod
    def OpenEdges(topology, silent: bool = True):
        """
        Returns the edges that border only one face.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The list of open edges.
        
        """

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.OpenEdges - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        topology_type = Topology.TypeAsString(topology)
        if not topology_type.lower() in ["edge", "wire", "face", "shell", "cell", "cellcomplex", "cluster", "aperture"]:
            if not silent:
                print("Topology.OpenEdges - Error: The input topology parameter is not a suitable topology for this function. Returning None.")
            return None
        
        return [e for e in Topology.SubTopologies(topology, subTopologyType="edge", silent=silent) if Topology.Degree(e, hostTopology=topology, silent=silent) < 2]
    
    @staticmethod
    def OpenVertices(topology, silent: bool = False):
        """
        Returns the vertices that border only one edge.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The list of open edges.
        
        """

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.OpenVertices - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        topology_type = Topology.TypeAsString(topology)
        if not topology_type.lower() in ["vertex", "edge", "wire", "face", "shell", "cell", "cellcomplex", "cluster", "aperture"]:
            if not silent:
                print("Topology.OpenVertices - Error: The input topology parameter is not a suitable topology for this function. Returning None.")
            return None
        
        return [v for v in Topology.SubTopologies(topology, subTopologyType="vertex", silent=silent) if Topology.Degree(v, hostTopology=topology, silent=silent) < 2]
    
    @staticmethod
    def Orient(
        topology,
        origin=None,
        dirA=[0, 0, 1],
        dirB=[0, 0, 1],
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Orients the input topology such that dirA is parallel to dirB.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        origin : topologic_core.Vertex , optional
            The origin about which the topology is oriented. If set to None, the
            centroid of the topology is used. Default is None.
        dirA : list , optional
            The source direction vector. Default is [0, 0, 1].
        dirB : list , optional
            The target direction vector. Default is [0, 0, 1].
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The oriented topology.
        """
        return Topology.OrientAndPlace(
            topology,
            originA=origin,
            originB=origin,
            dirA=dirA,
            dirB=dirB,
            tolerance=tolerance,
            silent=silent,
        )

    @staticmethod
    def OrientAndPlace(
        topology,
        originA=None,
        originB=None,
        dirA=[0, 0, 1],
        dirB=[0, 0, 1],
        transferDictionaries: bool = True,
        tolerance: float = 0.0001,
        silent: bool = False,
    ):
        """
        Orients and places the input topology using a single affine transformation.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        originA : topologic_core.Vertex , optional
            The source origin about which the topology is oriented. If set to None,
            the centroid of the topology is used. Default is None.
        originB : topologic_core.Vertex , optional
            The target location of originA. If set to None, originA is used and no
            placement translation is applied. Default is None.
        dirA : list , optional
            The source direction vector. Default is [0, 0, 1].
        dirB : list , optional
            The target direction vector. Default is [0, 0, 1].
        transferDictionaries : bool , optional
            If set to True, dictionaries are transferred to the transformed topology.
            Default is True.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The oriented and placed topology.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Vector import Vector

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.OrientAndPlace - Error: The input topology is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(originA, "Vertex"):
            originA = Topology.Centroid(topology)

        if not Topology.IsInstance(originA, "Vertex"):
            if not silent:
                print("Topology.OrientAndPlace - Error: Could not determine originA. Returning None.")
            return None

        if not Topology.IsInstance(originB, "Vertex"):
            originB = originA

        # Source and target anchor coordinates.
        px, py, pz = Vertex.Coordinates(originA)
        qx, qy, qz = Vertex.Coordinates(originB)

        same_position = (
            abs(px - qx) <= tolerance
            and abs(py - qy) <= tolerance
            and abs(pz - qz) <= tolerance
        )

        same_direction = Vector.IsParallel(
            dirA,
            dirB,
            tolerance=tolerance
        )

        # Complete no-op.
        if same_position and same_direction:
            return topology

        # Rotation aligning dirA with dirB.
        rotation = Vector.TransformationMatrix(dirA, dirB)

        if rotation is None:
            if not silent:
                print("Topology.OrientAndPlace - Error: Could not compute the transformation matrix. Returning None.")
            return None

        r00, r01, r02 = rotation[0][0], rotation[0][1], rotation[0][2]
        r10, r11, r12 = rotation[1][0], rotation[1][1], rotation[1][2]
        r20, r21, r22 = rotation[2][0], rotation[2][1], rotation[2][2]

        # Translation that maps originA exactly onto originB after rotation:
        #
        #     q = R*p + t
        #
        # therefore:
        #
        #     t = q - R*p
        tx = qx - (r00 * px + r01 * py + r02 * pz)
        ty = qy - (r10 * px + r11 * py + r12 * pz)
        tz = qz - (r20 * px + r21 * py + r22 * pz)

        matrix = [
            [r00, r01, r02, tx],
            [r10, r11, r12, ty],
            [r20, r21, r22, tz],
            [0.0, 0.0, 0.0, 1.0],
        ]

        return Topology.Transform(
            topology,
            matrix,
            transferDictionaries=transferDictionaries,
            tolerance=tolerance,
            silent=silent,
        )
    
    @staticmethod
    def Place(
        topology,
        originA=None,
        originB=None,
        mantissa: int = 6,
        silent: bool = False
    ):
        """
        Places the input topology at the specified location.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        originA : topologic_core.Vertex , optional
            The old location to use as the origin of the movement. If set to None,
            the centroid of the input topology is used. Default is None.
        originB : topologic_core.Vertex , optional
            The new location at which to place the topology. If set to None, the
            world origin (0, 0, 0) is used. Default is None.
        mantissa : int , optional
            The number of decimal places to round the coordinates to. Default is 6.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The placed topology.
        """
        from topologicpy.Vertex import Vertex

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Place - Error: The input topology is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(originA, "Vertex"):
            originA = Topology.Centroid(topology)

        if not Topology.IsInstance(originA, "Vertex"):
            if not silent:
                print("Topology.Place - Error: Could not determine originA. Returning None.")
            return None

        if not Topology.IsInstance(originB, "Vertex"):
            originB = Vertex.Origin()

        x = Vertex.X(originB, mantissa=mantissa) - Vertex.X(originA, mantissa=mantissa)
        y = Vertex.Y(originB, mantissa=mantissa) - Vertex.Y(originA, mantissa=mantissa)
        z = Vertex.Z(originB, mantissa=mantissa) - Vertex.Z(originA, mantissa=mantissa)

        if x == 0 and y == 0 and z == 0:
            return topology

        return Topology.Translate(
            topology,
            x=x,
            y=y,
            z=z,
            silent=silent
        )

    @staticmethod
    def PrincipalAxes(topology, n: int = 10, mantissa: int = 6, silent: bool = False):
        """
        Returns the prinicipal axes (vectors) of the input topology.
        Please note that this is not a perfect algorithm and it can get confused based on the geometry of the input.
        Also, please note that there is no guarantee that three returned vectors match your expectation for an x,y,z axis order.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        n : int , optional
            The number of segments to use to increase the number of points on each face. Default is 10.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The list of x, y, and z vectors representing the principal axes of the topology.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Topology import Topology
        from topologicpy.Grid import Grid
        from topologicpy.Vector import Vector
        import numpy as np

        def generate_floats(n):
            if n < 2:
                return [0.0] if n == 1 else []
            return [i / (n - 1) for i in range(n)]

        
        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.PrincipalAxes - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        topology_type = Topology.TypeAsString(topology)
        if not topology_type.lower() in ["face", "shell", "cell", "cellcomplex", "cluster", "aperture"]:
            if not silent:
                print("Topology.PrincipalAxes - Error: The input topology parameter is not suitable for this function. Returning None.")
            return None
        
        faces = Topology.Faces(topology)
        if len(faces) == 0:
            if not silent:
                print("Topology.PrincipalAxes - Error: The input topology parameter does not contain any faces. Returning None.")
            return None
        
        # Step 1: Derive a copy topology to work with.
        if Topology.IsInstance(topology, "CellComplex"):
            top = CellComplex.ExternalBoundary(topology)
        else:
            top = Topology.Copy(topology)
        
        # Step 2: Increase the number of vertices by adding a grid of points on each face.
        faces = Topology.Faces(top)
        vertices = Topology.Vertices(top)
        r = generate_floats(n)
        for face in faces:
            vertices += Topology.Vertices(Grid.VerticesByParameters(face=face, uRange=r, vRange=r, clip=True))
        points = np.array([[Vertex.X(v, mantissa=mantissa), Vertex.Y(v, mantissa=mantissa), Vertex.Z(v, mantissa=mantissa)] for v in vertices])

        # Step 3: Align orientation using PCA
        # Compute PCA
        mean = points.mean(axis=0)
        centered_points = points - mean
        covariance_matrix = np.cov(centered_points.T)
        eigenvalues, eigenvectors = np.linalg.eigh(covariance_matrix)

        # Sort eigenvectors by eigenvalues (largest first)
        sorted_indices = np.argsort(-eigenvalues)
        eigenvectors = eigenvectors[:, sorted_indices]

        # Enforce consistent orientation by flipping eigenvectors
        for i in range(3):  # Ensure each eigenvector points in a positive direction
            if np.dot(eigenvectors[:, i], [1, 0, 0]) < 0:
                eigenvectors[:, i] *= -1
        
        # Retrieve and return the principal axes
        x_axis = Vector.ByCoordinates(*eigenvectors[:, 0])
        y_axis = Vector.ByCoordinates(*eigenvectors[:, 1])
        z_axis = Vector.ByCoordinates(*eigenvectors[:, 2])
        return x_axis, y_axis, z_axis

    @staticmethod
    def RemoveCollinearEdges(topology, angTolerance: float = 0.1, tolerance: float = 0.0001, silent: bool = False):
        """
        Removes the collinear edges of the input topology

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        angTolerance : float , optional
            The desired angular tolerance. Default is 0.1.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with the collinear edges removed.

        """
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Cluster import Cluster
        import inspect
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.RemoveCollinearEdges - Error: The input topology parameter is not a valid topology. Returning None.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return None
        return_topology = topology
        if Topology.IsInstance(topology, "vertex") or Topology.IsInstance(topology, "edge"):
            return_topoology = topology
        elif Topology.IsInstance(topology, "Wire"):
            return_topology = Wire.RemoveCollinearEdges(topology, angTolerance=angTolerance, tolerance=tolerance, silent=silent)
        elif Topology.IsInstance(topology, "Face"):
            return_topology = Face.RemoveCollinearEdges(topology, angTolerance=angTolerance, tolerance=tolerance, silent=silent)
        elif Topology.IsInstance(topology, "Shell"):
            return_topology = Shell.RemoveCollinearEdges(topology, angTolerance=angTolerance, tolerance=tolerance, silent=silent)
        elif Topology.IsInstance(topology, "Cell"):
            return_topology = Cell.RemoveCollinearEdges(topology, angTolerance=angTolerance, tolerance=tolerance, silent=silent)
        elif Topology.IsInstance(topology, "CellComplex"):
            return_topology = CellComplex.RemoveCollinearEdges(topology, angTolerance=angTolerance, tolerance=tolerance, silent=silent)
        elif Topology.IsInstance(topology, "Cluster"):
            topologies = []
            topologies += Cluster.FreeVertices(topology)
            topologies += Cluster.FreeEdges(topology)
            faces = Topology.Faces(topology)
            for face in faces:
                topologies.append(Face.RemoveCollinearEdges(face, angTolerance=angTolerance, tolerance=tolerance, silent=silent))
            return_topology = Topology.SelfMerge(Cluster.ByTopologies(topologies), tolerance=tolerance)
        else:
            if not silent:
                print("Topology.RemoveCollinearEdges - Error: The input topology parameter is not a valid topology. Returning None.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return_topology = None
        return return_topology

    @staticmethod
    def RemoveContent(topology, contents, silent: bool = False):
        """
        Removes the input content list from the input topology

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        contents : list
            The input list of contents.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with the input list of contents removed.

        """
        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.RemoveContent - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        if isinstance(contents, list) == False:
            contents = [contents]
        # return topology.RemoveContents(contents) # H to Core
        return Core.InstanceCall(topology, 'RemoveContents', contents)
    
    @staticmethod
    def RemoveCoplanarFaces(topology, epsilon=0.01, tolerance=0.0001, silent: bool = False):
        """
        Removes coplanar faces in the input topology

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        epsilon : float , optional
            The desired epsilon (another form of tolerance) for finding if two faces are coplanar. Default is 0.01.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with coplanar faces merged into one face.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Cluster import Cluster

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.RemoveCoplanarFaces - Error: The input topology parameter is not a valid topologic topology. Returning None.")
            return None
        t = Topology.Type(topology)
        if (t == Topology.TypeID("Vertex")) or (t == Topology.TypeID("Edge")) or (t == Topology.TypeID("Wire")) or (t == Topology.TypeID("Face")):
            return topology

        def faces_on_same_plane(face1, face2, epsilon=1e-6):
            vertices = Topology.Vertices(face1)
            distances = []
            for v in vertices:
                distances.append(Vertex.PerpendicularDistance(v, face=face2, mantissa=6))
            d = sum(distances) / len(distances) if distances else float('inf')
            return d <= epsilon

        def cluster_faces_on_planes(faces, epsilon=1e-6):

            # Create a dictionary to store bins based on plane equations
            bins = {}

            # Iterate through each face
            for i, face in enumerate(faces):
                # Check if a bin already exists for the plane equation
                found_bin = False
                for bin_face in bins.values():
                    if faces_on_same_plane(face, bin_face[0], epsilon=epsilon):
                        bin_face.append(face)
                        found_bin = True
                        break

                # If no bin is found, create a new bin
                if not found_bin:
                    bins[i] = [face]

            # Convert bins to a list of lists
            return list(bins.values())

        faces = Topology.Faces(topology)
        face_clusters = cluster_faces_on_planes(faces, epsilon=epsilon)
        final_faces = []
        for face_cluster in face_clusters:
            t = Topology.SelfMerge(Cluster.ByTopologies(face_cluster), tolerance=tolerance)
            if Topology.IsInstance(t, "Face"):
                #final_faces.append(Face.RemoveCollinearEdges(t))
                final_faces.append(t)
            elif Topology.IsInstance(t, "Shell"):
                    f = Face.ByShell(t, silent=True)
                    if Topology.IsInstance(f, "Face"):
                        final_faces.append(f)
                    else:
                        if not silent:
                            print("Topology.RemoveCoplanarFaces - Warning: Could not remove some coplanar faces. Re-adding original faces.")
                        final_faces += Shell.Faces(t)
            else: # It is a cluster
                shells = Topology.Shells(t)
                for shell in shells:
                    f = Face.ByShell(shell)
                    if Topology.IsInstance(f, "Face"):
                        final_faces.append(f)
                    else:
                        if not silent:
                            print("Topology.RemoveCoplanarFaces - Warning: Could not remove some coplanar faces. Re-adding original faces.")
                        final_faces += Shell.Faces(shell)
                if len(shells) == 0:
                    faces = Topology.Faces(t)
                    final_faces += faces
                faces = Cluster.FreeFaces(t)
                final_faces += faces
        return_topology = None
        if Topology.IsInstance(topology, "CellComplex"):
            return_topology = CellComplex.ByFaces(final_faces, tolerance=tolerance, silent=silent)
        elif Topology.IsInstance(topology, "Cell"):
            return_topology = Cell.ByFaces(final_faces, tolerance=tolerance, silent=silent)
        elif Topology.IsInstance(topology, "Shell"):
            if len(final_faces) == 1:
                return_topology = final_faces[0]
            else:
                return_topology = Shell.ByFaces(final_faces, tolerance=tolerance, silent=silent)
        if not Topology.IsInstance(return_topology, "Topology"):
            return_topology = Cluster.ByTopologies(final_faces, silent=silent)
        return return_topology

    @staticmethod
    def RemoveEdges(topology, edges: list = [], tolerance: float = 0.0001, silent: bool = False):
        """
        Removes the input list of faces from the input topology

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        edges : list
            The input list of edges.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with the input list of edges removed.

        """

        from topologicpy.Cluster import Cluster
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.RemoveEdges - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        edges = [e for e in edges if Topology.IsInstance(e, "Edge")]
        if len(edges) < 1:
            return topology
        t_edges = Topology.Edges(topology)
        t_faces = Topology.Faces(topology)
        if len(t_edges) < 1:
            return topology
        if len(t_faces) > 0:
            remove_faces = []
            for t_e in t_edges:
                remove = False
                for i, e in enumerate(edges):
                    if Topology.IsSame(t_e, e):
                        remove = True
                        remove_faces += Topology.SuperTopologies(e, hostTopology=topology, topologyType="face")
                        edges = edges[:i]+ edges[i:]
                        break
            if len(remove_faces) > 0:
                return Topology.RemoveFaces(topology, remove_faces)
        else:
            remaining_edges = []
            for t_e in t_edges:
                remove = False
                for i, e in enumerate(edges):
                    if Topology.IsSame(t_e, e):
                        remove = True
                        edges = edges[:i]+ edges[i:]
                        break
                if not remove:
                    remaining_edges.append(t_e)
            if len(remaining_edges) < 1:
                return None
            elif len(remaining_edges) == 1:
                return remaining_edges[0]
            return Topology.SelfMerge(Cluster.ByTopologies(remaining_edges), tolerance=tolerance)

    @staticmethod
    def RemoveFaces(topology, faces: list = [], tolerance: float = 0.0001, silent: bool = False):
        """
        Removes the input list of faces from the input topology

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        faces : list
            The input list of faces.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with the input list of faces removed.

        """

        from topologicpy.Cluster import Cluster
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.RemoveFaces - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        faces = [f for f in faces if Topology.IsInstance(f, "Face")]
        if len(faces) < 1:
            return topology
        t_faces = Topology.Faces(topology)
        if len(t_faces) < 1:
            return topology
        remaining_faces = []
        for t_f in t_faces:
            remove = False
            for i, f in enumerate(faces):
                if Topology.IsSame(t_f, f):
                    remove = True
                    faces = faces[:i]+ faces[i:]
                    break
            if not remove:
                remaining_faces.append(t_f)
        if len(remaining_faces) < 1:
            return None
        elif len(remaining_faces) == 1:
            return remaining_faces[0]
        return Topology.SelfMerge(Cluster.ByTopologies(remaining_faces), tolerance=tolerance)
    
    @staticmethod
    def RemoveFacesBySelectors(topology, selectors: list = [], tolerance: float = 0.0001, silent: bool = False):
        """
        Removes faces that contain the input list of selectors (vertices) from the input topology

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        selectors : list
            The input list of selectors (vertices).
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with the identified faces removed.

        """
        from topologicpy.Vertex import Vertex

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.RemoveFacesBySelectors - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        selectors = [v for v in selectors if Topology.IsInstance(v, "Vertex")]
        if len(selectors) < 1:
            if not silent:
                print("Topology.RemoveFacesBySelectors - Warning: The input selectors parameter does not contain any valid selectors. Returning the input topology.")
            return topology
        t_faces = Topology.Faces(topology)
        to_remove = []
        for t_f in t_faces:
            remove = False
            for i, v in enumerate(selectors):
                if Vertex.IsInternal(v, t_f, tolerance=tolerance):
                    remove = True
                    selectors = selectors[:i]+ selectors[i:]
                    break
            if remove:
                to_remove.append(t_f)
        if len(to_remove) < 1:
            return topology
        return Topology.RemoveFaces(topology, faces = to_remove, silent=silent)

    @staticmethod
    def RemoveVertices(topology, vertices: list = [], tolerance: float = 0.0001, silent: bool = False):
        """
        Removes the input list of vertices from the input topology

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        vertices : list
            The input list of vertices.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with the input list of vertices removed.

        """

        from topologicpy.Cluster import Cluster
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.RemoveVertices - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        vertices = [v for v in vertices if Topology.IsInstance(v, "Vertex")]
        if len(vertices) < 1:
            if not silent:
                print("Topology.RemoveFacesBySelectors - Warning: The input vertices parameter does not contain any valid selectors. Returning the input topology.")
            return topology
        t_vertices = Topology.Vertices(topology, silent=True)
        t_edges = Topology.Edges(topology)
        if len(t_vertices) < 1:
            return topology
        if len(t_edges) > 0:
            remove_edges = []
            for t_v in t_vertices:
                remove = False
                for i, v in enumerate(vertices):
                    if Topology.IsSame(t_v, v):
                        remove = True
                        remove_edges += Topology.SuperTopologies(v, hostTopology=topology, topologyType="edge")
                        vertices = vertices[:i]+ vertices[i:]
                        break
            if len(remove_edges) > 0:
                return Topology.RemoveEdges(topology, remove_edges)
        else:
            remaining_vertices = []
            for t_v in t_vertices:
                remove = False
                for i, e in enumerate(vertices):
                    if Topology.IsSame(t_v, v):
                        remove = True
                        vertices = vertices[:i]+ vertices[i:]
                        break
                if not remove:
                    remaining_vertices.append(t_v)
            if len(remaining_vertices) < 1:
                return None
            elif len(remaining_vertices) == 1:
                return remaining_vertices[0]
            return Topology.SelfMerge(Cluster.ByTopologies(remaining_vertices), tolerance=tolerance)
    
    @staticmethod
    def Cleanup(topology=None, silent: bool = False):
        """
        Cleans up all resources in which are managed by topologic library. Use this to manage your application's memory consumption.
        USE WITH CARE. This methods deletes dictionaries, contents, and contexts

        Parameters
        ----------
        topology : topologic_core.Topology , optional
            If specified the resources used by the input topology will be deleted. If not, ALL resources will be deleted.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        topologic_core.Topology
            The input topology, but with its resources deleted or None.
        """
        if not topology == None:
            if not Topology.IsInstance(topology, "Topology"):
                if not silent:
                    print("Topology.Cleanup - Error: The input topology parameter is not a valid topology. Returning None.")
                return None
        Core.Topology.Cleanup(topology)
        return topology

    @staticmethod
    def ReplaceVertices(
        topology,
        verticesA: list = [],
        verticesB: list = [],
        mantissa: int = 6,
        tolerance: float = 0.0001,
        silent: bool = False,
    ):
        """
        Replaces vertices in the first input list with the corresponding vertices
        in the second input list and rebuilds the input topology. The two lists
        must have the same length.

        The original topology structure and topology type are preserved whenever
        possible. Structured topologies such as Faces with internal boundaries
        and heterogeneous Clusters are rebuilt hierarchically rather than through
        a flattened geometry representation.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        verticesA : list
            The vertices in the input topology to replace.
        verticesB : list
            The replacement vertices. Each vertex corresponds by index to a vertex
            in verticesA.
        mantissa : int , optional
            The number of decimal places to which coordinates are rounded.
            Default is 6.
        tolerance : float , optional
            The desired tolerance used to match vertices. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Topology
            The rebuilt topology with the requested vertices replaced, or None if
            the operation fails.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Cluster import Cluster

        # ------------------------------------------------------------------
        # Helpers
        # ------------------------------------------------------------------

        def preserve_dictionary(source, target):
            """Preserves the dictionary of the source topology."""
            if not Topology.IsInstance(
                target,
                "Topology"
            ):
                return target

            try:
                dictionary = Topology.Dictionary(
                    source,
                    silent=True
                )

                if dictionary is not None:
                    target = Topology.SetDictionary(
                        target,
                        dictionary,
                        silent=True
                    )

            except Exception:
                pass

            return target

        def cluster_constituents(cluster):
            """
            Returns the actual constituent topologies stored by the Cluster.

            The native backend accessor is preferred because the public
            Cluster.Topologies method derives free topologies and may therefore
            alter or lose the original Cluster hierarchy.
            """

            # --------------------------------------------------------------
            # Backend-native return-value form.
            #
            # PythonOCC uses:
            #
            #     cluster.Topologies() -> list
            # --------------------------------------------------------------

            try:
                result = Core.InstanceCall(
                    cluster,
                    "Topologies"
                )

                if isinstance(
                    result,
                    list
                ):
                    return [
                        item
                        for item in result
                        if Topology.IsInstance(
                            item,
                            "Topology"
                        )
                    ]

            except Exception:
                pass

            # --------------------------------------------------------------
            # Backend-native output-list form.
            # --------------------------------------------------------------

            try:
                result = []

                Core.InstanceCall(
                    cluster,
                    "Topologies",
                    result
                )

                if len(result) > 0:
                    return [
                        item
                        for item in result
                        if Topology.IsInstance(
                            item,
                            "Topology"
                        )
                    ]

            except Exception:
                pass

            # --------------------------------------------------------------
            # Legacy hostTopology + output-list form.
            # --------------------------------------------------------------

            try:
                result = []

                Core.InstanceCall(
                    cluster,
                    "Topologies",
                    None,
                    result
                )

                if len(result) > 0:
                    return [
                        item
                        for item in result
                        if Topology.IsInstance(
                            item,
                            "Topology"
                        )
                    ]

            except Exception:
                pass

            # --------------------------------------------------------------
            # Final public fallback.
            # --------------------------------------------------------------

            try:
                result = Cluster.Topologies(
                    cluster,
                    tolerance=tolerance,
                    silent=True
                )

                if isinstance(
                    result,
                    list
                ):
                    return [
                        item
                        for item in result
                        if Topology.IsInstance(
                            item,
                            "Topology"
                        )
                    ]

            except Exception:
                pass

            return []

        # ------------------------------------------------------------------
        # Validate inputs
        # ------------------------------------------------------------------

        if not Topology.IsInstance(
            topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.ReplaceVertices - Error: The input topology parameter "
                    "is not a valid topology. Returning None."
                )
            return None

        if not isinstance(
            verticesA,
            (list, tuple)
        ):
            if not silent:
                print(
                    "Topology.ReplaceVertices - Error: The input verticesA parameter "
                    "is not a valid list. Returning None."
                )
            return None

        if not isinstance(
            verticesB,
            (list, tuple)
        ):
            if not silent:
                print(
                    "Topology.ReplaceVertices - Error: The input verticesB parameter "
                    "is not a valid list. Returning None."
                )
            return None

        verticesA = list(
            verticesA
        )

        verticesB = list(
            verticesB
        )

        if len(verticesA) != len(verticesB):
            if not silent:
                print(
                    "Topology.ReplaceVertices - Error: The verticesA and verticesB "
                    "parameters must have the same length. Returning None."
                )
            return None

        if len(verticesA) == 0:
            if not silent:
                print(
                    "Topology.ReplaceVertices - Warning: No replacement vertices were "
                    "specified. Returning the input topology."
                )
            return topology

        if not all(
            Topology.IsInstance(
                vertex,
                "Vertex"
            )
            for vertex in verticesA
        ):
            if not silent:
                print(
                    "Topology.ReplaceVertices - Error: The verticesA parameter contains "
                    "one or more invalid vertices. Returning None."
                )
            return None

        if not all(
            Topology.IsInstance(
                vertex,
                "Vertex"
            )
            for vertex in verticesB
        ):
            if not silent:
                print(
                    "Topology.ReplaceVertices - Error: The verticesB parameter contains "
                    "one or more invalid vertices. Returning None."
                )
            return None

        topology_type = Topology.TypeAsString(
            topology,
            silent=True
        )

        if isinstance(
            topology_type,
            str
        ):
            topology_type = topology_type.lower()

        else:
            topology_type = None

        # ------------------------------------------------------------------
        # Cluster
        #
        # A heterogeneous Cluster must not be flattened through Geometry.
        # Doing so loses which Faces form Cells and which Edges form Wires.
        #
        # Retrieve the actual backend-native constituents and rebuild each one
        # recursively.
        # ------------------------------------------------------------------

        if topology_type == "cluster":

            topologies = cluster_constituents(
                topology
            )

            if len(topologies) == 0:
                if not silent:
                    print(
                        "Topology.ReplaceVertices - Error: Could not retrieve the "
                        "constituent topologies of the input Cluster. Returning None."
                    )
                return None

            rebuilt_topologies = []

            for child in topologies:

                rebuilt_child = Topology.ReplaceVertices(
                    child,
                    verticesA=verticesA,
                    verticesB=verticesB,
                    mantissa=mantissa,
                    tolerance=tolerance,
                    silent=silent
                )

                if not Topology.IsInstance(
                    rebuilt_child,
                    "Topology"
                ):
                    if not silent:
                        print(
                            "Topology.ReplaceVertices - Error: Could not rebuild "
                            "one of the constituent topologies of the input Cluster. "
                            "Returning None."
                        )
                    return None

                rebuilt_topologies.append(
                    rebuilt_child
                )

            try:
                new_topology = Cluster.ByTopologies(
                    rebuilt_topologies,
                    silent=True
                )

            except TypeError:
                new_topology = Cluster.ByTopologies(
                    rebuilt_topologies
                )

            except Exception:
                new_topology = None

            if not Topology.IsInstance(
                new_topology,
                "Cluster"
            ):
                if not silent:
                    print(
                        "Topology.ReplaceVertices - Error: Could not rebuild the "
                        "input Cluster. Returning None."
                    )
                return None

            return preserve_dictionary(
                topology,
                new_topology
            )

        # ------------------------------------------------------------------
        # Face with internal boundaries
        #
        # Geometry() intentionally triangulates Faces containing holes, making
        # it unsuitable for lossless reconstruction of such a Face.
        #
        # Replace vertices in the external and internal boundary Wires and call
        # the backend Face constructor directly.
        #
        # Do NOT call Face.ByWires here. Face.ByWires performs additional
        # SpatialRelationship validation which is unrelated to this operation
        # and currently depends on Copy/BREP behaviour.
        # ------------------------------------------------------------------

        if topology_type == "face":

            try:
                internal_boundaries = Face.InternalBoundaries(
                    topology
                )

            except Exception:
                internal_boundaries = []

            if (
                isinstance(
                    internal_boundaries,
                    list
                )
                and len(internal_boundaries) > 0
            ):

                try:
                    external_boundary = Face.ExternalBoundary(
                        topology,
                        silent=True
                    )

                except TypeError:
                    external_boundary = Face.ExternalBoundary(
                        topology
                    )

                except Exception:
                    external_boundary = None

                if not Topology.IsInstance(
                    external_boundary,
                    "Wire"
                ):
                    if not silent:
                        print(
                            "Topology.ReplaceVertices - Error: Could not retrieve "
                            "the external boundary of the input Face. Returning None."
                        )
                    return None

                new_external_boundary = Topology.ReplaceVertices(
                    external_boundary,
                    verticesA=verticesA,
                    verticesB=verticesB,
                    mantissa=mantissa,
                    tolerance=tolerance,
                    silent=silent
                )

                if not Topology.IsInstance(
                    new_external_boundary,
                    "Wire"
                ):
                    if not silent:
                        print(
                            "Topology.ReplaceVertices - Error: Could not rebuild "
                            "the external boundary of the input Face. Returning None."
                        )
                    return None

                new_internal_boundaries = []

                for internal_boundary in internal_boundaries:

                    new_internal_boundary = Topology.ReplaceVertices(
                        internal_boundary,
                        verticesA=verticesA,
                        verticesB=verticesB,
                        mantissa=mantissa,
                        tolerance=tolerance,
                        silent=silent
                    )

                    if not Topology.IsInstance(
                        new_internal_boundary,
                        "Wire"
                    ):
                        if not silent:
                            print(
                                "Topology.ReplaceVertices - Error: Could not rebuild "
                                "an internal boundary of the input Face. Returning None."
                            )
                        return None

                    new_internal_boundaries.append(
                        new_internal_boundary
                    )

                # ----------------------------------------------------------
                # Direct backend construction.
                #
                # This is the actual construction operation ultimately used by
                # Face.ByWires, without its additional SpatialRelationship
                # validation layer.
                # ----------------------------------------------------------

                try:
                    new_face = Core.Face.ByExternalInternalBoundaries(
                        new_external_boundary,
                        new_internal_boundaries,
                        tolerance
                    )

                except TypeError:
                    try:
                        new_face = Core.Face.ByExternalInternalBoundaries(
                            new_external_boundary,
                            new_internal_boundaries
                        )

                    except Exception:
                        new_face = None

                except Exception:
                    new_face = None

                if Topology.IsInstance(
                    new_face,
                    "Face"
                ):
                    return preserve_dictionary(
                        topology,
                        new_face
                    )

                if not silent:
                    print(
                        "Topology.ReplaceVertices - Error: Could not rebuild the "
                        "Face from its transformed external and internal boundaries. "
                        "Returning None."
                    )

                return None

        # ------------------------------------------------------------------
        # Determine desired generic reconstruction type
        # ------------------------------------------------------------------

        supported_rebuild_types = [
            "vertex",
            "edge",
            "wire",
            "face",
            "shell",
            "cell",
            "cellcomplex"
        ]

        if topology_type in supported_rebuild_types:
            rebuild_type = topology_type

        else:
            rebuild_type = None

        # ------------------------------------------------------------------
        # Extract generic geometry
        # ------------------------------------------------------------------

        try:
            geometry = Topology.Geometry(
                topology,
                triangulate=False,
                mantissa=mantissa,
                tolerance=tolerance,
                silent=True,
            )

        except TypeError:
            geometry = Topology.Geometry(
                topology,
                mantissa=mantissa,
                tolerance=tolerance,
            )

        except Exception as error:
            if not silent:
                print(
                    "Topology.ReplaceVertices - Error: Could not extract the geometry "
                    f"of the input topology. {error}. Returning None."
                )
            return None

        if not isinstance(
            geometry,
            dict
        ):
            if not silent:
                print(
                    "Topology.ReplaceVertices - Error: Could not extract valid geometry "
                    "from the input topology. Returning None."
                )
            return None

        geometry_vertices = geometry.get(
            "vertices",
            []
        )

        geometry_edges = geometry.get(
            "edges",
            []
        )

        geometry_faces = geometry.get(
            "faces",
            []
        )

        if (
            not isinstance(
                geometry_vertices,
                list
            )
            or len(geometry_vertices) == 0
        ):
            if not silent:
                print(
                    "Topology.ReplaceVertices - Error: The input topology contains no "
                    "valid geometry vertices. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Recreate geometry vertices for matching
        # ------------------------------------------------------------------

        vertices = []

        for coordinates in geometry_vertices:

            try:
                vertex = Vertex.ByCoordinates(
                    coordinates
                )

            except Exception:
                vertex = None

            if not Topology.IsInstance(
                vertex,
                "Vertex"
            ):
                if not silent:
                    print(
                        "Topology.ReplaceVertices - Error: Could not reconstruct a "
                        "geometry vertex. Returning None."
                    )
                return None

            vertices.append(
                vertex
            )

        # ------------------------------------------------------------------
        # Map source vertices to geometry indices
        # ------------------------------------------------------------------

        replacement_indices = {}
        missing_count = 0

        for source_vertex, replacement_vertex in zip(
            verticesA,
            verticesB
        ):

            index = Vertex.Index(
                source_vertex,
                vertices,
                tolerance=tolerance,
            )

            if index is None:
                missing_count += 1
                continue

            replacement_indices[index] = replacement_vertex

        if len(replacement_indices) == 0:
            if not silent:
                print(
                    "Topology.ReplaceVertices - Warning: None of the vertices in "
                    "verticesA were found in the input topology. Returning the input "
                    "topology."
                )
            return topology

        # ------------------------------------------------------------------
        # Construct replacement coordinate list
        # ------------------------------------------------------------------

        new_geometry_vertices = []

        for index, vertex in enumerate(
            vertices
        ):

            replacement = replacement_indices.get(
                index,
                vertex
            )

            coordinates = Vertex.Coordinates(
                replacement,
                outputType="xyz",
                mantissa=mantissa,
            )

            if (
                not isinstance(
                    coordinates,
                    list
                )
                or len(coordinates) != 3
            ):
                if not silent:
                    print(
                        "Topology.ReplaceVertices - Error: Could not retrieve the "
                        "coordinates of a replacement vertex. Returning None."
                    )
                return None

            new_geometry_vertices.append(
                coordinates
            )

        # ------------------------------------------------------------------
        # Generic reconstruction
        # ------------------------------------------------------------------

        try:
            new_topology = Topology.ByGeometry(
                vertices=new_geometry_vertices,
                edges=geometry_edges,
                faces=geometry_faces,
                topologyType=rebuild_type,
                tolerance=tolerance,
                silent=True,
            )

        except TypeError:
            new_topology = Topology.ByGeometry(
                vertices=new_geometry_vertices,
                edges=geometry_edges,
                faces=geometry_faces,
                topologyType=rebuild_type,
            )

        except Exception as error:
            if not silent:
                print(
                    "Topology.ReplaceVertices - Error: Could not rebuild the topology. "
                    f"{error}. Returning None."
                )
            return None

        if not Topology.IsInstance(
            new_topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.ReplaceVertices - Error: Could not rebuild a valid "
                    "topology. Returning None."
                )
            return None

        if missing_count > 0 and not silent:
            print(
                "Topology.ReplaceVertices - Warning: "
                f"{missing_count} source vertices were not found in the input topology."
            )

        return preserve_dictionary(
            topology,
            new_topology
        )

    @staticmethod
    def Rotate(
        topology,
        origin=None,
        axis: list = [0, 0, 1],
        angle: float = 0,
        angTolerance: float = 0.001,
        transferDictionaries: bool = True,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Rotates the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        origin : topologic_core.Vertex , optional
            The origin (center) of the rotation. If set to None, the world
            origin (0, 0, 0) is used. Default is None.
        axis : list , optional
            The vector representing the axis of rotation. Default is
            [0, 0, 1], which equates to the Z axis.
        angle : float , optional
            The angle of rotation in degrees. Default is 0.
        angTolerance : float , optional
            The angle tolerance in degrees under which no rotation is carried
            out. Default is 0.001 degrees.
        transferDictionaries : bool , optional
            If set to True, dictionaries are transferred from the original
            topology to the rotated topology. Default is True.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Topology
            The rotated topology.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Dictionary import Dictionary

        def rotate_vertex_3d(
            vertex,
            axis,
            angle_degrees,
            origin
        ):
            """
            Rotates a coordinate around an arbitrary axis.

            This helper is retained solely for the legacy TopologicCore
            workaround.
            """
            vertex = np.array(
                vertex
            )

            axis = np.array(
                axis
            )

            origin = np.array(
                origin
            )

            angle_radians = np.radians(
                angle_degrees
            )

            axis = (
                np.array(axis)
                / np.linalg.norm(axis)
            )

            a = np.cos(
                angle_radians / 2
            )

            b, c, d = (
                -axis
                * np.sin(
                    angle_radians / 2
                )
            )

            rotation_matrix = np.array(
                [
                    [
                        a * a + b * b - c * c - d * d,
                        2 * (b * c - a * d),
                        2 * (b * d + a * c)
                    ],
                    [
                        2 * (b * c + a * d),
                        a * a - b * b + c * c - d * d,
                        2 * (c * d - a * b)
                    ],
                    [
                        2 * (b * d - a * c),
                        2 * (c * d + a * b),
                        a * a - b * b - c * c + d * d
                    ]
                ]
            )

            translated_vertex = (
                vertex
                - origin
            )

            rotated_vertex = (
                np.dot(
                    rotation_matrix,
                    translated_vertex
                )
                + origin
            )

            return [
                value
                for value in rotated_vertex
            ]

        # ------------------------------------------------------------------
        # Validate inputs
        # ------------------------------------------------------------------

        if not Topology.IsInstance(
            topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.Rotate - Error: The input topology parameter "
                    "is not a valid topologic topology. Returning None."
                )
            return None

        if not Topology.IsInstance(
            origin,
            "Vertex"
        ):
            origin = Vertex.ByCoordinates(
                0,
                0,
                0
            )

        if not Topology.IsInstance(
            origin,
            "Vertex"
        ):
            if not silent:
                print(
                    "Topology.Rotate - Error: The input origin parameter "
                    "is not a valid topologic vertex. Returning None."
                )
            return None

        try:
            x, y, z = axis

        except Exception:
            if not silent:
                print(
                    "Topology.Rotate - Error: The input axis parameter must "
                    "contain exactly three numeric values. Returning None."
                )
            return None

        return_topology = topology

        # ------------------------------------------------------------------
        # Rotation
        # ------------------------------------------------------------------

        if abs(angle) >= angTolerance:

            # --------------------------------------------------------------
            # Legacy TopologicCore
            #
            # TopologicCore rotation can fail for valid topology. Preserve
            # the historical manual vertex-rotation workaround only for this
            # backend.
            # --------------------------------------------------------------

            if Topology._IsTopologicCoreBackend():

                try:
                    return_topology = Core.TopologyUtility.Rotate(
                        topology,
                        origin,
                        x,
                        y,
                        z,
                        angle
                    )

                except Exception:
                    return_topology = None

                if not Topology.IsInstance(
                    return_topology,
                    "Topology"
                ):
                    if not silent:
                        print(
                            "Topology.Rotate - Warning: TopologicCore rotation "
                            "operation failed. Trying the legacy workaround."
                        )

                    vertices = [
                        Vertex.Coordinates(
                            vertex
                        )
                        for vertex in Topology.Vertices(
                            topology
                        )
                    ]

                    origin_coordinates = Vertex.Coordinates(
                        origin
                    )

                    rotated_vertices = []

                    for vertex in vertices:
                        rotated_vertices.append(
                            rotate_vertex_3d(
                                vertex,
                                axis,
                                angle,
                                origin_coordinates
                            )
                        )

                    rotated_vertices = [
                        Vertex.ByCoordinates(
                            rotated_vertex
                        )
                        for rotated_vertex in rotated_vertices
                    ]

                    return_topology = Topology.ReplaceVertices(
                        topology,
                        verticesA=Topology.Vertices(
                            topology
                        ),
                        verticesB=rotated_vertices
                    )

                    return_topology = Topology.SelfMerge(
                        return_topology,
                        tolerance=tolerance
                    )

            # --------------------------------------------------------------
            # Normal backend path
            #
            # Trust the backend. Do not reconstruct or SelfMerge a failed
            # result, because doing so would hide a backend defect.
            # --------------------------------------------------------------

            else:

                try:
                    return_topology = Core.TopologyUtility.Rotate(
                        topology,
                        origin,
                        x,
                        y,
                        z,
                        angle
                    )

                except Exception as error:
                    if not silent:
                        print(
                            "Topology.Rotate - Error: The active backend "
                            "rotation operation failed. Returning None."
                        )
                        print(
                            "Error:",
                            error
                        )
                    return None

                if not Topology.IsInstance(
                    return_topology,
                    "Topology"
                ):
                    if not silent:
                        print(
                            "Topology.Rotate - Error: The active backend "
                            "did not return a valid topology. Returning None."
                        )
                    return None

        # ------------------------------------------------------------------
        # Dictionary transfer
        # ------------------------------------------------------------------

        if transferDictionaries is True:
            d = Topology.Dictionary(
                topology
            )

            if len(
                Dictionary.Keys(
                    d
                )
            ) > 0:
                return_topology = Topology.SetDictionary(
                    return_topology,
                    d
                )

            vertices = Topology.Vertices(
                topology,
                silent=True
            )

            edges = Topology.Edges(
                topology,
                silent=True
            )

            wires = Topology.Wires(
                topology,
                silent=True
            )

            faces = Topology.Faces(
                topology,
                silent=True
            )

            shells = Topology.Shells(
                topology,
                silent=True
            )

            cells = Topology.Cells(
                topology,
                silent=True
            )

            cellComplexes = Topology.CellComplexes(
                topology,
                silent=True
            )

            r_vertices = Topology.Vertices(
                return_topology,
                silent=True
            )

            r_edges = Topology.Edges(
                return_topology,
                silent=True
            )

            r_wires = Topology.Wires(
                return_topology,
                silent=True
            )

            r_faces = Topology.Faces(
                return_topology,
                silent=True
            )

            r_shells = Topology.Shells(
                return_topology,
                silent=True
            )

            r_cells = Topology.Cells(
                return_topology,
                silent=True
            )

            r_cellComplexes = Topology.CellComplexes(
                return_topology,
                silent=True
            )

            for i, t in enumerate(
                r_vertices
            ):
                t = Topology.SetDictionary(
                    t,
                    Topology.Dictionary(
                        vertices[i]
                    ),
                    silent=True
                )

            for i, t in enumerate(
                r_edges
            ):
                t = Topology.SetDictionary(
                    t,
                    Topology.Dictionary(
                        edges[i]
                    ),
                    silent=True
                )

            for i, t in enumerate(
                r_wires
            ):
                t = Topology.SetDictionary(
                    t,
                    Topology.Dictionary(
                        wires[i]
                    ),
                    silent=True
                )

            for i, t in enumerate(
                r_faces
            ):
                t = Topology.SetDictionary(
                    t,
                    Topology.Dictionary(
                        faces[i]
                    ),
                    silent=True
                )

            for i, t in enumerate(
                r_shells
            ):
                t = Topology.SetDictionary(
                    t,
                    Topology.Dictionary(
                        shells[i]
                    ),
                    silent=True
                )

            for i, t in enumerate(
                r_cells
            ):
                t = Topology.SetDictionary(
                    t,
                    Topology.Dictionary(
                        cells[i]
                    ),
                    silent=True
                )

            for i, t in enumerate(
                r_cellComplexes
            ):
                t = Topology.SetDictionary(
                    t,
                    Topology.Dictionary(
                        cellComplexes[i]
                    ),
                    silent=True
                )

        return return_topology
    
    @staticmethod
    def RotateByEulerAngles(topology,
                            origin = None,
                            roll: float = 0,
                            pitch: float = 0,
                            yaw: float = 0,
                            transferDictionaries: bool = True,
                            angTolerance: float = 0.001,
                            tolerance: float = 0.0001,
                            silent: bool = False):
        """
        Rotates the input topology using Euler angles (roll, pitch, yaw). See https://en.wikipedia.org/wiki/Aircraft_principal_axes

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        origin : topologic_core.Vertex , optional
            The origin (center) of the rotation. If set to None, the world origin (0, 0, 0) is used. Default is None.
        roll : float , optional
            The rotation angle in degrees around the X-axis. Default is 0.
        pitch = float , optional
            The rotation angle in degrees around the Y-axis. Default is 0.
        yaw = float , optional
            The rotation angle in degrees around the Z-axis. Default is 0.
        transferDictionaries : bool , optional
            If set to True, the dictionaries are transfered from the original object to the rotated object. Default is True.
        angTolerance : float , optional
            The angle tolerance in degrees under which no rotation is carried out. Default is 0.001 degrees.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The rotated topology.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Dictionary import Dictionary

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.RotateByEulerAngles - Error: The input topology parameter is not a valid topologic topology. Returning None.")
            return None
        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)
        if not Topology.IsInstance(origin, "Vertex"):
            if not silent:
                print("Topology.RotateByEulerAngles - Error: The input origin parameter is not a valid topologic vertex. Returning None.")
            return None
        return_topology = Topology.Copy(topology)
        return_topology = Topology.Rotate(return_topology, origin=origin, axis=[1,0,0], angle=roll, transferDictionaries=transferDictionaries, angTolerance=angTolerance, tolerance=tolerance, silent=silent)
        return_topology = Topology.Rotate(return_topology, origin=origin, axis=[0,1,0], angle=pitch, transferDictionaries=transferDictionaries, angTolerance=angTolerance, tolerance=tolerance, silent=silent)
        return_topology = Topology.Rotate(return_topology, origin=origin, axis=[0,0,1], angle=yaw, transferDictionaries=transferDictionaries, angTolerance=angTolerance, tolerance=tolerance, silent=silent)
        return return_topology
    
    @staticmethod
    def RotateByQuaternion(topology,
                           origin=None,
                           quaternion: list = [0,0,0,1],
                           transferDictionaries: bool = False,
                           angTolerance: float = 0.001,
                           tolerance: float = 0.0001,
                           silent: bool = False):
        """
        Rotates the input topology using Quaternion rotations. See https://en.wikipedia.org/wiki/Quaternion
        
        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        origin : topologic_core.Vertex , optional
            The origin (center) of the rotation. If set to None, the world origin (0, 0, 0) is used. Default is None.
        quaternion : list or numpy array of size 4
            The input Quaternion list. It should be in the form [x, y, z, w].
        transferDictionaries : bool , optional
            If set to True, the dictionaries are transfered from the original object to the rotated object. Default is True.
        angTolerance : float , optional
            The angle tolerance in degrees under which no rotation is carried out. Default is 0.001 degrees.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The rotated topology.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Dictionary import Dictionary

        def quaternion_to_euler(quaternion):
            """
            Convert a quaternion into Euler angles (roll, pitch, yaw)
            Roll is rotation around x-axis, Pitch is rotation around y-axis, and Yaw is rotation around z-axis.
            Quaternion should be in the form [x, y, z, w]

            Args:
            quaternion: list or numpy array of size 4

            Returns:
            A list of Euler angles in degrees [roll, pitch, yaw]
            """
            import numpy as np
            x, y, z, w = quaternion

            # Roll (x-axis rotation)
            sinr_cosp = 2 * (w * x + y * z)
            cosr_cosp = 1 - 2 * (x * x + y * y)
            roll = np.arctan2(sinr_cosp, cosr_cosp)

            # Pitch (y-axis rotation)
            sinp = 2 * (w * y - z * x)
            if abs(sinp) >= 1:
                pitch = np.sign(sinp) * np.pi / 2  # use 90 degrees if out of range
            else:
                pitch = np.arcsin(sinp)

            # Yaw (z-axis rotation)
            siny_cosp = 2 * (w * z + x * y)
            cosy_cosp = 1 - 2 * (y * y + z * z)
            yaw = np.arctan2(siny_cosp, cosy_cosp)

            # Convert radians to degrees
            roll = np.degrees(roll)
            pitch = np.degrees(pitch)
            yaw = np.degrees(yaw)
            return [roll, pitch, yaw]
        
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.RotateByQuaternion - Error: The input topology parameter is not a valid topologic topology. Returning None.", topology)
            return None
        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)
        if not Topology.IsInstance(origin, "Vertex"):
            if not silent:
                print("Topology.RotateByQuaternion - Error: The input origin parameter is not a valid topologic vertex. Returning None.")
            return None
        roll, pitch, yaw = quaternion_to_euler(quaternion)
        return_topology = Topology.RotateByEulerAngles(topology=topology, origin=origin, roll=roll, pitch=pitch, yaw=yaw,  transferDictionaries=transferDictionaries, angTolerance=angTolerance, tolerance=tolerance, silent=silent)
        return return_topology
    
    @staticmethod
    def Scale(topology, origin=None, x=1, y=1, z=1, transferDictionaries: bool = True, silent: bool = False):
        """
        Scales the input topology

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        origin : topologic_core.Vertex , optional
            The origin (center) of the scaling. If set to None, the world origin (0, 0, 0) is used. Default is None.
        x : float , optional
            The 'x' component of the scaling factor. Default is 1.
        y : float , optional
            The 'y' component of the scaling factor. Default is 1.
        z : float , optional
            The 'z' component of the scaling factor. Default is 1..

        Returns
        -------
        topologic_core.Topology
            The scaled topology.

        """
        
        from topologicpy.Vertex import Vertex

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Scale - Error: The input topology parameter is not a valid Topology. Returning None.")
            return None
        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)
        if not Topology.IsInstance(origin, "Vertex"):
            if not silent:
                print("Topology.Scale - Error: The input origin parameter is not a valid Vertex. Returning None.")
            return None
        if abs(x) <= 0.00001:
            if not silent:
                print("Topology.Scale - Warning: the x input parameter is close to 0. This can cause an malformed geometric result.")
        if abs(y) <= 0.00001:
            if not silent:
                print("Topology.Scale - Warning: the y input parameter is close to 0. This can cause an malformed geometric result.")
        if abs(z) <= 0.00001:
            if not silent:
                print("Topology.Scale - Warning: the z input parameter is close to 0. This can cause an malformed geometric result.")
        return_topology = None
        try:
            return_topology = Core.TopologyUtility.Scale(topology, origin, x, y, z)
        except:
            if not silent:
                print("Topology.Scale - Error: Core scale operation failed. Returning None.")
            return_topology = None
        
        if transferDictionaries == True:
            vertices = Topology.Vertices(topology, silent=True)
            edges = Topology.Edges(topology, silent=True)
            wires = Topology.Wires(topology, silent=True)
            faces = Topology.Faces(topology, silent=True)
            shells = Topology.Shells(topology, silent=True)
            cells = Topology.Cells(topology, silent=True)
            cellComplexes = Topology.CellComplexes(topology, silent=True)
            
            r_vertices = Topology.Vertices(return_topology, silent=True)
            r_edges = Topology.Edges(return_topology, silent=True)
            r_wires = Topology.Wires(return_topology, silent=True)
            r_faces = Topology.Faces(return_topology, silent=True)
            r_shells = Topology.Shells(return_topology, silent=True)
            r_cells = Topology.Cells(return_topology, silent=True)
            r_cellComplexes = Topology.CellComplexes(return_topology, silent=True)

            for i, t in enumerate(r_vertices):
                t = Topology.SetDictionary(t, Topology.Dictionary(vertices[i]), silent=True)
            for i, t in enumerate(r_edges):
                t = Topology.SetDictionary(t, Topology.Dictionary(edges[i]), silent=True)
            for i, t in enumerate(r_wires):
                t = Topology.SetDictionary(t, Topology.Dictionary(wires[i]), silent=True)
            for i, t in enumerate(r_faces):
                t = Topology.SetDictionary(t, Topology.Dictionary(faces[i]), silent=True)
            for i, t in enumerate(r_shells):
                t = Topology.SetDictionary(t, Topology.Dictionary(shells[i]), silent=True)
            for i, t in enumerate(r_cells):
                t = Topology.SetDictionary(t, Topology.Dictionary(cells[i]), silent=True)
            for i, t in enumerate(r_cellComplexes):
                t = Topology.SetDictionary(t, Topology.Dictionary(cellComplexes[i]), silent=True)
            return return_topology
        return return_topology

    
    @staticmethod
    def SelectSubTopology(topology, selector, subTopologyType: str = "vertex", silent: bool = False):
        """
        Returns the subtopology within the input topology based on the input selector and the subTopologyType.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        selector : topologic_core.Vertex
            A vertex located on the desired subtopology.
        subTopologyType : str , optional.
            The desired subtopology type. This can be of "vertex", "edge", "wire", "face", "shell", "cell", or "cellcomplex". It is case insensitive. Default is "vertex".
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The selected subtopology.

        """
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.SelectSubTopology - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(selector, "Vertex"):
            if not silent:
                print("Topology.SelectSubtopology - Error: The input selector parameter is not a valid vertex. Returning None.")
            return None
        t = 1
        if subTopologyType.lower() == "vertex":
            t = 1
        elif subTopologyType.lower() == "edge":
            t = 2
        elif subTopologyType.lower() == "wire":
            t = 4
        elif subTopologyType.lower() == "face":
            t = 8
        elif subTopologyType.lower() == "shell":
            t = 16
        elif subTopologyType.lower() == "cell":
            t = 32
        elif subTopologyType.lower() == "cellcomplex":
            t = 64
        # return topology.SelectSubtopology(selector, t) # H to Core
        return Core.InstanceCall(topology, 'SelectSubtopology', selector, t)


    @staticmethod
    def SelfMerge(topology,
                  transferDictionaries: bool = False,
                  ontology: bool = False,
                  tolerance: float = 0.0001,
                  silent: bool = False):
        """
        Self merges the input topology to return the most logical topology type
        given the input data.

        This version uses a fast progressive singleton test before falling back to
        the expensive core SelfMerge operation.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        transferDictionaries : bool , optional
            If set to True, the dictionary of the input Cluster is transferred to
            the returned singleton candidate when applicable. Default is False.
        ontology : bool , optional
            If True, the returned topology is annotated with TopologicPy ontology metadata. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The self-merged topology.
        """

        from topologicpy.Cluster import Cluster

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.SelfMerge - Error: The input topology is not a valid topology. Returning None")
            return None

        # Non-cluster topologies are already single logical topologies.
        if not Topology.IsInstance(topology, "Cluster"):
            return Topology._OntologyAnnotate(topology, ontology=ontology, generatedBy="Topology.SelfMerge", annotateSubtopologies=True, silent=True)

        def _len_items(func, t):
            try:
                items = func(t, silent=True)
                if isinstance(items, list):
                    return len(items), items
                return 0, []
            except Exception:
                return 0, []

        def _vertices(t):
            return Topology._OntologyAnnotate(Topology.Vertices(t, silent=True), ontology=ontology, generatedBy="Topology.SelfMerge", annotateSubtopologies=True, silent=True)

        # ------------------------------------------------------------------
        # 1. Fastest possible direct-child test.
        # ------------------------------------------------------------------
        # If Cluster.Topologies returns direct children and there is exactly one,
        # we can unwrap immediately without scanning all subtopologies.
        # try:
        #     children = Cluster.Topologies(topology)
        #     if isinstance(children, list) and len(children) == 1:
        #         child = children[0]
        #         if Topology.IsInstance(child, "Topology"):
        #             if transferDictionaries:
        #                 try:
        #                     d = Topology.Dictionary(topology)
        #                     if d:
        #                         child = Topology.SetDictionary(child, d)
        #                 except Exception:
        #                     pass
        #             return child
        # except Exception:
        #     pass

        # ------------------------------------------------------------------
        # 2. Progressive singleton test.
        # ------------------------------------------------------------------
        # Find the highest-dimensional candidate. Then compare the candidate and
        # the cluster progressively. Stop as soon as a count differs.
        #
        # This is cheaper than computing a complete count signature for both.
        # ------------------------------------------------------------------

        levels = [
            ("CellComplex", Topology.CellComplexes),
            ("Cell",        Topology.Cells),
            ("Shell",       Topology.Shells),
            ("Face",        Topology.Faces),
            ("Wire",        Topology.Wires),
            ("Edge",        Topology.Edges),
            ("Vertex",      _vertices),
        ]

        candidate = None
        candidate_level_index = None

        for i, (_, extractor) in enumerate(levels):
            n, items = _len_items(extractor, topology)

            if n == 0:
                continue

            if n > 1:
                candidate = None
                break

            candidate = items[0]
            candidate_level_index = i
            break

        if Topology.IsInstance(candidate, "Topology"):
            is_singleton = True

            # Compare only from the candidate's own level downward.
            # For example, if the candidate is a Cell, do not compare CellComplexes.
            for _, extractor in levels[candidate_level_index:]:
                n_cluster, _ = _len_items(extractor, topology)
                n_candidate, _ = _len_items(extractor, candidate)

                if n_cluster != n_candidate:
                    is_singleton = False
                    break

            if is_singleton:
                if transferDictionaries:
                    try:
                        d = Topology.Dictionary(topology)
                        if d:
                            candidate = Topology.SetDictionary(candidate, d)
                    except Exception:
                        pass
                return candidate

        # ------------------------------------------------------------------
        # 3. Expensive fallback.
        # ------------------------------------------------------------------

        try:
            # return_topology = topology.SelfMerge() # H to Core
            return_topology = Core.InstanceCall(topology, 'SelfMerge')
        except Exception:
            return_topology = None

        if not Topology.IsInstance(return_topology, "Topology"):
            return None

        # ------------------------------------------------------------------
        # 4. Minimal post-simplification only.
        # ------------------------------------------------------------------
        # Avoid Topology.Merge(cells[0], Cluster.ByTopologies(cells[1:])) here.
        # That previous behaviour can be very expensive and should not be part of
        # the fast SelfMerge path.
        # ------------------------------------------------------------------

        try:
            if Topology.IsInstance(return_topology, "CellComplex"):
                cells = Topology.Cells(return_topology)
                if isinstance(cells, list) and len(cells) == 1:
                    return cells[0]
            if Topology.IsInstance(return_topology, "Shell"):
                faces = Topology.Faces(return_topology)
                if isinstance(faces, list) and len(faces) == 1:
                    return faces[0]
            if Topology.IsInstance(return_topology, "Wire"):
                edges = Topology.Edges(return_topology)
                if isinstance(edges, list) and len(edges) == 1:
                    return edges[0]
        except Exception:
            pass

        return Topology._OntologyAnnotate(return_topology, ontology=ontology, generatedBy="Topology.SelfMerge", annotateSubtopologies=True, silent=True)
    
    @staticmethod
    def SetDictionary(topology, dictionary, silent: biool = False):
        """
        Sets the input topology's dictionary to the input dictionary.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph, topologicpy.TGraph, dict
            The input topology, graph, TGraph, TGraph vertex record, or TGraph edge record.
        dictionary : topologic_core.Dictionary or dict
            The input dictionary.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology, topologic_core.Graph, topologicpy.TGraph, dict, or None
            The input object with the input dictionary set in it.

        """

        from topologicpy.Dictionary import Dictionary
        import inspect

        def _caller():
            try:
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print("caller name:", calframe[1][3])
            except Exception:
                pass

        def _is_tgraph_vertex_record(obj):
            if not isinstance(obj, dict):
                return False
            if "dictionary" not in obj or not isinstance(obj.get("dictionary"), dict):
                return False
            if "src" in obj and "dst" in obj:
                return False
            return "index" in obj

        def _is_tgraph_edge_record(obj):
            if not isinstance(obj, dict):
                return False
            if "dictionary" not in obj or not isinstance(obj.get("dictionary"), dict):
                return False
            return "index" in obj and "src" in obj and "dst" in obj

        def _dictionary_to_python(d):
            if isinstance(d, dict):
                return dict(d)

            try:
                from topologicpy.TGraph import TGraph
                py_dict = TGraph._DictionaryToPython(d)
                if isinstance(py_dict, dict):
                    return py_dict
            except Exception:
                pass

            try:
                py_dict = Dictionary.PythonDictionary(d)
                if isinstance(py_dict, dict):
                    return py_dict
            except Exception:
                pass

            try:
                keys = Dictionary.Keys(d)
                if isinstance(keys, list):
                    return {k: Dictionary.ValueAtKey(d, k, None) for k in keys}
            except TypeError:
                try:
                    keys = Dictionary.Keys(d)
                    if isinstance(keys, list):
                        return {k: Dictionary.ValueAtKey(d, k) for k in keys}
                except Exception:
                    pass
            except Exception:
                pass

            return None

        py_dict = _dictionary_to_python(dictionary)

        if not isinstance(py_dict, dict):
            if not silent:
                print("Topology.SetDictionary - Warning: the input dictionary parameter is not a valid dictionary. Returning original input.")
                _caller()
            return topology

        # ---------------------------------------------------------------------
        # TGraph object.
        # ---------------------------------------------------------------------

        is_tgraph = False
        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            is_tgraph = False

        if is_tgraph:
            try:
                topology.SetDictionary(py_dict)
            except Exception:
                try:
                    topology._dictionary = dict(py_dict)
                    topology._invalidate_cache()
                except Exception:
                    if not silent:
                        print("Topology.SetDictionary - Error: Could not set the dictionary of the input TGraph. Returning original input.")
                        _caller()
            return topology

        # ---------------------------------------------------------------------
        # TGraph vertex or edge record.
        # ---------------------------------------------------------------------

        if _is_tgraph_vertex_record(topology) or _is_tgraph_edge_record(topology):
            topology["dictionary"] = dict(py_dict)

            # Preserve TGraph structural metadata inside the dictionary for consistency
            # with records created by TGraph.AddVertex and TGraph.AddEdge.
            if "index" in topology:
                topology["dictionary"].setdefault("index", topology.get("index"))

            if "active" in topology:
                topology["dictionary"].setdefault("active", topology.get("active", True))

            if _is_tgraph_edge_record(topology):
                # Preserve legacy structural keys for backwards compatibility,
                # and also expose the canonical _005 aliases used by the
                # ontology/RDF layer. Ontology_005 filters active/directed and
                # maps src/dst to top:srcId/top:dstId when exported.
                topology["dictionary"].setdefault("src", topology.get("src"))
                topology["dictionary"].setdefault("dst", topology.get("dst"))
                topology["dictionary"].setdefault("srcId", topology.get("src"))
                topology["dictionary"].setdefault("dstId", topology.get("dst"))
                topology["dictionary"].setdefault("directed", topology.get("directed", False))

            return topology

        # ---------------------------------------------------------------------
        # Topologic topology or graph.
        # ---------------------------------------------------------------------

        if not Topology.IsInstance(topology, "Topology") and not Topology.IsInstance(topology, "Graph"):
            if not silent:
                print("Topology.SetDictionary - Error: the input topology parameter is not a valid topology, graph, TGraph, TGraph vertex, or TGraph edge. Returning None.")
                _caller()
            return None

        if isinstance(dictionary, dict):
            dictionary = Dictionary.ByPythonDictionary(dictionary)

        if not Topology.IsInstance(dictionary, "Dictionary"):
            if not silent:
                print("Topology.SetDictionary - Warning: the input dictionary parameter is not a valid dictionary. Returning original input.")
                _caller()
            return topology

        _ = Core.InstanceCall(topology, "SetDictionary", dictionary)
        return topology
    
    @staticmethod
    def SetSnapshot(topology, snapshot=None, timestamp=None, key: str = "timestamp", silent: bool = False):
        """
        Sets a date/time stamped snapshot and stores it in the input topology's content system.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology
        snapshot : topologic_core.Topology
            The snapshot topology to be stored.
        timestamp : datetime
            The date/time stamp to store in the snapshot's dictionary
        key : str, optional
            The dictionary key under which to store the timestamp.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The input topology with the snapshot stored in it.

        """
        from topologicpy.Dictionary import Dictionary
        from datetime import datetime
        def is_valid_timestamp(timestamp):
            if isinstance(timestamp, datetime):
                return True
            elif isinstance(timestamp, str):
                try:
                    # Split the timestamp string into date and time parts
                    date_part, time_part = timestamp.split(' ')
                    # Parse the date part
                    date_obj = datetime.strptime(date_part, '%Y-%m-%d')
                    # Split the time part into hours, minutes, and seconds
                    hours, minutes, seconds = map(float, time_part.split(':'))
                    # Check if seconds are within valid range
                    if seconds < 0 or seconds >= 60:
                        return False
                    # Create a datetime object with the parsed date and time parts
                    datetime_obj = datetime(date_obj.year, date_obj.month, date_obj.day, int(hours), int(minutes), int(seconds))
                    return True
                except ValueError:
                    return False
            else:
                return False

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.SetSnapshot - Error: The input topology parameter is not a valid topology. Returning None.")
                return None
        if not Topology.IsInstance(snapshot, "Topology"):
            snapshot = Topology.Copy(topology)
        if not Topology.IsInstance(snapshot, "Topology"):
            if not silent:
                print("Topology.SetSnapshot - Error: The input snapshot parameter is not a valid topology. Returning None.")
                return None
        if timestamp == None:
            timestamp = datetime.now()
        if not is_valid_timestamp(timestamp):
            if not silent:
                print("Topology.SetSnapshot - Error: The input timestamp parameter is not a valid timestamp. Returning None.")
                return None
        
        d = Topology.Dictionary(snapshot)
        d = Dictionary.SetValueAtKey(d, key, str(timestamp))
        snapshot = Topology.SetDictionary(snapshot, d)
        topology = Topology.AddContent(topology, snapshot)
        return topology
    
    @staticmethod
    def SharedTopologies(topologyA, topologyB, silent: bool = False):
        """
        Returns the shared topologies between the two input topologies

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        dict
            A dictionary with the list of vertices, edges, wires, and faces. The keys are "vertices", "edges", "wires", and "faces".

        """
        if not Topology.IsInstance(topologyA, "Topology"):
            if not silent:
                print("Topology.SharedTopologies - Error: the input topologyA parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(topologyB, "Topology"):
            if not silent:
                print("Topology.SharedTopologies - Error: the input topologyB parameter is not a valid topology. Returning None.")
            return None
        vOutput = []
        eOutput = []
        wOutput = []
        fOutput = []
        # _ = topologyA.SharedTopologies(topologyB, 1, vOutput) # H to Core
        _ = Core.InstanceCall(topologyA, 'SharedTopologies', topologyB, 1, vOutput)
        # _ = topologyA.SharedTopologies(topologyB, 2, eOutput) # H to Core
        _ = Core.InstanceCall(topologyA, 'SharedTopologies', topologyB, 2, eOutput)
        # _ = topologyA.SharedTopologies(topologyB, 4, wOutput) # H to Core
        _ = Core.InstanceCall(topologyA, 'SharedTopologies', topologyB, 4, wOutput)
        # _ = topologyA.SharedTopologies(topologyB, 8, fOutput) # H to Core
        _ = Core.InstanceCall(topologyA, 'SharedTopologies', topologyB, 8, fOutput)
        return {"vertices":vOutput, "edges":eOutput, "wires":wOutput, "faces":fOutput}

    @staticmethod
    def SharedVertices(topologyA, topologyB, silent: bool = False):
        """
        Returns the shared vertices between the two input topologies

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of shared vertices.

        """
        if not Topology.IsInstance(topologyA, "Topology"):
            if not silent:
                print("Topology.SharedVertices - Error: the input topologyA parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(topologyB, "Topology"):
            if not silent:
                print("Topology.SharedVertices - Error: the input topologyB parameter is not a valid topology. Returning None.")
            return None
        
        vOutput = []
        _ = Core.InstanceCall(topologyA, 'SharedTopologies', topologyB, 1, vOutput)
        return vOutput
    
    
    @staticmethod
    def SharedEdges(topologyA, topologyB, silent: bool = False):
        """
        Returns the shared edges between the two input topologies

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.

        Returns
        -------
        list
            The list of shared edges.

        """
        if not Topology.IsInstance(topologyA, "Topology"):
            if not silent:
                print("Topology.SharedEdges - Error: the input topologyA parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(topologyB, "Topology"):
            if not silent:
                print("Topology.SharedEdges - Error: the input topologyB parameter is not a valid topology. Returning None.")
            return None
        eOutput = []
        _ = Core.InstanceCall(topologyA, 'SharedTopologies', topologyB, 2, eOutput)
        return eOutput
    
    @staticmethod
    def SharedWires(topologyA, topologyB, silent: bool = False):
        """
        Returns the shared wires between the two input topologies

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.

        Returns
        -------
        list
            The list of shared wires.

        """
        if not Topology.IsInstance(topologyA, "Topology"):
            if not silent:
                print("Topology.SharedWires - Error: the input topologyA parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(topologyB, "Topology"):
            if not silent:
                print("Topology.SharedWires - Error: the input topologyB parameter is not a valid topology. Returning None.")
            return None
        wOutput = []
        _ = Core.InstanceCall(topologyA, 'SharedTopologies', topologyB, 4, wOutput)
        return wOutput
    
    @staticmethod
    def SharedFaces(topologyA, topologyB, silent: bool = False):
        """
        Returns the shared faces between the two input topologies

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.

        Returns
        -------
        list
            The list of shared faces.

        """
        if not Topology.IsInstance(topologyA, "Topology"):
            if not silent:
                print("Topology.SharedFaces - Error: the input topologyA parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(topologyB, "Topology"):
            if not silent:
                print("Topology.SharedFaces - Error: the input topologyB parameter is not a valid topology. Returning None.")
            return None
        fOutput = []
        _ = Core.InstanceCall(topologyA, 'SharedTopologies', topologyB, 8, fOutput)
        return fOutput

    @staticmethod
    def Shells(topology, silent: bool = False):
        """
        Returns the shells of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of shells.

        """

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Shells - Error: The input is not a valid topology. Returning None")
            return None
        
        if Topology.IsInstance(topology, "Shell"):
            if not silent:
                print("Topology.Shells - Warning: The input is a Shell. Returning the same shell embedded in a list.")
            return [topology]
        
        if Topology.IsInstance(topology, "Face") or Topology.IsInstance(topology, "Wire") or Topology.IsInstance(topology, "Edge") or Topology.IsInstance(topology, "Vertex"):
            if not silent:
                print("Topology.Shells - Warning: The input is a lower dimension than a shell. Returning an empty list.")
            return []
        
        return Topology.SubTopologies(topology=topology, subTopologyType="shell", silent=silent)

    @staticmethod
    def ShortestEdge(topologyA,
                     topologyB,
                     tolerance: float = 0.0001,
                     silent: bool = False):
        """
        Returns the shortest connecting Edge between two topologies.

        This method deterministically finds the pair of closest points between
        topologyA and topologyB by examining their sub-topologies (vertices,
        edges, and faces). It then returns a new Edge whose endpoints lie at
        these two closest points.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tolerance : float , optional
            Numerical tolerance for detecting near-zero distances and
            degeneracies. Default is 1e-6.
        silent : bool , optional
            If True, the method will not print warnings. Default is False.

        Returns
        -------
        topologic_core.Edge or None
            A new Edge whose start and end vertices represent the closest points
            on topologyA and topologyB, respectively. Returns None if a valid
            distance cannot be computed.

        Notes
        -----
        - Sub-topologies are collected using:
            * Topology.Vertices(topology)
            * Topology.Edges(topology)
            * Topology.Faces(topology)
        - The returned Edge is not required to belong to either original
            topology; it is a geometric representation of the shortest segment.
        - If the shortest distance is (numerically) zero, the start and end
            vertices of the returned Edge will coincide (or be extremely close).
        """

        if not Topology.IsInstance(topologyA, "topology"):
            if not silent:
                print("Topology.ShortestEdge - Error: The input topologyA parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(topologyB, "topology"):
            if not silent:
                print("Topology.ShortestEdge - Error: The input topologyB parameter is not a valid topology. Returning None.")
            return None

        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        import math
        from math import sqrt, isfinite


        # ------------------------------------------------------------------
        # Helper functions – pure geometry (no Topologic dependencies)
        # ------------------------------------------------------------------
        def _coords(vertex):
            return Vertex.Coordinates(vertex)  # [x, y, z]

        def _sub(a, b):
            return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]

        def _add(a, b):
            return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]

        def _dot(a, b):
            return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]

        def _cross(a, b):
            return [
                a[1]*b[2] - a[2]*b[1],
                a[2]*b[0] - a[0]*b[2],
                a[0]*b[1] - a[1]*b[0]
            ]

        def _scale(a, s):
            return [a[0]*s, a[1]*s, a[2]*s]

        def _length2(a):
            return _dot(a, a)

        def _length(a):
            return math.sqrt(_length2(a))

        def _normalize(a):
            l2 = _length2(a)
            if l2 <= tolerance*tolerance:
                return [0.0, 0.0, 0.0]
            inv = 1.0 / math.sqrt(l2)
            return [a[0]*inv, a[1]*inv, a[2]*inv]

        # Closest point on segment AB to point P
        def _closest_point_on_segment(P, A, B):
            AB = _sub(B, A)
            AB2 = _length2(AB)
            if AB2 <= tolerance*tolerance:
                return A, 0.0
            t = _dot(_sub(P, A), AB) / AB2
            if t < 0.0:
                t = 0.0
            elif t > 1.0:
                t = 1.0
            Q = _add(A, _scale(AB, t))
            return Q, t

        # Point–segment distance^2
        def _point_segment_distance2(P, A, B):
            Q, _t = _closest_point_on_segment(P, A, B)
            return _length2(_sub(P, Q)), Q

        # Segment–segment distance^2
        def _segment_segment_distance2(A0, A1, B0, B1):
            SMALL_NUM = tolerance

            u = _sub(A1, A0)
            v = _sub(B1, B0)
            w0 = _sub(A0, B0)

            a = _dot(u, u)
            b = _dot(u, v)
            c = _dot(v, v)
            d = _dot(u, w0)
            e = _dot(v, w0)

            denom = a*c - b*b

            if denom < SMALL_NUM:
                # Lines almost parallel
                s = 0.0
                t = e / c if c > SMALL_NUM else 0.0
                t = max(0.0, min(1.0, t))
            else:
                s = (b*e - c*d) / denom
                s = max(0.0, min(1.0, s))
                t = (a*e - b*d) / denom
                if t < 0.0:
                    t = 0.0
                    s = max(0.0, min(1.0, -d / a if a > SMALL_NUM else 0.0))
                elif t > 1.0:
                    t = 1.0
                    s = max(0.0, min(1.0, (b - d) / a if a > SMALL_NUM else 0.0))

            P_closest = _add(A0, _scale(u, s))
            Q_closest = _add(B0, _scale(v, t))
            diff = _sub(P_closest, Q_closest)
            return _length2(diff), P_closest, Q_closest

        # Build local frame for a face
        def _face_frame(face):
            wire = Face.ExternalBoundary(face)
            verts = Wire.Vertices(wire)
            if len(verts) < 3:
                return None, None, None, None

            p0 = _coords(verts[0])
            p1 = _coords(verts[1])
            p2 = None
            for v in verts[2:]:
                cand = _coords(v)
                if _length(_cross(_sub(p1, p0), _sub(cand, p0))) > tolerance:
                    p2 = cand
                    break
            if p2 is None:
                return None, None, None, None

            u = _normalize(_sub(p1, p0))
            n = _normalize(_cross(_sub(p1, p0), _sub(p2, p0)))
            v = _cross(n, u)
            return p0, u, v, n

        def _project_to_face_2d(P, origin, u, v):
            PO = _sub(P, origin)
            return [_dot(PO, u), _dot(PO, v)]

        # 2D point-in-polygon
        def _point_in_polygon_2d(pt, poly2d):
            x, y = pt
            inside = False
            n = len(poly2d)
            if n < 3:
                return False
            j = n - 1
            for i in range(n):
                xi, yi = poly2d[i]
                xj, yj = poly2d[j]
                denom = (yj - yi) if (yj - yi) != 0 else 1e-16
                intersect = ((yi > y) != (yj > y)) and \
                            (x < (xj - xi) * (y - yi) / denom + xi)
                if intersect:
                    inside = not inside
                j = i
            return inside

        # Point–face distance^2
        def _point_face_distance2(P, face):
            origin, u, v, n = _face_frame(face)
            if origin is None:
                # Degenerate – fallback to vertices only
                wire = Face.ExternalBoundary(face)
                verts = Wire.Vertices(wire)
                min_d2_local = float("inf")
                best_q = None
                for vv in verts:
                    Q = _coords(vv)
                    d2 = _length2(_sub(P, Q))
                    if d2 < min_d2_local:
                        min_d2_local = d2
                        best_q = Q
                return min_d2_local, best_q

            wire = Face.ExternalBoundary(face)
            verts = Wire.Vertices(wire)
            poly2d = []
            for vtx in verts:
                poly2d.append(_project_to_face_2d(_coords(vtx), origin, u, v))

            PO = _sub(P, origin)
            dist_n = _dot(PO, n)
            P_plane = _sub(P, _scale(n, dist_n))
            P2d = _project_to_face_2d(P_plane, origin, u, v)

            if _point_in_polygon_2d(P2d, poly2d):
                return dist_n*dist_n, P_plane

            # Else min over polygon edges
            min_d2 = float("inf")
            best_q = None
            nverts = len(verts)
            for i in range(nverts):
                A = _coords(verts[i])
                B = _coords(verts[(i+1) % nverts])
                d2, Q = _point_segment_distance2(P, A, B)
                if d2 < min_d2:
                    min_d2 = d2
                    best_q = Q
            return min_d2, best_q

        # ------------------------------------------------------------------
        # Collect primitives
        # ------------------------------------------------------------------
        try:
            verticesA = Topology.Vertices(topologyA, silent=True) or []
        except Exception:
            verticesA = []

        try:
            verticesB = Topology.Vertices(topologyB, silent=True) or []
        except Exception:
            verticesB = []

        try:
            edgesA = Topology.Edges(topologyA, silent=True) or []
        except Exception:
            edgesA = []

        try:
            edgesB = Topology.Edges(topologyB, silent=True) or []
        except Exception:
            edgesB = []

        try:
            facesA = Topology.Faces(topologyA, silent=True) or []
        except Exception:
            facesA = []

        try:
            facesB = Topology.Faces(topologyB, silent=True) or []
        except Exception:
            facesB = []

        if (not verticesA and not edgesA and not facesA) or \
            (not verticesB and not edgesB and not facesB):
            if not silent:
                print("[Topology.ShortestEdge] One of the topologies has no "
                        "vertices, edges, or faces – returning None.")
            return None

        # ------------------------------------------------------------------
        # Main search
        # ------------------------------------------------------------------
        min_d2 = float("inf")
        bestP = None
        bestQ = None

        # 1. Vertex–vertex (full, usually cheap)
        for va in verticesA:
            pa = _coords(va)
            for vb in verticesB:
                pb = _coords(vb)
                d2 = _length2(_sub(pa, pb))
                # Skip self-coincident pairs (same vertex shared by both
                # topologies) so the true shortest connecting edge between
                # distinct vertices is found, not a degenerate zero-length one.
                if d2 <= tolerance*tolerance:
                    continue
                if d2 < min_d2:
                    min_d2 = d2
                    bestP = pa
                    bestQ = pb
            # (no early break here)

        if min_d2 <= tolerance*tolerance:
            vA = Vertex.ByCoordinates(bestP[0], bestP[1], bestP[2])
            vB = Vertex.ByCoordinates(bestQ[0], bestQ[1], bestQ[2])
            if Vertex.Distance(vA, vB) <= tolerance:
                if not silent:
                    print("Topology.ShortestEdge - Error: The input topologies touch. Therefore the shortest edge degenerated into a vertex. Returning None.")
                return None
            return Edge.ByStartVertexEndVertex(vA, vB)

        # 2. Vertex–edge (both directions), exhaustive
        def _vertex_edge_pass(vertices, edges, reverse=False):
            nonlocal min_d2, bestP, bestQ
            for v in vertices:
                pv = _coords(v)
                for e in edges:
                    s = Edge.StartVertex(e)
                    t = Edge.EndVertex(e)
                    ps = _coords(s)
                    pt = _coords(t)
                    d2, Q = _point_segment_distance2(pv, ps, pt)
                    if d2 < min_d2:
                        min_d2 = d2
                        if reverse:
                            bestP = Q
                            bestQ = pv
                        else:
                            bestP = pv
                            bestQ = Q
                        if min_d2 <= tolerance*tolerance:
                            return

        _vertex_edge_pass(verticesA, edgesB, reverse=False)
        if min_d2 > tolerance*tolerance:
            _vertex_edge_pass(verticesB, edgesA, reverse=True)

        if min_d2 <= tolerance*tolerance:
            vA = Vertex.ByCoordinates(bestP[0], bestP[1], bestP[2])
            vB = Vertex.ByCoordinates(bestQ[0], bestQ[1], bestQ[2])
            if Vertex.Distance(vA, vB) <= tolerance:
                if not silent:
                    print("Topology.ShortestEdge - Error: The input topologies touch. Therefore the shortest edge degenerated into a vertex. Returning None.")
                return None
            return Edge.ByStartVertexEndVertex(vA, vB)

        # 3. Edge–edge
        #    If BVHs are available and you want, you can use them here to
        #    restrict candidate pairs. For now, we do exhaustive search; you
        #    can replace 'edgesB' with BVH.Clashes(bvhB, ea) if your BVH
        #    returns nearby topologies (not just intersecting ones).
        for ea in edgesA:
            sa = _coords(Edge.StartVertex(ea))
            ta = _coords(Edge.EndVertex(ea))

            candidate_edgesB = edgesB
            # Example hook (uncomment if BVH.Clashes returns nearby edges):
            # if bvhB is not None:
            #     candidate_edgesB = BVH.Clashes(bvhB, ea) or []

            for eb in candidate_edgesB:
                sb = _coords(Edge.StartVertex(eb))
                tb = _coords(Edge.EndVertex(eb))
                d2, P_closest, Q_closest = _segment_segment_distance2(sa, ta, sb, tb)
                if d2 < min_d2:
                    min_d2 = d2
                    bestP = P_closest
                    bestQ = Q_closest
                    if min_d2 <= tolerance*tolerance:
                        break
            if min_d2 <= tolerance*tolerance:
                break

        if min_d2 <= tolerance*tolerance:
            vA = Vertex.ByCoordinates(bestP[0], bestP[1], bestP[2])
            vB = Vertex.ByCoordinates(bestQ[0], bestQ[1], bestQ[2])
            if Vertex.Distance(vA, vB) <= tolerance:
                if not silent:
                    print("Topology.ShortestEdge - Error: The input topologies touch. Therefore the shortest edge degenerated into a vertex. Returning None.")
                return None
            return Edge.ByStartVertexEndVertex(vA, vB)

        # 4. Vertex–face (both directions), optionally BVH-accelerated
        def _vertex_face_pass(vertices, faces, reverse=False):
            nonlocal min_d2, bestP, bestQ
            for v in vertices:
                pv = _coords(v)

                candidate_faces = faces

                for f in candidate_faces:
                    d2, Q = _point_face_distance2(pv, f)
                    if d2 < min_d2:
                        min_d2 = d2
                        if reverse:
                            bestP = Q
                            bestQ = pv
                        else:
                            bestP = pv
                            bestQ = Q
                        if min_d2 <= tolerance*tolerance:
                            return

        _vertex_face_pass(verticesA, facesB, reverse=False)
        if min_d2 > tolerance*tolerance:
            _vertex_face_pass(verticesB, facesA, reverse=True)

        if not isfinite(min_d2):
            if not silent:
                print("[Topology.ShortestEdge] Failed to compute a finite distance.")
            return None

        # ------------------------------------------------------------------
        # Construct resulting Edge
        # ------------------------------------------------------------------
        dist = math.sqrt(max(min_d2, 0.0))
        if dist <= tolerance:
            # Treat as touching; still create an Edge (possibly degenerate)
            pass

        if bestP is None or bestQ is None:
            if not silent:
                print("[Topology.ShortestEdge] No closest points recorded; returning None.")
            return None

        vA = Vertex.ByCoordinates(bestP[0], bestP[1], bestP[2])
        vB = Vertex.ByCoordinates(bestQ[0], bestQ[1], bestQ[2])
        if Vertex.Distance(vA, vB) <= tolerance:
            if not silent:
                print("Topology.ShortestEdge - Error: The input topologies touch. Therefore the shortest edge degenerated into a vertex. Returning None.")
            return None
        return Edge.ByStartVertexEndVertex(vA, vB)

    @staticmethod
    def ShortestDistance(
        topologyA,
        topologyB,
        mantissa: int = 6,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Returns the shortest Euclidean distance between two topologies.

        For backends other than TopologicCore, a native backend distance
        implementation is used when available.

        For TopologicCore, and for backends without a native distance operation,
        the distance is calculated using backend-independent geometric primitives.
        The compatibility calculation supports vertices, edges, faces with holes,
        shells, cells, cell complexes, and clusters.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        mantissa : int , optional
            Number of decimal places to which the distance is rounded.
            Default is 6.
        tolerance : float , optional
            The desired tolerance. Distances less than or equal to this value
            are returned as zero. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        float
            The shortest distance between topologyA and topologyB.
            Returns None if the distance cannot be computed.
        """
        import math

        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face

        # ------------------------------------------------------------------
        # Validation
        # ------------------------------------------------------------------

        if not Topology.IsInstance(topologyA, "Topology"):
            if not silent:
                print(
                    "Topology.ShortestDistance - Error: The input topologyA "
                    "parameter is not a valid topology. Returning None."
                )
            return None

        if not Topology.IsInstance(topologyB, "Topology"):
            if not silent:
                print(
                    "Topology.ShortestDistance - Error: The input topologyB "
                    "parameter is not a valid topology. Returning None."
                )
            return None

        try:
            mantissa = int(mantissa)
            tolerance = abs(float(tolerance))
        except Exception:
            if not silent:
                print(
                    "Topology.ShortestDistance - Error: Invalid mantissa or "
                    "tolerance parameter. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Native backend path
        #
        # PythonOCC and other replacement backends are allowed to use their
        # native distance implementation. TopologicCore deliberately bypasses
        # its native Distance function because it can return finite but
        # geometrically incorrect values for several topology combinations.
        # ------------------------------------------------------------------

        is_topologic_core = Topology._IsTopologicCoreBackend()

        try:
            has_native_distance = Core.HasAttribute(
                "TopologyUtility",
                "Distance"
            )
        except Exception:
            has_native_distance = False

        if has_native_distance and not is_topologic_core:
            try:
                distance = Core.TopologyUtility.Distance(
                    topologyA,
                    topologyB,
                    tolerance
                )
            except Exception as error:
                if not silent:
                    print(
                        "Topology.ShortestDistance - Error: The active backend "
                        "distance operation failed. Returning None."
                    )
                    print("Error:", error)
                return None

            if distance is None:
                if not silent:
                    print(
                        "Topology.ShortestDistance - Error: The active backend "
                        "could not compute the distance. Returning None."
                    )
                return None

            try:
                distance = float(distance)
            except Exception:
                if not silent:
                    print(
                        "Topology.ShortestDistance - Error: The active backend "
                        "returned an invalid distance. Returning None."
                    )
                return None

            if not math.isfinite(distance):
                return None

            if distance < -tolerance:
                return None

            if abs(distance) <= tolerance:
                distance = 0.0

            return round(distance, mantissa)

        # ------------------------------------------------------------------
        # Backend-independent geometry helpers
        # ------------------------------------------------------------------

        tolerance2 = tolerance * tolerance

        def coordinates(vertex):
            return [
                float(Vertex.X(vertex)),
                float(Vertex.Y(vertex)),
                float(Vertex.Z(vertex)),
            ]

        def add(a, b):
            return [
                a[0] + b[0],
                a[1] + b[1],
                a[2] + b[2],
            ]

        def subtract(a, b):
            return [
                a[0] - b[0],
                a[1] - b[1],
                a[2] - b[2],
            ]

        def scale(a, factor):
            return [
                a[0] * factor,
                a[1] * factor,
                a[2] * factor,
            ]

        def dot(a, b):
            return (
                a[0] * b[0]
                + a[1] * b[1]
                + a[2] * b[2]
            )

        def cross(a, b):
            return [
                a[1] * b[2] - a[2] * b[1],
                a[2] * b[0] - a[0] * b[2],
                a[0] * b[1] - a[1] * b[0],
            ]

        def length_squared(a):
            return dot(a, a)

        def normalize(a):
            magnitude2 = length_squared(a)

            if magnitude2 <= tolerance2:
                return None

            inverse = 1.0 / math.sqrt(magnitude2)

            return scale(a, inverse)

        # ------------------------------------------------------------------
        # Point-segment distance
        # ------------------------------------------------------------------

        def point_segment_distance_squared(point, start, end):
            direction = subtract(end, start)
            denominator = length_squared(direction)

            if denominator <= tolerance2:
                difference = subtract(point, start)
                return length_squared(difference)

            parameter = dot(
                subtract(point, start),
                direction
            ) / denominator

            parameter = max(
                0.0,
                min(1.0, parameter)
            )

            closest = add(
                start,
                scale(direction, parameter)
            )

            difference = subtract(
                point,
                closest
            )

            return length_squared(difference)

        # ------------------------------------------------------------------
        # Segment-segment distance
        #
        # Robust finite-segment algorithm. Both parameters are clamped after
        # considering the interaction between the two segments.
        # ------------------------------------------------------------------

        def segment_segment_distance_squared(a0, a1, b0, b1):
            u = subtract(a1, a0)
            v = subtract(b1, b0)
            w = subtract(a0, b0)

            a = dot(u, u)
            b = dot(u, v)
            c = dot(v, v)
            d = dot(u, w)
            e = dot(v, w)

            if a <= tolerance2 and c <= tolerance2:
                return length_squared(
                    subtract(a0, b0)
                )

            if a <= tolerance2:
                return point_segment_distance_squared(
                    a0,
                    b0,
                    b1
                )

            if c <= tolerance2:
                return point_segment_distance_squared(
                    b0,
                    a0,
                    a1
                )

            denominator = a * c - b * b

            s_numerator = 0.0
            s_denominator = denominator

            t_numerator = 0.0
            t_denominator = denominator

            if denominator <= tolerance2:
                s_numerator = 0.0
                s_denominator = 1.0

                t_numerator = e
                t_denominator = c

            else:
                s_numerator = b * e - c * d
                t_numerator = a * e - b * d

                if s_numerator < 0.0:
                    s_numerator = 0.0
                    t_numerator = e
                    t_denominator = c

                elif s_numerator > s_denominator:
                    s_numerator = s_denominator
                    t_numerator = e + b
                    t_denominator = c

            if t_numerator < 0.0:
                t_numerator = 0.0

                if -d < 0.0:
                    s_numerator = 0.0
                    s_denominator = 1.0

                elif -d > a:
                    s_numerator = 1.0
                    s_denominator = 1.0

                else:
                    s_numerator = -d
                    s_denominator = a

            elif t_numerator > t_denominator:
                t_numerator = t_denominator

                if (-d + b) < 0.0:
                    s_numerator = 0.0
                    s_denominator = 1.0

                elif (-d + b) > a:
                    s_numerator = 1.0
                    s_denominator = 1.0

                else:
                    s_numerator = -d + b
                    s_denominator = a

            if abs(s_numerator) <= tolerance2:
                s = 0.0
            else:
                s = s_numerator / s_denominator

            if abs(t_numerator) <= tolerance2:
                t = 0.0
            else:
                t = t_numerator / t_denominator

            closest_a = add(
                a0,
                scale(u, s)
            )

            closest_b = add(
                b0,
                scale(v, t)
            )

            return length_squared(
                subtract(
                    closest_a,
                    closest_b
                )
            )

        # ------------------------------------------------------------------
        # Wire helpers
        # ------------------------------------------------------------------

        def wire_points(wire):
            if not Topology.IsInstance(wire, "Wire"):
                return []

            try:
                vertices = Wire.Vertices(wire)
            except Exception:
                vertices = Topology.Vertices(
                    wire,
                    silent=True
                ) or []

            points = []

            for vertex in vertices:
                if Topology.IsInstance(vertex, "Vertex"):
                    points.append(
                        coordinates(vertex)
                    )

            return points

        # ------------------------------------------------------------------
        # Face frame
        # ------------------------------------------------------------------

        def face_data(face):
            try:
                external = Face.ExternalBoundary(
                    face,
                    silent=True
                )
            except TypeError:
                external = Face.ExternalBoundary(face)
            except Exception:
                external = None

            if not Topology.IsInstance(external, "Wire"):
                return None

            external_points = wire_points(external)

            if len(external_points) < 3:
                return None

            origin = external_points[0]

            first_direction = None
            normal = None

            for i in range(1, len(external_points)):
                candidate = subtract(
                    external_points[i],
                    origin
                )

                if length_squared(candidate) > tolerance2:
                    first_direction = candidate
                    break

            if first_direction is None:
                return None

            for i in range(1, len(external_points)):
                candidate = subtract(
                    external_points[i],
                    origin
                )

                candidate_normal = cross(
                    first_direction,
                    candidate
                )

                if length_squared(candidate_normal) > tolerance2:
                    normal = normalize(candidate_normal)
                    break

            if normal is None:
                return None

            axis_u = normalize(first_direction)

            if axis_u is None:
                return None

            axis_v = normalize(
                cross(normal, axis_u)
            )

            if axis_v is None:
                return None

            internal_wires = []

            try:
                result = Face.InternalBoundaries(face)

                if isinstance(result, list):
                    internal_wires = [
                        wire
                        for wire in result
                        if Topology.IsInstance(wire, "Wire")
                    ]
            except Exception:
                internal_wires = []

            loops = [
                external_points
            ]

            for wire in internal_wires:
                points = wire_points(wire)

                if len(points) >= 3:
                    loops.append(points)

            return {
                "origin": origin,
                "u": axis_u,
                "v": axis_v,
                "normal": normal,
                "loops": loops,
            }

        # ------------------------------------------------------------------
        # 2D trimmed-face tests
        # ------------------------------------------------------------------

        def project_2d(point, data):
            relative = subtract(
                point,
                data["origin"]
            )

            return [
                dot(relative, data["u"]),
                dot(relative, data["v"]),
            ]

        def point_on_segment_2d(point, start, end):
            px, py = point
            ax, ay = start
            bx, by = end

            dx = bx - ax
            dy = by - ay

            segment_length2 = dx * dx + dy * dy

            if segment_length2 <= tolerance2:
                return (
                    (px - ax) * (px - ax)
                    + (py - ay) * (py - ay)
                    <= tolerance2
                )

            parameter = (
                (px - ax) * dx
                + (py - ay) * dy
            ) / segment_length2

            if parameter < -tolerance or parameter > 1.0 + tolerance:
                return False

            parameter = max(
                0.0,
                min(1.0, parameter)
            )

            qx = ax + parameter * dx
            qy = ay + parameter * dy

            return (
                (px - qx) * (px - qx)
                + (py - qy) * (py - qy)
                <= tolerance2
            )

        def point_in_polygon_2d(point, polygon):
            if len(polygon) < 3:
                return False, False

            for i in range(len(polygon)):
                if point_on_segment_2d(
                    point,
                    polygon[i],
                    polygon[(i + 1) % len(polygon)]
                ):
                    return True, True

            x, y = point
            inside = False

            j = len(polygon) - 1

            for i in range(len(polygon)):
                xi, yi = polygon[i]
                xj, yj = polygon[j]

                if (yi > y) != (yj > y):
                    denominator = yj - yi

                    if abs(denominator) <= 1.0e-16:
                        denominator = (
                            1.0e-16
                            if denominator >= 0
                            else -1.0e-16
                        )

                    x_intersection = (
                        (xj - xi)
                        * (y - yi)
                        / denominator
                        + xi
                    )

                    if x < x_intersection:
                        inside = not inside

                j = i

            return inside, False

        def point_in_trimmed_face_2d(point, data):
            loops_2d = []

            for loop in data["loops"]:
                loops_2d.append(
                    [
                        project_2d(
                            loop_point,
                            data
                        )
                        for loop_point in loop
                    ]
                )

            external_inside, external_boundary = point_in_polygon_2d(
                point,
                loops_2d[0]
            )

            if not external_inside:
                return False

            if external_boundary:
                return True

            for hole in loops_2d[1:]:
                hole_inside, hole_boundary = point_in_polygon_2d(
                    point,
                    hole
                )

                if hole_boundary:
                    return True

                if hole_inside:
                    return False

            return True

        # ------------------------------------------------------------------
        # Point-face distance
        # ------------------------------------------------------------------

        def point_face_distance_squared(point, face):
            data = face_data(face)

            if data is None:
                return math.inf

            relative = subtract(
                point,
                data["origin"]
            )

            signed_distance = dot(
                relative,
                data["normal"]
            )

            projected = subtract(
                point,
                scale(
                    data["normal"],
                    signed_distance
                )
            )

            projected_2d = project_2d(
                projected,
                data
            )

            if point_in_trimmed_face_2d(
                projected_2d,
                data
            ):
                return signed_distance * signed_distance

            minimum = math.inf

            for loop in data["loops"]:
                for i in range(len(loop)):
                    distance2 = point_segment_distance_squared(
                        point,
                        loop[i],
                        loop[(i + 1) % len(loop)]
                    )

                    if distance2 < minimum:
                        minimum = distance2

            return minimum

        # ------------------------------------------------------------------
        # Segment-face distance
        # ------------------------------------------------------------------

        def segment_face_distance_squared(start, end, face):
            data = face_data(face)

            if data is None:
                return math.inf

            relative_start = subtract(
                start,
                data["origin"]
            )

            relative_end = subtract(
                end,
                data["origin"]
            )

            distance_start = dot(
                relative_start,
                data["normal"]
            )

            distance_end = dot(
                relative_end,
                data["normal"]
            )

            denominator = distance_start - distance_end

            # Segment intersects the plane.
            if abs(denominator) > 1.0e-16:
                parameter = distance_start / denominator

                if (
                    parameter >= -tolerance
                    and parameter <= 1.0 + tolerance
                ):
                    parameter = max(
                        0.0,
                        min(1.0, parameter)
                    )

                    intersection = add(
                        start,
                        scale(
                            subtract(end, start),
                            parameter
                        )
                    )

                    intersection_2d = project_2d(
                        intersection,
                        data
                    )

                    if point_in_trimmed_face_2d(
                        intersection_2d,
                        data
                    ):
                        return 0.0

            minimum = min(
                point_face_distance_squared(
                    start,
                    face
                ),
                point_face_distance_squared(
                    end,
                    face
                ),
            )

            for loop in data["loops"]:
                for i in range(len(loop)):
                    distance2 = segment_segment_distance_squared(
                        start,
                        end,
                        loop[i],
                        loop[(i + 1) % len(loop)]
                    )

                    if distance2 < minimum:
                        minimum = distance2

            return minimum

        # ------------------------------------------------------------------
        # Collect geometric primitives
        # ------------------------------------------------------------------

        def collect(topology):
            try:
                vertices = Topology.Vertices(
                    topology,
                    silent=True
                ) or []
            except Exception:
                vertices = []

            try:
                edges = Topology.Edges(
                    topology,
                    silent=True
                ) or []
            except Exception:
                edges = []

            try:
                faces = Topology.Faces(
                    topology,
                    silent=True
                ) or []
            except Exception:
                faces = []

            try:
                cells = Topology.Cells(
                    topology,
                    silent=True
                ) or []
            except Exception:
                cells = []

            return vertices, edges, faces, cells

        vertices_a, edges_a, faces_a, cells_a = collect(
            topologyA
        )

        vertices_b, edges_b, faces_b, cells_b = collect(
            topologyB
        )

        if (
            len(vertices_a) == 0
            and len(edges_a) == 0
            and len(faces_a) == 0
        ):
            return None

        if (
            len(vertices_b) == 0
            and len(edges_b) == 0
            and len(faces_b) == 0
        ):
            return None

        # ------------------------------------------------------------------
        # Solid containment
        #
        # Boundary-feature distance alone cannot detect one solid completely
        # contained in another, so explicitly test vertices against Cells.
        # ------------------------------------------------------------------

        if len(cells_b) > 0:
            for vertex in vertices_a:
                for cell in cells_b:
                    try:
                        if Vertex.IsInternal(
                            vertex,
                            cell,
                            tolerance=tolerance
                        ):
                            return 0.0
                    except Exception:
                        pass

        if len(cells_a) > 0:
            for vertex in vertices_b:
                for cell in cells_a:
                    try:
                        if Vertex.IsInternal(
                            vertex,
                            cell,
                            tolerance=tolerance
                        ):
                            return 0.0
                    except Exception:
                        pass

        # ------------------------------------------------------------------
        # Exhaustive closest-feature search
        # ------------------------------------------------------------------

        minimum2 = math.inf

        # Vertex - Vertex
        for vertex_a in vertices_a:
            point_a = coordinates(vertex_a)

            for vertex_b in vertices_b:
                point_b = coordinates(vertex_b)

                distance2 = length_squared(
                    subtract(
                        point_a,
                        point_b
                    )
                )

                if distance2 < minimum2:
                    minimum2 = distance2

                if minimum2 <= tolerance2:
                    return 0.0

        # Vertex - Edge
        for vertex in vertices_a:
            point = coordinates(vertex)

            for edge in edges_b:
                start = coordinates(
                    Edge.StartVertex(edge)
                )

                end = coordinates(
                    Edge.EndVertex(edge)
                )

                distance2 = point_segment_distance_squared(
                    point,
                    start,
                    end
                )

                if distance2 < minimum2:
                    minimum2 = distance2

                if minimum2 <= tolerance2:
                    return 0.0

        for vertex in vertices_b:
            point = coordinates(vertex)

            for edge in edges_a:
                start = coordinates(
                    Edge.StartVertex(edge)
                )

                end = coordinates(
                    Edge.EndVertex(edge)
                )

                distance2 = point_segment_distance_squared(
                    point,
                    start,
                    end
                )

                if distance2 < minimum2:
                    minimum2 = distance2

                if minimum2 <= tolerance2:
                    return 0.0

        # Edge - Edge
        for edge_a in edges_a:
            a0 = coordinates(
                Edge.StartVertex(edge_a)
            )

            a1 = coordinates(
                Edge.EndVertex(edge_a)
            )

            for edge_b in edges_b:
                b0 = coordinates(
                    Edge.StartVertex(edge_b)
                )

                b1 = coordinates(
                    Edge.EndVertex(edge_b)
                )

                distance2 = segment_segment_distance_squared(
                    a0,
                    a1,
                    b0,
                    b1
                )

                if distance2 < minimum2:
                    minimum2 = distance2

                if minimum2 <= tolerance2:
                    return 0.0

        # Vertex - Face
        for vertex in vertices_a:
            point = coordinates(vertex)

            for face in faces_b:
                distance2 = point_face_distance_squared(
                    point,
                    face
                )

                if distance2 < minimum2:
                    minimum2 = distance2

                if minimum2 <= tolerance2:
                    return 0.0

        for vertex in vertices_b:
            point = coordinates(vertex)

            for face in faces_a:
                distance2 = point_face_distance_squared(
                    point,
                    face
                )

                if distance2 < minimum2:
                    minimum2 = distance2

                if minimum2 <= tolerance2:
                    return 0.0

        # Edge - Face
        for edge in edges_a:
            start = coordinates(
                Edge.StartVertex(edge)
            )

            end = coordinates(
                Edge.EndVertex(edge)
            )

            for face in faces_b:
                distance2 = segment_face_distance_squared(
                    start,
                    end,
                    face
                )

                if distance2 < minimum2:
                    minimum2 = distance2

                if minimum2 <= tolerance2:
                    return 0.0

        for edge in edges_b:
            start = coordinates(
                Edge.StartVertex(edge)
            )

            end = coordinates(
                Edge.EndVertex(edge)
            )

            for face in faces_a:
                distance2 = segment_face_distance_squared(
                    start,
                    end,
                    face
                )

                if distance2 < minimum2:
                    minimum2 = distance2

                if minimum2 <= tolerance2:
                    return 0.0

        # ------------------------------------------------------------------
        # Finalize
        # ------------------------------------------------------------------

        if not math.isfinite(minimum2):
            if not silent:
                print(
                    "Topology.ShortestDistance - Error: Could not compute the "
                    "shortest distance. Returning None."
                )
            return None

        distance = math.sqrt(
            max(0.0, minimum2)
        )

        if distance <= tolerance:
            distance = 0.0

        return round(
            distance,
            mantissa
        )

    @staticmethod
    def ShortestEdges(topology, removeCoplanarFaces: bool = False, epsilon: float = 0.001, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns the list of the shortest edges found in the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        removeCoplanarFaces : bool , optional
            If set to True, coplanar faces are removed to find the true shortest straight edges. Otherwise they are not. Default is False.
        epsilon : float , optional
            The desired epsilon (another form of tolerance) for finding if two faces are coplanar. Default is 0.01.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        Returns
        -------
        list
            The list of the shortest edges found in the input topology.
        
        """
        from topologicpy.Edge import Edge

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.ShortestEdges - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        edges = Topology.Edges(topology)
        if len(edges) == 0:
            if not silent:
                print("Topology.ShortestEdges - Error: The input topology parameter does not contain any edges. Returning None.")
            return None
        if len(edges) == 1:
            return edges[0]
        
        if removeCoplanarFaces == True:
            simple_topology = Topology.RemoveCoplanarFaces(topology)
            simple_topology = Topology.RemoveCollinearEdges(simple_topology)
            edges = Topology.Edges(simple_topology)
        edge_lengths = [Edge.Length(edge) for edge in edges]
        min_length = min(edge_lengths)
        min_edges = []
        for i, edge_length in enumerate(edge_lengths):
            if abs(min_length - edge_length) <= tolerance:
                min_edges.append(edges[i])
        return min_edges

    @staticmethod
    def Show(*topologies,
            nameKey="name",
            opacityKey="opacity",
            showVertices=True,
            vertexSize=None,
            vertexSizeKey=None,
            vertexColor="black",
            vertexColorKey=None,
            vertexBorderWidth=0,
            vertexBorderColor="black",
            vertexBorderWidthKey=None,
            vertexBorderColorKey=None,
            vertexLabelKey=None,
            showVertexLabel=False,
            vertexLabelFontSize=5,
            vertexGroupKey=None,
            vertexGroups=[],
            vertexMinGroup=None,
            vertexMaxGroup=None,
            showVertexLegend=False,
            vertexLegendLabel="Vertices",

            directed=False,
            arrowSize=0.1,
            arrowSizeKey=None,
            showEdges=True,
            edgeWidth=None,
            edgeWidthKey=None,
            edgeColor=None,
            edgeColorKey=None,
            edgeDash=False,
            edgeDashKey=None,

            edgeLabelKey=None,
            showEdgeLabel=False,
            edgeGroupKey=None,
            edgeGroups=[],
            edgeMinGroup=None,
            edgeMaxGroup=None,
            showEdgeLegend=False,
            edgeLegendLabel="Edges",

            showFaces=True,
            faceOpacity=0.5,
            faceOpacityKey=None,
            faceColor="#FAFAFA",
            faceColorKey=None,
            faceLabelKey=None,
            faceGroupKey=None,
            faceGroups=[],
            faceMinGroup=None,
            faceMaxGroup=None,
            showFaceLegend=False,
            faceLegendLabel="Faces",
            intensityKey=None,
            intensities=[],

            material="default",
            materialKey=None,
            flatShading=True,
            ambient=None,
            ambientKey=None,
            diffuse=None,
            diffuseKey=None,
            specular=None,
            specularKey=None,
            roughness=None,
            roughnessKey=None,

            width=950,
            height=500,
            xAxis=False,
            yAxis=False,
            zAxis=False,
            axisSize=1,
            backgroundColor='rgba(0,0,0,0)',
            marginLeft=0,
            marginRight=0,
            marginTop=20,
            marginBottom=0,
            camera=[-1.25, -1.25, 1.25],
            center=[0, 0, 0],
            up=[0, 0, 1],
            projection="perspective",
            renderer="notebook",
            showScale=False,

            cbValues=[],
            cbTicks=5,
            cbX=-0.15,
            cbWidth=15,
            cbOutlineWidth=0,
            cbTitle="",
            cbSubTitle="",
            cbUnits="",
            colorScale="Viridis",

            sagitta=0,
            absolute=False,
            sides=8,
            angle=0,

            showFigure=True,
            mantissa=6,
            tolerance=0.0001,
            silent=False):
        """
            Shows the input topology on screen.

        Parameters
        ----------
        topologies : topologic_core.Topology or list
            The input topology. This must contain faces and or edges. If the input is a list, a cluster is first created
        opacityKey : str , optional
            The key under which to find the opacity of the topology. Default is "opacity".
        showVertices : bool , optional
            If set to True the vertices will be drawn. Otherwise, they will not be drawn. Default is True.
        vertexSize : float , optional
            The desired size of the vertices. Default is 1.1.
        vertexSizeKey : str , optional
            The key under which to find the size of the vertex. Default is None.
        vertexColor : str , optional
            The desired color of the output vertices. This can be any plotly color string and may be specified as:
            - A hex string (e.g. '#ff0000')
            - An rgb/rgba string (e.g. 'rgb(255,0,0)')
            - An hsl/hsla string (e.g. 'hsl(0,100%,50%)')
            - An hsv/hsva string (e.g. 'hsv(0,100%,100%)')
            - A named CSS color.
            The default is "black".
        vertexColorKey : str , optional
            The key under which to find the color of the vertex. Default is None.
        vertexBorderWidth : float , optional
            The desired width of the borders of the output vertices. Default is 0.
        vertexBorderColor : str , optional
            The desired color of the borders of the output vertices. This can be any plotly color string and may be specified as:
            - A hex string (e.g. '#ff0000')
            - An rgb/rgba string (e.g. 'rgb(255,0,0)')
            - An hsl/hsla string (e.g. 'hsl(0,100%,50%)')
            - An hsv/hsva string (e.g. 'hsv(0,100%,100%)')
            - A named CSS color.
            The default is "black".
        vertexLabelKey : str , optional
            The dictionary key to use to display the vertex label. Default is None.
        showVertexLabels : bool , optional
            If set to True, the vertex labels are shown permenantely on screen. Otherwise, they are not. Default is False.
        vertexLabelFontSize : int , optional
            The font size of the vertex labels. Default is 5.
        vertexGroupKey : str , optional
            The dictionary key to use to display the vertex group. Default is None.
        vertexGroups : list , optional
            The list of vertex groups against which to index the color of the vertex. Default is [].
        vertexMinGroup : int or float , optional
            For numeric vertexGroups, vertexMinGroup is the desired minimum value for the scaling of colors. This should match the type of value associated with the vertexGroupKey. If set to None, it is set to the minimum value in vertexGroups. Default is None.
        vertexMaxGroup : int or float , optional
            For numeric vertexGroups, vertexMaxGroup is the desired maximum value for the scaling of colors. This should match the type of value associated with the vertexGroupKey. If set to None, it is set to the maximum value in vertexGroups. Default is None.
        showVertexLegend : bool, optional
            If set to True, the legend for the vertices of this topology is shown. Otherwise, it isn't. Default is False.
        vertexLegendLabel : str , optional
            The legend label string used to identify vertices. Default is "Topology Vertices".
        directed : bool , optional
            If set to True, arrowheads are drawn to show direction. Default is False.
        arrowSize : int, optional
            The desired size of arrowheads for directed graphs. Default is 0.1.
        arrowSizeKey: str , optional
            The edge dictionary key under which to find the arrowhead size. Default is None.
        showEdges : bool , optional
            If set to True the edges will be drawn. Otherwise, they will not be drawn. Default is True.
        edgeWidth : float , optional
            The desired thickness of the output edges. Default is 1.
        edgeColor : str , optional
            The desired color of the output edges. This can be any plotly color string and may be specified as:
            - A hex string (e.g. '#ff0000')
            - An rgb/rgba string (e.g. 'rgb(255,0,0)')
            - An hsl/hsla string (e.g. 'hsl(0,100%,50%)')
            - An hsv/hsva string (e.g. 'hsv(0,100%,100%)')
            - A named CSS color.
            The default is "black".
        edgeColorKey : str , optional
            The key under which to find the color of the edge. Default is None.
        edgeDash : bool , optional
            If set to True, the edges are drawn as dashed lines. Default is False.
        edgeDashKey : str , optional
            The key under which to find the boolean flag to draw edges as dashed lines. Default is None.
        edgeWidthKey : str , optional
            The key under which to find the width of the edge. Default is None.
        edgeLabelKey : str , optional
            The dictionary key to use to display the edge label. Default is None.
        showEdgeLabels : bool , optional
            If set to True, the edge labels are shown permenantely on screen. Otherwise, they are not. Default is False.
        edgeGroupKey : str , optional
            The dictionary key to use to display the edge group. Default is None.
        edgeGroups : list , optional
            The list of edge groups against which to index the color of the edge. Default is [].
        edgeMinGroup : int or float , optional
            For numeric edgeGroups, edgeMinGroup is the desired minimum value for the scaling of colors. This should match the type of value associated with the edgeGroupKey. If set to None, it is set to the minimum value in edgeGroups. Default is None.
        edgeMaxGroup : int or float , optional
            For numeric edgeGroups, edgeMaxGroup is the desired maximum value for the scaling of colors. This should match the type of value associated with the edgeGroupKey. If set to None, it is set to the maximum value in edgeGroups. Default is None.
        showEdgeLegend : bool, optional
            If set to True, the legend for the edges of this topology is shown. Otherwise, it isn't. Default is False.
        edgeLegendLabel : str , optional
            The legend label string used to identify edges. Default is "Topology Edges".
        
        showFaces : bool , optional
            If set to True the faces will be drawn. Otherwise, they will not be drawn. Default is True.
        faceOpacity : float , optional
            The desired opacity of the output faces (0=transparent, 1=opaque). Default is 0.5.
        faceOpacityKey : str , optional
            The key under which to find the opacity of the face. Default is None.
        faceColor : str , optional
            The desired color of the output faces. This can be any plotly color string and may be specified as:
            - A hex string (e.g. '#ff0000')
            - An rgb/rgba string (e.g. 'rgb(255,0,0)')
            - An hsl/hsla string (e.g. 'hsl(0,100%,50%)')
            - An hsv/hsva string (e.g. 'hsv(0,100%,100%)')
            - A named CSS color.
            The default is "#FAFAFA".
        faceColorKey : str , optional
            The key under which to find the color of the face. Default is None.
        faceLabelKey : str , optional
            The dictionary key to use to display the face label. Default is None.
        faceGroupKey : str , optional
            The dictionary key to use to display the face group. Default is None.
        faceGroups : list , optional
            The list of face groups against which to index the color of the face. This can bhave numeric or string values. This should match the type of value associated with the faceGroupKey. Default is [].
        faceMinGroup : int or float , optional
            For numeric faceGroups, minGroup is the desired minimum value for the scaling of colors. This should match the type of value associated with the faceGroupKey. If set to None, it is set to the minimum value in faceGroups. Default is None.
        faceMaxGroup : int or float , optional
            For numeric faceGroups, maxGroup is the desired maximum value for the scaling of colors. This should match the type of value associated with the faceGroupKey. If set to None, it is set to the maximum value in faceGroups. Default is None.
        showFaceLegend : bool, optional
            If set to True, the legend for the faces of this topology is shown. Otherwise, it isn't. Default is False.
        faceLegendLabel : str , optional
            The legend label string used to idenitfy edges. Default is "Topology Faces".
        width : int , optional
            The width in pixels of the figure. The default value is 950.
        height : int , optional
            The height in pixels of the figure. The default value is 950.
        xAxis : bool , optional
            If set to True the x axis is drawn. Otherwise it is not drawn. Default is False.
        yAxis : bool , optional
            If set to True the y axis is drawn. Otherwise it is not drawn. Default is False.
        zAxis : bool , optional
            If set to True the z axis is drawn. Otherwise it is not drawn. Default is False.
        backgroundColor : str , optional
            The desired color of the background. This can be any plotly color string and may be specified as:
            - A hex string (e.g. '#ff0000')
            - An rgb/rgba string (e.g. 'rgb(255,0,0)')
            - An hsl/hsla string (e.g. 'hsl(0,100%,50%)')
            - An hsv/hsva string (e.g. 'hsv(0,100%,100%)')
            - A named CSS color.
            The default is "rgba(0,0,0,0)".
        marginLeft : int , optional
            The size in pixels of the left margin. The default value is 0.
        marginRight : int , optional
            The size in pixels of the right margin. The default value is 0.
        marginTop : int , optional
            The size in pixels of the top margin. The default value is 20.
        marginBottom : int , optional
            The size in pixels of the bottom margin. The default value is 0.
        camera : list , optional
            The desired location of the camera). Default is [-1.25, -1.25, 1.25].
        center : list , optional
            The desired center (camera target). Default is [0, 0, 0].
        up : list , optional
            The desired up vector. Default is [0, 0, 1].
        projection : str , optional
            The desired type of projection. The options are "orthographic" or "perspective". It is case insensitive. Default is "perspective"
        renderer : str , optional
            The desired renderer. See Plotly.Renderers(). If set to None, the code will attempt to discover the most suitable renderer. Default is None.
        intensityKey : str , optional
            If not None, the dictionary of each vertex is searched for the value associated with the intensity key. This value is then used to color-code the vertex based on the colorScale. Default is None.
        intensities : list , optional
            The list of intensities against which to index the intensity of the vertex. Default is [].
        material : str , optional
            The type of object material. Case in-sensitive. Supported pre-built materials are:
            Preset     Ambient  Diffuse  Specular  Roughness  Description
            --------------------------------------------------------------
            chalk        1.0      0.4       0.0        1.0     Very soft shading, low contrast
            concrete     0.85     0.75      0.05       0.9     Highly matte, micro-rough surface, minimal specular reflection
            eggshell     0.65     0.85      0.25       0.45    Slight sheen, soft highlights without gloss
            glossy       0.5      0.9       0.6        0.1     Highly polished appearance
            matte        0.9      0.7       0.0        1.0     Flat, non-reflective surfaces
            metallic     0.3      0.8       0.9        0.2     Strong, sharp reflections
            plastic      0.6      0.9       0.2        0.4     Soft highlights, good shape readability
            Default is a matte material that uses facenormalepsilon=0.
        materialKey : str , optional
            The dictionary key under which the material string is stored. Default is None.
        flatShading : bool , optional
            If set to True, the model is rendered with flat shading with no clear light source. Default is True.
        ambient : float , optional
            Controls the strength of ambient light applied uniformly to the surface.
            Higher values reduce shading contrast by increasing overall brightness.
            Typical range is [0, 1]. This over-rides the material pre-sets. Default is 0.6.
        ambientKey : str , optional
            The dictionary key under which the ambient value (float) is stored. Default is None.
        diffuse : float , optional
            Controls the strength of diffuse (Lambertian) lighting based on the angle
            between the light direction and the surface normal.
            Higher values enhance shape perception through shading.
            Typical range is [0, 1]. This over-rides the material pre-sets. Default is None.
        diffuseKey : str , optional
            The dictionary key under which the diffuse value (float) is stored. Default is None.
        specular : float , optional
            Controls the intensity of specular (mirror-like) highlights on the surface.
            Higher values produce sharper and brighter highlights, giving a glossy appearance.
            Typical range is [0, 1]. This over-rides the material pre-sets. Default is None.
        specularKey : str , optional
            The dictionary key under which the specular value (float) is stored. Default is None.
        roughness : float , optional
            Controls the spread of specular highlights on the surface.
            Lower values result in sharp, concentrated highlights (smooth surfaces),
            while higher values produce broader, softer highlights (rough surfaces).
            Typical range is [0, 1]. This over-rides the material pre-sets. Default is None.
        roughnessKey : str , optional
            The dictionary key under which the roughness value (float) is stored. Default is None.
        showScale : bool , optional
            If set to True, the colorbar is shown. Default is False.
        cbValues : list , optional
            The input list of values to use for the colorbar. Default is [].
        cbTicks : int , optional
            The number of ticks to use on the colorbar. Default is 5.
        cbX : float , optional
            The x location of the colorbar. Default is -0.15.
        cbWidth : int , optional
            The width in pixels of the colorbar. Default is 15
        cbOutlineWidth : int , optional
            The width in pixels of the outline of the colorbar. Default is 0.
        cbTitle : str , optional
            The title of the colorbar. Default is "".
        cbSubTitle : str , optional
            The subtitle of the colorbar. Default is "".
        cbUnits: str , optional
            The units used in the colorbar. Default is ""
        colorScale : str , optional
            The desired type of plotly color scales to use (e.g. "viridis", "plasma"). Default is "viridis". For a full list of names, see https://plotly.com/python/builtin-colorscales/.
        showFigure : bool , optional
            If set to True, the figure will be shown and a None is returned. If not, the figure will be returned, but not shown. Default is True.
        mantissa : int , optional
            The desired length of the mantissa for the values listed on the colorbar. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        Plotly figure
            The created plotly figure.

        """

        from topologicpy.Plotly import Plotly
        from topologicpy.Dictionary import Dictionary
        from topologicpy.Graph import Graph

        try:
            from topologicpy.TGraph import TGraph
        except Exception:
            TGraph = None

        def _is_tgraph(obj):
            return TGraph is not None and isinstance(obj, TGraph)

        def _flatten(items):
            result = []
            for item in items:
                if isinstance(item, list):
                    result.extend(_flatten(item))
                else:
                    result.append(item)
            return result

        def _dict_value(d, key, default=None):
            if d is None or key is None:
                return default
            if isinstance(d, dict):
                value = d.get(key, default)
                return default if value is None else value
            try:
                value = Dictionary.ValueAtKey(d, key, default)
                return default if value is None else value
            except TypeError:
                try:
                    value = Dictionary.ValueAtKey(d, key)
                    return default if value is None else value
                except Exception:
                    return default
            except Exception:
                return default

        def _dictionary(obj):
            if _is_tgraph(obj):
                try:
                    return TGraph.Dictionary(obj)
                except Exception:
                    return {}
            try:
                return Topology.Dictionary(obj, silent=True)
            except Exception:
                return None

        input_topologies = _flatten(list(topologies))

        if len(input_topologies) == 0:
            if not silent:
                print("Topology.Show - Error: No valid topology, graph, or TGraph was input. Returning None.")
            return None

        data = []
        topology_counter = 0
        graph_counter = 0
        offset = 3

        for i, topology in enumerate(input_topologies):
            if topology is None:
                continue

            d = _dictionary(topology)
            name = _dict_value(d, nameKey, "Untitled")

            vSize = 1.1 if vertexSize is None else vertexSize
            eWidth = 1 if edgeWidth is None else edgeWidth
            eColor = "black" if edgeColor is None else edgeColor
            fOpacity = _dict_value(d, opacityKey, faceOpacity)

            # ------------------------------------------------------------
            # TGraph branch must come before legacy Graph branch.
            # Topology.IsInstance(tgraph, "Graph") may intentionally return True.
            # ------------------------------------------------------------
            if _is_tgraph(topology):
                try:
                    tgraph_data = Plotly.DataByTGraph(
                        topology,
                        sagitta=sagitta,
                        absolute=absolute,
                        sides=sides,
                        angle=angle,
                        directed=directed,
                        arrowSize=arrowSize,
                        arrowSizeKey=arrowSizeKey,

                        vertexColor=vertexColor,
                        vertexColorKey=vertexColorKey,
                        vertexSize=vSize,
                        vertexSizeKey=vertexSizeKey,
                        vertexLabelKey=vertexLabelKey,
                        vertexBorderColor=vertexBorderColor,
                        vertexBorderWidth=vertexBorderWidth,
                        vertexBorderColorKey=vertexBorderColorKey,
                        vertexBorderWidthKey=vertexBorderWidthKey,
                        vertexGroupKey=vertexGroupKey,
                        vertexGroups=vertexGroups,
                        vertexMinGroup=vertexMinGroup,
                        vertexMaxGroup=vertexMaxGroup,
                        showVertices=showVertices,
                        showVertexLabel=showVertexLabel,
                        vertexLabelFontSize=vertexLabelFontSize,
                        showVertexLegend=showVertexLegend,
                        vertexLegendLabel=str(i + 1) + ": " + str(name) + " (" + vertexLegendLabel + ")",
                        vertexLegendRank=graph_counter + 1,
                        vertexLegendGroup=graph_counter + 1,

                        edgeColor=eColor,
                        edgeColorKey=edgeColorKey,
                        edgeWidth=eWidth,
                        edgeWidthKey=edgeWidthKey,
                        edgeDash=edgeDash,
                        edgeDashKey=edgeDashKey,
                        edgeLabelKey=edgeLabelKey,
                        edgeGroupKey=edgeGroupKey,
                        edgeGroups=edgeGroups,
                        edgeMinGroup=edgeMinGroup,
                        edgeMaxGroup=edgeMaxGroup,
                        showEdges=showEdges,
                        showEdgeLabel=showEdgeLabel,
                        showEdgeLegend=showEdgeLegend,
                        edgeLegendLabel=str(i + 1) + ": " + str(name) + " (" + edgeLegendLabel + ")",
                        edgeLegendRank=graph_counter + 2,
                        edgeLegendGroup=graph_counter + 2,

                        colorScale=colorScale,
                        mantissa=mantissa,
                        tolerance=tolerance,
                        silent=silent,
                    )
                    if isinstance(tgraph_data, list):
                        data.extend(tgraph_data)
                    graph_counter += offset
                except Exception as e:
                    if not silent:
                        print("Topology.Show - Error: Could not create Plotly data from TGraph.")
                        print("Error:", e)
                continue

            # ------------------------------------------------------------
            # Legacy Graph branch.
            # ------------------------------------------------------------
            if Topology.IsInstance(topology, "Graph"):
                try:
                    graph_data = Plotly.DataByGraph(
                        topology,
                        sagitta=sagitta,
                        absolute=absolute,
                        sides=sides,
                        angle=angle,
                        directed=directed,
                        arrowSize=arrowSize,
                        arrowSizeKey=arrowSizeKey,

                        vertexColor=vertexColor,
                        vertexColorKey=vertexColorKey,
                        vertexSize=vSize,
                        vertexSizeKey=vertexSizeKey,
                        vertexLabelKey=vertexLabelKey,
                        vertexBorderColor=vertexBorderColor,
                        vertexBorderWidth=vertexBorderWidth,
                        vertexBorderColorKey=vertexBorderColorKey,
                        vertexBorderWidthKey=vertexBorderWidthKey,
                        vertexGroupKey=vertexGroupKey,
                        vertexGroups=vertexGroups,
                        vertexMinGroup=vertexMinGroup,
                        vertexMaxGroup=vertexMaxGroup,
                        showVertices=showVertices,
                        showVertexLabel=showVertexLabel,
                        vertexLabelFontSize=vertexLabelFontSize,
                        showVertexLegend=showVertexLegend,
                        vertexLegendLabel=str(i + 1) + ": " + str(name) + " (" + vertexLegendLabel + ")",
                        vertexLegendRank=graph_counter + 1,
                        vertexLegendGroup=graph_counter + 1,

                        edgeColor=eColor,
                        edgeColorKey=edgeColorKey,
                        edgeWidth=eWidth,
                        edgeWidthKey=edgeWidthKey,
                        edgeDash=edgeDash,
                        edgeDashKey=edgeDashKey,
                        edgeLabelKey=edgeLabelKey,
                        edgeGroupKey=edgeGroupKey,
                        edgeGroups=edgeGroups,
                        edgeMinGroup=edgeMinGroup,
                        edgeMaxGroup=edgeMaxGroup,
                        showEdges=showEdges,
                        showEdgeLabel=showEdgeLabel,
                        showEdgeLegend=showEdgeLegend,
                        edgeLegendLabel=str(i + 1) + ": " + str(name) + " (" + edgeLegendLabel + ")",
                        edgeLegendRank=graph_counter + 2,
                        edgeLegendGroup=graph_counter + 2,

                        colorScale=colorScale,
                        mantissa=mantissa,
                        silent=silent,
                    )
                    if isinstance(graph_data, list):
                        data.extend(graph_data)
                    graph_counter += offset
                except Exception as e:
                    if not silent:
                        print("Topology.Show - Error: Could not create Plotly data from Graph.")
                        print("Error:", e)
                continue

            # ------------------------------------------------------------
            # Topologic topology branch.
            # ------------------------------------------------------------
            if Topology.IsInstance(topology, "Topology"):
                try:
                    topology_data = Plotly.DataByTopology(
                        topology=topology,

                        showVertices=showVertices,
                        vertexSize=vSize,
                        vertexSizeKey=vertexSizeKey,
                        vertexColor=vertexColor,
                        vertexColorKey=vertexColorKey,
                        vertexBorderWidth=vertexBorderWidth,
                        vertexBorderColor=vertexBorderColor,
                        vertexBorderColorKey=vertexBorderColorKey,
                        vertexBorderWidthKey=vertexBorderWidthKey,
                        vertexLabelKey=vertexLabelKey,
                        showVertexLabel=showVertexLabel,
                        vertexLabelFontSize=vertexLabelFontSize,
                        vertexGroupKey=vertexGroupKey,
                        vertexGroups=vertexGroups,
                        vertexMinGroup=vertexMinGroup,
                        vertexMaxGroup=vertexMaxGroup,
                        showVertexLegend=showVertexLegend,
                        vertexLegendLabel=str(i + 1) + ": " + str(name) + " (" + vertexLegendLabel + ")",
                        vertexLegendRank=topology_counter + 1,
                        vertexLegendGroup=topology_counter + 1,

                        directed=directed,
                        arrowSize=arrowSize,
                        arrowSizeKey=arrowSizeKey,
                        showEdges=showEdges,
                        edgeWidth=eWidth,
                        edgeWidthKey=edgeWidthKey,
                        edgeColor=eColor,
                        edgeColorKey=edgeColorKey,
                        edgeLabelKey=edgeLabelKey,
                        showEdgeLabel=showEdgeLabel,
                        edgeGroupKey=edgeGroupKey,
                        edgeGroups=edgeGroups,
                        edgeMinGroup=edgeMinGroup,
                        edgeMaxGroup=edgeMaxGroup,
                        showEdgeLegend=showEdgeLegend,
                        edgeLegendLabel=str(i + 1) + ": " + str(name) + " (" + edgeLegendLabel + ")",
                        edgeLegendRank=topology_counter + 2,
                        edgeLegendGroup=topology_counter + 2,

                        showFaces=showFaces,
                        faceOpacity=fOpacity,
                        faceOpacityKey=faceOpacityKey,
                        faceColor=faceColor,
                        faceColorKey=faceColorKey,
                        faceLabelKey=faceLabelKey,
                        faceGroupKey=faceGroupKey,
                        faceGroups=faceGroups,
                        faceMinGroup=faceMinGroup,
                        faceMaxGroup=faceMaxGroup,
                        showFaceLegend=showFaceLegend,
                        faceLegendLabel=str(i + 1) + ": " + str(name) + " (" + faceLegendLabel + ")",
                        faceLegendRank=topology_counter + 3,
                        faceLegendGroup=topology_counter + 3,

                        intensityKey=intensityKey,
                        intensities=intensities,

                        material=material,
                        flatShading=flatShading,
                        materialKey=materialKey,
                        ambient=ambient,
                        ambientKey=ambientKey,
                        diffuse=diffuse,
                        diffuseKey=diffuseKey,
                        specular=specular,
                        specularKey=specularKey,
                        roughness=roughness,
                        roughnessKey=roughnessKey,

                        colorScale=colorScale,
                        mantissa=mantissa,
                        tolerance=tolerance,
                        silent=silent,
                    )
                    if isinstance(topology_data, list):
                        data.extend(topology_data)
                    topology_counter += offset
                except Exception as e:
                    if not silent:
                        print("Topology.Show - Error: Could not create Plotly data from Topology.")
                        print("Error:", e)
                continue

            if not silent:
                print("Topology.Show - Warning: Input item is not a valid topology, graph, or TGraph. Skipping item.")
                print("Item:", topology)

        figure = Plotly.FigureByData(
            data=data,
            width=width,
            height=height,
            xAxis=xAxis,
            yAxis=yAxis,
            zAxis=zAxis,
            axisSize=axisSize,
            backgroundColor=backgroundColor,
            marginLeft=marginLeft,
            marginRight=marginRight,
            marginTop=marginTop,
            marginBottom=marginBottom,
            tolerance=tolerance,
        )

        if showScale:
            figure = Plotly.AddColorBar(
                figure,
                values=cbValues,
                nTicks=cbTicks,
                xPosition=cbX,
                width=cbWidth,
                outlineWidth=cbOutlineWidth,
                title=cbTitle,
                subTitle=cbSubTitle,
                units=cbUnits,
                colorScale=colorScale,
                mantissa=mantissa,
            )

        def _fit_3d_scene_ranges(figure, padding=0.08, equalize=True):
            """
            Fits Plotly 3D scene axis ranges to all 3D trace coordinates.

            This is especially important for orthographic projection, where camera eye
            distance is not a reliable way to zoom out and fit the object.

            Parameters
            ----------
            figure : plotly.graph_objects.Figure
                The Plotly figure.
            padding : float , optional
                Fractional padding around the bounding box. Default is 0.08.
            equalize : bool , optional
                If True, all axes are expanded to the same span so the object sits
                inside a cubic scene. This is usually safer for orthographic projection.
                Default is True.

            Returns
            -------
            dict or None
                A scene dictionary with xaxis/yaxis/zaxis ranges, or None if no 3D
                coordinates were found.
            """

            import math

            xs = []
            ys = []
            zs = []

            def _extend_numeric(values, target):
                if values is None:
                    return

                try:
                    iterator = list(values)
                except Exception:
                    iterator = [values]

                for v in iterator:
                    if v is None:
                        continue

                    try:
                        f = float(v)
                    except Exception:
                        continue

                    if math.isfinite(f):
                        target.append(f)

            try:
                traces = list(figure.data)
            except Exception:
                traces = []

            for trace in traces:
                # Mesh3d and Scatter3d both expose x, y, z.
                _extend_numeric(getattr(trace, "x", None), xs)
                _extend_numeric(getattr(trace, "y", None), ys)
                _extend_numeric(getattr(trace, "z", None), zs)

            if not xs or not ys or not zs:
                return None

            xmin = min(xs)
            xmax = max(xs)
            ymin = min(ys)
            ymax = max(ys)
            zmin = min(zs)
            zmax = max(zs)

            xspan = xmax - xmin
            yspan = ymax - ymin
            zspan = zmax - zmin

            maxspan = max(xspan, yspan, zspan)

            if maxspan <= 0:
                maxspan = 1.0

            pad = maxspan * float(padding)

            if equalize:
                cx = 0.5 * (xmin + xmax)
                cy = 0.5 * (ymin + ymax)
                cz = 0.5 * (zmin + zmax)

                half = 0.5 * maxspan + pad

                xmin = cx - half
                xmax = cx + half
                ymin = cy - half
                ymax = cy + half
                zmin = cz - half
                zmax = cz + half
            else:
                xmin -= pad
                xmax += pad
                ymin -= pad
                ymax += pad
                zmin -= pad
                zmax += pad

            return dict(
                xaxis=dict(range=[xmin, xmax], autorange=False),
                yaxis=dict(range=[ymin, ymax], autorange=False),
                zaxis=dict(range=[zmin, zmax], autorange=False),
                aspectmode="data",
            )
        if "ortho" in str(projection).lower():
            camera_settings = dict(
                eye=dict(x=camera[0], y=camera[1], z=camera[2]),
                center=dict(x=center[0], y=center[1], z=center[2]),
                up=dict(x=up[0], y=up[1], z=up[2]),
                projection=dict(type="orthographic"),
            )

            fitted_scene = _fit_3d_scene_ranges(
                figure,
                padding=0.10,
                equalize=True,
            )

            if fitted_scene is None:
                fitted_scene = dict(aspectmode="data")

        else:
            camera_settings = dict(
                eye=dict(x=camera[0], y=camera[1], z=camera[2]),
                center=dict(x=center[0], y=center[1], z=center[2]),
                up=dict(x=up[0], y=up[1], z=up[2]),
                projection=dict(type="perspective"),
            )

            fitted_scene = dict(aspectmode="data")

        figure.update_layout(
            scene_camera=camera_settings,
            scene=fitted_scene,
            autosize=False,
            width=width,
            height=height,
            margin=dict(
                l=marginLeft,
                r=marginRight,
                t=marginTop,
                b=marginBottom,
            ),
        )

        if showFigure:
            Plotly.Show(
                figure=figure,
                renderer=renderer,
                camera=camera,
                center=center,
                up=up,
                projection=projection,
            )
            return None

        return figure

    @staticmethod
    def SmallestFaces(topology, removeCoplanarFaces: bool = False, epsilon: float = 0.001, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns the list of the smallest faces found in the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        removeCoplanarFaces : bool , optional
            If set to True, coplanar faces are removed to find the true smallest faces. Otherwise they are not. Default is False.
        epsilon : float , optional
            The desired epsilon (another form of tolerance) for finding if two faces are coplanar. Default is 0.01.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        Returns
        -------
        list
            The list of the smallest faces found in the input topology.
        
        """
        from topologicpy.Face import Face

        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.SmallestFaces - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        faces = Topology.Faces(topology)
        if len(faces) == 0:
            if not silent:
                print("Topology.SmallestFaces - Error: The input topology parameter does not contain any faces. Returning None.")
            return None
        if len(faces) == 1:
            return faces
        
        if removeCoplanarFaces == True:
            simple_topology = Topology.RemoveCoplanarFaces(topology)
            simple_topology = Topology.RemoveCollinearEdges(simple_topology)
            faces = Topology.Faces(simple_topology)
        face_areas = [Face.Area(face) for face in faces]
        min_area = min(face_areas)
        min_faces = []
        for i, face_area in enumerate(face_areas):
            if abs(min_area - face_area) <= tolerance:
                min_faces.append(faces[i])
        return min_faces
    
    @staticmethod
    def Snapshots(topology, start=None, end=None, key="timestamp", silent: bool = False):
        """
        Returns the list of the stored snapshots within the start and end timestamps.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        start : datetime
            The start date/time.
        end : datetime
            The end date/time.
        key : str , optional
            The dictionary key under which the timestampe is store. Default is "timestamp".
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The list of the snapshots that fit the input parameters.
        
        """
        from topologicpy.Dictionary import Dictionary
        from datetime import datetime
        def is_valid_timestamp(timestamp):
            if isinstance(timestamp, datetime):
                return True
            elif isinstance(timestamp, str):
                try:
                    # Split the timestamp string into date and time parts
                    date_part, time_part = timestamp.split(' ')
                    # Parse the date part
                    date_obj = datetime.strptime(date_part, '%Y-%m-%d')
                    # Split the time part into hours, minutes, and seconds
                    hours, minutes, seconds = map(float, time_part.split(':'))
                    # Check if seconds are within valid range
                    if seconds < 0 or seconds >= 60:
                        return False
                    # Create a datetime object with the parsed date and time parts
                    return datetime(date_obj.year, date_obj.month, date_obj.day, int(hours), int(minutes), int(seconds))
                except ValueError:
                    return False
            else:
                return False
        
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Snapshots - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        if start == None:
            start = datetime.datetime(year=1900, month=1, day=1) # Set the start date to a date in the distant past
        if end == None:
            end = datetime.now() # Set the end date to the present.
        if not is_valid_timestamp(start):
            if not silent:
                print("Topology.Snapshots - Error: The input start parameter is not a valid timestamp. Returning None.")
                return None
        if not is_valid_timestamp(end):
            if not silent:
                print("Topology.Snapshots - Error: The input end parameter is not a valid timestamp. Returning None.")
            return None
        contents = Topology.Contents(topology)    
        snapshots = []
        for content in contents:
            d = Topology.Dictionary(content)
            timestamp = Dictionary.ValueAtKey(d, key)
            timestamp = is_valid_timestamp(timestamp)
            if not timestamp == False:
                if start <= timestamp <= end:
                    snapshots.append(content)
        return snapshots

    @staticmethod
    def SortBySelectors(
        topologies,
        selectors,
        exclusive: bool = False,
        bvhThreshold: int = 256,
        tolerance: float = 0.0001,
        silent: bool = False,
        ):
        """
        Sorts the input list of topologies according to the input list of selectors.

        Parameters
        ----------
        topologies : list
            The input list of topologies.
        selectors : list
            The input list of selectors. These should be vertices.
        exclusive : bool , optional
            If set to True, each topology can be selected by at most one selector.
            Default is False.
        bvhThreshold : int , optional
            BVH acceleration is used only when len(topologies) * len(selectors)
            is greater than or equal to this value. Set to 0 to always attempt BVH.
            Default is 256.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        dict
            A dictionary containing the list of sorted and unsorted topologies.
            The keys are "sorted" and "unsorted".

        """

        from topologicpy.Vertex import Vertex

        if not isinstance(topologies, list):
            if not silent:
                print("Topology.SortBySelectors - Error: The input topologies parameter is not a valid list. Returning None.")
            return None

        if not isinstance(selectors, list):
            if not silent:
                print("Topology.SortBySelectors - Error: The input selectors parameter is not a valid list. Returning None.")
            return None

        topologies = [t for t in topologies if Topology.IsInstance(t, "topology")]

        # NOTE: The original code had this condition inverted.
        if len(topologies) == 0:
            if not silent:
                print("Topology.SortBySelectors - Error: The input topologies parameter does not contain any valid topologies. Returning None.")
            return None

        if len(selectors) == 0:
            return {"sorted": [], "unsorted": topologies}

        n_topologies = len(topologies)
        n_selectors = len(selectors)

        sortedTopologies = []
        selectedTopologies = [0] * n_topologies
        usedTopologies = [0] * n_topologies

        indexByID = {id(t): i for i, t in enumerate(topologies)}

        def _is_valid_vertex(selector):
            try:
                return Topology.IsInstance(selector, "vertex")
            except:
                return False

        def _is_internal(selector, topology):
            try:
                return Vertex.IsInternal(selector, topology, tolerance=tolerance)
            except:
                return False

        def _candidate_indices_from_bvh_result(result):
            """
            Attempts to normalize different possible BVH.Clashes return formats
            into a sorted list of topology indices.
            """
            if result is None:
                return []

            if not isinstance(result, list):
                result = [result]

            indices = []

            for item in result:
                if isinstance(item, int):
                    if 0 <= item < n_topologies:
                        indices.append(item)
                    continue

                if id(item) in indexByID:
                    indices.append(indexByID[id(item)])
                    continue

                if isinstance(item, dict):
                    # Support common possible BVH item dictionary formats.
                    for key in ["topology", "item", "object", "content"]:
                        value = item.get(key, None)
                        if id(value) in indexByID:
                            indices.append(indexByID[id(value)])
                            break

                    for key in ["index", "id"]:
                        value = item.get(key, None)
                        if isinstance(value, int) and 0 <= value < n_topologies:
                            indices.append(value)
                            break

            return sorted(set(indices))

        def _all_candidate_indices():
            return list(range(n_topologies))

        useBVH = (n_topologies * n_selectors) >= max(0, bvhThreshold)
        bvh = None

        if useBVH:
            try:
                from topologicpy.BVH import BVH

                try:
                    bvh = BVH.ByTopologies(topologies, tolerance=tolerance, silent=True)
                except TypeError:
                    # Fallback for older/newer BVH signatures.
                    bvh = BVH.ByTopologies(topologies)

                if bvh is None:
                    useBVH = False

            except:
                useBVH = False

        for selector in selectors:
            found = False

            if not _is_valid_vertex(selector):
                sortedTopologies.append(None)
                continue

            candidateIndices = None

            if useBVH and bvh is not None:
                try:
                    try:
                        candidates = BVH.Clashes(bvh, selector, tolerance=tolerance, silent=True)
                    except TypeError:
                        try:
                            candidates = BVH.Clashes(bvh, selector, tolerance=tolerance)
                        except TypeError:
                            candidates = BVH.Clashes(bvh, selector)

                    candidateIndices = _candidate_indices_from_bvh_result(candidates)

                except:
                    candidateIndices = None

            if candidateIndices is None:
                candidateIndices = _all_candidate_indices()

            for j in candidateIndices:
                if exclusive and usedTopologies[j] == 1:
                    continue

                if _is_internal(selector, topologies[j]):
                    sortedTopologies.append(topologies[j])
                    selectedTopologies[j] = 1

                    if exclusive:
                        usedTopologies[j] = 1

                    found = True
                    break

            if not found:
                sortedTopologies.append(None)

        unsortedTopologies = [
            topologies[i]
            for i in range(n_topologies)
            if selectedTopologies[i] == 0
        ]

        return {"sorted": sortedTopologies, "unsorted": unsortedTopologies}

    @staticmethod
    def SpatialRelationship(topologyA,
                            topologyB,
                            include: list = ["contains", "coveredBy", "covers", "crosses", "disjoint", "equals", "overlaps", "touches","within", "proximity"],
                            proximityValues = [1, 5, 10],
                            proximityLabels = ["near", "intermediate", "far"],
                            useShortestDistance: bool = False,
                            mantissa: int = 6,
                            tolerance: float = 0.0001,
                            silent: bool = False):
        """
        Returns the spatial relationship string between the two input topologies according to OGC / ISO 19107 / DE-9IM / RCC-8

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology
        topologyB : topologic_core. Topology
            The second input topology.
        include : list , optional
            The type(s) of spatial relationships to search for. Default is ["contains", "coveredBy", "covers", "crosses", "disjoint", "equals", "overlaps", "touches","within"].
            - Contains: The inverse of "within," where geometry A contains geometry B. The interior and boundary of B are completely contained within the interior of A.
            - CoveredBy: The inverse of "covers." Geometry A is covered by geometry B, with A's surface lying entirely on B's surface. 
            - Covers: Geometry B lies entirely on the surface of geometry A. This is a weaker version of Contains() as it allows for B to touch A's boundary.            
            - Crosses: The geometries have some interior points in common, but not all of the interior of one is contained in the interior of the other. This often describes a line crossing a polygon or another line.            
            - Disjoint: The boundary and interior of the two geometries do not intersect at all.
            - Equals: The two geometries are exactly the same, representing the same set of points.
            - Intersects: The geometries have at least one point in common. Intersects is the most general relationship, and if any other relationship (except disjoint) is true, then Intersects() is also true.
            - Overlaps: The intersection of the two geometries results in a new, distinct geometry of the same dimension. For example, two overlapping polygons produce a new polygon.
            - Touches: The geometries share at least one point on their boundaries but their interiors do not intersect.
            - Within: The interior and boundary of geometry A are completely contained within the interior of geometry B.
            - Proximity: Classifies the shortest distance between the objects according to proximityValues and proximityLabels.
        proximityValues: list , optional
            The list of maximum distance values that specify the desired proximityLabel.
            This list must be sorted in ascending order and have the same number of elements as the proximityLabels list.
            Objects that are further than the largest specified distance are not classified and not included.
            An object is considered to fall within the range if it is less than or equal to the value in this list.
            If you wish ALL objects to be classified specifiy the last number in this list to be larger than the
            largest distance that can exist between any two objects in the list. Default is [1, 5, 10]
        proximityLabels: list , optional
            The list of range labels (e.g. "near", "intermediate", "far") that correspond to the proximityValues list.
            The list must have the same number of elements as the proximityValues list. Default is ["near", "intermediate", "far"]
        useShortestDistance : bool , optional
            If set to True, the shortest distance between the two input topologies is used.
            Otherwise, the distance between their centroids is used. Default is False.
        mantissa : int , optional
            The desired length of the mantissa. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        str
            The found spatial relationship. One of ["contains", "disjoint", "equals", "overlaps", "touches", "within", "covers", "coveredBy"] or "unknown"

        """
        from topologicpy.Topology import Topology
        
        if not Topology.IsInstance(topologyA, "topology"):
            if not silent:
                print("Topology.SpatialRelationship - Error: The topologyA input parameter is not a valid Topology. Returning None.")
            return None
        
        if not Topology.IsInstance(topologyB, "topology"):
            if not silent:
                print("Topology.SpatialRelationship - Error: The topologyB input parameter is not a valid Topology. Returning None.")
            return None
        
        if len(proximityValues) != len(proximityLabels):
            if not silent:
                print("Topology.SpatialRelationship - Error: the proximityValues and proximityLabels input parameters are not of the same length. Returning None")
            return None

        from topologicpy.Vertex import Vertex
        from topologicpy.Cluster import Cluster

        topologyB = Topology.Copy(topologyB) # To avoid a bug in topologic_core.

        inc = {s.lower() for s in include}


        # ---------- decision order (first-true wins) ----------
        # 1) disjoint
        if "disjoint" in inc and Topology.Disjoint(topologyA, topologyB, tolerance=tolerance, silent=silent):
            return "disjoint"
        # 2) equals
        if "equals" in inc and Topology.Equals(topologyA, topologyB, tolerance=tolerance, silent=silent):
            return "equals"
        # 3) crosses (MUST be before contains/within/covers/coveredBy to avoid your issue)
        if "crosses" in inc and Topology.Crosses(topologyA, topologyB, tolerance=tolerance, silent=silent):
            return "crosses"
        # 4) contains / within (strict)
        if "contains" in inc and Topology.Contains(topologyA, topologyB, tolerance=tolerance, silent=silent):
            return "contains"
        if "within" in inc and Topology.Within(topologyA, topologyB, tolerance=tolerance, silent=silent):
            return "within"
        # 5) covers / coveredBy (non-strict)
        if "covers" in inc and Topology.Covers(topologyA, topologyB, tolerance=tolerance, silent=silent):
            return "covers"
        if ("coveredby" in inc or "coveredBy" in include) and Topology.CoveredBy(topologyA, topologyB, tolerance=tolerance, silent=silent):
            return "coveredBy"
        # 6) overlaps (same dimension only)
        if "overlaps" in inc and Topology.Overlaps(topologyA, topologyB, tolerance=tolerance, silent=silent):
            return "overlaps"
        # 7) touches (incl. vertex-at-endpoint)
        if "touches" in inc and Topology.Touches(topologyA, topologyB, tolerance=tolerance, silent=silent):
            return "touches"
        # 8) proximity
        if "proximity" in inc:
            return Topology.Proximity(topologyA, topologyB, proximityValues, proximityLabels, useShortestDistance=useShortestDistance, tolerance=tolerance, silent=silent)
        
        return None

# Spatial Relationships

   # Helpers

    def _ext_boundary_or_none(t, tolerance: float = 0.0001, silent: bool = False):
        # Cells/Shells use their external shell; closed shells and wires return None
        if Topology.IsInstance(t, "CellComplex"):
            return Topology.ExternalBoundary(t, silent=True)
        if Topology.IsInstance(t, "Shell"):
            eb = Topology.ExternalBoundary(t, silent=True)
            if eb == None:
                return t
        return Topology.ExternalBoundary(t, silent=True)

    def _interior_intersection_exists(
        a,
        b,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Returns True if the interiors of the two input topologies intersect.

        For equal-dimensional topologies, a same-dimensional intersection
        necessarily represents interior-interior intersection. This avoids
        subtracting external boundaries from the intersection, which is not
        reliable for mixed-dimensional Boolean operations.

        For mixed-dimensional topologies, the previous boundary-subtraction
        strategy is retained as a fallback.
        """
        from topologicpy.Cluster import Cluster

        inter = Topology.Intersect(
            a,
            b,
            tolerance=tolerance,
            silent=silent
        )

        if inter is None:
            return False

        da = Topology.Dimensionality(a)
        db = Topology.Dimensionality(b)
        di = Topology.Dimensionality(inter)

        # ------------------------------------------------------------------
        # Equal-dimensional operands
        #
        # If their intersection has the same dimension, their interiors
        # intersect.
        #
        # Examples:
        #
        # Cell ∩ Cell -> Cell      => interiors intersect
        # Face ∩ Face -> Face      => interiors intersect
        #
        # A lower-dimensional result represents boundary-only contact.
        # ------------------------------------------------------------------

        if da == db:
            return di == da

        # ------------------------------------------------------------------
        # Mixed-dimensional fallback.
        # ------------------------------------------------------------------

        eb_parts = []

        eb_a = Topology._ext_boundary_or_none(
            a,
            tolerance=tolerance,
            silent=silent
        )

        eb_b = Topology._ext_boundary_or_none(
            b,
            tolerance=tolerance,
            silent=silent
        )

        if eb_a is not None:
            eb_parts.append(eb_a)

        if eb_b is not None:
            eb_parts.append(eb_b)

        if not eb_parts:
            return True

        eb_union = Cluster.ByTopologies(
            eb_parts
        )

        interior_part = Topology.Difference(
            inter,
            eb_union,
            tolerance=tolerance,
            silent=silent
        )

        return interior_part is not None

    def _edge_endpoints(e, tolerance: float = 0.0001, silent: bool = False):
        """Return the two endpoint vertices of an Edge e."""
        from topologicpy.Edge import Edge
        try:
            v0 = Edge.StartVertex(e, silent=True)
            v1 = Edge.EndVertex(e, silent=True)
            return [v0, v1] if (v0 is not None and v1 is not None) else []
        except Exception:
            # Fallback: try boundary vertices if Start/End not available
            eb = Topology._ext_boundary_or_none(e)
            return Topology.Vertices(eb) or []
    
    def _wire_endpoints(w, tolerance: float = 0.0001, silent: bool = False):
        """Return the two endpoint vertices of a wire w."""
        from topologicpy.Wire import Wire
        try:
            v0 = Wire.StartVertex(w, silent=True)
            v1 = Wire.EndVertex(w, silent=True)
            return [v0, v1] if (v0 is not None and v1 is not None) else []
        except Exception:
            # Fallback: try boundary vertices if Start/End not available
            eb = Topology._ext_boundary_or_none(w)
            return Topology.Vertices(w) or []

    def _is_endpoint(v, t, tolerance: float = 0.0001, silent: bool = False):
        """True if vertex v coincides with an endpoint of edge or wire t (within tolerance)."""
        from topologicpy.Vertex import Vertex

        if Topology.IsInstance(t, "edge"):
            for p in Topology._edge_endpoints(t):
                # Prefer exact topologic test; backstop with metric distance
                if Topology.IsSame(v, p):
                    return True
                try:
                    if Vertex.Distance(v, p) <= tolerance:
                        return True
                except Exception:
                    pass
        elif Topology.IsInstance(t, "wire"):
            for p in Topology._wire_endpoints(t):
                # Prefer exact topologic test; backstop with metric distance
                if Topology.IsSame(v, p):
                    return True
                try:
                    if Vertex.Distance(v, p) <= tolerance:
                        return True
                except Exception:
                    pass
        return False
    
    @staticmethod
    def Proximity(
        topologyA,
        topologyB,
        proximityValues,
        proximityLabels,
        useShortestDistance: bool = False,
        tolerance: float = 0.0001,
        silent: bool = False,
    ):
        """
        Returns the proximity label between two input topologies.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topolgoyB : topologic_core.Topology
            The second input topology.
        proximityValues : list
            A list of distance threshold values sorted in ascending order.
        proximityLabels : list
            A list of proximity labels corresponding to the proximityValues list.
        useShortestDistance : bool , optional
            If set to True, the shortest distance between the two input topologies is used.
            Otherwise, the distance between their centroids is used. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        str or None
            The proximity label corresponding to the first threshold greater than or equal
            to the computed distance, or None if no threshold is matched.
        """
        from topologicpy.Vertex import Vertex
        a = topologyA
        b = topologyB

        if not Topology.IsInstance(a, "Topology"):
            if not silent:
                print("Topology.Proximity - Error: The input a parameter is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(b, "Topology"):
            if not silent:
                print("Topology.Proximity - Error: The input b parameter is not a valid topology. Returning None.")
            return None

        if not isinstance(proximityValues, (list, tuple)):
            if not silent:
                print("Topology.Proximity - Error: The proximityValues input parameter is not a list or a tuple. Returning None.")
            return None
        if not isinstance(proximityLabels, (list, tuple)):
            if not silent:
                print("Topology.Proximity - Error: The proximityLabels input parameter is not a list or a tuple. Returning None.")
            return None

        if len(proximityValues) == 0:
            if not silent:
                print("Topology.Proximity - Error: The proximityValues input parameter is an empty list or tuple. Returning None.")
            return None
        
        if len(proximityLabels) == 0:
            if not silent:
                print("Topology.Proximity - Error: The proximityLabels input parameter is an empty list or tuple. Returning None.")
            return None
        
        if len(proximityValues) != len(proximityLabels):
            if not silent:
                print("Topology.Proximity - Error: The proximityValues and proximityLabels input parameters are not equal in length. Returning None.")
            return None

        try:
            bands = sorted(
                [(float(v), str(proximityLabels[i])) for i, v in enumerate(proximityValues)],
                key=lambda x: x[0],
            )
        except Exception:
            return None

        sd = None

        if useShortestDistance:
            try:
                sd = Topology.ShortestDistance(a, b, tolerance=tolerance, silent=True)
                sd = float(sd)
            except Exception:
                sd = None

        if sd is None:
            try:
                va = Topology.Centroid(a)
                vb = Topology.Centroid(b)
                ca = Vertex.Coordinates(va)
                cb = Vertex.Coordinates(vb)
                dx = float(ca[0]) - float(cb[0])
                dy = float(ca[1]) - float(cb[1])
                dz = float(ca[2]) - float(cb[2])
                sd = (dx * dx + dy * dy + dz * dz) ** 0.5
            except Exception:
                if not silent:
                    print("proximity - Error: Could not compute distance. Returning None.")
                return None

        for upper_bound, label in bands:
            if sd <= upper_bound + tolerance:
                return label

        return None

    @staticmethod
    def Contains(topologyA, topologyB, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns True if the input topologyA contains the input topologyB. Returns False otherwise.

        Containment means that topologyB lies completely within topologyA and does not intersect
        the external boundary of topologyA.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The input containing topology.
        topologyB : topologic_core.Topology
            The input contained topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if topologyA contains topologyB. False otherwise. Returns None if either input is invalid.

        """
        # The inverse of "within," where geometry A contains geometry B.
        # The interior and boundary of B are completely contained within the interior of A.
        # Boundary of B should not intersect with the boundary of A.
        a = topologyA
        b = topologyB
        if not Topology.IsInstance(a, "Topology"):
            if not silent:
                print("Topology.Contains - Error: The input a parameter is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(b, "Topology"):
            if not silent:
                print("Topology.Contains - Error: The input b parameter is not a valid topology. Returning None.")
            return None
        # Contains(a, b) == True iff no part of b lies outside a.
        # The previous implementation rejected the case with Intersect(b, eb_a) is
        # not None, but that intersects b with a's boundary, which is non-None
        # whenever b touches a's boundary — so it wrongly returned False for a
        # boundary-touching containment. Rely on Difference alone.
        return Topology.Difference(b, a, tolerance=tolerance, silent=True) == None

    @staticmethod
    def CoveredBy(topologyA, topologyB, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns True if the input topologyA is covered by the input topologyB. Returns False otherwise.

        CoveredBy is the inverse of Covers.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The input covered topology.
        topologyB : topologic_core.Topology
            The input covering topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if topologyA is covered by topologyB. False otherwise. Returns None if either input is invalid.

        """
        a = topologyA
        b = topologyB
        if not Topology.IsInstance(a, "Topology"):
            if not silent:
                print("Topology.CoveredBy - Error: The input a parameter is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(b, "Topology"):
            if not silent:
                print("Topology.CoveredBy - Error: The input b parameter is not a valid topology. Returning None.")
            return None
        return Topology.Covers(b, a, tolerance  = tolerance, silent = silent)

    @staticmethod
    def Covers(topologyA, topologyB, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns True if the input topologyA covers the input topologyB. Returns False otherwise.

        Coverage means that no part of topologyB lies outside topologyA. Boundary contact is allowed.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The input covering topology.
        topologyB : topologic_core.Topology
            The input covered topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if topologyA covers topologyB. False otherwise. Returns None if either input is invalid.

        """
        a = topologyA
        b = topologyB
        if not Topology.IsInstance(a, "Topology"):
            if not silent:
                print("Topology.Covers - Error: The input a parameter is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(b, "Topology"):
            if not silent:
                print("Topology.Covers - Error: The input b parameter is not a valid topology. Returning None.")
            return None

        result = Topology.Difference(b, a, tolerance=tolerance, silent=silent)

        return result is None

    @staticmethod
    def Crosses(topologyA, topologyB, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns True if the input topologyA crosses the input topologyB. Returns False otherwise.

        Crossing means that the two topologies intersect in a manner where their interiors intersect,
        but neither topology simply contains or covers the other. For one-dimensional topologies,
        crossing occurs when the intersection is an interior point of both topologies rather than
        a shared segment or endpoint contact.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if topologyA crosses topologyB. False otherwise. Returns None if either input is invalid.

        """
        a = topologyA
        b = topologyB
        if not Topology.IsInstance(a, "Topology"):
            if not silent:
                print("Topology.Crosses - Error: The input a parameter is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(b, "Topology"):
            if not silent:
                print("Topology.Crosses - Error: The input b parameter is not a valid topology. Returning None.")
            return None
        da, db = Topology.Dimensionality(a), Topology.Dimensionality(b)
        inter = Topology.Intersect(a, b, tolerance=tolerance, silent=silent)
        if inter is None:
            return False

        # 1D–1D special case (Edges/Wires):
        # crosses iff the intersection is a point that lies in the INTERIOR of both edges
        if da == 1 and db == 1:
            inter_edges = Topology.Edges(inter, silent=True) or []
            if inter_edges:
                # Shared segment → not crosses (this is overlaps)
                return False
            inter_verts = Topology.Vertices(inter, silent=True) or []
            if not inter_verts:
                return False
            v = inter_verts[0]
            # interior point of both → neither endpoint
            return (not Topology._is_endpoint(v, a)) and (not Topology._is_endpoint(v, b))

        # 1D–2D or 1D–3D: interior–interior contact and not inclusion → crosses
        if (da == 1 and db in (2, 3)) or (db == 1 and da in (2, 3)):
            # exclude inclusion/coverage
            if Topology.Covers(a, b, tolerance  = tolerance, silent = silent) or Topology.Covers(b, a, tolerance  = tolerance, silent = silent):
                return False
            return Topology.Intersect(a,b) is not None

        # Do NOT classify 0D–2D/3D as crosses (point-in-region/volume → within/coveredBy)
        # 0D–1D interior handled by other logic (if you support vertex-on-edge crosses)

        return False

    @staticmethod
    def Disjoint(topologyA, topologyB, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns True if the input topologyA is disjoint from the input topologyB. Returns False otherwise.

        Two topologies are disjoint if they do not intersect.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if topologyA is disjoint from topologyB. False otherwise. Returns None if either input is invalid.

        """
        a = topologyA
        b = topologyB
        if not Topology.IsInstance(a, "Topology"):
            if not silent:
                print("Topology.Disjoint - Error: The input a parameter is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(b, "Topology"):
            if not silent:
                print("Topology.Disjoint - Error: The input b parameter is not a valid topology. Returning None.")
            return None
        return Topology.Intersect(a, b, tolerance=tolerance, silent=silent) is None

    @staticmethod
    def Equals(topologyA, topologyB, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns True if the input topologyA is equal to the input topologyB. Returns False otherwise.

        Two topologies are considered equal if their symmetric difference is None within the
        specified tolerance. For CellComplex inputs, the external boundary is used for comparison.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if topologyA is equal to topologyB. False otherwise. Returns None if either input is invalid.

        """
        a = topologyA
        b = topologyB
        if not Topology.IsInstance(a, "Topology"):
            if not silent:
                print("Topology.Equals - Error: The input a parameter is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(b, "Topology"):
            if not silent:
                print("Topology.Equals - Error: The input b parameter is not a valid topology. Returning None.")
            return None
        a_ = Topology.ExternalBoundary(a, silent=True) if (Topology.IsInstance(a, "CellComplex")) else a
        b_ = Topology.ExternalBoundary(b, silent=True) if (Topology.IsInstance(b, "CellComplex")) else b
        # Two topologies are equal iff neither has any part outside the other.
        # Using symmetric-difference (XOR) is None was incorrect: XOR is None
        # whenever one operand is fully contained by the other (XOR short-circuits
        # to None when one of the two directional subtractions is empty), so a
        # concentric inner face was wrongly reported equal to its containing
        # outer face. Test both directional differences instead.
        if Topology.Difference(a, b, tolerance=tolerance, silent=True) is not None:
            return False
        if Topology.Difference(b, a, tolerance=tolerance, silent=True) is not None:
            return False
        return True

    @staticmethod
    def Overlaps(topologyA, topologyB, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns True if the input topologyA overlaps the input topologyB. Returns False otherwise.

        Overlap means that the two topologies have the same dimensionality, are not equal, and
        their intersection produces a distinct topology of the same dimensionality. Cases where
        one topology covers the other are not considered overlaps.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if topologyA overlaps topologyB. False otherwise. Returns None if either input is invalid.

        """
        # The intersection of the two geometries results in a new, distinct geometry of the same dimension.
        # For example, two overlapping polygons produce a new polygon.
        a = topologyA
        b = topologyB
        if not Topology.IsInstance(a, "Topology"):
            if not silent:
                print("Topology.Overlaps - Error: The input a parameter is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(b, "Topology"):
            if not silent:
                print("Topology.Overlaps - Error: The input b parameter is not a valid topology. Returning None.")
            return None

        if Topology.Dimensionality(a) != Topology.Dimensionality(b):
            return False
        if Topology.Equals(a, b, tolerance=tolerance, silent=True):
            return False
        inter = Topology.Intersect(a, b, tolerance=tolerance, silent=True)
        if inter == None:
            return False
        if Topology.Dimensionality(inter) != Topology.Dimensionality(a):
            return False
        # if not _intersects(a, b):
        #     return False
        if Topology.Covers(a, b) or Topology.Covers(b, a):
            return False
        return Topology.SymmetricDifference(a, b, tolerance=tolerance, silent=silent) is not None

    @staticmethod
    def Touches(
        topologyA,
        topologyB,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Returns True if the input topologyA touches the input topologyB.
        Returns False otherwise.

        Two topologies are considered to touch when their boundaries are in
        contact while their interiors do not intersect. For equal-dimensional
        two- and three-dimensional topologies, boundary contact is determined
        using shortest distance rather than relying solely on Boolean
        intersection, since some backends may not return lower-dimensional
        intersections for edge- or vertex-only contact.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        bool
            True if topologyA touches topologyB. False otherwise.
            Returns None if either input is invalid.
        """

        if not Topology.IsInstance(topologyA, "Topology"):
            if not silent:
                print(
                    "Topology.Touches - Error: "
                    "The input topologyA parameter is not a valid topology. "
                    "Returning None."
                )
            return None

        if not Topology.IsInstance(topologyB, "Topology"):
            if not silent:
                print(
                    "Topology.Touches - Error: "
                    "The input topologyB parameter is not a valid topology. "
                    "Returning None."
                )
            return None

        a = topologyA
        b = topologyB

        da = Topology.Dimensionality(a)
        db = Topology.Dimensionality(b)

        # ==================================================================
        # Equal-dimensional 2D / 3D topologies
        # ==================================================================
        #
        # A same-dimensional intersection means that the interiors overlap,
        # so the relationship cannot be Touches.
        #
        # If no same-dimensional intersection exists, determine boundary
        # contact from the shortest boundary distance. This handles face-,
        # edge-, and vertex-contact consistently across backends.
        # ==================================================================

        if da == db and da >= 2:

            inter = Topology.Intersect(
                a,
                b,
                tolerance=tolerance,
                silent=True
            )

            if inter is not None:

                di = Topology.Dimensionality(inter)

                if di == da:
                    return False

            if Topology.IsInstance(a, "Shell"):
                eb_a = a
            else:
                eb_a = Topology._ext_boundary_or_none(
                    a,
                    tolerance=tolerance,
                    silent=True
                )

            if Topology.IsInstance(b, "Shell"):
                eb_b = b
            else:
                eb_b = Topology._ext_boundary_or_none(
                    b,
                    tolerance=tolerance,
                    silent=True
                )

            if eb_a is None or eb_b is None:
                return False

            distance = Topology.ShortestDistance(
                eb_a,
                eb_b,
                mantissa=12,
                tolerance=tolerance,
                silent=True
            )

            if distance is None:
                return False

            return distance <= tolerance

        # ==================================================================
        # Remaining dimension combinations require a direct intersection.
        # ==================================================================

        inter = Topology.Intersect(
            a,
            b,
            tolerance=tolerance,
            silent=True
        )

        if inter is None:
            return False

        # ------------------------------------------------------------------
        # 0D - 0D
        # ------------------------------------------------------------------

        if da == 0 and db == 0:
            return True

        # ------------------------------------------------------------------
        # 0D - 1D
        # ------------------------------------------------------------------

        if da == 0 and db == 1:
            return Topology._is_endpoint(
                a,
                b,
                tolerance=tolerance,
                silent=True
            )

        if db == 0 and da == 1:
            return Topology._is_endpoint(
                b,
                a,
                tolerance=tolerance,
                silent=True
            )

        # ------------------------------------------------------------------
        # 1D - 1D
        # ------------------------------------------------------------------

        if da == 1 and db == 1:

            inter_edges = Topology.Edges(
                inter,
                silent=True
            ) or []

            # Shared length means overlap, not touch.
            if inter_edges:
                return False

            inter_vertices = Topology.Vertices(
                inter,
                silent=True
            ) or []

            if not inter_vertices:
                return False

            for vertex in inter_vertices:

                if (
                    Topology._is_endpoint(
                        vertex,
                        a,
                        tolerance=tolerance,
                        silent=True
                    )
                    or
                    Topology._is_endpoint(
                        vertex,
                        b,
                        tolerance=tolerance,
                        silent=True
                    )
                ):
                    return True

            return False

        # ------------------------------------------------------------------
        # 1D - 2D
        # ------------------------------------------------------------------

        if (
            (da == 1 and db == 2)
            or
            (da == 2 and db == 1)
        ):

            edge_like = a if da == 1 else b

            inter_edges = Topology.Edges(
                inter,
                silent=True
            ) or []

            # Shared edge length means the 1D topology lies on/in the
            # 2D topology rather than merely touching it.
            if inter_edges:
                return False

            inter_vertices = Topology.Vertices(
                inter,
                silent=True
            ) or []

            if not inter_vertices:
                return False

            for vertex in inter_vertices:

                if Topology._is_endpoint(
                    vertex,
                    edge_like,
                    tolerance=tolerance,
                    silent=True
                ):
                    return True

            return False

        # ------------------------------------------------------------------
        # Remaining mixed-dimensional cases
        # ------------------------------------------------------------------

        if Topology._interior_intersection_exists(
            a,
            b,
            tolerance=tolerance,
            silent=True
        ):
            return False

        if Topology.IsInstance(a, "Shell"):
            eb_a = a
        else:
            eb_a = Topology._ext_boundary_or_none(
                a,
                tolerance=tolerance,
                silent=True
            )

        if Topology.IsInstance(b, "Shell"):
            eb_b = b
        else:
            eb_b = Topology._ext_boundary_or_none(
                b,
                tolerance=tolerance,
                silent=True
            )

        if eb_a is None or eb_b is None:
            return False

        distance = Topology.ShortestDistance(
            eb_a,
            eb_b,
            mantissa=12,
            tolerance=tolerance,
            silent=True
        )

        if distance is None:
            return False

        return distance <= tolerance

    @staticmethod
    def Within(topologyA, topologyB, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns True if the input topologyA is within the input topologyB. Returns False otherwise.

        Within is the inverse of Contains.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The input contained topology.
        topologyB : topologic_core.Topology
            The input containing topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if topologyA is within topologyB. False otherwise. Returns None if either input is invalid.

        """
        a = topologyA
        b = topologyB
        if not Topology.IsInstance(a, "Topology"):
            if not silent:
                print("Topology.Within - Error: The input a parameter is not a valid topology. Returning None.")
            return None

        if not Topology.IsInstance(b, "Topology"):
            if not silent:
                print("Topology.Within - Error: The input b parameter is not a valid topology. Returning None.")
            return None
        return Topology.Contains(b, a, tolerance = tolerance, silent = silent)

    @staticmethod
    def Spin(topology, origin=None, triangulate: bool = True, direction: list = [0, 0, 1], angle: float = 360, sides: int = 16,
                     tolerance: float = 0.0001, silent: bool = False):
        """
        Spins the input topology around an axis to create a new topology.See https://en.wikipedia.org/wiki/Solid_of_revolution.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        origin : topologic_core.Vertex
            The origin (center) of the spin.
        triangulate : bool , optional
            If set to True, the result will be triangulated. Default is True.
        direction : list , optional
            The vector representing the direction of the spin axis. Default is [0, 0, 1].
        angle : float , optional
            The angle in degrees for the spin. Default is 360.
        sides : int , optional
            The desired number of sides. Default is 16.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.


        Returns
        -------
        topologic_core.Topology
            The spun topology.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Cluster import Cluster

        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Spin - Error: the input topology parameter is not a valid topology. Returning None.")
                return None
        if not Topology.IsInstance(origin, "Vertex"):
            if not silent:
                print("Topology.Spin - Error: the input origin parameter is not a valid vertex. Returning None.")
                return None
        topologies = []
        unit_degree = angle / float(sides)
        for i in range(sides+1):
            tempTopology = Topology.Rotate(topology, origin=origin, axis=direction, angle=unit_degree*i)
            if tempTopology:
                topologies.append(tempTopology)
        returnTopology = None
        if Topology.Type(topology) == Topology.TypeID("Vertex"):
            returnTopology = Wire.ByVertices(topologies, close=False, tolerance=tolerance, silent=silent)
        elif Topology.Type(topology) == Topology.TypeID("Edge"):
            try:
                returnTopology = Shell.ByWires(topologies,triangulate=triangulate, tolerance=tolerance, silent=True)
            except:
                try:
                    returnTopology = Cluster.ByTopologies(topologies)
                except:
                    returnTopology = None
        elif Topology.Type(topology) == Topology.TypeID("Wire"):
            if Wire.IsClosed(topology):
                #returnTopology = Cell.ByWires(topologies, triangulate=triangulate, tolerance=tolerance, silent=True)
                try:
                    returnTopology = Cell.ByWires(topologies, triangulate=triangulate, tolerance=tolerance, silent=True)
                    returnTopology = Cell.ExternalBoundary(returnTopology)
                    returnTopology = Cell.ByShell(returnTopology)
                except:
                    try:
                        returnTopology = CellComplex.ByWires(topologies, tolerance=tolerance)
                        try:
                            returnTopology = CellComplex.ExternalBoundary(returnTopology)
                        except:
                            pass
                    except:
                        try:
                            returnTopology = Shell.ByWires(topologies, triangulate=triangulate, tolerance=tolerance, silent=True)
                        except:
                            try:
                                returnTopology = Cluster.ByTopologies(topologies)
                            except:
                                returnTopology = None
            else:
                Shell.ByWires(topologies, triangulate=triangulate, tolerance=tolerance, silent=True)
                try:
                    returnTopology = Shell.ByWires(topologies, triangulate=triangulate, tolerance=tolerance, silent=True)
                except:
                    try:
                        returnTopology = Cluster.ByTopologies(topologies)
                    except:
                        returnTopology = None
        elif Topology.IsInstance(topology, "Face"):
            external_wires = []
            for t in topologies:
                external_wires.append(Core.Face.ExternalBoundary(t))
            try:
                returnTopology = CellComplex.ByWires(external_wires, tolerance=tolerance)
            except:
                try:
                    returnTopology = Shell.ByWires(external_wires, triangulate=triangulate, tolerance=tolerance, silent=True)
                except:
                    try:
                        returnTopology = Cluster.ByTopologies(topologies)
                    except:
                        returnTopology = None
        else:
            returnTopology = Topology.SelfMerge(Cluster.ByTopologies(topologies), tolerance=tolerance)
        if not returnTopology:
            return Cluster.ByTopologies(topologies)
        if Topology.Type(returnTopology) == Topology.TypeID("Shell"):
            try:
                new_t = Cell.ByShell(returnTopology)
                if new_t:
                    returnTopology = new_t
            except:
                pass
        return returnTopology
    
    @staticmethod
    def SubCombinations(topology,
                        subTopologyType=None,
                        minSize: int = 2,
                        maxSize: int = None,
                        maxCombinations: int = 100,
                        timeLimit: int = 10,
                        removeCoplanarFaces: bool = False,
                        removeCollinearEdges: bool = False,
                        tolerance: float = 0.001,
                        silent: bool = False):
        """
        Creates connected sub-combination topologies of the input topology.
        Warning: This is prone to combinatorial explosion.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The input topology. This cannot be vertex or edge.
        subTopologyType : str , optional except when topology is a Cluster
            The type of subTopology to include in the combinations.
        minSize : int , optional
            The minimum number of subtopologies to include in a combination.
            This number cannot be less than 2. Default is 2.
        maxSize : int , optional
            The maximum number of subtopologies to include in a combination.
            Default is None which means the maximum will be set to the number of
            subtopologies minus 1.
        maxCombinations : int , optional
            The maximum number of combinations to create. Default is 100.
        timeLimit : int , optional
            The time limit in seconds. Default is 10 seconds.
        removeCoplanarFaces : bool , optional
            If set to True, coplanar faces are removed. Otherwise they are not.
            Default is False.
        removeCollinearEdges : bool , optional
            If set to True, collinear edges are removed. Otherwise they are not.
            Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of created sub-combinations.

        """

        from topologicpy.Cluster import Cluster
        from topologicpy.Graph import Graph
        from topologicpy.Topology import Topology
        from topologicpy.Dictionary import Dictionary
        from topologicpy.Helper import Helper
        import random
        import time

        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            TGraph = None
            is_tgraph = False

        if Topology.IsInstance(topology, "cluster") and subTopologyType is None:
            if not silent:
                print("Topology.SubCombinations - Error: The topology input parameter is a cluster but the subTopologyType is not specified. Returning None.")
            return None

        if not is_tgraph and (Topology.IsInstance(topology, "vertex") or Topology.IsInstance(topology, "edge")):
            if not silent:
                print("Topology.SubCombinations - Error: The topology input parameter cannot be a vertex or an edge. Returning None.")
            return None

        if not is_tgraph and not Topology.IsInstance(topology, "Topology") and not Topology.IsInstance(topology, "Graph"):
            if not silent:
                print("Topology.SubCombinations - Error: The topology input parameter is not a valid topology or graph. Returning None.")
            return None

        mapping = {
            "cellcomplex": "cell",
            "cell": "face",
            "shell": "face",
            "face": "edge",
            "wire": "edge",
            "graph": "vertex",
            "tgraph": "vertex",
        }

        if is_tgraph:
            type_string = "tgraph"
        else:
            type_string = Topology.TypeAsString(topology).lower()
            if type_string == "graph":
                type_string = "graph"

        if type_string not in mapping:
            if not silent:
                print(f"Topology.SubCombinations - Error: The input topology type ({type_string}) is not supported. Returning None.")
            return None

        if subTopologyType is None:
            subTopologyType = mapping[type_string]

        subTopologyType = subTopologyType.lower()

        if subTopologyType not in ["cell", "face", "edge", "vertex"]:
            if not silent:
                print(f"Topology.SubCombinations - Error: Unknown subTopologyType: {subTopologyType}. Returning None.")
            return None

        if is_tgraph and subTopologyType != "vertex":
            if not silent:
                print("Topology.SubCombinations - Error: TGraph only supports subTopologyType='vertex'. Returning None.")
            return None

        if ((type_string in ["cell", "shell"]) and subTopologyType not in ["face", "edge"]) or \
        ((type_string in ["wire", "face"]) and subTopologyType != "edge"):
            if not silent:
                print(f"Topology.SubCombinations - Error: The subTopology type {subTopologyType} is not appropriate for topology of type {type_string}. Returning None.")
            return None

        if is_tgraph:
            active_vertex_indices = TGraph._ActiveVertexIndices(topology)
            num_subtopologies = len(active_vertex_indices)

            if num_subtopologies < 2:
                if not silent:
                    print("Topology.SubCombinations - Warning: Not enough vertices found. Returning empty list.")
                return []

            position_by_vertex_index = {vertex_index: i for i, vertex_index in enumerate(active_vertex_indices)}

            adjacency = {i: [] for i in range(num_subtopologies)}
            for vertex_index in active_vertex_indices:
                i = position_by_vertex_index[vertex_index]
                neighbours = TGraph.AdjacentIndices(topology, vertex_index, mode="all")
                for neighbour in neighbours:
                    if neighbour in position_by_vertex_index:
                        j = position_by_vertex_index[neighbour]
                        if j != i and j not in adjacency[i]:
                            adjacency[i].append(j)

            all_subtopologies = active_vertex_indices

        else:
            all_subtopologies = Topology.SubTopologies(topology, subTopologyType=subTopologyType, silent=silent)
            num_subtopologies = len(all_subtopologies)

            if num_subtopologies < 2:
                if not silent:
                    print("Topology.SubCombinations - Warning: Not enough subtopologies found. Returning empty list.")
                return []

            subt_label_key = "__index__"
            all_subtopologies = [
                Topology.SetDictionary(subt, Dictionary.ByKeyValue(subt_label_key, i))
                for i, subt in enumerate(all_subtopologies)
            ]

            adjacency = Dictionary.AdjacencyDictionary(
                topology,
                subTopologyType=subTopologyType,
                labelKey=subt_label_key,
                weightKey=None,
                includeWeights=False
            )

        indices = list(range(num_subtopologies))

        minSize = max(2, int(minSize))
        maxSize = num_subtopologies - 1 if maxSize is None else min(int(maxSize), num_subtopologies - 1)

        if maxSize < minSize:
            if not silent:
                print("Topology.SubCombinations - Warning: The requested size range is empty. Returning empty list.")
            return []

        group_sizes = list(range(minSize, maxSize + 1))
        num_sizes = len(group_sizes)

        if num_sizes < 1:
            return []

        per_size_combinations = max(1, int(maxCombinations) // num_sizes)
        per_size_time = float(timeLimit) / float(num_sizes) if num_sizes > 0 else float(timeLimit)

        results = []
        seen_groups = set()

        for group_size in reversed(group_sizes):
            size_start_time = time.time()
            remaining = per_size_combinations
            tries = 0
            max_tries = max(10, per_size_combinations * 10)

            while remaining > 0 and (time.time() - size_start_time) < per_size_time and tries < max_tries:
                random.shuffle(indices)

                for seed in indices:
                    if (time.time() - size_start_time) > per_size_time:
                        break

                    group = Helper.Grow(seed, group_size, adjacency, visited_global=seen_groups)

                    if group:
                        key = tuple(sorted(group))
                        if key not in seen_groups:
                            tries += 1
                            seen_groups.add(key)
                            results.append(group)
                            remaining -= 1

                    if remaining <= 0 or tries >= max_tries:
                        break

        return_combinations = []

        for result in reversed(results):
            if is_tgraph:
                original_vertex_indices = [all_subtopologies[i] for i in result]
                combination = TGraph.Subgraph(topology, original_vertex_indices, induced=True)
                return_combinations.append(combination)
                continue

            subtopologies = [all_subtopologies[i] for i in result]

            if Topology.IsInstance(topology, "Graph"):
                edges = Graph.Edges(topology, vertices=subtopologies)
                combination = Graph.ByVerticesEdges(subtopologies, edges)

            else:
                combination = Topology.SelfMerge(Cluster.ByTopologies(subtopologies), tolerance=tolerance)

                if removeCollinearEdges:
                    if Topology.IsInstance(combination, "face") or Topology.IsInstance(combination, "wire"):
                        combination = Topology.RemoveCollinearEdges(combination, tolerance=tolerance)

                if removeCoplanarFaces:
                    if Topology.IsInstance(combination, "cellcomplex") or Topology.IsInstance(combination, "cell") or Topology.IsInstance(combination, "shell"):
                        combination = Topology.RemoveCoplanarFaces(combination, tolerance=tolerance)

            return_combinations.append(combination)

        return return_combinations
    
    @staticmethod
    def SymDif(topologyA, topologyB, tranDict: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns the symmetric difference (XOR) of the input operand topologies. See https://en.wikipedia.org/wiki/Boolean_operation.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tranDict : bool , optional
            If set to True the dictionaries of the operands are merged and transferred to the result. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            the resultant topology.

        """
        return Topology._Boolean(topologyA=topologyA, topologyB=topologyB, operation="symdif", tranDict=tranDict, tolerance=tolerance, silent=silent)

    @staticmethod
    def SymmetricDifference(topologyA, topologyB, tranDict: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns the symmetric difference (XOR) of the input operand topologies. See https://en.wikipedia.org/wiki/Boolean_operation.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tranDict : bool , optional
            If set to True the dictionaries of the operands are merged and transferred to the result. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            the resultant topology.

        """
        return Topology._Boolean(topologyA=topologyA, topologyB=topologyB, operation="symdif", tranDict=tranDict, tolerance=tolerance, silent=silent)

    @staticmethod
    def Taper(
        topology,
        origin=None,
        ratioRange: list = [0, 1],
        triangulate: bool = False,
        mantissa: int = 6,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Tapers the input topology along its Z-axis based on the input ratio range.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        origin : topologic_core.Vertex , optional
            The desired origin for tapering. If not specified, the centroid of
            the input topology is used. The tapering uses the X and Y coordinates
            of the specified origin, but uses the Z coordinate of each vertex
            being tapered. Default is None.
        ratioRange : list , optional
            The desired ratio range. This specifies a linear range from bottom
            to top for tapering the vertices. A value of 0 means no tapering and
            1 means maximum inward tapering. Negative numbers result in outward
            tapering. Values greater than 1 are clamped to 1.
            Default is [0, 1].
        triangulate : bool , optional
            If set to True, the input topology is triangulated before tapering.
            Otherwise, it is not triangulated. Default is False.
        mantissa : int , optional
            The number of decimal places to round coordinates to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Vertices are not moved if the calculated
            movement distance is at or below this tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Topology
            The tapered topology.
        """
        from topologicpy.Vertex import Vertex

        # ------------------------------------------------------------------
        # Validate topology
        # ------------------------------------------------------------------

        if not Topology.IsInstance(
            topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.Taper - Error: The input topology parameter "
                    "is not a valid topology. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Validate ratio range
        # ------------------------------------------------------------------

        if (
            not isinstance(ratioRange, (list, tuple))
            or len(ratioRange) != 2
        ):
            if not silent:
                print(
                    "Topology.Taper - Error: The input ratioRange parameter "
                    "must contain exactly two numeric values. Returning None."
                )
            return None

        try:
            ratioRange = [
                min(1.0, float(ratioRange[0])),
                min(1.0, float(ratioRange[1]))
            ]

        except Exception:
            if not silent:
                print(
                    "Topology.Taper - Error: The input ratioRange parameter "
                    "must contain exactly two numeric values. Returning None."
                )
            return None

        # No taper.
        if ratioRange == [0.0, 0.0]:
            return topology

        # Every vertex would collapse onto the taper axis.
        if ratioRange == [1.0, 1.0]:
            if not silent:
                print(
                    "Topology.Taper - Error: Degenerate result. "
                    "Returning the input topology."
                )
            return topology

        # ------------------------------------------------------------------
        # Optional triangulation
        # ------------------------------------------------------------------

        if triangulate is True:
            topology = Topology.Triangulate(
                topology,
                tolerance=tolerance,
                silent=silent
            )

            if not Topology.IsInstance(
                topology,
                "Topology"
            ):
                if not silent:
                    print(
                        "Topology.Taper - Error: Could not triangulate the "
                        "input topology. Returning None."
                    )
                return None

        topology_type = Topology.TypeAsString(
            topology
        )

        # ------------------------------------------------------------------
        # Resolve taper origin
        # ------------------------------------------------------------------

        if not Topology.IsInstance(
            origin,
            "Vertex"
        ):
            origin = Topology.Centroid(
                topology
            )

        if not Topology.IsInstance(
            origin,
            "Vertex"
        ):
            if not silent:
                print(
                    "Topology.Taper - Error: Could not determine a valid "
                    "taper origin. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Retrieve vertices
        # ------------------------------------------------------------------

        vertices = Topology.Vertices(
            topology,
            silent=True
        )

        if not isinstance(vertices, list) or len(vertices) == 0:
            if not silent:
                print(
                    "Topology.Taper - Error: The input topology contains no "
                    "vertices. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Determine Z range
        # ------------------------------------------------------------------

        z_values = [
            Vertex.Z(
                vertex,
                mantissa=mantissa
            )
            for vertex in vertices
        ]

        z_min = min(
            z_values
        )

        z_max = max(
            z_values
        )

        height = (
            z_max
            - z_min
        )

        # Tapering requires a Z interval over which the ratio can vary.
        if abs(height) <= tolerance:
            if not silent:
                print(
                    "Topology.Taper - Warning: The input topology has no "
                    "significant extent along the Z-axis. Returning the "
                    "input topology."
                )
            return topology

        origin_x = Vertex.X(
            origin,
            mantissa=mantissa
        )

        origin_y = Vertex.Y(
            origin,
            mantissa=mantissa
        )

        # ------------------------------------------------------------------
        # Calculate replacement vertices
        # ------------------------------------------------------------------

        new_vertices = []

        for vertex in vertices:

            vertex_x = Vertex.X(
                vertex,
                mantissa=mantissa
            )

            vertex_y = Vertex.Y(
                vertex,
                mantissa=mantissa
            )

            vertex_z = Vertex.Z(
                vertex,
                mantissa=mantissa
            )

            height_ratio = (
                (vertex_z - z_min)
                / height
            )

            taper_ratio = (
                ratioRange[0]
                + height_ratio
                * (
                    ratioRange[1]
                    - ratioRange[0]
                )
            )

            new_origin = Vertex.ByCoordinates(
                origin_x,
                origin_y,
                vertex_z
            )

            if not Topology.IsInstance(
                new_origin,
                "Vertex"
            ):
                if not silent:
                    print(
                        "Topology.Taper - Error: Could not create a valid "
                        "local taper origin. Returning None."
                    )
                return None

            distance = Vertex.Distance(
                new_origin,
                vertex,
                mantissa=mantissa
            )

            new_distance = (
                distance
                * taper_ratio
            )

            if abs(new_distance) > tolerance:

                direction = [
                    origin_x - vertex_x,
                    origin_y - vertex_y,
                    0
                ]

                new_vertex = Topology.TranslateByDirectionDistance(
                    vertex,
                    direction=direction,
                    distance=new_distance,
                    silent=silent
                )

                if not Topology.IsInstance(
                    new_vertex,
                    "Vertex"
                ):
                    if not silent:
                        print(
                            "Topology.Taper - Error: Could not calculate a "
                            "replacement vertex. Returning None."
                        )
                    return None

            else:
                new_vertex = vertex

            new_vertices.append(
                new_vertex
            )

        # ------------------------------------------------------------------
        # Rebuild topology with tapered vertices
        # ------------------------------------------------------------------

        return_topology = Topology.ReplaceVertices(
            topology,
            verticesA=vertices,
            verticesB=new_vertices,
            mantissa=mantissa,
            tolerance=tolerance,
            silent=silent
        )

        if not Topology.IsInstance(
            return_topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.Taper - Error: Could not rebuild the tapered "
                    "topology. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Legacy TopologicCore repair
        #
        # TopologicCore may return an unintended topology type after vertex
        # replacement. Preserve the historical Fix/SelfMerge coercion only
        # for that backend.
        #
        # All other backends are trusted and their result is returned without
        # topology-type coercion.
        # ------------------------------------------------------------------

        if Topology._IsTopologicCoreBackend():

            return_topology = Topology.Fix(
                return_topology,
                topologyType=topology_type,
                tolerance=tolerance,
                silent=silent
            )

            if (
                Topology.IsInstance(
                    return_topology,
                    "Topology"
                )
                and Topology.TypeAsString(
                    return_topology
                ) != topology_type
            ):
                return_topology = Topology.SelfMerge(
                    return_topology,
                    tolerance=tolerance,
                    silent=silent
                )

        return return_topology
    
    # @staticmethod
    # def Twist(
    #     topology,
    #     origin=None,
    #     angleRange: list = [45, 90],
    #     triangulate: bool = False,
    #     mantissa: int = 6,
    #     angTolerance: float = 0.01,
    #     tolerance: float = 0.0001,
    #     silent: bool = False
    # ):
    #     """
    #     Twists the input topology along its Z-axis based on the input angle range.

    #     Parameters
    #     ----------
    #     topology : topologic_core.Topology
    #         The input topology.
    #     origin : topologic_core.Vertex , optional
    #         The desired origin for twisting. If not specified, the centroid of
    #         the input topology is used. The twisting uses the X and Y coordinates
    #         of the specified origin, but uses the Z coordinate of each vertex
    #         being twisted. Default is None.
    #     angleRange : list , optional
    #         The desired angle range in degrees. This specifies a linear angular
    #         range from the lowest Z coordinate to the highest Z coordinate of the
    #         topology. Positive and negative angles follow the rotation convention
    #         used by Topology.Rotate about the positive Z-axis.
    #         Default is [45, 90].
    #     triangulate : bool , optional
    #         If set to True, the input topology is triangulated before twisting.
    #         This is useful for higher-dimensional topologies because a varying
    #         twist can make originally planar polygonal faces non-planar.
    #         Default is False.
    #     mantissa : int , optional
    #         The number of decimal places to round coordinates to. Default is 6.
    #     angTolerance : float , optional
    #         The angular tolerance in degrees below which no rotation is carried
    #         out. Default is 0.01.
    #     tolerance : float , optional
    #         The desired geometric tolerance. Default is 0.0001.
    #     silent : bool , optional
    #         If set to True, error and warning messages are suppressed.
    #         Default is False.

    #     Returns
    #     -------
    #     topologic_core.Topology
    #         The twisted topology.
    #     """
    #     from topologicpy.Vertex import Vertex

    #     # ------------------------------------------------------------------
    #     # Validate topology
    #     # ------------------------------------------------------------------

    #     if not Topology.IsInstance(
    #         topology,
    #         "Topology"
    #     ):
    #         if not silent:
    #             print(
    #                 "Topology.Twist - Error: The input topology parameter "
    #                 "is not a valid topology. Returning None."
    #             )
    #         return None

    #     # ------------------------------------------------------------------
    #     # Validate angle range
    #     # ------------------------------------------------------------------

    #     if (
    #         not isinstance(
    #             angleRange,
    #             (list, tuple)
    #         )
    #         or len(angleRange) != 2
    #     ):
    #         if not silent:
    #             print(
    #                 "Topology.Twist - Error: The input angleRange parameter "
    #                 "must contain exactly two numeric values. Returning None."
    #             )
    #         return None

    #     try:
    #         angle_range = [
    #             float(angleRange[0]),
    #             float(angleRange[1])
    #         ]

    #     except Exception:
    #         if not silent:
    #             print(
    #                 "Topology.Twist - Error: The input angleRange parameter "
    #                 "must contain exactly two numeric values. Returning None."
    #             )
    #         return None

    #     # ------------------------------------------------------------------
    #     # Identity fast path
    #     # ------------------------------------------------------------------

    #     if angle_range == [0.0, 0.0]:
    #         return topology

    #     # ------------------------------------------------------------------
    #     # Optional triangulation
    #     #
    #     # Record the topology type AFTER triangulation. A Face, for example,
    #     # may legitimately become a Shell of triangular Faces.
    #     # ------------------------------------------------------------------

    #     if triangulate is True:

    #         topology = Topology.Triangulate(
    #             topology,
    #             tolerance=tolerance,
    #             silent=silent
    #         )

    #         if not Topology.IsInstance(
    #             topology,
    #             "Topology"
    #         ):
    #             if not silent:
    #                 print(
    #                     "Topology.Twist - Error: Could not triangulate the "
    #                     "input topology. Returning None."
    #                 )
    #             return None

    #     topology_type = Topology.TypeAsString(
    #         topology
    #     )

    #     # ------------------------------------------------------------------
    #     # Resolve origin
    #     # ------------------------------------------------------------------

    #     if not Topology.IsInstance(
    #         origin,
    #         "Vertex"
    #     ):
    #         origin = Topology.Centroid(
    #             topology
    #         )

    #     if not Topology.IsInstance(
    #         origin,
    #         "Vertex"
    #     ):
    #         if not silent:
    #             print(
    #                 "Topology.Twist - Error: Could not determine a valid "
    #                 "twist origin. Returning None."
    #             )
    #         return None

    #     # ------------------------------------------------------------------
    #     # Retrieve vertices and Z range
    #     # ------------------------------------------------------------------

    #     vertices = Topology.Vertices(
    #         topology,
    #         silent=True
    #     )

    #     if (
    #         not isinstance(
    #             vertices,
    #             list
    #         )
    #         or len(vertices) == 0
    #     ):
    #         if not silent:
    #             print(
    #                 "Topology.Twist - Error: The input topology contains no "
    #                 "vertices. Returning None."
    #             )
    #         return None

    #     z_values = [
    #         Vertex.Z(
    #             vertex,
    #             mantissa=mantissa
    #         )
    #         for vertex in vertices
    #     ]

    #     z_min = min(
    #         z_values
    #     )

    #     z_max = max(
    #         z_values
    #     )

    #     height = z_max - z_min

    #     # ------------------------------------------------------------------
    #     # A twist range cannot be interpolated if there is no Z extent.
    #     # ------------------------------------------------------------------

    #     if abs(height) <= tolerance:

    #         if not silent:
    #             print(
    #                 "Topology.Twist - Warning: The input topology has no "
    #                 "significant extent along the Z-axis. Returning the "
    #                 "input topology."
    #             )

    #         return topology

    #     origin_x = Vertex.X(
    #         origin,
    #         mantissa=mantissa
    #     )

    #     origin_y = Vertex.Y(
    #         origin,
    #         mantissa=mantissa
    #     )

    #     # ------------------------------------------------------------------
    #     # Calculate transformed vertices
    #     # ------------------------------------------------------------------

    #     new_vertices = []

    #     for vertex in vertices:

    #         vertex_z = Vertex.Z(
    #             vertex,
    #             mantissa=mantissa
    #         )

    #         height_ratio = (
    #             vertex_z - z_min
    #         ) / height

    #         angle = (
    #             angle_range[0]
    #             + height_ratio
    #             * (
    #                 angle_range[1]
    #                 - angle_range[0]
    #             )
    #         )

    #         local_origin = Vertex.ByCoordinates(
    #             origin_x,
    #             origin_y,
    #             vertex_z
    #         )

    #         if not Topology.IsInstance(
    #             local_origin,
    #             "Vertex"
    #         ):
    #             if not silent:
    #                 print(
    #                     "Topology.Twist - Error: Could not create a valid "
    #                     "local twist origin. Returning None."
    #                 )
    #             return None

    #         new_vertex = Topology.Rotate(
    #             vertex,
    #             origin=local_origin,
    #             axis=[0, 0, 1],
    #             angle=angle,
    #             transferDictionaries=False,
    #             angTolerance=angTolerance,
    #             tolerance=tolerance,
    #             silent=silent
    #         )

    #         if not Topology.IsInstance(
    #             new_vertex,
    #             "Vertex"
    #         ):
    #             if not silent:
    #                 print(
    #                     "Topology.Twist - Error: Could not calculate a "
    #                     "replacement vertex. Returning None."
    #                 )
    #             return None

    #         new_vertices.append(
    #             new_vertex
    #         )

    #     # ------------------------------------------------------------------
    #     # Rebuild topology
    #     # ------------------------------------------------------------------

    #     return_topology = Topology.ReplaceVertices(
    #         topology,
    #         verticesA=vertices,
    #         verticesB=new_vertices,
    #         mantissa=mantissa,
    #         tolerance=tolerance,
    #         silent=silent
    #     )

    #     if not Topology.IsInstance(
    #         return_topology,
    #         "Topology"
    #     ):
    #         if not silent:
    #             print(
    #                 "Topology.Twist - Error: Could not rebuild the twisted "
    #                 "topology. Returning None."
    #             )
    #         return None

    #     # ------------------------------------------------------------------
    #     # Legacy TopologicCore reconstruction workaround.
    #     #
    #     # PythonOCC and future backends are trusted to reconstruct the topology
    #     # natively through ReplaceVertices. Do not conceal reconstruction or
    #     # planarity failures with Fix.
    #     # ------------------------------------------------------------------

    #     if Topology._IsTopologicCoreBackend():

    #         return_topology = Topology.Fix(
    #             return_topology,
    #             topologyType=topology_type,
    #             tolerance=tolerance,
    #             silent=silent
    #         )

    #     return return_topology

    @staticmethod
    def Twist(
        topology,
        origin=None,
        angleRange: list = [45, 90],
        triangulate: bool = False,
        mantissa: int = 6,
        angTolerance: float = 0.01,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Twists the input topology along its Z-axis based on the input angle range.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        origin : topologic_core.Vertex , optional
            The desired origin for twisting. If not specified, the centroid of
            the input topology is used. The twisting uses the X and Y coordinates
            of the specified origin, but uses the Z coordinate of each vertex
            being twisted. Default is None.
        angleRange : list , optional
            The desired angle range in degrees. This specifies a linear angular
            range from the lowest Z coordinate to the highest Z coordinate of the
            topology. Positive and negative angles follow the rotation convention
            used by Topology.Rotate about the positive Z-axis.
            Default is [45, 90].
        triangulate : bool , optional
            If set to True, the input topology is triangulated before twisting.
            This is useful for higher-dimensional topologies because a varying
            twist can make originally planar polygonal faces non-planar.
            Default is False.
        mantissa : int , optional
            The number of decimal places to round coordinates to. Default is 6.
        angTolerance : float , optional
            The angular tolerance in degrees below which no rotation is carried
            out. Default is 0.01.
        tolerance : float , optional
            The desired geometric tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Topology
            The twisted topology.
        """
        from topologicpy.Vertex import Vertex

        # ------------------------------------------------------------------
        # Validate topology.
        # ------------------------------------------------------------------

        if not Topology.IsInstance(
            topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.Twist - Error: The input topology parameter "
                    "is not a valid topology. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Validate angle range.
        # ------------------------------------------------------------------

        if (
            not isinstance(
                angleRange,
                (list, tuple)
            )
            or len(angleRange) != 2
        ):
            if not silent:
                print(
                    "Topology.Twist - Error: The input angleRange parameter "
                    "must contain exactly two numeric values. Returning None."
                )
            return None

        try:
            angle_range = [
                float(angleRange[0]),
                float(angleRange[1])
            ]

        except Exception:
            if not silent:
                print(
                    "Topology.Twist - Error: The input angleRange parameter "
                    "must contain exactly two numeric values. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Identity fast path.
        # ------------------------------------------------------------------

        if angle_range == [
            0.0,
            0.0
        ]:
            return topology

        # ------------------------------------------------------------------
        # Optional triangulation.
        # ------------------------------------------------------------------

        if triangulate is True:

            topology = Topology.Triangulate(
                topology,
                tolerance=tolerance,
                silent=silent
            )

            if not Topology.IsInstance(
                topology,
                "Topology"
            ):
                if not silent:
                    print(
                        "Topology.Twist - Error: Could not triangulate the "
                        "input topology. Returning None."
                    )
                return None

        topology_type = Topology.TypeAsString(
            topology
        )

        # ------------------------------------------------------------------
        # Resolve origin.
        # ------------------------------------------------------------------

        if not Topology.IsInstance(
            origin,
            "Vertex"
        ):
            origin = Topology.Centroid(
                topology
            )

        if not Topology.IsInstance(
            origin,
            "Vertex"
        ):
            if not silent:
                print(
                    "Topology.Twist - Error: Could not determine a valid "
                    "twist origin. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Retrieve vertices and Z range.
        # ------------------------------------------------------------------

        vertices = Topology.Vertices(
            topology,
            silent=True
        )

        if (
            not isinstance(vertices, list)
            or len(vertices) == 0
        ):
            if not silent:
                print(
                    "Topology.Twist - Error: The input topology contains no "
                    "vertices. Returning None."
                )
            return None

        z_values = [
            Vertex.Z(
                vertex,
                mantissa=mantissa
            )
            for vertex in vertices
        ]

        z_min = min(
            z_values
        )

        z_max = max(
            z_values
        )

        height = (
            z_max
            - z_min
        )

        if abs(height) <= tolerance:

            if not silent:
                print(
                    "Topology.Twist - Warning: The input topology has no "
                    "significant extent along the Z-axis. Returning the "
                    "input topology."
                )

            return topology

        origin_x = Vertex.X(
            origin,
            mantissa=mantissa
        )

        origin_y = Vertex.Y(
            origin,
            mantissa=mantissa
        )

        # ------------------------------------------------------------------
        # Calculate transformed vertices.
        # ------------------------------------------------------------------

        new_vertices = []

        for vertex in vertices:

            vertex_z = Vertex.Z(
                vertex,
                mantissa=mantissa
            )

            height_ratio = (
                vertex_z
                - z_min
            ) / height

            angle = (
                angle_range[0]
                + height_ratio
                * (
                    angle_range[1]
                    - angle_range[0]
                )
            )

            local_origin = Vertex.ByCoordinates(
                origin_x,
                origin_y,
                vertex_z
            )

            if not Topology.IsInstance(
                local_origin,
                "Vertex"
            ):
                if not silent:
                    print(
                        "Topology.Twist - Error: Could not create a valid "
                        "local twist origin. Returning None."
                    )
                return None

            new_vertex = Topology.Rotate(
                vertex,
                origin=local_origin,
                axis=[0, 0, 1],
                angle=angle,
                transferDictionaries=False,
                angTolerance=angTolerance,
                tolerance=tolerance,
                silent=silent
            )

            if not Topology.IsInstance(
                new_vertex,
                "Vertex"
            ):
                if not silent:
                    print(
                        "Topology.Twist - Error: Could not calculate a "
                        "replacement vertex. Returning None."
                    )
                return None

            new_vertices.append(
                new_vertex
            )

        # ------------------------------------------------------------------
        # Rebuild topology.
        # ------------------------------------------------------------------

        return_topology = Topology.ReplaceVertices(
            topology,
            verticesA=vertices,
            verticesB=new_vertices,
            mantissa=mantissa,
            tolerance=tolerance,
            silent=silent
        )

        if not Topology.IsInstance(
            return_topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.Twist - Error: Could not rebuild the twisted "
                    "topology. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Legacy TopologicCore reconstruction workaround.
        # ------------------------------------------------------------------

        if Topology._IsTopologicCoreBackend():

            return_topology = Topology.Fix(
                return_topology,
                topologyType=topology_type,
                tolerance=tolerance,
                silent=silent
            )

            if not Topology.IsInstance(
                return_topology,
                "Topology"
            ):
                return None

            # --------------------------------------------------------------
            # Fix must not silently discard transformed vertices.
            #
            # A varying twist can make a formerly planar polygon impossible
            # for TopologicCore to represent as the original topology type.
            # In that case returning None is preferable to fabricating a
            # lower-vertex topology.
            # --------------------------------------------------------------

            repaired_vertices = Topology.Vertices(
                return_topology,
                silent=True
            ) or []

            if len(repaired_vertices) != len(
                new_vertices
            ):
                if not silent:
                    print(
                        "Topology.Twist - Error: TopologicCore reconstruction "
                        "changed the vertex count. Returning None."
                    )

                return None

        return return_topology

    @staticmethod
    def Unflatten(topology, origin=None, direction=[0, 0, 1], transferDictionaries: bool = True, silent: bool = False):
        """
        Unflattens the input topology such that the world origin is translated to the input origin and the input topology is rotated such that the Up direction (see Vector.Up()) is aligned with the input vector.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        origin : topologic_core.Vertex , optional
            The input origin. If set to None, The object's centroid will be used to translate the world origin. Default is None.
        vector : list , optional
            The input direction vector. The input topology will be rotated such that this vector is pointed in the positive Z axis.
        transferDictionaries : bool , optional
            If set to True, the dictionaries are transfered from the original object to the translated object. Default is True.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The flattened topology.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Vector import Vector

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Unflatten - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.Origin()
        up = Vector.Up()
        tran_mat = Vector.TransformationMatrix(up, direction)
        unflat_topology = Topology.Transform(topology, tran_mat,
                                             transferDictionaries=transferDictionaries,
                                             silent=True)
        unflat_topology = Topology.Translate(unflat_topology,
                                             x = Vertex.X(origin),
                                             y = Vertex.Y(origin),
                                             z = Vertex.Z(origin),
                                             transferDictionaries=transferDictionaries,
                                             silent = True)
        return unflat_topology
    
    @staticmethod
    def Vertices(topology, silent: bool = True):
        """
        Returns the vertices of the input topology or graph.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The input topology or graph.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is True.

        Returns
        -------
        list
            The list of vertices.

        """

        from topologicpy.Graph import Graph
        import inspect

        is_tgraph = False
        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            is_tgraph = False

        if is_tgraph:
            return TGraph.Vertices(topology)

        if Topology.IsInstance(topology, "graph"):
            return Graph.Vertices(topology)

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Vertices - Error: The input is not a valid topology or graph. Returning None")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print("caller name:", calframe[1][3])
            return None

        if Topology.IsInstance(topology, "Vertex"):
            if not silent:
                print("Topology.Vertices - Warning: The input is a Vertex. Returning the same vertex embedded in a list.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print("caller name:", calframe[1][3])
            return [topology]

        return Topology.SubTopologies(topology=topology, subTopologyType="vertex", silent=silent)
    
    @staticmethod
    def Wires(topology, silent: bool = False):
        """
        Returns the wires of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of wires.

        """
        import inspect

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.Wires - Error: The input is not a valid topology. Returning None")
            return None
        
        if Topology.IsInstance(topology, "Wire"):
            if not silent:
                print("Topology.Wires - Warning: The input is a Wire. Returning the same wire embedded in a list.")
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print('caller name:', calframe[1][3])
            return [topology]
        
        if Topology.IsInstance(topology, "Edge") or Topology.IsInstance(topology, "Vertex"):
            if not silent:
                print("Topology.Wires - Warning: The input is a lower dimension than a wire. Returning an empty list.")
            return []
        
        return Topology.SubTopologies(topology=topology, subTopologyType="wire", silent=silent)
    
    @staticmethod
    def SubTopologies(topology, subTopologyType="vertex", silent: bool = False):
        """
        Returns the subtopologies of the input topology or graph as specified by the subTopologyType input string.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The input topology or graph.
        subTopologyType : str , optional
            The requested subtopology type. This can be one of "vertex", "edge", "wire", "face", "shell",
            "cell", "cellcomplex", "cluster", or "aperture". It is case insensitive. Default is "vertex".
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of subtopologies.

        """

        from topologicpy.Face import Face
        from topologicpy.Graph import Graph
        import inspect

        is_tgraph = False
        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            is_tgraph = False

        if not isinstance(subTopologyType, str):
            if not silent:
                print("Topology.SubTopologies - Error: the input subTopologyType parameter is not a valid string. Returning None.")
            return None

        subTopologyType = subTopologyType.lower()

        valid_types = [
            "vertex",
            "edge",
            "wire",
            "face",
            "shell",
            "cell",
            "cellcomplex",
            "cluster",
            "aperture",
        ]

        if subTopologyType not in valid_types:
            if not silent:
                print(
                    f"Topology.SubTopologies - Error: the input subTopologyType parameter "
                    f"{subTopologyType} is not recognized. Returning None."
                )
                curframe = inspect.currentframe()
                calframe = inspect.getouterframes(curframe, 2)
                print("caller name:", calframe[1][3])
            return None

        # Special case for TGraph.
        if is_tgraph:
            if subTopologyType == "vertex":
                return TGraph.Vertices(topology)
            elif subTopologyType == "edge":
                return TGraph.Edges(topology)
            else:
                if not silent:
                    print(
                        f"Topology.SubTopologies - Error: the input subTopologyType parameter "
                        f"{subTopologyType} is not a valid subTopology of TGraphs. Returning None."
                    )
                return None

        if (
            not Topology.IsInstance(topology, "Topology")
            and not Topology.IsInstance(topology, "Graph")
        ):
            if not silent:
                print(
                    "Topology.SubTopologies - Error: the input topology parameter is not "
                    "a valid topology or graph. Returning None."
                )
            return None

        # Special case for Graphs.
        if Topology.IsInstance(topology, "Graph"):
            if subTopologyType == "vertex":
                return Graph.Vertices(topology)
            elif subTopologyType == "edge":
                return Graph.Edges(topology)
            else:
                if not silent:
                    print(
                        f"Topology.SubTopologies - Error: the input subTopologyType parameter "
                        f"{subTopologyType} is not a valid subTopology of Graphs. Returning None."
                    )
                return None

        topology_type = Topology.TypeAsString(topology)
        if not isinstance(topology_type, str):
            if not silent:
                print(
                    "Topology.SubTopologies - Error: Could not determine the type of the "
                    "input topology. Returning None."
                )
            return None

        topology_type = topology_type.lower()

        # A topology is considered a subtopology of itself.
        if topology_type == subTopologyType:
            return [topology]

        # Topologic's standard topology hierarchy is:
        #
        # Vertex < Edge < Wire < Face < Shell < Cell < CellComplex < Cluster
        #
        # A lower-order topology cannot contain a higher-order topology. Some
        # backends, particularly topologic_core, interpret calls such as
        # Edge.Wires(None, output) as ancestor searches and consequently require
        # a non-null host topology. Avoid such calls and return an empty list.
        #
        # Aperture is deliberately excluded from this hierarchy because it is
        # contextual rather than a dimensional topology level.
        hierarchy = {
            "vertex": 0,
            "edge": 1,
            "wire": 2,
            "face": 3,
            "shell": 4,
            "cell": 5,
            "cellcomplex": 6,
            "cluster": 7,
        }

        if topology_type in hierarchy and subTopologyType in hierarchy:
            if hierarchy[topology_type] < hierarchy[subTopologyType]:
                return []

        subTopologies = []

        # Special case for faces to return vertices/edges in CW/CCW order.
        if (
            Topology.IsInstance(topology, "Face")
            and subTopologyType in ["vertex", "edge"]
        ):
            wires = Face.Wires(topology)
            if not isinstance(wires, list):
                return []

            for wire in wires:
                result = Topology.SubTopologies(
                    wire,
                    subTopologyType=subTopologyType,
                    silent=silent,
                )
                if isinstance(result, list):
                    subTopologies += result

        else:
            if subTopologyType == "vertex":
                Core.InstanceCall(topology, "Vertices", None, subTopologies)

            elif subTopologyType == "edge":
                Core.InstanceCall(topology, "Edges", None, subTopologies)

            elif subTopologyType == "wire":
                Core.InstanceCall(topology, "Wires", None, subTopologies)

            elif subTopologyType == "face":
                Core.InstanceCall(topology, "Faces", None, subTopologies)

            elif subTopologyType == "shell":
                Core.InstanceCall(topology, "Shells", None, subTopologies)

            elif subTopologyType == "cell":
                Core.InstanceCall(topology, "Cells", None, subTopologies)

            elif subTopologyType == "cellcomplex":
                Core.InstanceCall(topology, "CellComplexes", None, subTopologies)

            elif subTopologyType == "cluster":
                Core.InstanceCall(topology, "Clusters", None, subTopologies)

            elif subTopologyType == "aperture":
                Core.InstanceCall(topology, "Apertures", None, subTopologies)

        if not subTopologies:
            return []

        return subTopologies

    
    @staticmethod
    def SuperTopologies(topology,
                        hostTopology,
                        topologyType: str = None,
                        silent: bool = False) -> list:
        """
        Returns the supertopologies connected to the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        hostTopology : topologic_core.Topology
            The host to topology in which to search for their supertopologies.
        topologyType : str , optional
            The topology type to search for. This can be any of "edge", "wire", "face", "shell", "cell", "cellcomplex", "cluster". It is case insensitive. If set to None, the immediate supertopology type is searched for. Default is None.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        list
            The list of supertopologies connected to the input topology.

        """
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.SuperTopologies - Error: the input topology parameter is not a valid topology. Returning None.")
            return None
        if not Topology.IsInstance(hostTopology, "Topology"):
            if not silent:
                print("Topology.SuperTopologies - Error: the input hostTopology parameter is not a valid topology. Returning None.")
            return None

        superTopologies = []

        if topologyType == None:
            typeID = 2*Topology.Type(topology)
        else:
            typeID = Topology.TypeID(topologyType)
        
        if typeID is None:
            if not silent:
                print("Topology.SuperTopologies - Error: The input topologyType parameter is not recognized. Returning None.")
            return None
        if Topology.Type(topology) >= typeID:
            if not silent:
                print("Topology.SuperTopologies - Error: The input topologyType parameter is not a valid type for a super topology of the input topology. Returning None.")
            return None #The user has asked for a topology type lower than the input topology
        elif typeID == Topology.TypeID("Edge"):
            # topology.Edges(hostTopology, superTopologies) # H to Core
            Core.InstanceCall(topology, 'Edges', hostTopology, superTopologies)
        elif typeID == Topology.TypeID("Wire"):
            # topology.Wires(hostTopology, superTopologies) # H to Core
            Core.InstanceCall(topology, 'Wires', hostTopology, superTopologies)
        elif typeID == Topology.TypeID("Face"):
            # topology.Faces(hostTopology, superTopologies) # H to Core
            Core.InstanceCall(topology, 'Faces', hostTopology, superTopologies)
        elif typeID == Topology.TypeID("Shell"):
            # topology.Shells(hostTopology, superTopologies) # H to Core
            Core.InstanceCall(topology, 'Shells', hostTopology, superTopologies)
        elif typeID == Topology.TypeID("Cell"):
            # topology.Cells(hostTopology, superTopologies) # H to Core
            Core.InstanceCall(topology, 'Cells', hostTopology, superTopologies)
        elif typeID == Topology.TypeID("CellComplex"):
            # topology.CellComplexes(hostTopology, superTopologies) # H to Core
            Core.InstanceCall(topology, 'CellComplexes', hostTopology, superTopologies)
        elif typeID == Topology.TypeID("Cluster"):
            # topology.Cluster(hostTopology, superTopologies) # H to Core
            Core.InstanceCall(topology, 'Cluster', hostTopology, superTopologies)
        else:
            if not silent:
                print("Topology.SuperTopologies - Error: The input topologyType parameter is not a valid type for a super topology of the input topology. Returning None.")
            return None
        if not superTopologies:
            return [] # Make sure you return an empty list instead of None
        return superTopologies
    
    @staticmethod
    def TransferDictionaries(sources, sinks, tolerance=0.0001, numWorkers=None, silent: bool = False):
        """
        Transfers the dictionaries from the list of sources to the list of sinks.

        Parameters
        ----------
        sources : list
            The list of topologies from which to transfer the dictionaries.
        sinks : list
            The list of topologies to which to transfer the dictionaries.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        numWorkers : int, optional
            Number of workers run in parallel to process. Default is None which sets the number to twice the number of CPU cores.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        dict
            Returns a dictionary with the lists of sources and sinks. The keys are "sinks" and "sources".

        """
        from topologicpy.Dictionary import Dictionary
        if not isinstance(sources, list):
            if not silent:
                print("Topology.TransferDictionaries - Error: The input sources parameter is not a valid list. Returning None.")
            return None
        if not isinstance(sinks, list):
            if not silent:
                print("Topology.TransferDictionaries - Error: The input sinks parameter is not a valid list. Returning None.")
            return None
        if numWorkers == None:
            import multiprocessing
            numWorkers = multiprocessing.cpu_count()*2
        sources = [x for x in sources if Topology.IsInstance(x, "Topology")]
        sinks = [x for x in sinks if Topology.IsInstance(x, "Topology")]
        so_dicts = [Dictionary.PythonDictionary(Topology.Dictionary(s)) for s in sources]
        if len(sources) < 1:
            if not silent:
                print("Topology.TransferDictionaries - Error: The input sources does not contain any valid topologies. Returning None.")
            return None
        if len(sinks) < 1:
            if not silent:
                print("Topology.TransferDictionaries - Error: The input sinks does not contain any valid topologies. Returning None.")
            return None

        queue = Queue()
        sources_str = [Topology.BREPString(s) for s in sources]
        sink_items = [SinkItem(id(s), Topology.BREPString(s)) for s in sinks]
        mergingProcess = MergingProcess(queue, sources_str, sink_items, so_dicts)
        mergingProcess.start()

        workerProcessPool = WorkerProcessPool(numWorkers, queue, sources_str, sink_items, so_dicts, tolerance=tolerance)
        workerProcessPool.startProcesses()
        workerProcessPool.join()

        queue.put_nowait(None)
        sinkMap = queue.get()
        mergingProcess.join()

        for i, sink in enumerate(sink_items):
            mapItem = sinkMap[sink.ID]
            newDict = Dictionary.ByKeysValues(mapItem.sinkKeys, mapItem.sinkValues)
            _ = Topology.SetDictionary(sinks[i], newDict)
        return {"sources": sources, "sinks": sinks}


    @staticmethod
    def TransferDictionariesByKey(topologies, dictionaries, key: str, silent: bool = False):
        """
        Transfers dictionaries to input topologies by matching a shared dictionary key.

        This method reads the dictionary of each input topology and indexes the topology
        by the value stored at the input key. It then reads each input dictionary and,
        when the same key value is found, transfers that dictionary to the matching
        topology.

        Parameters
        ----------
        topologies : list
            The target topologies that will receive dictionaries.
        dictionaries : list
            The source dictionaries. Each item can be either a Topologic dictionary or
            a Python dictionary. Nested dictionaries are not extracted or handled.
        key : str
            The dictionary key whose value is used to match source dictionaries to
            target topologies.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The updated list of topologies. Topologies without a matching dictionary
            are returned unchanged.

        Examples
        --------
        updated_faces = Topology.TransferByKey(faces, face_dictionaries, "id")

        updated_spaces = Topology.TransferByKey(spaces, room_dictionaries, "GlobalId")
        """

        from topologicpy.Dictionary import Dictionary

        if topologies is None:
            if not silent:
                print("Topology.TransferByKey - Error: The input topologies parameter is None. Returning None.")
            return None

        if dictionaries is None:
            if not silent:
                print("Topology.TransferByKey - Error: The input dictionaries parameter is None. Returning None.")
            return None

        if not isinstance(key, str) or len(key.strip()) < 1:
            if not silent:
                print("Topology.TransferByKey - Error: The input key parameter is not a valid string. Returning None.")
            return None

        if not isinstance(topologies, (list, tuple)):
            topologies = [topologies]
        else:
            topologies = list(topologies)

        if not isinstance(dictionaries, (list, tuple)):
            dictionaries = [dictionaries]
        else:
            dictionaries = list(dictionaries)

        value_to_indices = {}

        for i, topology in enumerate(topologies):
            if topology is None:
                continue

            topology_dictionary = Topology.Dictionary(topology)
            if topology_dictionary is None:
                continue

            value = Dictionary.ValueAtKey(topology_dictionary, key, None)

            # Do not use `if value:` because valid values such as 0 or False
            # should still be usable for matching.
            if value is None:
                continue

            value_to_indices.setdefault(str(value), []).append(i)

        if len(value_to_indices) < 1:
            if not silent:
                print("Topology.TransferByKey - Warning: No target topology contains the input key. Returning the original topologies.")
            return topologies

        transfer_count = 0

        for dictionary in dictionaries:
            if dictionary is None:
                continue

            source_dictionary = None

            if isinstance(dictionary, dict):
                source_dictionary = Dictionary.ByPythonDictionary(dictionary)
            elif dictionary.__class__.__name__ == "Dictionary":
                source_dictionary = dictionary

            if source_dictionary is None:
                continue

            value = Dictionary.ValueAtKey(source_dictionary, key, None)
            if value is None:
                continue

            indices = value_to_indices.get(str(value), None)
            if indices is None:
                continue

            for index in indices:
                updated_topology = Topology.SetDictionary(topologies[index], source_dictionary)
                if updated_topology is not None:
                    topologies[index] = updated_topology
                    transfer_count += 1

        if transfer_count < 1 and not silent:
            print("Topology.TransferByKey - Warning: No dictionaries were transferred. Returning the original topologies.")

        return topologies
    
    @staticmethod
    def TransferDictionariesBySelectors(topology,
                                        selectors,
                                        tranVertices=False,
                                        tranEdges=False,
                                        tranFaces=False,
                                        tranCells=False,
                                        tolerance=0.0001,
                                        numWorkers=None,
                                        silent: bool = False):
        """
        Transfers the dictionaries of the list of selectors to the subtopologies of the input topology based on the input parameters.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        selectors : list
            The list of input selectors from which to transfer the dictionaries.
        tranVertices : bool , optional
            If True transfer dictionaries to the vertices of the input topology.
        tranEdges : bool , optional
            If True transfer dictionaries to the edges of the input topology.
        tranFaces : bool , optional
            If True transfer dictionaries to the faces of the input topology.
        tranCells : bool , optional
            If True transfer dictionaries to the cells of the input topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        numWorkers : int , optional
            Number of workers run in parallel to process. If you set it to 1, no parallel processing will take place.
            The default is None which causes the algorithm to use twice the number of cpu cores in the host computer.
        Returns
        -------
        Topology
            The input topology with the dictionaries transferred to its subtopologies.

        """
        import time
        # timePrep = time.time()
        from topologicpy.Vertex import Vertex
        from topologicpy.Cluster import Cluster
        from topologicpy.Dictionary import Dictionary
        from topologicpy.BVH import BVH
        
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.TransferDictionariesBySelectors - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        if not isinstance(selectors, list):
            if not silent:
                print("Topology.TransferDictionariesBySelectors - Error: The input selectors parameter is not a valid list. Returning None.")
            return None
        selectors_tmp = [x for x in selectors if Topology.IsInstance(x, "Vertex")]
        if len(selectors_tmp) < 1:
            if not silent:
                print("Topology.TransferDictionariesBySelectors - Error: The input selectors do not contain any valid topologies. Returning None.")
            return None
        
        
        # --------------------------
        # Collect primitives
        # --------------------------
        def collect_cells(topo):
            if Topology.IsInstance(topo, "cell"):
                return [topo]
            else:
                return Topology.Cells(topo, silent=True)

        def collect_faces(topo):
            if Topology.IsInstance(topo, "face"):
                return [topo]
            else:
                return Topology.Faces(topo, silent=True)

        def collect_edges(topo):
            if Topology.IsInstance(topo, "edge"):
                return [topo]
            else:
                return Topology.Edges(topo, silent=True)
        def collect_vertices(topo):
            if Topology.IsInstance(topo, "vertex"):
                return [topo]
            else:
                return Topology.Vertices(topo, silent=True)
        vertices = []
        edges = []
        faces = []
        cells = []
        if tranVertices:
            vertices = collect_vertices(topology)
        if tranEdges:
            edges = collect_edges(topology)
        if tranFaces:
            faces = collect_faces(topology)
        if tranCells:
            cells = collect_cells(topology)
        primitives = []
        primitives.extend(cells)
        primitives.extend(faces)
        primitives.extend(edges)
        primitives.extend(vertices)
        # print("bvh preparation", f"{time.time() - timePrep:.4f}s", len(primitives))

        # timeStart = time.time()

        bvh = BVH.ByTopologies(primitives, tolerance=tolerance, silent=True)
        # print("bvh created", f"{time.time() - timeStart:.4f}s", len(bvh.items))

        for s in selectors:
            try:
                candidates = BVH.Clashes(bvh, s, tolerance=tolerance) or []
            except Exception as e:
                # print(f"BVH clash query failed for a selector. Trying fallback. {e}")
                # Fallback if your BVH needs a non-degenerate query
                candidates = primitives

            if not candidates:
                continue
            for element in candidates:
                status = Vertex.IsInternal(s, element, tolerance=tolerance)
                if status:
                    d1 = Topology.Dictionary(s)
                    d2 = Topology.Dictionary(element)
                    d3 = Dictionary.ByMergedDictionaries(d1, d2)
                    element = Topology.SetDictionary(element, d3)
        # print("bvh query done", f"{time.time() - timeStart:.4f}s")
        return topology

    # @staticmethod
    # def Translate(
    #     topology,
    #     x=0,
    #     y=0,
    #     z=0,
    #     transferDictionaries: bool = True,
    #     silent: bool = False
    # ):
    #     """
    #     Translates (moves) the input topology.

    #     Parameters
    #     ----------
    #     topology : topologic_core.Topology
    #         The input topology.
    #     x : float , optional
    #         The x translation value. Default is 0.
    #     y : float , optional
    #         The y translation value. Default is 0.
    #     z : float , optional
    #         The z translation value. Default is 0.
    #     transferDictionaries : bool , optional
    #         If set to True, dictionaries are transferred from the original topology
    #         and its subtopologies to the translated topology. Default is True.
    #     silent : bool , optional
    #         If set to True, error and warning messages are suppressed. Default is False.

    #     Returns
    #     -------
    #     topologic_core.Topology
    #         The translated topology.

    #     """
    #     if not Topology.IsInstance(topology, "Topology"):
    #         if not silent:
    #             print(
    #                 "Topology.Translate - Error: The input topology parameter "
    #                 "is not a valid topology. Returning None."
    #             )
    #         return None

    #     # Store source topology dictionary.
    #     source_dictionary = None
    #     if transferDictionaries:
    #         source_dictionary = Topology.Dictionary(topology)

    #         # Collect source subtopologies before the transform.
    #         vertices = Topology.Vertices(topology, silent=True) or []
    #         edges = Topology.Edges(topology, silent=True) or []
    #         wires = Topology.Wires(topology, silent=True) or []
    #         faces = Topology.Faces(topology, silent=True) or []
    #         shells = Topology.Shells(topology, silent=True) or []
    #         cells = Topology.Cells(topology, silent=True) or []
    #         cellComplexes = Topology.CellComplexes(topology, silent=True) or []

    #     # Delegate the geometric operation to the active backend.
    #     try:
    #         return_topology = Core.TopologyUtility.Translate(
    #             topology,
    #             x,
    #             y,
    #             z
    #         )
    #     except Exception as e:
    #         if not silent:
    #             print(
    #                 "Topology.Translate - Error: The core translate operation "
    #                 "failed. Returning None."
    #             )
    #             print("Error:", e)
    #         return None

    #     if not Topology.IsInstance(return_topology, "Topology"):
    #         if not silent:
    #             print(
    #                 "Topology.Translate - Error: The core translate operation "
    #                 "did not return a valid topology. Returning None."
    #             )
    #         return None

    #     if not transferDictionaries:
    #         return return_topology

    #     # Collect translated subtopologies.
    #     r_vertices = Topology.Vertices(return_topology, silent=True) or []
    #     r_edges = Topology.Edges(return_topology, silent=True) or []
    #     r_wires = Topology.Wires(return_topology, silent=True) or []
    #     r_faces = Topology.Faces(return_topology, silent=True) or []
    #     r_shells = Topology.Shells(return_topology, silent=True) or []
    #     r_cells = Topology.Cells(return_topology, silent=True) or []
    #     r_cellComplexes = Topology.CellComplexes(
    #         return_topology,
    #         silent=True
    #     ) or []

    #     # Transfer subtopology dictionaries conservatively.
    #     for source, target in zip(vertices, r_vertices):
    #         Topology.SetDictionary(
    #             target,
    #             Topology.Dictionary(source),
    #             silent=True
    #         )

    #     for source, target in zip(edges, r_edges):
    #         Topology.SetDictionary(
    #             target,
    #             Topology.Dictionary(source),
    #             silent=True
    #         )

    #     for source, target in zip(wires, r_wires):
    #         Topology.SetDictionary(
    #             target,
    #             Topology.Dictionary(source),
    #             silent=True
    #         )

    #     for source, target in zip(faces, r_faces):
    #         Topology.SetDictionary(
    #             target,
    #             Topology.Dictionary(source),
    #             silent=True
    #         )

    #     for source, target in zip(shells, r_shells):
    #         Topology.SetDictionary(
    #             target,
    #             Topology.Dictionary(source),
    #             silent=True
    #         )

    #     for source, target in zip(cells, r_cells):
    #         Topology.SetDictionary(
    #             target,
    #             Topology.Dictionary(source),
    #             silent=True
    #         )

    #     for source, target in zip(cellComplexes, r_cellComplexes):
    #         Topology.SetDictionary(
    #             target,
    #             Topology.Dictionary(source),
    #             silent=True
    #         )

    #     # Transfer the dictionary attached to the topology itself.
    #     if source_dictionary is not None:
    #         return_topology = Topology.SetDictionary(
    #             return_topology,
    #             source_dictionary,
    #             silent=True
    #         )

    #     return return_topology

    @staticmethod
    def Translate(
        topology,
        x=0,
        y=0,
        z=0,
        transferDictionaries: bool = True,
        silent: bool = False
    ):
        """
        Translates (moves) the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        x : float , optional
            The x translation value. Default is 0.
        y : float , optional
            The y translation value. Default is 0.
        z : float , optional
            The z translation value. Default is 0.
        transferDictionaries : bool , optional
            If set to True, dictionaries are transferred from the original topology
            and its subtopologies to the translated topology. Default is True.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The translated topology.
        """
        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print(
                    "Topology.Translate - Error: The input topology parameter "
                    "is not a valid topology. Returning None."
                )
            return None

        source_dictionary = None

        if transferDictionaries:
            source_dictionary = Topology.Dictionary(topology)

            vertices = Topology.Vertices(topology, silent=True) or []
            edges = Topology.Edges(topology, silent=True) or []
            wires = Topology.Wires(topology, silent=True) or []
            faces = Topology.Faces(topology, silent=True) or []
            shells = Topology.Shells(topology, silent=True) or []
            cells = Topology.Cells(topology, silent=True) or []
            cellComplexes = Topology.CellComplexes(
                topology,
                silent=True
            ) or []

        # ------------------------------------------------------------------
        # First attempt: translate the input topology directly.
        # ------------------------------------------------------------------

        return_topology = None
        translation_error = None

        try:
            return_topology = Core.TopologyUtility.Translate(
                topology,
                x,
                y,
                z
            )
        except Exception as error:
            translation_error = error
            return_topology = None

        # ------------------------------------------------------------------
        # TopologicCore compatibility fallback.
        #
        # Legacy TopologicCore can fail to translate a topology after
        # dictionaries have been attached to its subtopologies. If that happens,
        # create a geometry-only BREP copy and retry the same native operation.
        #
        # PythonOCC never enters this branch.
        # ------------------------------------------------------------------

        if (
            not Topology.IsInstance(return_topology, "Topology")
            and transferDictionaries
            and Topology._IsTopologicCoreBackend()
        ):
            try:
                brep = Topology.BREPString(
                    topology,
                    silent=True
                )

                clean_topology = Topology.ByBREPString(
                    brep,
                    silent=True
                )

                if Topology.IsInstance(
                    clean_topology,
                    "Topology"
                ):
                    return_topology = Core.TopologyUtility.Translate(
                        clean_topology,
                        x,
                        y,
                        z
                    )

            except Exception as error:
                translation_error = error
                return_topology = None

        if not Topology.IsInstance(
            return_topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.Translate - Error: The core translate operation "
                    "failed or returned an invalid topology. Returning None."
                )

                if translation_error is not None:
                    print(
                        "Error:",
                        translation_error
                    )

            return None

        if not transferDictionaries:
            return return_topology

        # ------------------------------------------------------------------
        # Retrieve translated subtopologies.
        # ------------------------------------------------------------------

        r_vertices = Topology.Vertices(
            return_topology,
            silent=True
        ) or []

        r_edges = Topology.Edges(
            return_topology,
            silent=True
        ) or []

        r_wires = Topology.Wires(
            return_topology,
            silent=True
        ) or []

        r_faces = Topology.Faces(
            return_topology,
            silent=True
        ) or []

        r_shells = Topology.Shells(
            return_topology,
            silent=True
        ) or []

        r_cells = Topology.Cells(
            return_topology,
            silent=True
        ) or []

        r_cellComplexes = Topology.CellComplexes(
            return_topology,
            silent=True
        ) or []

        # ------------------------------------------------------------------
        # Transfer subtopology dictionaries.
        # ------------------------------------------------------------------

        for source, target in zip(
            vertices,
            r_vertices
        ):
            Topology.SetDictionary(
                target,
                Topology.Dictionary(source),
                silent=True
            )

        for source, target in zip(
            edges,
            r_edges
        ):
            Topology.SetDictionary(
                target,
                Topology.Dictionary(source),
                silent=True
            )

        for source, target in zip(
            wires,
            r_wires
        ):
            Topology.SetDictionary(
                target,
                Topology.Dictionary(source),
                silent=True
            )

        for source, target in zip(
            faces,
            r_faces
        ):
            Topology.SetDictionary(
                target,
                Topology.Dictionary(source),
                silent=True
            )

        for source, target in zip(
            shells,
            r_shells
        ):
            Topology.SetDictionary(
                target,
                Topology.Dictionary(source),
                silent=True
            )

        for source, target in zip(
            cells,
            r_cells
        ):
            Topology.SetDictionary(
                target,
                Topology.Dictionary(source),
                silent=True
            )

        for source, target in zip(
            cellComplexes,
            r_cellComplexes
        ):
            Topology.SetDictionary(
                target,
                Topology.Dictionary(source),
                silent=True
            )

        # ------------------------------------------------------------------
        # Transfer parent dictionary.
        # ------------------------------------------------------------------

        if source_dictionary is not None:
            return_topology = Topology.SetDictionary(
                return_topology,
                source_dictionary,
                silent=True
            )

        return return_topology
    @staticmethod
    def Transform(
        topology,
        matrix: list,
        angTolerance: float = 0.001,
        transferDictionaries: bool = True,
        tolerance: float = 0.0001,
        silent: bool = False,
    ):
        """
        Transforms the input topology by the input 4x4 affine transformation matrix.

        The complete affine transformation is delegated to the active Core backend.
        The legacy Scale -> Rotate -> Translate reconstruction fallback is used only
        when the active backend is TopologicCore.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        matrix : list
            The input 4x4 affine transformation matrix in row-major form:

            [
                [a00, a01, a02, tx],
                [a10, a11, a12, ty],
                [a20, a21, a22, tz],
                [0,   0,   0,   1]
            ]

        angTolerance : float , optional
            The angular tolerance in degrees below which a rotation is ignored
            by the legacy TopologicCore fallback. Default is 0.001.
        transferDictionaries : bool , optional
            If set to True, the dictionary of the input topology is transferred
            to the transformed topology. Default is True.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Topology
            The transformed topology.
        """
        import math
        from topologicpy.Vertex import Vertex

        # ------------------------------------------------------------------
        # Validate topology
        # ------------------------------------------------------------------

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print(
                    "Topology.Transform - Error: The input topology parameter "
                    "is not a valid topology. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Validate matrix structure
        # ------------------------------------------------------------------

        if (
            not isinstance(matrix, (list, tuple))
            or len(matrix) != 4
            or any(
                not isinstance(row, (list, tuple))
                or len(row) != 4
                for row in matrix
            )
        ):
            if not silent:
                print(
                    "Topology.Transform - Error: The input matrix parameter "
                    "is not a valid 4x4 matrix. Returning None."
                )
            return None

        try:
            m = [
                [
                    float(matrix[i][j])
                    for j in range(4)
                ]
                for i in range(4)
            ]
        except (TypeError, ValueError):
            if not silent:
                print(
                    "Topology.Transform - Error: The input matrix contains "
                    "non-numeric values. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Validate affine last row
        # ------------------------------------------------------------------

        if (
            abs(m[3][0]) > tolerance
            or abs(m[3][1]) > tolerance
            or abs(m[3][2]) > tolerance
            or abs(m[3][3] - 1.0) > tolerance
        ):
            if not silent:
                print(
                    "Topology.Transform - Error: The input matrix is not a valid "
                    "affine transformation matrix. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Identity fast path
        # ------------------------------------------------------------------

        identity = (
            (1.0, 0.0, 0.0, 0.0),
            (0.0, 1.0, 0.0, 0.0),
            (0.0, 0.0, 1.0, 0.0),
            (0.0, 0.0, 0.0, 1.0),
        )

        if all(
            abs(m[i][j] - identity[i][j]) <= tolerance
            for i in range(4)
            for j in range(4)
        ):
            return topology

        tx = m[0][3]
        ty = m[1][3]
        tz = m[2][3]

        a00, a01, a02 = m[0][0], m[0][1], m[0][2]
        a10, a11, a12 = m[1][0], m[1][1], m[1][2]
        a20, a21, a22 = m[2][0], m[2][1], m[2][2]

        # ------------------------------------------------------------------
        # Native backend path
        #
        # Try the supported calling conventions for compatibility between
        # backends. These are API-signature alternatives, not geometric
        # reconstruction fallbacks.
        # ------------------------------------------------------------------

        transformed = None

        if Core.HasAttribute("TopologyUtility", "Transform"):

            # 12-scalar form.
            try:
                transformed = Core.TopologyUtility.Transform(
                    topology,
                    tx,
                    ty,
                    tz,
                    a00,
                    a01,
                    a02,
                    a10,
                    a11,
                    a12,
                    a20,
                    a21,
                    a22,
                )
            except Exception:
                transformed = None

            # Nested 4x4 form.
            if not Topology.IsInstance(transformed, "Topology"):
                try:
                    transformed = Core.TopologyUtility.Transform(
                        topology,
                        m,
                    )
                except Exception:
                    transformed = None

            # Flat 16-value form.
            if not Topology.IsInstance(transformed, "Topology"):
                try:
                    transformed = Core.TopologyUtility.Transform(
                        topology,
                        [
                            m[i][j]
                            for i in range(4)
                            for j in range(4)
                        ],
                    )
                except Exception:
                    transformed = None

        if Topology.IsInstance(transformed, "Topology"):

            if transferDictionaries:
                try:
                    dictionary = Topology.Dictionary(
                        topology,
                        silent=True
                    )

                    if dictionary is not None:
                        transformed = Topology.SetDictionary(
                            transformed,
                            dictionary,
                            silent=True,
                        )
                except Exception:
                    pass

            return transformed

        # ------------------------------------------------------------------
        # Non-TopologicCore backends
        #
        # Do not hide a native affine-transform failure by decomposing the
        # operation into unrelated public transformations.
        # ------------------------------------------------------------------

        if not Topology._IsTopologicCoreBackend():
            if not silent:
                print(
                    "Topology.Transform - Error: The active backend could not "
                    "perform the affine transformation. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Legacy TopologicCore fallback
        #
        # Decompose:
        #
        #     affine = Translate * Rotate * Scale
        #
        # This path is retained strictly for the deprecated TopologicCore
        # backend. It cannot represent general shear.
        # ------------------------------------------------------------------

        sx = math.sqrt(
            a00 * a00
            + a10 * a10
            + a20 * a20
        )

        sy = math.sqrt(
            a01 * a01
            + a11 * a11
            + a21 * a21
        )

        sz = math.sqrt(
            a02 * a02
            + a12 * a12
            + a22 * a22
        )

        eps = max(
            1e-12,
            float(tolerance)
        )

        if (
            sx < eps
            or sy < eps
            or sz < eps
        ):
            if not silent:
                print(
                    "Topology.Transform - Error: Degenerate scale detected "
                    "in the transformation matrix. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Remove scale to obtain rotation matrix
        # ------------------------------------------------------------------

        r00, r10, r20 = (
            a00 / sx,
            a10 / sx,
            a20 / sx
        )

        r01, r11, r21 = (
            a01 / sy,
            a11 / sy,
            a21 / sy
        )

        r02, r12, r22 = (
            a02 / sz,
            a12 / sz,
            a22 / sz
        )

        # ------------------------------------------------------------------
        # Reflection handling
        # ------------------------------------------------------------------

        det = (
            r00 * (r11 * r22 - r12 * r21)
            - r01 * (r10 * r22 - r12 * r20)
            + r02 * (r10 * r21 - r11 * r20)
        )

        if det < 0.0:

            if (
                abs(sx) >= abs(sy)
                and abs(sx) >= abs(sz)
            ):
                sx = -sx
                r00 = -r00
                r10 = -r10
                r20 = -r20

            elif (
                abs(sy) >= abs(sx)
                and abs(sy) >= abs(sz)
            ):
                sy = -sy
                r01 = -r01
                r11 = -r11
                r21 = -r21

            else:
                sz = -sz
                r02 = -r02
                r12 = -r12
                r22 = -r22

        # ------------------------------------------------------------------
        # Reject shear in the legacy decomposition path
        # ------------------------------------------------------------------

        dot01 = (
            r00 * r01
            + r10 * r11
            + r20 * r21
        )

        dot02 = (
            r00 * r02
            + r10 * r12
            + r20 * r22
        )

        dot12 = (
            r01 * r02
            + r11 * r12
            + r21 * r22
        )

        if (
            abs(dot01) > tolerance
            or abs(dot02) > tolerance
            or abs(dot12) > tolerance
        ):
            if not silent:
                print(
                    "Topology.Transform - Error: The transformation matrix "
                    "contains shear, but TopologicCore could not perform the "
                    "native affine transformation. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Convert rotation matrix to axis-angle
        # ------------------------------------------------------------------

        trace = (
            r00
            + r11
            + r22
        )

        cosine = max(
            -1.0,
            min(
                1.0,
                (trace - 1.0) * 0.5
            )
        )

        angle_rad = math.acos(
            cosine
        )

        angle_deg = math.degrees(
            angle_rad
        )

        do_rotate = (
            angle_deg
            > float(angTolerance)
        )

        ax = 0.0
        ay = 0.0
        az = 1.0

        if do_rotate:

            sin_angle = math.sin(
                angle_rad
            )

            if abs(sin_angle) > 1e-10:

                ax = (
                    r21 - r12
                ) / (
                    2.0 * sin_angle
                )

                ay = (
                    r02 - r20
                ) / (
                    2.0 * sin_angle
                )

                az = (
                    r10 - r01
                ) / (
                    2.0 * sin_angle
                )

            else:

                # Near 180 degrees.
                ax = math.sqrt(
                    max(
                        0.0,
                        (r00 + 1.0) * 0.5
                    )
                )

                ay = math.sqrt(
                    max(
                        0.0,
                        (r11 + 1.0) * 0.5
                    )
                )

                az = math.sqrt(
                    max(
                        0.0,
                        (r22 + 1.0) * 0.5
                    )
                )

                if r01 < 0.0:
                    ay = -ay

                if r02 < 0.0:
                    az = -az

            axis_length = math.sqrt(
                ax * ax
                + ay * ay
                + az * az
            )

            if axis_length <= eps:
                do_rotate = False

            else:
                ax /= axis_length
                ay /= axis_length
                az /= axis_length

        origin = Vertex.Origin()

        result = topology

        # ------------------------------------------------------------------
        # Scale
        # ------------------------------------------------------------------

        if (
            abs(sx - 1.0) > tolerance
            or abs(sy - 1.0) > tolerance
            or abs(sz - 1.0) > tolerance
        ):

            result = Topology.Scale(
                result,
                origin=origin,
                x=sx,
                y=sy,
                z=sz,
                transferDictionaries=False,
                silent=silent,
            )

            if not Topology.IsInstance(
                result,
                "Topology"
            ):
                return None

        # ------------------------------------------------------------------
        # Rotate
        # ------------------------------------------------------------------

        if do_rotate:

            result = Topology.Rotate(
                result,
                origin=origin,
                axis=[
                    ax,
                    ay,
                    az
                ],
                angle=angle_deg,
                angTolerance=angTolerance,
                transferDictionaries=False,
                tolerance=tolerance,
                silent=silent,
            )

            if not Topology.IsInstance(
                result,
                "Topology"
            ):
                return None

        # ------------------------------------------------------------------
        # Translate
        # ------------------------------------------------------------------

        if (
            abs(tx) > tolerance
            or abs(ty) > tolerance
            or abs(tz) > tolerance
        ):

            result = Topology.Translate(
                result,
                x=tx,
                y=ty,
                z=tz,
                transferDictionaries=False,
                silent=silent,
            )

            if not Topology.IsInstance(
                result,
                "Topology"
            ):
                return None

        # ------------------------------------------------------------------
        # Transfer parent dictionary
        # ------------------------------------------------------------------

        if transferDictionaries:
            try:
                dictionary = Topology.Dictionary(
                    topology,
                    silent=True
                )

                if dictionary is not None:
                    result = Topology.SetDictionary(
                        result,
                        dictionary,
                        silent=True,
                    )
            except Exception:
                pass

        return result

    @staticmethod
    def TranslateByDirectionDistance(topology, direction: list = [0, 0, 0], distance: float = 0, transferDictionaries: bool =True, silent: bool = False):
        """
        Translates (moves) the input topology along the input direction by the specified distance.

        Parameters
        ----------
        topology : topologic_core.topology
            The input topology.
        direction : list , optional
            The direction vector in which the topology should be moved. Default is [0, 0, 0]
        distance : float , optional
            The distance by which the toplogy should be moved. Default is 0.
        transferDictionaries : bool , optional
            If set to True, the dictionaries are transfered from the original object to the translated object. Default is True.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            The translated topology.

        """
        from topologicpy.Vector import Vector

        if not Topology.IsInstance(topology, "Topology"):
            if not silent:
                print("Topology.TranslateByDirectionDistance - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        v = Vector.SetMagnitude(direction, distance)
        return Topology.Translate(topology, x=v[0], y=v[1], z=v[2], transferDictionaries=transferDictionaries, silent=silent)

    # @staticmethod
    # def Triangulate(
    #     topology,
    #     transferDictionaries: bool = False,
    #     mode: int = 0,
    #     meshSize: float = None,
    #     tolerance: float = 0.0001,
    #     silent: bool = False
    # ):
    #     """
    #     Triangulates the input topology.

    #     Parameters
    #     ----------
    #     topology : topologic_core.Topology
    #         The input topology.
    #     transferDictionaries : bool , optional
    #         If set to True, the dictionaries of the faces in the input topology
    #         will be transferred to the created triangular faces. Default is False.
    #     mode : int , optional
    #         The desired mode of meshing algorithm. Several options are available:
    #         0: Classic
    #         1: MeshAdapt
    #         3: Initial Mesh Only
    #         5: Delaunay
    #         6: Frontal-Delaunay
    #         7: BAMG
    #         8: Frontal-Delaunay for Quads
    #         9: Packing of Parallelograms
    #         All options other than 0 use the gmsh library.
    #     meshSize : float , optional
    #         The desired mesh size when using a meshing mode. If set to None,
    #         it is calculated automatically. Default is None.
    #     tolerance : float , optional
    #         The desired tolerance. Default is 0.0001.
    #     silent : bool , optional
    #         If set to True, error and warning messages are suppressed.
    #         Default is False.

    #     Returns
    #     -------
    #     topologic_core.Topology
    #         The triangulated topology.
    #     """
    #     from topologicpy.Face import Face
    #     from topologicpy.Shell import Shell
    #     from topologicpy.Cell import Cell
    #     from topologicpy.CellComplex import CellComplex
    #     from topologicpy.Cluster import Cluster

    #     def cluster_constituents(cluster):

    #         try:
    #             result = Core.InstanceCall(
    #                 cluster,
    #                 "Topologies"
    #             )

    #             if isinstance(result, list):
    #                 return [
    #                     item
    #                     for item in result
    #                     if Topology.IsInstance(
    #                         item,
    #                         "Topology"
    #                     )
    #                 ]

    #         except Exception:
    #             pass

    #         try:
    #             result = []

    #             Core.InstanceCall(
    #                 cluster,
    #                 "Topologies",
    #                 result
    #             )

    #             if len(result) > 0:
    #                 return [
    #                     item
    #                     for item in result
    #                     if Topology.IsInstance(
    #                         item,
    #                         "Topology"
    #                     )
    #                 ]

    #         except Exception:
    #             pass

    #         try:
    #             result = []

    #             Core.InstanceCall(
    #                 cluster,
    #                 "Topologies",
    #                 None,
    #                 result
    #             )

    #             if len(result) > 0:
    #                 return [
    #                     item
    #                     for item in result
    #                     if Topology.IsInstance(
    #                         item,
    #                         "Topology"
    #                     )
    #                 ]

    #         except Exception:
    #             pass

    #         try:
    #             result = Cluster.Topologies(
    #                 cluster,
    #                 tolerance=tolerance,
    #                 silent=True
    #             )

    #             if isinstance(result, list):
    #                 return [
    #                     item
    #                     for item in result
    #                     if Topology.IsInstance(
    #                         item,
    #                         "Topology"
    #                     )
    #                 ]

    #         except Exception:
    #             pass

    #         return []

    #     # ------------------------------------------------------------------
    #     # Validate input
    #     # ------------------------------------------------------------------

    #     if not Topology.IsInstance(
    #         topology,
    #         "Topology"
    #     ):
    #         if not silent:
    #             print(
    #                 "Topology.Triangulate - Error: The input topology parameter "
    #                 "is not a valid topology. Returning None."
    #             )
    #         return None

    #     topology_type = Topology.Type(
    #         topology
    #     )

    #     # ------------------------------------------------------------------
    #     # Vertex / Edge / Wire
    #     #
    #     # These genuinely contain no Faces, so triangulation is a legitimate
    #     # no-op and the original topology is returned.
    #     # ------------------------------------------------------------------

    #     if topology_type in [
    #         Topology.TypeID("Vertex"),
    #         Topology.TypeID("Edge"),
    #         Topology.TypeID("Wire")
    #     ]:

    #         if not silent:
    #             print(
    #                 "Topology.Triangulate - Warning: The input topology parameter "
    #                 "contains no faces. Returning the original topology."
    #             )

    #         return topology

    #     # ------------------------------------------------------------------
    #     # Cluster
    #     # ------------------------------------------------------------------

    #     if topology_type == Topology.TypeID(
    #         "Cluster"
    #     ):

    #         constituents = cluster_constituents(
    #             topology
    #         )

    #         # A Cluster constituent-query failure must remain visible.
    #         # Returning the input Cluster would conceal the failure.
    #         if len(constituents) == 0:

    #             if not silent:
    #                 print(
    #                     "Topology.Triangulate - Error: Could not retrieve any "
    #                     "constituent topologies from the input Cluster. "
    #                     "Returning None."
    #                 )

    #             return None

    #         triangulated_constituents = []

    #         for constituent in constituents:

    #             triangulated = Topology.Triangulate(
    #                 constituent,
    #                 transferDictionaries=transferDictionaries,
    #                 mode=mode,
    #                 meshSize=meshSize,
    #                 tolerance=tolerance,
    #                 silent=True
    #             )

    #             if not Topology.IsInstance(
    #                 triangulated,
    #                 "Topology"
    #             ):

    #                 if not silent:
    #                     print(
    #                         "Topology.Triangulate - Error: Could not triangulate "
    #                         "one of the constituent topologies of the input Cluster. "
    #                         "Returning None."
    #                     )

    #                 return None

    #             triangulated_constituents.append(
    #                 triangulated
    #             )

    #         try:
    #             return_topology = Cluster.ByTopologies(
    #                 triangulated_constituents,
    #                 silent=True
    #             )

    #         except TypeError:
    #             return_topology = Cluster.ByTopologies(
    #                 triangulated_constituents
    #             )

    #         except Exception:
    #             return_topology = None

    #         if not Topology.IsInstance(
    #             return_topology,
    #             "Cluster"
    #         ):

    #             if not silent:
    #                 print(
    #                     "Topology.Triangulate - Error: Could not rebuild the "
    #                     "triangulated Cluster. Returning None."
    #                 )

    #             return None

    #         return return_topology

    #     # ------------------------------------------------------------------
    #     # Remember CellComplex cell count before reconstruction.
    #     # ------------------------------------------------------------------

    #     expected_cell_count = None

    #     if topology_type == Topology.TypeID(
    #         "CellComplex"
    #     ):

    #         original_cells = Topology.Cells(
    #             topology,
    #             silent=True
    #         ) or []

    #         expected_cell_count = len(
    #             original_cells
    #         )

    #     # ------------------------------------------------------------------
    #     # Retrieve Faces
    #     #
    #     # At this point the input is Face, Shell, Cell, or CellComplex.
    #     # All of these must contain Faces. An empty/invalid face query therefore
    #     # represents a failure rather than a legitimate no-op.
    #     # ------------------------------------------------------------------

    #     topology_faces = Topology.Faces(
    #         topology,
    #         silent=True
    #     )

    #     if (
    #         not isinstance(
    #             topology_faces,
    #             list
    #         )
    #         or len(topology_faces) == 0
    #     ):

    #         if not silent:
    #             print(
    #                 "Topology.Triangulate - Error: Could not retrieve Faces "
    #                 "from the input topology. Returning None."
    #             )

    #         return None

    #     # ------------------------------------------------------------------
    #     # Triangulate Faces
    #     # ------------------------------------------------------------------

    #     face_triangles = []
    #     selectors = []

    #     for face in topology_faces:

    #         vertices = Topology.Vertices(
    #             face,
    #             silent=True
    #         ) or []

    #         if len(vertices) > 3:

    #             triangles = Face.Triangulate(
    #                 face,
    #                 mode=mode,
    #                 meshSize=meshSize,
    #                 tolerance=tolerance,
    #                 silent=silent
    #             )

    #             if Topology.IsInstance(
    #                 triangles,
    #                 "Face"
    #             ):
    #                 triangles = [
    #                     triangles
    #                 ]

    #             if not isinstance(
    #                 triangles,
    #                 list
    #             ):

    #                 if not silent:
    #                     print(
    #                         "Topology.Triangulate - Error: Could not triangulate "
    #                         "one of the Faces of the input topology. Returning None."
    #                     )

    #                 return None

    #             triangles = [
    #                 triangle
    #                 for triangle in triangles
    #                 if Topology.IsInstance(
    #                     triangle,
    #                     "Face"
    #                 )
    #             ]

    #             if len(triangles) == 0:

    #                 if not silent:
    #                     print(
    #                         "Topology.Triangulate - Error: Face triangulation "
    #                         "returned no valid triangular Faces. Returning None."
    #                     )

    #                 return None

    #         else:
    #             triangles = [
    #                 face
    #             ]

    #         for triangle in triangles:

    #             if transferDictionaries:

    #                 selector = Topology.Centroid(
    #                     triangle
    #                 )

    #                 if Topology.IsInstance(
    #                     selector,
    #                     "Vertex"
    #                 ):

    #                     selector = Topology.SetDictionary(
    #                         selector,
    #                         Topology.Dictionary(
    #                             face
    #                         ),
    #                         silent=True
    #                     )

    #                     selectors.append(
    #                         selector
    #                     )

    #             face_triangles.append(
    #                 triangle
    #             )

    #     if len(face_triangles) == 0:

    #         if not silent:
    #             print(
    #                 "Topology.Triangulate - Error: No valid triangular Faces "
    #                 "were produced. Returning None."
    #             )

    #         return None

    #     # ------------------------------------------------------------------
    #     # Typed reconstruction
    #     # ------------------------------------------------------------------

    #     return_topology = None

    #     if topology_type in [
    #         Topology.TypeID("Face"),
    #         Topology.TypeID("Shell")
    #     ]:

    #         try:
    #             return_topology = Shell.ByFaces(
    #                 face_triangles,
    #                 tolerance=tolerance,
    #                 silent=True
    #             )

    #         except TypeError:
    #             return_topology = Shell.ByFaces(
    #                 face_triangles,
    #                 tolerance=tolerance
    #             )

    #         except Exception:
    #             return_topology = None

    #     elif topology_type == Topology.TypeID(
    #         "Cell"
    #     ):

    #         try:
    #             return_topology = Cell.ByFaces(
    #                 face_triangles,
    #                 tolerance=tolerance,
    #                 silent=True
    #             )

    #         except TypeError:
    #             return_topology = Cell.ByFaces(
    #                 face_triangles,
    #                 tolerance=tolerance
    #             )

    #         except Exception:
    #             return_topology = None

    #     elif topology_type == Topology.TypeID(
    #         "CellComplex"
    #     ):

    #         # --------------------------------------------------------------
    #         # PythonOCC / future backend path.
    #         #
    #         # Do NOT call public CellComplex.ByFaces here. Its Shapely
    #         # preprocessing intentionally removes coplanar overlaps, while the
    #         # coplanar subdivisions in a triangulated CellComplex are meaningful
    #         # topology and must be retained.
    #         # --------------------------------------------------------------

    #         if not Topology._IsTopologicCoreBackend():

    #             try:
    #                 return_topology = Core.CellComplex.ByFaces(
    #                     face_triangles,
    #                     tolerance,
    #                     False
    #                 )

    #             except TypeError:

    #                 try:
    #                     return_topology = Core.CellComplex.ByFaces(
    #                         face_triangles,
    #                         tolerance
    #                     )

    #                 except TypeError:

    #                     try:
    #                         return_topology = Core.CellComplex.ByFaces(
    #                             face_triangles
    #                         )

    #                     except Exception:
    #                         return_topology = None

    #                 except Exception:
    #                     return_topology = None

    #             except Exception:
    #                 return_topology = None

    #             # ----------------------------------------------------------
    #             # A CellComplex reconstruction that silently drops internal
    #             # partitions is not a successful triangulation.
    #             # ----------------------------------------------------------

    #             if Topology.IsInstance(
    #                 return_topology,
    #                 "CellComplex"
    #             ):

    #                 resulting_cells = Topology.Cells(
    #                     return_topology,
    #                     silent=True
    #                 ) or []

    #                 if (
    #                     expected_cell_count is not None
    #                     and len(resulting_cells) != expected_cell_count
    #                 ):

    #                     if not silent:
    #                         print(
    #                             "Topology.Triangulate - Error: The active backend "
    #                             "changed the CellComplex cell count from "
    #                             f"{expected_cell_count} to {len(resulting_cells)}. "
    #                             "Returning None."
    #                         )

    #                     return None

    #         # --------------------------------------------------------------
    #         # Legacy TopologicCore path.
    #         # --------------------------------------------------------------

    #         else:

    #             try:
    #                 return_topology = CellComplex.ByFaces(
    #                     face_triangles,
    #                     tolerance=tolerance,
    #                     silent=True
    #                 )

    #             except TypeError:
    #                 return_topology = CellComplex.ByFaces(
    #                     face_triangles,
    #                     tolerance=tolerance
    #                 )

    #             except Exception:
    #                 return_topology = None

    #     # ------------------------------------------------------------------
    #     # Legacy TopologicCore reconstruction workaround
    #     # ------------------------------------------------------------------

    #     if not Topology.IsInstance(
    #         return_topology,
    #         "Topology"
    #     ):

    #         if Topology._IsTopologicCoreBackend():

    #             try:
    #                 return_topology = Cluster.ByTopologies(
    #                     face_triangles,
    #                     silent=True
    #                 )

    #             except TypeError:
    #                 return_topology = Cluster.ByTopologies(
    #                     face_triangles
    #                 )

    #             except Exception:
    #                 return_topology = None

    #             if Topology.IsInstance(
    #                 return_topology,
    #                 "Topology"
    #             ):

    #                 return_topology = Topology.SelfMerge(
    #                     return_topology,
    #                     tolerance=tolerance,
    #                     silent=silent
    #                 )

    #         else:

    #             if not silent:
    #                 print(
    #                     "Topology.Triangulate - Error: The active backend could "
    #                     "not reconstruct the triangulated topology. Returning None."
    #                 )

    #             return None

    #     if not Topology.IsInstance(
    #         return_topology,
    #         "Topology"
    #     ):

    #         if not silent:
    #             print(
    #                 "Topology.Triangulate - Error: Could not reconstruct the "
    #                 "triangulated topology. Returning None."
    #             )

    #         return None

    #     # ------------------------------------------------------------------
    #     # Transfer Face dictionaries
    #     # ------------------------------------------------------------------

    #     if (
    #         transferDictionaries
    #         and len(selectors) > 0
    #     ):

    #         return_topology = Topology.TransferDictionariesBySelectors(
    #             return_topology,
    #             selectors,
    #             tranFaces=True,
    #             tolerance=tolerance
    #         )

    #     return return_topology

    @staticmethod
    def Triangulate(
        topology,
        transferDictionaries: bool = False,
        mode: int = 0,
        meshSize: float = None,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Triangulates the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        transferDictionaries : bool , optional
            If set to True, the dictionaries of the faces in the input topology
            will be transferred to the created triangular faces. Default is False.
        mode : int , optional
            The desired mode of meshing algorithm. Several options are available:
            0: Classic
            1: MeshAdapt
            3: Initial Mesh Only
            5: Delaunay
            6: Frontal-Delaunay
            7: BAMG
            8: Frontal-Delaunay for Quads
            9: Packing of Parallelograms
            All options other than 0 use the gmsh library.
        meshSize : float , optional
            The desired mesh size when using a meshing mode. If set to None,
            it is calculated automatically. Default is None.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Topology
            The triangulated topology.
        """
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Cluster import Cluster

        # def cluster_constituents(cluster):
        #     # --------------------------------------------------------------
        #     # Try all backend-native calling conventions. An empty list from
        #     # one convention is not authoritative; another convention may be
        #     # the one implemented by the active backend.
        #     # --------------------------------------------------------------

        #     try:
        #         result = Core.InstanceCall(
        #             cluster,
        #             "Topologies"
        #         )

        #         if isinstance(result, list):
        #             result = [
        #                 item
        #                 for item in result
        #                 if Topology.IsInstance(
        #                     item,
        #                     "Topology"
        #                 )
        #             ]

        #             if result:
        #                 return result

        #     except Exception:
        #         pass

        #     try:
        #         result = []

        #         Core.InstanceCall(
        #             cluster,
        #             "Topologies",
        #             result
        #         )

        #         result = [
        #             item
        #             for item in result
        #             if Topology.IsInstance(
        #                 item,
        #                 "Topology"
        #             )
        #         ]

        #         if result:
        #             return result

        #     except Exception:
        #         pass

        #     try:
        #         result = []

        #         Core.InstanceCall(
        #             cluster,
        #             "Topologies",
        #             None,
        #             result
        #         )

        #         result = [
        #             item
        #             for item in result
        #             if Topology.IsInstance(
        #                 item,
        #                 "Topology"
        #             )
        #         ]

        #         if result:
        #             return result

        #     except Exception:
        #         pass

        #     try:
        #         result = Cluster.Topologies(
        #             cluster,
        #             tolerance=tolerance,
        #             silent=True
        #         )

        #         if isinstance(result, list):
        #             result = [
        #                 item
        #                 for item in result
        #                 if Topology.IsInstance(
        #                     item,
        #                     "Topology"
        #                 )
        #             ]

        #             if result:
        #                 return result

        #     except Exception:
        #         pass

        #     return []
        def cluster_constituents(cluster):
            """
            Returns the top-level constituent topologies of the input cluster.
            """
            try:
                result = Cluster.Topologies(
                    cluster,
                    tolerance=tolerance,
                    silent=True
                )
            except Exception:
                return []

            if not isinstance(
                result,
                list
            ):
                return []

            return [
                topology
                for topology in result
                if Topology.IsInstance(
                    topology,
                    "Topology"
                )
            ]

        def valid_triangulated_cellcomplex(
            candidate,
            expected_cell_count=None
        ):
            if not Topology.IsInstance(
                candidate,
                "CellComplex"
            ):
                return False

            cells = Topology.Cells(
                candidate,
                silent=True
            ) or []

            if (
                expected_cell_count is not None
                and len(cells) != expected_cell_count
            ):
                return False

            faces = Topology.Faces(
                candidate,
                silent=True
            ) or []

            if not faces:
                return False

            for face in faces:
                vertices = Topology.Vertices(
                    face,
                    silent=True
                ) or []

                if len(vertices) != 3:
                    return False

            return True

        # ------------------------------------------------------------------
        # Validate input.
        # ------------------------------------------------------------------

        if not Topology.IsInstance(
            topology,
            "Topology"
        ):
            if not silent:
                print(
                    "Topology.Triangulate - Error: The input topology parameter "
                    "is not a valid topology. Returning None."
                )
            return None

        topology_type = Topology.Type(
            topology
        )

        # ------------------------------------------------------------------
        # Vertex / Edge / Wire.
        # ------------------------------------------------------------------

        if topology_type in [
            Topology.TypeID("Vertex"),
            Topology.TypeID("Edge"),
            Topology.TypeID("Wire")
        ]:

            if not silent:
                print(
                    "Topology.Triangulate - Warning: The input topology parameter "
                    "contains no faces. Returning the original topology."
                )

            return topology

        # ------------------------------------------------------------------
        # Cluster.
        # ------------------------------------------------------------------

        if topology_type == Topology.TypeID(
            "Cluster"
        ):

            constituents = cluster_constituents(
                topology
            )

            if not constituents:

                if not silent:
                    print(
                        "Topology.Triangulate - Error: Could not retrieve any "
                        "constituent topologies from the input Cluster. "
                        "Returning None."
                    )

                return None

            triangulated_constituents = []

            for constituent in constituents:

                triangulated = Topology.Triangulate(
                    constituent,
                    transferDictionaries=transferDictionaries,
                    mode=mode,
                    meshSize=meshSize,
                    tolerance=tolerance,
                    silent=True
                )

                if not Topology.IsInstance(
                    triangulated,
                    "Topology"
                ):

                    if not silent:
                        print(
                            "Topology.Triangulate - Error: Could not triangulate "
                            "one of the constituent topologies of the input Cluster. "
                            "Returning None."
                        )

                    return None

                triangulated_constituents.append(
                    triangulated
                )

            try:
                return_topology = Cluster.ByTopologies(
                    triangulated_constituents,
                    silent=True
                )

            except TypeError:
                return_topology = Cluster.ByTopologies(
                    triangulated_constituents
                )

            except Exception:
                return_topology = None

            if not Topology.IsInstance(
                return_topology,
                "Cluster"
            ):

                if not silent:
                    print(
                        "Topology.Triangulate - Error: Could not rebuild the "
                        "triangulated Cluster. Returning None."
                    )

                return None

            return return_topology

        # ------------------------------------------------------------------
        # Remember CellComplex cell count before reconstruction.
        # ------------------------------------------------------------------

        expected_cell_count = None

        if topology_type == Topology.TypeID(
            "CellComplex"
        ):

            original_cells = Topology.Cells(
                topology,
                silent=True
            ) or []

            expected_cell_count = len(
                original_cells
            )

        # ------------------------------------------------------------------
        # Retrieve Faces.
        # ------------------------------------------------------------------

        topology_faces = Topology.Faces(
            topology,
            silent=True
        )

        if (
            not isinstance(topology_faces, list)
            or len(topology_faces) == 0
        ):

            if not silent:
                print(
                    "Topology.Triangulate - Error: Could not retrieve any Faces "
                    "from the input Face, Shell, Cell, or CellComplex. "
                    "Returning None."
                )

            return None

        # ------------------------------------------------------------------
        # Triangulate Faces.
        # ------------------------------------------------------------------

        face_triangles = []
        selectors = []

        for face in topology_faces:

            vertices = Topology.Vertices(
                face,
                silent=True
            ) or []

            if len(vertices) > 3:

                triangles = Face.Triangulate(
                    face,
                    mode=mode,
                    meshSize=meshSize,
                    tolerance=tolerance,
                    silent=silent
                )

                if Topology.IsInstance(
                    triangles,
                    "Face"
                ):
                    triangles = [
                        triangles
                    ]

                if not isinstance(
                    triangles,
                    list
                ):

                    if not silent:
                        print(
                            "Topology.Triangulate - Error: Could not triangulate "
                            "one of the Faces of the input topology. Returning None."
                        )

                    return None

                triangles = [
                    triangle
                    for triangle in triangles
                    if Topology.IsInstance(
                        triangle,
                        "Face"
                    )
                ]

                if not triangles:

                    if not silent:
                        print(
                            "Topology.Triangulate - Error: Face triangulation "
                            "returned no valid triangular Faces. Returning None."
                        )

                    return None

            else:
                triangles = [
                    face
                ]

            for triangle in triangles:

                if transferDictionaries:

                    selector = Topology.Centroid(
                        triangle
                    )

                    if Topology.IsInstance(
                        selector,
                        "Vertex"
                    ):

                        selector = Topology.SetDictionary(
                            selector,
                            Topology.Dictionary(
                                face
                            ),
                            silent=True
                        )

                        selectors.append(
                            selector
                        )

                face_triangles.append(
                    triangle
                )

        if not face_triangles:

            if not silent:
                print(
                    "Topology.Triangulate - Error: No valid triangular Faces "
                    "were produced. Returning None."
                )

            return None

        # ------------------------------------------------------------------
        # Typed reconstruction.
        # ------------------------------------------------------------------

        return_topology = None

        if topology_type in [
            Topology.TypeID("Face"),
            Topology.TypeID("Shell")
        ]:

            try:
                return_topology = Shell.ByFaces(
                    face_triangles,
                    tolerance=tolerance,
                    silent=True
                )

            except TypeError:
                return_topology = Shell.ByFaces(
                    face_triangles,
                    tolerance=tolerance
                )

            except Exception:
                return_topology = None

        elif topology_type == Topology.TypeID(
            "Cell"
        ):

            try:
                return_topology = Cell.ByFaces(
                    face_triangles,
                    tolerance=tolerance,
                    silent=True
                )

            except TypeError:
                return_topology = Cell.ByFaces(
                    face_triangles,
                    tolerance=tolerance
                )

            except Exception:
                return_topology = None

        elif topology_type == Topology.TypeID(
            "CellComplex"
        ):

            # --------------------------------------------------------------
            # PythonOCC / future-backend path.
            #
            # This is the already-green path and is intentionally unchanged.
            # --------------------------------------------------------------

            if not Topology._IsTopologicCoreBackend():

                try:
                    return_topology = Core.CellComplex.ByFaces(
                        face_triangles,
                        tolerance,
                        False
                    )

                except TypeError:

                    try:
                        return_topology = Core.CellComplex.ByFaces(
                            face_triangles,
                            tolerance
                        )

                    except TypeError:

                        try:
                            return_topology = Core.CellComplex.ByFaces(
                                face_triangles
                            )

                        except Exception:
                            return_topology = None

                    except Exception:
                        return_topology = None

                except Exception:
                    return_topology = None

                if Topology.IsInstance(
                    return_topology,
                    "CellComplex"
                ):

                    resulting_cells = Topology.Cells(
                        return_topology,
                        silent=True
                    ) or []

                    if (
                        expected_cell_count is not None
                        and len(resulting_cells)
                        != expected_cell_count
                    ):

                        if not silent:
                            print(
                                "Topology.Triangulate - Error: The active backend "
                                "changed the CellComplex cell count from "
                                f"{expected_cell_count} to "
                                f"{len(resulting_cells)}. Returning None."
                            )

                        return None

            # --------------------------------------------------------------
            # TopologicCore compatibility path.
            #
            # Do not use public CellComplex.ByFaces here. Its coplanar-face
            # preprocessing can dissolve the triangular subdivisions we have
            # just created.
            # --------------------------------------------------------------

            else:

                try:
                    candidate = CellComplex._ByFaces(
                        face_triangles,
                        tolerance=tolerance,
                        silent=True
                    )

                except Exception:
                    candidate = None

                if valid_triangulated_cellcomplex(
                    candidate,
                    expected_cell_count
                ):
                    return_topology = candidate

                else:
                    # ------------------------------------------------------
                    # Secondary pure-Topologic reconstruction path.
                    # ------------------------------------------------------

                    try:
                        candidate = CellComplex.ByFacesTopologic(
                            face_triangles,
                            tolerance=tolerance,
                            silent=True
                        )

                    except Exception:
                        candidate = None

                    if valid_triangulated_cellcomplex(
                        candidate,
                        expected_cell_count
                    ):
                        return_topology = candidate

                    else:
                        return_topology = None

        # ------------------------------------------------------------------
        # Legacy TopologicCore reconstruction fallback.
        # ------------------------------------------------------------------

        if not Topology.IsInstance(
            return_topology,
            "Topology"
        ):

            if Topology._IsTopologicCoreBackend():

                try:
                    return_topology = Cluster.ByTopologies(
                        face_triangles,
                        silent=True
                    )

                except TypeError:
                    return_topology = Cluster.ByTopologies(
                        face_triangles
                    )

                except Exception:
                    return_topology = None

                if Topology.IsInstance(
                    return_topology,
                    "Topology"
                ):

                    return_topology = Topology.SelfMerge(
                        return_topology,
                        tolerance=tolerance,
                        silent=silent
                    )

            else:

                if not silent:
                    print(
                        "Topology.Triangulate - Error: The active backend could "
                        "not reconstruct the triangulated topology. Returning None."
                    )

                return None

        if not Topology.IsInstance(
            return_topology,
            "Topology"
        ):

            if not silent:
                print(
                    "Topology.Triangulate - Error: Could not reconstruct the "
                    "triangulated topology. Returning None."
                )

            return None

        # ------------------------------------------------------------------
        # A TopologicCore CellComplex fallback must still satisfy the actual
        # triangulation contract.
        # ------------------------------------------------------------------

        if (
            topology_type
            == Topology.TypeID("CellComplex")
            and Topology._IsTopologicCoreBackend()
            and not valid_triangulated_cellcomplex(
                return_topology,
                expected_cell_count
            )
        ):

            if not silent:
                print(
                    "Topology.Triangulate - Error: TopologicCore could not "
                    "reconstruct the CellComplex while preserving triangular "
                    "faces and cell count. Returning None."
                )

            return None

        # ------------------------------------------------------------------
        # Transfer Face dictionaries.
        # ------------------------------------------------------------------

        if (
            transferDictionaries
            and selectors
        ):

            return_topology = Topology.TransferDictionariesBySelectors(
                return_topology,
                selectors,
                tranFaces=True,
                tolerance=tolerance
            )

        return return_topology

    @staticmethod
    def Type(topology, silent: bool = False):
        """
        Returns the type of the input topology.

        Parameters
        ----------
        topology : topologic_core.Topology
            The input topology.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        int
            The type of the input topology.

        """
        if not Topology.IsInstance(topology, "topology"):
            if not silent:
                print("Topology.Type - Error: The input topology parameter is not a valid topology. Returning None.")
            return None
        
        # return topology.Type() # H to Core
        return Core.InstanceCall(topology, 'Type')
    
    @staticmethod
    def TypeAsString(topology, silent: bool = False):
        """
        Returns the type of the input topology or graph as a string.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The input topology or graph.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        str
            The type of the topology or graph as a string.

        """

        try:
            from topologicpy.TGraph import TGraph
            if isinstance(topology, TGraph):
                return "TGraph"
        except Exception:
            pass

        if Topology.IsInstance(topology, "Graph"):
            return "Graph"

        if Topology.IsInstance(topology, "Topology"):
            return Core.InstanceCall(topology, "GetTypeAsString")

        if not silent:
            print("Topology.TypeAsString - Error: The input topology parameter is not a valid topology or graph. Returning None.")

        return None
    
    @staticmethod
    def TypeID(name: str = None, silent: bool = False) -> int:
        """
        Returns the type id of the input name string.

        Parameters
        ----------
        name : str , optional
            The input class name string. This could be one of:
                "vertex",
                "edge",
                "wire",
                "face",
                "shell",
                "cell",
                "cellcomplex",
                "cluster",
                "aperture",
                "context",
                "dictionary",
                "graph",
                "tgraph",
                "topology"

            It is case insensitive. Default is None.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        int
            The type id of the input topologyType string.

        """

        if not isinstance(name, str):
            if not silent:
                print("Topology.TypeID - Error: The input topologyType parameter is not a valid string. Returning None.")
            return None

        name = name.lower()

        if name not in [
            "vertex", "edge", "wire",
            "face", "shell", "cell",
            "cellcomplex", "cluster", "aperture",
            "context", "dictionary", "graph",
            "tgraph", "topology"
        ]:
            print("Topology.TypeID - Error: The input name parameter is not a recognized string. Returning None.")
            return None

        if name == "vertex":
            return 1
        elif name == "edge":
            return 2
        elif name == "wire":
            return 4
        elif name == "face":
            return 8
        elif name == "shell":
            return 16
        elif name == "cell":
            return 32
        elif name == "cellcomplex":
            return 64
        elif name == "cluster":
            return 128
        elif name == "aperture":
            return 256
        elif name == "context":
            return 512
        elif name == "dictionary":
            return 1024
        elif name == "graph":
            return 2048
        elif name == "tgraph":
            return 2048
        elif name == "topology":
            return 4096

        if not silent:
            print("Topology.TypeID - Error: The input name parameter is not recognized. Returning None.")
        return None
    
    @staticmethod
    def Union(
        topologyA,
        topologyB,
        tranDict: bool = False,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Unions the input operand topologies.
        See https://en.wikipedia.org/wiki/Boolean_operation.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tranDict : bool , optional
            If set to True the dictionaries of the operands are merged and
            transferred to the result. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Topology
            The resultant topology.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Cluster import Cluster

        if (
            not Topology.IsInstance(
                topologyA,
                "topology"
            )
            and not Topology.IsInstance(
                topologyB,
                "topology"
            )
        ):
            if not silent:
                print(
                    "Topology.Union - Error: The inputs topologyA and topologyB "
                    "are not valid topologies. Returning None."
                )
            return None

        if not Topology.IsInstance(
            topologyA,
            "topology"
        ):
            if not silent:
                print(
                    "Topology.Union - Warning: The topologyA input parameter is "
                    "not a valid topology. Returning topologyB."
                )
            return topologyB

        if not Topology.IsInstance(
            topologyB,
            "topology"
        ):
            if not silent:
                print(
                    "Topology.Union - Warning: The topologyB input parameter is "
                    "not a valid topology. Returning topologyA."
                )
            return topologyA

        # --------------------------------------------------------------
        # Normal backend path
        #
        # Trust the backend result. The special cases below exist solely
        # to compensate for known TopologicCore Boolean behaviour.
        # --------------------------------------------------------------

        if not Topology._IsTopologicCoreBackend():
            return Topology._Boolean(
                topologyA,
                topologyB,
                operation="union",
                tranDict=tranDict,
                tolerance=tolerance,
                silent=silent
            )

        # --------------------------------------------------------------
        # Legacy TopologicCore Face / Face workaround
        # --------------------------------------------------------------

        if (
            Topology.IsInstance(
                topologyA,
                "Face"
            )
            and Topology.IsInstance(
                topologyB,
                "Face"
            )
        ):
            if Face.IsCoplanar(
                topologyA,
                topologyB
            ):
                topologyC = Topology._Boolean(
                    topologyA,
                    topologyB,
                    operation="merge",
                    tranDict=tranDict,
                    tolerance=tolerance
                )

                if Topology.IsInstance(
                    topologyC,
                    "Cluster"
                ):
                    return topologyC

                elif Topology.IsInstance(
                    topologyC,
                    "Shell"
                ):
                    eb_list = Shell.ExternalBoundary(
                        topologyC
                    )

                    if Topology.IsInstance(
                        eb_list,
                        "Cluster"
                    ):
                        eb_list = Topology.Wires(
                            eb_list
                        )

                    else:
                        eb_list = [
                            eb_list
                        ]

                    topologyA_wire = Face.ExternalBoundary(
                        topologyA
                    )

                    topologyB_wire = Face.ExternalBoundary(
                        topologyB
                    )

                    internal_boundaries = []
                    found = False

                    for eb in eb_list:
                        v = Topology.Vertices(
                            eb
                        )[0]

                        if found is False:
                            if (
                                Vertex.IsInternal(
                                    v,
                                    topologyA_wire,
                                    tolerance=tolerance
                                )
                                or Vertex.IsInternal(
                                    v,
                                    topologyB_wire,
                                    tolerance=tolerance
                                )
                            ):
                                external_boundary = eb
                                found = True

                        else:
                            internal_boundaries.append(
                                eb
                            )

                    return Face.ByWires(
                        external_boundary,
                        internal_boundaries
                    )

        # --------------------------------------------------------------
        # Legacy TopologicCore Edge / Wire workaround
        # --------------------------------------------------------------

        elif (
            Topology.TypeAsString(
                topologyA
            ).lower() in [
                "edge",
                "wire"
            ]
            and Topology.TypeAsString(
                topologyB
            ).lower() in [
                "edge",
                "wire"
            ]
        ):
            union = Topology.Merge(
                topologyA,
                topologyB
            )

            if Topology.IsInstance(
                union,
                "wire"
            ):
                union = Wire.RemoveCollinearEdges(
                    union
                )

                return union

            elif Topology.IsInstance(
                union,
                "cluster"
            ):
                wires = Cluster.Wires(
                    union
                )

                final_topologies = Cluster.FreeEdges(
                    union
                )

                for wire in wires:
                    final_topologies.append(
                        Wire.RemoveCollinearEdges(
                            wire
                        )
                    )

                return Cluster.ByTopologies(
                    final_topologies
                )

        # --------------------------------------------------------------
        # General TopologicCore Boolean Union
        # --------------------------------------------------------------

        return Topology._Boolean(
            topologyA,
            topologyB,
            operation="union",
            tranDict=tranDict,
            tolerance=tolerance,
            silent=silent
        )

    @staticmethod
    def UUID(topology, namespace: str = "topologicpy", uuidKey: str = "uuid", deterministic: bool = False, silent: bool = False):
        """
        Returns the UUID of the input topology or graph.

        If deterministic is False, this method returns an existing UUID stored in the
        topology dictionary. If no UUID exists, a new UUID v4 is created, stored in
        the topology dictionary, and returned. This is the fast path.

        If deterministic is True, this method computes a UUID v5 from the topology's
        geometry and dictionaries. This is slower because it traverses the full
        topology or graph.

        Parameters
        ----------
        topology : topologic_core.Topology, topologic_core.Graph, or topologicpy.TGraph
            The input topology or graph.
        namespace : str , optional
            The namespace string to use when deterministic is True. Default is "topologicpy".
        uuidKey : str , optional
            The dictionary key under which the UUID is stored. Default is "uuid".
        deterministic : bool , optional
            If set to True, compute a deterministic content-derived UUID. If set to
            False, return or create a persistent stored UUID. Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        str
            The UUID string of the input topology or graph.

        """

        import uuid

        from topologicpy.Dictionary import Dictionary

        is_tgraph = False
        try:
            from topologicpy.TGraph import TGraph
            is_tgraph = isinstance(topology, TGraph)
        except Exception:
            TGraph = None
            is_tgraph = False

        if not is_tgraph and not Topology.IsInstance(topology, "Topology") and not Topology.IsInstance(topology, "Graph"):
            if not silent:
                print("Topology.UUID - Error: The input topology parameter is not a valid topology or graph. Returning None.")
            return None

        # Fast path: dictionary lookup, then create and store a UUID if missing.
        if not deterministic:
            if is_tgraph:
                d = TGraph.Dictionary(topology)
                uuid_value = d.get(uuidKey, None) if isinstance(d, dict) else None

                if uuid_value is None:
                    uuid_value = str(uuid.uuid4())
                    d = dict(d) if isinstance(d, dict) else {}
                    d[uuidKey] = uuid_value
                    topology.SetDictionary(d)

                return str(uuid_value)

            d = Topology.Dictionary(topology)
            uuid_value = Dictionary.ValueAtKey(d, uuidKey, None)

            if uuid_value is None:
                uuid_value = str(uuid.uuid4())
                d = Dictionary.SetValueAtKey(d, uuidKey, uuid_value)
                topology = Topology.SetDictionary(topology, d, silent=silent)

            return str(uuid_value)

        # Slow path: deterministic UUID based on current topology/graph content.
        predefined_namespace_dns = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")
        namespace_uuid = uuid.uuid5(predefined_namespace_dns, namespace)

        if is_tgraph:
            data = TGraph.ToPython(topology, includeRepresentations=False)

            # Exclude the UUID key itself from deterministic hashing if present.
            graph_dict = dict(data.get("dictionary", {}))
            graph_dict.pop(uuidKey, None)

            vertices = []
            for v in data.get("vertices", []):
                if not isinstance(v, dict):
                    continue
                vd = dict(v.get("dictionary", {}))
                vd.pop(uuidKey, None)
                vertices.append({
                    "index": v.get("index"),
                    "active": v.get("active", True),
                    "dictionary": dict(sorted(vd.items(), key=lambda item: str(item[0]))),
                })

            edges = []
            for e in data.get("edges", []):
                if not isinstance(e, dict):
                    continue
                ed = dict(e.get("dictionary", {}))
                ed.pop(uuidKey, None)
                edges.append({
                    "index": e.get("index"),
                    "src": e.get("src"),
                    "dst": e.get("dst"),
                    "directed": e.get("directed", False),
                    "active": e.get("active", True),
                    "dictionary": dict(sorted(ed.items(), key=lambda item: str(item[0]))),
                })

            final_data = {
                "type": "TGraph",
                "directed": data.get("directed", False),
                "allowSelfLoops": data.get("allowSelfLoops", True),
                "allowParallelEdges": data.get("allowParallelEdges", False),
                "dictionary": dict(sorted(graph_dict.items(), key=lambda item: str(item[0]))),
                "vertices": sorted(vertices, key=lambda item: item.get("index", 0)),
                "edges": sorted(edges, key=lambda item: item.get("index", 0)),
            }

            final_str = json.dumps(final_data, sort_keys=True, default=str)
            return str(uuid.uuid5(namespace_uuid, final_str))

        if Topology.IsInstance(topology, "Graph"):
            from topologicpy.Graph import Graph

            mesh_data = Graph.MeshData(topology)

            final_str = (
                str(mesh_data.get("vertices", [])) +
                str(mesh_data.get("edges", [])) +
                str(mesh_data.get("vertexDictionaries", [])) +
                str(mesh_data.get("edgeDictionaries", []))
            )

            return str(uuid.uuid5(namespace_uuid, final_str))

        cellComplexes = Topology.CellComplexes(topology, silent=True) or []
        cells = Topology.Cells(topology, silent=True) or []
        shells = Topology.Shells(topology, silent=True) or []
        faces = Topology.Faces(topology, silent=True) or []
        wires = Topology.Wires(topology, silent=True) or []
        edges = Topology.Edges(topology, silent=True) or []
        vertices = Topology.Vertices(topology, silent=True) or []
        apertures = Topology.Apertures(topology, subTopologyType="all", silent=True) or []

        subTopologies = cellComplexes + cells + shells + faces + wires + edges + vertices + apertures

        dictionaries = [Dictionary.PythonDictionary(Topology.Dictionary(topology))]
        dictionaries.extend(
            Dictionary.PythonDictionary(Topology.Dictionary(subTopology))
            for subTopology in subTopologies
        )

        top_geom = Topology.Geometry(topology, mantissa=6)

        final_str = (
            str(top_geom.get("vertices", [])) +
            str(top_geom.get("edges", [])) +
            str(top_geom.get("faces", [])) +
            str(dictionaries)
        )

        return str(uuid.uuid5(namespace_uuid, final_str))
    
    @staticmethod
    def View3D(*topologies,
               uuid = None,
               nameKey="name",
               colorKey="color",
               opacityKey="opacity",
               defaultColor=[256,256,256],
               defaultOpacity=0.5,
               transposeAxes: bool = True,
               mode: int = 0,
               meshSize: float = None,
               overwrite: bool = False,
               mantissa: int = 6,
               tolerance: float = 0.0001,
               silent: bool = False):
        """
        Sends the input topologies to 3dviewer.net. The topologies must be 3D meshes.

        Parameters
        ----------
        topologies : list or comma separated topologies
            The input list of topologies.
        uuid : UUID , optional
            The UUID v5 to use to identify these topologies. Default is a UUID based on the topologies themselves.
        nameKey : str , optional
            The topology dictionary key under which to find the name of the topology. Default is "name".
        colorKey : str, optional
            The topology dictionary key under which to find the color of the topology. Default is "color".
        opacityKey : str , optional
            The topology dictionary key under which to find the opacity of the topology. Default is "opacity".
        defaultColor : list , optional
            The default color to use if no color is stored in the topology dictionary. Default is [255,255, 255] (white).
        defaultOpacity : float , optional
            The default opacity to use of no opacity is stored in the topology dictionary. This must be between 0 and 1. Default is 1 (fully opaque).
        transposeAxes : bool , optional
            If set to True the Z and Y coordinates are transposed so that Y points "up"
        mode : int , optional
            The desired mode of meshing algorithm (for triangulation). Several options are available:
            0: Classic
            1: MeshAdapt
            3: Initial Mesh Only
            5: Delaunay
            6: Frontal-Delaunay
            7: BAMG
            8: Fontal-Delaunay for Quads
            9: Packing of Parallelograms
            All options other than 0 (Classic) use the gmsh library. See https://gmsh.info/doc/texinfo/gmsh.html#Mesh-options
            WARNING: The options that use gmsh can be very time consuming and can create very heavy geometry.
        meshSize : float , optional
            The desired size of the mesh when using the "mesh" option. If set to None, it will be
            calculated automatically and set to 10% of the overall size of the face.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        overwrite : bool , optional
            If set to True the ouptut file will overwrite any pre-existing file. Otherwise, it won't. Default is False.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        bool
            True if the export operation is successful. False otherwise.

        """
        from topologicpy.Helper import Helper
        from topologicpy.Cluster import Cluster
        import requests
        import webbrowser

        if isinstance(topologies, tuple):
            topologies = Helper.Flatten(list(topologies))
        if isinstance(topologies, list):
            new_topologies = [d for d in topologies if Topology.IsInstance(d, "Topology")]
        if len(new_topologies) == 0:
            if not silent:
                print("Topology.View3D - Error: the input topologies parameter does not contain any valid topologies. Returning None.")
            return None
        if not isinstance(new_topologies, list):
            if not silent:
                print("Topology.View3D - Error: The input topologies parameter is not a valid list. Returning None.")
            return None

        if uuid == None:
            cluster = Cluster.ByTopologies(new_topologies)
            uuid = Topology.UUID(cluster)
        obj_string, mtl_string = Topology.OBJString(new_topologies,
                                                    nameKey=nameKey,
                                                    colorKey=colorKey,
                                                    opacityKey=opacityKey,
                                                    defaultColor=defaultColor,
                                                    defaultOpacity=defaultOpacity,
                                                    transposeAxes=transposeAxes,
                                                    mode=mode,
                                                    meshSize=meshSize,
                                                    mantissa=mantissa,
                                                    tolerance=tolerance)
        

        file_contents = {}
        file_contents['example.obj'] = obj_string
        file_contents['example.mtl'] = mtl_string

        try:
            response = requests.post('https://3dviewer.deno.dev/upload/'+str(uuid), files=file_contents)
            if response.status_code != 200:
                print(f'Failed to upload file(s): {response.status_code} {response.reason}')
            # Open the web page in the default web browser
            # URL of the web page you want to open
            url = "https://3dviewer.deno.dev/#channel="+str(uuid)
            if not url in opened_urls:
                opened_urls.add(url)
                webbrowser.open(url)
        except requests.exceptions.RequestException as e:
            if not silent:
                print(f'Topology.View3D - Error: Could not upload file(s): {e}. Returning None.')
            return None
        return True
    
    @staticmethod
    def XOR(topologyA, topologyB, tranDict: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns the symmetric difference (XOR) of the input operand topologies. See https://en.wikipedia.org/wiki/Boolean_operation.

        Parameters
        ----------
        topologyA : topologic_core.Topology
            The first input topology.
        topologyB : topologic_core.Topology
            The second input topology.
        tranDict : bool , optional
            If set to True the dictionaries of the operands are merged and transferred to the result. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Topology
            the resultant topology.

        """
        return Topology._Boolean(topologyA=topologyA, topologyB=topologyB, operation="symdif", tranDict=tranDict, tolerance=tolerance, silent=silent)
