# re-export the extension module
from .topologic import *
