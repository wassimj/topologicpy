# Copyright (C) 2024
# Wassim Jabi <wassim.jabi@gmail.com>
#
# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU Affero General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
# details.
#
# You should have received a copy of the GNU Affero General Public License along with
# this program. If not, see <https://www.gnu.org/licenses/>.

import math

class Matrix:
    @staticmethod
    def Add(matA, matB):
        """
        Adds the two input matrices.
        
        Parameters
        ----------
        matA : list
            The first input matrix.
        matB : list
            The second input matrix.

        Returns
        -------
        list
            The matrix resulting from the addition of the two input matrices.

        """
        matC = []
        if not isinstance(matA, list):
            return None
        if not isinstance(matB, list):
            return None
        for i in range(len(matA)):
            tempRow = []
            for j in range(len(matB)):
                tempRow.append(matA[i][j] + matB[i][j])
            matC.append(tempRow)
        return matC

    @staticmethod
    def ByRotation(angleX=0, angleY=0, angleZ=0, order="xyz"):
        def rotateXMatrix(radians):
            c = math.cos(radians)
            s = math.sin(radians)
            return [[1, 0, 0, 0],
                    [0, c, -s, 0],
                    [0, s, c, 0],
                    [0, 0, 0, 1]]

        def rotateYMatrix(radians):
            c = math.cos(radians)
            s = math.sin(radians)
            return [[c, 0, s, 0],
                    [0, 1, 0, 0],
                    [-s, 0, c, 0],
                    [0, 0, 0, 1]]

        def rotateZMatrix(radians):
            c = math.cos(radians)
            s = math.sin(radians)
            return [[c, -s, 0, 0],
                    [s, c, 0, 0],
                    [0, 0, 1, 0],
                    [0, 0, 0, 1]]

        xMat = rotateXMatrix(math.radians(angleX))
        yMat = rotateYMatrix(math.radians(angleY))
        zMat = rotateZMatrix(math.radians(angleZ))

        if order.lower() == "xyz":
            return Matrix.Multiply(Matrix.Multiply(zMat, yMat), xMat)
        if order.lower() == "xzy":
            return Matrix.Multiply(Matrix.Multiply(yMat, zMat), xMat)
        if order.lower() == "yxz":
            return Matrix.Multiply(Matrix.Multiply(zMat, xMat), yMat)
        if order.lower() == "yzx":
            return Matrix.Multiply(Matrix.Multiply(xMat, zMat), yMat)
        if order.lower() == "zxy":
            return Matrix.Multiply(Matrix.Multiply(yMat, xMat), zMat)
        if order.lower() == "zyx":
            return Matrix.Multiply(Matrix.Multiply(xMat, yMat), zMat)

    
    @staticmethod
    def ByScaling(scaleX=1.0, scaleY=1.0, scaleZ=1.0):
        """
        Creates a 4x4 scaling matrix.

        Parameters
        ----------
        scaleX : float , optional
            The desired scaling factor along the X axis. The default is 1.
        scaleY : float , optional
            The desired scaling factor along the X axis. The default is 1.
        scaleZ : float , optional
            The desired scaling factor along the X axis. The default is 1.
        
        Returns
        -------
        list
            The created 4X4 scaling matrix.

        """
        return [[scaleX,0,0,0],
                [0,scaleY,0,0],
                [0,0,scaleZ,0],
                [0,0,0,1]]
    
    @staticmethod
    def ByTranslation(translateX=0, translateY=0, translateZ=0):
        """
        Creates a 4x4 translation matrix.

        Parameters
        ----------
        translateX : float , optional
            The desired translation distance along the X axis. The default is 0.
        translateY : float , optional
            The desired translation distance along the X axis. The default is 0.
        translateZ : float , optional
            The desired translation distance along the X axis. The default is 0.
        
        Returns
        -------
        list
            The created 4X4 translation matrix.

        """
        return [[1,0,0,translateX],
                [0,1,0,translateY],
                [0,0,1,translateZ],
                [0,0,0,1]]
    
    @staticmethod
    def EigenvaluesAndVectors(matrix, mantissa: int = 6, silent: bool = False):
        import numpy as np
        """
        Returns the eigenvalues and eigenvectors of the input matrix. See https://en.wikipedia.org/wiki/Eigenvalues_and_eigenvectors
        
        Parameters
        ----------
        matrix : list
            The input matrix. Assumed to be a laplacian matrix.
        mantissa : int , optional
            The desired length of the mantissa. The default is 6.
        silent : bool , optional
            If set to True, no error and warning messages are printed. Otherwise, they are. The default is False.

        Returns
        -------
        list
            The list of eigenvalues and eigenvectors of the input matrix.

        """
        from topologicpy.Helper import Helper
        import numpy as np

        if not isinstance(matrix, list):
            if not silent:
                print("Matrix.Eigenvalues - Error: The input matrix parameter is not a valid matrix. Returning None.")
            return None
        
        np_matrix = np.array(matrix)
        if not isinstance(np_matrix, np.ndarray):
            if not silent:
                print("Matrix.Eigenvalues - Error: The input matrix parameter is not a valid matrix. Returning None.")
            return None
        
        # Square check
        if np_matrix.shape[0] != np_matrix.shape[1]:
            if not silent:
                print("Matrix.Eigenvalues - Error: The input matrix parameter is not a square matrix. Returning None.")
            return None
        
        # Symmetry check
        if not np.allclose(np_matrix, np_matrix.T):
            if not silent:
                print("Matrix.Eigenvalues - Error: The input matrix is not symmetric. Returning None.")
            return None
        
        # # Degree matrix
        # degree_matrix = np.diag(np_matrix.sum(axis=1))
        
        # # Laplacian matrix
        # laplacian_matrix = degree_matrix - np_matrix
        
        # Eigenvalues
        eigenvalues, eigenvectors = np.linalg.eig(np_matrix)
        
        e_values = [round(x, mantissa) for x in list(np.sort(eigenvalues))]
        e_vectors = []
        for eigenvector in eigenvectors:
            e_vectors.append([round(x, mantissa) for x in eigenvector])
        e_vectors = Helper.Sort(e_vectors, list(eigenvalues))
        return e_values, e_vectors
    
    @staticmethod
    def Multiply(matA, matB):
        """
        Multiplies two matrices (matA and matB). The first matrix (matA) is applied first in the transformation,
        followed by the second matrix (matB).

        Parameters
        ----------
        matA : list of list of float
            The first input matrix.
        matB : list of list of float
            The second input matrix.

        Returns
        -------
        list of list of float
            The resulting matrix after multiplication.

        """
        # Input validation
        if not (isinstance(matA, list) and all(isinstance(row, list) for row in matA) and
                isinstance(matB, list) and all(isinstance(row, list) for row in matB)):
            raise ValueError("Both inputs must be 2D lists representing matrices.")
        
        # Check matrix dimension compatibility
        if len(matA[0]) != len(matB):
            raise ValueError("Number of columns in matA must equal the number of rows in matB.")

        # Dimensions of the resulting matrix
        rows_A, cols_A = len(matA), len(matA[0])
        rows_B, cols_B = len(matB), len(matB[0])
        result = [[0.0] * cols_B for _ in range(rows_A)]

        # Matrix multiplication
        for i in range(rows_A):
            for j in range(cols_B):
                result[i][j] = sum(matA[i][k] * matB[k][j] for k in range(cols_A))

        return result

    @staticmethod
    def Subtract(matA, matB):
        """
        Subtracts the two input matrices.
        
        Parameters
        ----------
        matA : list
            The first input matrix.
        matB : list
            The second input matrix.

        Returns
        -------
        list
            The matrix resulting from the subtraction of the second input matrix from the first input matrix.

        """
        if not isinstance(matA, list):
            return None
        if not isinstance(matB, list):
            return None
        matC = []
        for i in range(len(matA)):
            tempRow = []
            for j in range(len(matB)):
                tempRow.append(matA[i][j] - matB[i][j])
            matC.append(tempRow)
        return matC

    @staticmethod
    def Transpose(matrix):
        """
        Transposes the input matrix.
        
        Parameters
        ----------
        matrix : list
            The input matrix.

        Returns
        -------
        list
            The transposed matrix.

        """
        return [list(x) for x in zip(*matrix)]
