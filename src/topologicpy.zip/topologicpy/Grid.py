# Copyright (C) 2026
# Wassim Jabi <wassim.jabi@gmail.com>
#
# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU Lesser General Public License as published by the Free
# Software Foundation, either version 3.0 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
# details.
#
# You should have received a copy of the GNU Lesser General Public License along
# with this program. If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

import math

from topologicpy.Core import Core


class Grid:
    """
    Creates grids on planar and non-planar Faces.

    Grid.OnFace creates the Edges; Grid.Vertices also finds their intersections.
    """

    # -------------------------------------------------------------------------
    # General helpers
    # -------------------------------------------------------------------------

    @staticmethod
    def _Tolerance(tolerance=0.0001):
        try:
            return max(abs(float(tolerance)), 1.0e-12)
        except Exception:
            return 0.0001

    @staticmethod
    def _Coordinates(vertex):
        from topologicpy.Vertex import Vertex
        if vertex is None:
            return None
        try:
            return [float(x) for x in Vertex.Coordinates(vertex, mantissa=None)]
        except Exception:
            try:
                return [float(x) for x in Vertex.Coordinates(vertex)]
            except Exception:
                return None

    @staticmethod
    def _Add(a, b):
        return [a[i] + b[i] for i in range(3)]

    @staticmethod
    def _Subtract(a, b):
        return [a[i] - b[i] for i in range(3)]

    @staticmethod
    def _Scale(v, s):
        return [v[i] * s for i in range(3)]

    @staticmethod
    def _Dot(a, b):
        return sum(a[i] * b[i] for i in range(3))

    @staticmethod
    def _Normalize(v, tolerance=0.0001):
        if not isinstance(v, (list, tuple)) or len(v) != 3:
            return None
        try:
            v = [float(x) for x in v]
        except Exception:
            return None
        m = math.sqrt(Grid._Dot(v, v))
        if m <= Grid._Tolerance(tolerance):
            return None
        return [x / m for x in v]

    @staticmethod
    def _Basis(normal, xDirection=None, tolerance=0.0001):
        """Return a stable world-oriented basis for a planar Face."""
        n = Grid._Normalize(normal, tolerance)
        if n is None:
            return None

        candidates = []
        if isinstance(xDirection, (list, tuple)) and len(xDirection) == 3:
            candidates.append(xDirection)
        candidates.extend(([1, 0, 0], [0, 1, 0], [0, 0, 1]))

        u = None
        for candidate in candidates:
            d = Grid._Normalize(candidate, tolerance)
            if d is None:
                continue
            p = Grid._Subtract(d, Grid._Scale(n, Grid._Dot(d, n)))
            u = Grid._Normalize(p, tolerance)
            if u is not None:
                break
        if u is None:
            return None

        # Prefer world Z on wall-like Faces and world Y on horizontal Faces.
        for candidate in ([0, 0, 1], [0, 1, 0], [1, 0, 0]):
            d = Grid._Normalize(candidate, tolerance)
            p = Grid._Subtract(d, Grid._Scale(n, Grid._Dot(d, n)))
            p = Grid._Subtract(p, Grid._Scale(u, Grid._Dot(p, u)))
            v = Grid._Normalize(p, tolerance)
            if v is not None:
                return u, v
        return None

    @staticmethod
    def _SetDictionary(topology, metadata):
        from topologicpy.Topology import Topology
        metadata = {str(k): v for k, v in metadata.items() if v is not None}
        try:
            result = Topology.SetDictionary(topology, metadata, silent=True)
            return result if result is not None else topology
        except Exception:
            return topology

    @staticmethod
    def _Labels(count, specification):
        if specification is None or specification is False:
            return [None] * count
        if specification is True:
            specification = "numbers"
        if isinstance(specification, (list, tuple)):
            result = [str(x) for x in specification[:count]]
            return result + [None] * (count - len(result))
        if isinstance(specification, str):
            mode = specification.lower()
            if mode in ("numbers", "numeric"):
                return [str(i + 1) for i in range(count)]
            if mode in ("letters", "alpha", "alphabetic"):
                result = []
                for index in range(count):
                    n = index + 1
                    label = ""
                    while n:
                        n, r = divmod(n - 1, 26)
                        label = chr(65 + r) + label
                    result.append(label)
                return result
            return [f"{specification}{i + 1}" for i in range(count)]
        return [None] * count

    @staticmethod
    def _Unique(values, tolerance=1.0e-10):
        result = []
        for value in sorted(float(x) for x in values):
            if not result or abs(value - result[-1]) > tolerance:
                result.append(value)
        return result

    # -------------------------------------------------------------------------
    # Placement helpers
    # -------------------------------------------------------------------------

    @staticmethod
    def _RegularDistances(length, spacing, alignment, includeBoundary, tolerance):
        """Return regularly spaced physical distances in [0, length]."""
        tol = Grid._Tolerance(tolerance)
        try:
            length = float(length)
            spacing = abs(float(spacing))
        except Exception:
            return None, None
        if length <= tol or spacing <= tol:
            return None, None

        alignment = str(alignment).lower()
        if alignment == "center":
            datum = 0.5 * length
        elif alignment in ("start", "left", "bottom", "lower"):
            datum = 0.0
        elif alignment in ("end", "right", "top", "upper"):
            datum = length
        else:
            return None, None

        values = [datum]
        k = 1
        while datum - k * spacing >= -tol:
            values.append(datum - k * spacing)
            k += 1
        k = 1
        while datum + k * spacing <= length + tol:
            values.append(datum + k * spacing)
            k += 1

        if includeBoundary:
            values.extend((0.0, length))

        values = [min(length, max(0.0, x)) for x in values
                  if -tol <= x <= length + tol]
        return Grid._Unique(values, max(tol, 1.0e-10)), datum

    @staticmethod
    def _ExplicitValues(values, includeBoundary):
        if values is None:
            return None
        if not isinstance(values, (list, tuple)):
            values = [values]
        result = []
        for value in values:
            try:
                value = min(1.0, max(0.0, float(value)))
                if math.isfinite(value):
                    result.append(value)
            except Exception:
                pass
        if includeBoundary:
            result.extend((0.0, 1.0))
        return Grid._Unique(result)

    @staticmethod
    def _DivisionValues(divisions, includeBoundary):
        try:
            divisions = int(divisions)
        except Exception:
            return None
        if divisions < 1:
            return None
        values = [i / divisions for i in range(divisions + 1)]
        return values if includeBoundary else values[1:-1]

    # -------------------------------------------------------------------------
    # Surface metric
    # -------------------------------------------------------------------------

    @staticmethod
    def _SurfaceMetric(face, axis, samples):
        """
        Return (normalized parameters, cumulative physical lengths) along the
        central reference curve.

        axis="u" varies U at V=0.5.
        axis="v" varies V at U=0.5.
        """
        from topologicpy.Face import Face

        samples = max(16, min(int(samples), 4096))
        parameters = [i / samples for i in range(samples + 1)]
        points = []

        for t in parameters:
            try:
                vertex = Face.VertexByParameters(
                    face,
                    u=t if axis == "u" else 0.5,
                    v=0.5 if axis == "u" else t,
                )
            except Exception:
                return None
            point = Grid._Coordinates(vertex)
            if point is None:
                return None
            points.append(point)

        lengths = [0.0]
        for a, b in zip(points[:-1], points[1:]):
            d = Grid._Subtract(b, a)
            lengths.append(lengths[-1] + math.sqrt(Grid._Dot(d, d)))

        return (parameters, lengths) if lengths[-1] > 1.0e-12 else None

    @staticmethod
    def _ParameterAtLength(distance, metric):
        parameters, lengths = metric
        total = lengths[-1]
        distance = min(total, max(0.0, float(distance)))
        if distance <= 0:
            return 0.0
        if distance >= total:
            return 1.0

        lo, hi = 0, len(lengths) - 1
        while hi - lo > 1:
            mid = (lo + hi) // 2
            if lengths[mid] <= distance:
                lo = mid
            else:
                hi = mid

        span = lengths[hi] - lengths[lo]
        if span <= 1.0e-15:
            return parameters[lo]
        f = (distance - lengths[lo]) / span
        return parameters[lo] + f * (parameters[hi] - parameters[lo])

    @staticmethod
    def _LengthAtParameter(parameter, metric):
        parameters, lengths = metric
        t = min(1.0, max(0.0, float(parameter)))
        if t <= 0:
            return 0.0
        if t >= 1:
            return lengths[-1]

        x = t * (len(parameters) - 1)
        i = min(int(math.floor(x)), len(parameters) - 2)
        f = x - i
        return lengths[i] + f * (lengths[i + 1] - lengths[i])

    @staticmethod
    def _SurfacePositions(face, axis, spacing, divisions, values, alignment,
                          includeBoundary, distribution, samples, tolerance):
        explicit = Grid._ExplicitValues(values, includeBoundary)
        metric = Grid._SurfaceMetric(face, axis, samples)
        if metric is None:
            return None

        if explicit is not None:
            return explicit, metric, None

        if divisions is not None:
            fractions = Grid._DivisionValues(divisions, includeBoundary)
            if fractions is None:
                return None
            if distribution == "parameter":
                positions = fractions
            else:
                total = metric[1][-1]
                positions = [Grid._ParameterAtLength(f * total, metric)
                             for f in fractions]
            return Grid._Unique(positions), metric, None

        distances, datum = Grid._RegularDistances(
            metric[1][-1], spacing, alignment, includeBoundary, tolerance
        )
        if distances is None:
            return None
        positions = [Grid._ParameterAtLength(d, metric) for d in distances]
        return Grid._Unique(positions), metric, datum

    # -------------------------------------------------------------------------
    # Planar mode
    # -------------------------------------------------------------------------

    @staticmethod
    def _PlanarFrame(face, xDirection, samples, tolerance):
        from topologicpy.Edge import Edge
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology

        try:
            normal = Face.NormalAtParameters(
                face, u=0.5, v=0.5, mantissa=12, silent=True
            )
        except Exception:
            try:
                normal = Face.Normal(face, mantissa=12)
            except Exception:
                return None

        basis = Grid._Basis(normal, xDirection, tolerance)
        if basis is None:
            return None
        u_dir, v_dir = basis

        try:
            origin = Grid._Coordinates(Face.VertexByParameters(face, u=0.5, v=0.5))
        except Exception:
            origin = None

        points = []
        for edge in Topology.Edges(face, silent=True) or []:
            try:
                linear = Edge.IsLinear(edge, silent=True)
            except Exception:
                linear = False
            n = 1 if linear else max(8, min(64, int(samples) // 4))
            for i in range(n + 1):
                try:
                    point = Grid._Coordinates(Edge.VertexByParameter(edge, i / n))
                except Exception:
                    point = None
                if point is not None:
                    points.append(point)

        if not points:
            return None
        if origin is None:
            origin = points[0]

        us, vs = [], []
        for point in points:
            delta = Grid._Subtract(point, origin)
            us.append(Grid._Dot(delta, u_dir))
            vs.append(Grid._Dot(delta, v_dir))

        u_bounds = [min(us), max(us)]
        v_bounds = [min(vs), max(vs)]
        tol = Grid._Tolerance(tolerance)
        if u_bounds[1] - u_bounds[0] <= tol or v_bounds[1] - v_bounds[0] <= tol:
            return None
        return origin, u_dir, v_dir, u_bounds, v_bounds

    @staticmethod
    def _PlanarPositions(bounds, spacing, divisions, values, alignment,
                         includeBoundary, tolerance):
        start, end = bounds
        length = end - start

        explicit = Grid._ExplicitValues(values, includeBoundary)
        if explicit is not None:
            return [start + t * length for t in explicit], None

        if divisions is not None:
            fractions = Grid._DivisionValues(divisions, includeBoundary)
            if fractions is None:
                return None
            return [start + t * length for t in fractions], None

        distances, datum = Grid._RegularDistances(
            length, spacing, alignment, includeBoundary, tolerance
        )
        if distances is None:
            return None
        return [start + d for d in distances], start + datum

    # -------------------------------------------------------------------------
    # Surface isocurve construction
    # -------------------------------------------------------------------------

    @staticmethod
    def _Edges(result):
        from topologicpy.Topology import Topology
        if result is None:
            return []
        if Topology.IsInstance(result, "Edge"):
            return [result]
        try:
            return Topology.Edges(result, silent=True) or []
        except Exception:
            return []

    @staticmethod
    def _Clip(edge, face, tolerance, strict=False):
        """
        Clip an exact isocurve/line to the trimmed Face.

        The fallback returns the original Edge only if several interior samples
        confirm that the entire tested curve lies in the Face.
        """
        from topologicpy.Edge import Edge
        from topologicpy.Topology import Topology
        from topologicpy.Vertex import Vertex

        if edge is None:
            return []

        try:
            clipped = Topology.Intersect(
                edge, face, tolerance=tolerance, silent=True
            )
            edges = Grid._Edges(clipped)
            if edges:
                return edges
        except Exception:
            pass

        if strict:
            return []

        # Useful for rectangular UV patches where Common occasionally returns
        # no 1D result although the isocurve is wholly on the Face.
        for t in (0.1, 0.3, 0.5, 0.7, 0.9):
            try:
                vertex = Edge.VertexByParameter(edge, t)
                inside = Vertex.IsInternal(vertex, face, tolerance=tolerance)
            except TypeError:
                try:
                    inside = Vertex.IsInternal(vertex, face)
                except Exception:
                    return []
            except Exception:
                return []
            if inside is False:
                return []
        return [edge]

    @staticmethod
    def _ApproximateIso(face, axis, parameter, samples, tolerance):
        """Explicit polyline fallback; used only when approximate=True."""
        from topologicpy.Edge import Edge
        from topologicpy.Face import Face
        from topologicpy.Vertex import Vertex

        samples = max(8, min(int(samples), 4096))
        result = []

        for i in range(samples):
            a = i / samples
            b = (i + 1) / samples
            m = (a + b) * 0.5
            try:
                if axis == "u":
                    va = Face.VertexByParameters(face, u=parameter, v=a)
                    vb = Face.VertexByParameters(face, u=parameter, v=b)
                    vm = Face.VertexByParameters(face, u=parameter, v=m)
                else:
                    va = Face.VertexByParameters(face, u=a, v=parameter)
                    vb = Face.VertexByParameters(face, u=b, v=parameter)
                    vm = Face.VertexByParameters(face, u=m, v=parameter)
            except Exception:
                continue

            try:
                inside = Vertex.IsInternal(vm, face, tolerance=tolerance)
            except TypeError:
                try:
                    inside = Vertex.IsInternal(vm, face)
                except Exception:
                    inside = True
            except Exception:
                inside = True

            if inside is False:
                continue

            try:
                edge = Edge.ByVertices(
                    [va, vb], tolerance=tolerance, silent=True
                )
            except Exception:
                edge = None
            if edge is not None:
                result.append(edge)

        return result

    @staticmethod
    def _Append(target, resultEdges, metadata):
        for segment, edge in enumerate(resultEdges):
            md = dict(metadata)
            md["grid_segment"] = segment
            edge = Grid._SetDictionary(edge, md)
            if edge is not None:
                target.append(edge)

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    @staticmethod
    def _PatternOnFace(face, gridType, output, spacing, uSpacing, vSpacing,
                       origin, rotation, cellSize, orientation, angle,
                       radialSpacing, angularSpacing, centre, projection,
                       xDirection, includeBoundary, clearance, samples,
                       approximate, tolerance, silent):
        """Build patterned grids using native edges, clipping and face slicing."""
        from topologicpy.Face import Face
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Vertex import Vertex
        from topologicpy.Topology import Topology
        from topologicpy.Cluster import Cluster

        def fail(message):
            if not silent:
                print("Grid.OnFace - Error: " + message + " Returning None.")
            return None

        try:
            def number(value, name, positive=False):
                value = float(value)
                if not math.isfinite(value) or (positive and value <= tolerance):
                    raise ValueError(name + " must be finite" + (" and positive." if positive else "."))
                return value

            tolerance = number(tolerance, "tolerance")
            if tolerance <= 0:
                raise ValueError("tolerance must be positive.")
            spacing = number(spacing, "spacing", True)
            du = number(spacing if uSpacing is None else uSpacing, "uSpacing", True)
            dv = number(spacing if vSpacing is None else vSpacing, "vSpacing", True)
            clearance = number(clearance, "clearance")
            if clearance < 0:
                raise ValueError("clearance must be nonnegative.")
            rotation = math.radians(number(rotation, "rotation"))
            pattern = str(gridType or "rectangular").lower()
            if pattern == "regular":
                pattern = "rectangular"
            if pattern not in ("rectangular", "hexagonal", "diagrid", "polar"):
                raise ValueError("gridType must be rectangular, hexagonal, diagrid, or polar.")
            output = str(output).lower()
            if output not in ("vertices", "edges", "faces"):
                raise ValueError("output must be vertices, edges, or faces.")
            projection = str(projection).lower()
            if projection not in ("local", "xy"):
                raise ValueError("projection must be local or xy.")
            if not Topology.IsInstance(face, "Face") or not Face.IsPlanar(face, silent=True):
                raise ValueError("Patterned grids require a planar Face.")
            frame = Grid._PlanarFrame(face, xDirection, samples, tolerance)
            if frame is None:
                raise ValueError("Cannot determine the face plane.")
            base, u, v, _, _ = frame
            normal = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]
            anchor = centre if pattern == "polar" and centre is not None else origin
            if anchor is not None:
                anchor = Grid._Coordinates(anchor) if Topology.IsInstance(anchor, "Vertex") else list(anchor)
                if len(anchor) != 3 or not all(math.isfinite(float(x)) for x in anchor):
                    raise ValueError("origin/centre must be a Vertex or three finite coordinates.")
                anchor = [float(x) for x in anchor]
                delta = Grid._Subtract(anchor, base)
                if projection == "xy":
                    if abs(normal[2]) <= tolerance:
                        raise ValueError("XY projection requires a nonvertical Face.")
                    base = [anchor[0], anchor[1], base[2]-(normal[0]*delta[0]+normal[1]*delta[1])/normal[2]]
                else:
                    base = Grid._Add(base, Grid._Subtract(delta, Grid._Scale(normal, Grid._Dot(delta, normal))))
            if projection == "xy":
                if abs(normal[2]) <= tolerance:
                    raise ValueError("XY projection requires a nonvertical Face.")
                d = [1., 0.] if xDirection is None else [float(xDirection[0]), float(xDirection[1])]
                length = math.hypot(*d)
                if length <= tolerance:
                    raise ValueError("xDirection needs a nonzero XY component.")
                a, b = d[0]/length, d[1]/length
                u = [a, b, -(normal[0]*a+normal[1]*b)/normal[2]]
                v = [-b, a, (normal[0]*b-normal[1]*a)/normal[2]]
            co, si = math.cos(rotation), math.sin(rotation)
            u, v = (Grid._Add(Grid._Scale(u, co), Grid._Scale(v, si)),
                    Grid._Add(Grid._Scale(u, -si), Grid._Scale(v, co)))
            # Invert the (possibly oblique) face frame without rounding coordinates.
            aa, ab, bb = Grid._Dot(u,u), Grid._Dot(u,v), Grid._Dot(v,v)
            determinant = aa*bb-ab*ab
            def uv(point):
                d = Grid._Subtract(point, base)
                a, b = Grid._Dot(d,u), Grid._Dot(d,v)
                return ((a*bb-b*ab)/determinant, (b*aa-a*ab)/determinant)
            def xyz(point):
                return Grid._Add(base, Grid._Add(Grid._Scale(u,point[0]), Grid._Scale(v,point[1])))
            points = []
            for edge in Topology.Edges(face, silent=True) or []:
                count = 1 if Edge.IsLinear(edge, silent=True) else max(16, int(samples))
                points.extend(uv(Grid._Coordinates(Edge.VertexByParameter(edge, i/count))) for i in range(count+1))
            x0, x1 = min(p[0] for p in points), max(p[0] for p in points)
            y0, y1 = min(p[1] for p in points), max(p[1] for p in points)
            radius = max(math.hypot(x,y) for x,y in points)+tolerance*10
            regions = [face]
            if clearance:
                inset = Face.ByOffset(face, offset=clearance, offsetKey="__grid_clearance__", smooth=False,
                                      tolerance=tolerance, epsilon=tolerance, silent=silent)
                regions = [inset] if Topology.IsInstance(inset,"Face") else (Topology.Faces(inset,silent=True) or [] if inset is not None else [])
                if not regions:
                    return [] if output != "edges" else None
            raw = []
            seen = set()
            def segment(a,b):
                key = tuple(sorted(tuple(round(c/tolerance) for c in p) for p in (a,b)))
                if key in seen or math.dist(a,b) <= tolerance:
                    return
                seen.add(key)
                edge = Edge.ByVertices([Vertex.ByCoordinates(*xyz(a)),Vertex.ByCoordinates(*xyz(b))], tolerance=tolerance, silent=True)
                if edge is None:
                    raise ValueError("Could not construct a grid Edge.")
                raw.append(edge)
                if len(raw) > 20000:
                    raise ValueError("Grid is too dense. Increase spacing.")
            def family(theta, separation):
                d = (math.cos(theta), math.sin(theta)); n = (-d[1],d[0])
                offsets = [x*n[0]+y*n[1] for x,y in ((x0,y0),(x1,y0),(x1,y1),(x0,y1))]
                lo,hi=math.ceil(min(offsets)/separation),math.floor(max(offsets)/separation)
                if hi-lo > 20000:
                    raise ValueError("Grid is too dense. Increase spacing.")
                for i in range(lo,hi+1):
                    t=i*separation
                    segment((n[0]*t-d[0]*radius*2,n[1]*t-d[1]*radius*2),
                            (n[0]*t+d[0]*radius*2,n[1]*t+d[1]*radius*2))
            if pattern == "rectangular":
                family(math.pi/2,du); family(0,dv)
            elif pattern == "diagrid":
                alpha=number(angle,"angle")
                if not 0 < alpha < 90:
                    raise ValueError("angle must be between 0 and 90 degrees.")
                family(math.radians(alpha),du); family(-math.radians(alpha),dv)
            elif pattern == "hexagonal":
                side=number(spacing if cellSize is None else cellSize,"cellSize",True)
                orientation=str(orientation).lower()
                if orientation not in ("flat-top","pointy-top"):
                    raise ValueError("orientation must be flat-top or pointy-top.")
                # Generate a padded axial lattice and retain only cells meeting the bounds.
                bound=max(abs(x0),abs(x1),abs(y0),abs(y1))
                count=math.ceil(bound/side)+2
                if (2*count+1)**2 > 20000:
                    raise ValueError("Grid is too dense. Increase cellSize.")
                phase=0 if orientation=="flat-top" else math.pi/6
                for q in range(-count,count+1):
                    for r in range(-count,count+1):
                        if orientation=="flat-top":
                            cx,cy=1.5*side*q,math.sqrt(3)*side*(r+q/2)
                        else:
                            cx,cy=math.sqrt(3)*side*(q+r/2),1.5*side*r
                        if cx+side<x0 or cx-side>x1 or cy+side<y0 or cy-side>y1:
                            continue
                        ring=[(cx+side*math.cos(phase+i*math.pi/3),cy+side*math.sin(phase+i*math.pi/3)) for i in range(6)]
                        for i in range(6):
                            segment(ring[i],ring[(i+1)%6])
            else:
                dr=number(spacing if radialSpacing is None else radialSpacing,"radialSpacing",True)
                da=number(angularSpacing,"angularSpacing",True)
                if da > 180:
                    raise ValueError("angularSpacing must not exceed 180 degrees.")
                steps=360/da
                if abs(steps-round(steps)) > 1e-8:
                    raise ValueError("angularSpacing must divide 360 exactly.")
                if math.ceil(radius/dr)*int(round(steps)) > 20000:
                    raise ValueError("Polar grid is too dense. Increase spacing.")
                for i in range(int(round(steps))):
                    t=math.radians(i*da)
                    segment((0,0),(radius*math.cos(t),radius*math.sin(t)))
                for i in range(1,math.floor(radius/dr)+1):
                    circle=Edge.Circle(radius=i*dr,tolerance=tolerance,silent=True)
                    if circle is None:
                        if not approximate:
                            raise ValueError("Exact circles unavailable; set approximate=True for sampled rings.")
                        n=max(16,int(samples))
                        for j in range(n):
                            segment((i*dr*math.cos(j*2*math.pi/n),i*dr*math.sin(j*2*math.pi/n)),
                                    (i*dr*math.cos((j+1)*2*math.pi/n),i*dr*math.sin((j+1)*2*math.pi/n)))
                    else:
                        matrix=[[u[j],v[j],normal[j],base[j]] for j in range(3)]+[[0,0,0,1]]
                        circle=Topology.Transform(circle,matrix,tolerance=tolerance,silent=True)
                        if circle is None:
                            raise ValueError("Cannot transform polar circle onto the face plane.")
                        raw.append(circle)
            clipped=[]
            for region in regions:
                for edge in raw:
                    clipped.extend(Grid._Clip(edge,region,tolerance,strict=True))
                if includeBoundary:
                    clipped.extend(Topology.Edges(region,silent=True) or [])
            clipped = [Grid._SetDictionary(edge,{"grid_type":pattern,"grid_projection":projection})
                       for edge in clipped]
            grid=Cluster.ByTopologies(clipped) if clipped else None
            if output == "edges":
                return grid
            if output == "vertices":
                if grid is None:
                    return []
                if Topology._IsTopologicCoreBackend() and any(
                        not Edge.IsLinear(edge, silent=True) for edge in clipped):
                    # The core Grid.Vertices fast path is analytical for straight
                    # segments. Split curves natively to retain ring/ray crossings.
                    merged = Topology.SelfMerge(grid, tolerance=tolerance, silent=True)
                    if merged is None:
                        raise ValueError("Cannot split curved grid intersections.")
                    vertices = Topology.Vertices(merged, silent=True) or []
                    return vertices
                return Grid.Vertices(grid,tolerance=tolerance,silent=silent)
            faces=[]
            for region in regions:
                cut=Topology.Slice(region,grid,tolerance=tolerance,silent=True) if grid else region
                if cut is None:
                    raise ValueError("Could not construct grid Faces.")
                parts=[cut] if Topology.IsInstance(cut,"Face") else Topology.Faces(cut,silent=True)
                if not parts:
                    raise ValueError("Grid slicing returned no Faces.")
                faces.extend(parts)
            return faces
        except Exception as exc:
            return fail(str(exc))

    @staticmethod
    def OnPlane(width: float = 10.0, length: float = 10.0, spacing: float = 1.0,
                uSpacing=None, vSpacing=None, gridType: str = "rectangular",
                output: str = "edges", origin=None, direction=None,
                rotation: float = 0.0, cellSize=None, orientation: str = "flat-top",
                angle: float = 45.0, radialSpacing=None, angularSpacing: float = 30.0,
                centre=None, includeBoundary: bool = False, clearance: float = 0.0,
                approximate: bool = False, samples: int = 128,
                tolerance: float = 0.0001, silent: bool = False):
        """
        Creates a finite patterned grid on a plane, defaulting to the XY plane.

        Parameters
        ----------
        width, length : float , optional
            Positive dimensions of the rectangular clipping Face. Default is 10.
        spacing : float , optional
            Common spacing in model units. Default is 1.
        uSpacing, vSpacing : float , optional
            Rectangular axis spacing or diagrid perpendicular family spacing.
            Defaults to spacing.
        gridType : str , optional
            "rectangular", "hexagonal", "diagrid", or "polar".
            Default is "rectangular".
        output : str , optional
            "vertices", "edges", or "faces". Default is "edges".
        origin : topologic_core.Vertex or list , optional
            Centre of the clipping rectangle and grid origin, as a Vertex or
            three coordinates. Default is the world origin.
        direction : list , optional
            Plane normal. Default is [0, 0, 1].
        rotation : float , optional
            Counterclockwise pattern rotation in degrees within the plane.
            The clipping rectangle is not rotated. Default is 0.
        cellSize : float , optional
            Hexagon side length. Defaults to spacing.
        orientation : str , optional
            "flat-top" or "pointy-top" hexagons. Default is "flat-top".
        angle : float , optional
            Diagrid directions are plus/minus this angle from the local X axis.
            Must be between 0 and 90 degrees. Default is 45.
        radialSpacing : float , optional
            Polar ring spacing. Defaults to spacing.
        angularSpacing : float , optional
            Polar ray spacing in degrees, dividing 360 exactly, at most 180.
            Only complete circular patterns are supported. Default is 30.
        centre : topologic_core.Vertex or list , optional
            Polar centre. Defaults to origin.
        includeBoundary : bool , optional
            Include clipping boundary Edges. Default is False.
        clearance : float , optional
            Nonnegative distance from the clipping boundary. Default is 0.
        approximate : bool , optional
            Permit sampled polar rings if exact circles are unavailable.
            Default is False.
        samples : int , optional
            Number of samples for boundary bounds or fallback rings.
            Default is 128.
        tolerance : float , optional
            Geometric tolerance. Default is 0.0001.
        silent : bool , optional
            If True, suppress error and warning messages. Default is False.

        Returns
        -------
        topologic_core.Cluster or list
            Cluster of Edges, list of unique Vertices, or list of Faces.
            Invalid input returns None. Empty grids return None for Edges
            and an empty list for Vertices/Faces.
        """
        from topologicpy.Face import Face
        from topologicpy.Vertex import Vertex
        try:
            width, length = float(width), float(length)
            if not all(math.isfinite(x) and x > tolerance for x in (width,length)):
                raise ValueError("width and length must be positive and finite.")
            if origin is None:
                origin=Vertex.ByCoordinates(0,0,0)
            elif isinstance(origin,(list,tuple)):
                origin=Vertex.ByCoordinates(*origin)
            normal=[0,0,1] if direction is None else Grid._Normalize(direction,tolerance)
            if normal is None:
                raise ValueError("direction must be a nonzero vector.")
            face=Face.Rectangle(origin=origin,width=width,length=length,direction=normal,silent=True)
            if face is None:
                raise ValueError("Could not construct clipping Face.")
            return Grid._PatternOnFace(face,gridType,output,spacing,uSpacing,vSpacing,
                origin,rotation,cellSize,orientation,angle,radialSpacing,
                angularSpacing,centre,"local",None,includeBoundary,clearance,
                samples,approximate,tolerance,silent)
        except Exception as exc:
            if not silent:
                print("Grid.OnPlane - Error: " + str(exc) + " Returning None.")
            return None

    @staticmethod
    def OnFaces(faces, spacing: float = 1.0, origin=None, direction=None,
                includeBoundary: bool = False, tolerance: float = 0.0001, clearance: float = 0.0):
        """Project one shared XY grid onto planar horizontal/sloping Faces.

        Unlike independent OnFace calls, all faces share the same grid origin
        and direction. Spacing is measured in XY, not along a slope. Holes and
        face boundaries clip the lines. Returns a Cluster of grid Edges or None
        when no lines intersect. Use OnFace for intrinsic curved-surface grids.
        clearance is a nonnegative XY distance in model units (default 0).
        Continuous adjoining patches are inset together using Face.ByOffset;
        internal slab seams are not treated as physical boundaries. The original
        XY grid origin/direction/spacing remain fixed. All offset regions survive;
        complete erosion returns None. Curved boundaries must be tessellated for
        this projected multi-face method.
        """
        import math
        from shapely.affinity import affine_transform
        from shapely.geometry import LineString
        from topologicpy.Navigation import Navigation
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Cluster import Cluster
        if not math.isfinite(spacing) or spacing <= 0:
            raise ValueError('spacing must be positive and finite.')
        if not math.isfinite(tolerance) or tolerance <= 0:raise ValueError('tolerance must be positive and finite.')
        if not math.isfinite(clearance) or clearance < 0:raise ValueError('clearance must be nonnegative and finite.')
        origin,direction=Navigation._Frame(origin,direction)
        ox,oy=origin;ux,uy=direction;edges=[]
        records=[Navigation._Record(face,tolerance=tolerance) for face in faces]
        allowed=Navigation._ClearanceDomains(records,clearance,tolerance,tolerance) if clearance else None
        for index,record in enumerate(records):
            original=Navigation._Shape(record)
            usable=original if allowed is None else original.intersection(allowed[index])
            if usable.is_empty:continue
            poly=affine_transform(usable,[ux,uy,-uy,ux,-ux*ox-uy*oy,uy*ox-ux*oy])
            x0,y0,x1,y1=poly.bounds
            if (x1-x0+y1-y0)/spacing > 200000:
                raise ValueError('Grid is too dense. Increase spacing.')
            lines=[]
            for axis,lo,hi in [(0,x0,x1),(1,y0,y1)]:
                for i in range(math.ceil((lo-tolerance)/spacing),math.floor((hi+tolerance)/spacing)+1):
                    value=i*spacing
                    if not includeBoundary and (abs(value-lo)<tolerance or abs(value-hi)<tolerance):continue
                    lines.append(LineString([(value,y0),(value,y1)]) if axis==0 else LineString([(x0,value),(x1,value)]))
            if includeBoundary:lines.append(poly.boundary)
            for line in lines:
                clipped=line.intersection(poly)
                parts=[clipped] if clipped.geom_type in ('LineString','LinearRing') else list(getattr(clipped,'geoms',[]))
                for part in parts:
                    if part.geom_type not in ('LineString','LinearRing'):continue
                    points=list(part.coords)
                    for a,b in zip(points,points[1:]):
                        def point(p):
                            x=ox+ux*p[0]-uy*p[1];y=oy+uy*p[0]+ux*p[1]
                            return Vertex.ByCoordinates(x,y,Navigation._Height(record,x,y))
                        if math.dist(a,b)<=tolerance:continue
                        edge=Edge.ByVertices([point(a),point(b)],tolerance=tolerance)
                        if edge is not None:edges.append(edge)
        return Cluster.ByTopologies(edges) if edges else None

    @staticmethod
    def OnFace(
        face,
        spacing: float = 1.0,
        uSpacing=None,
        vSpacing=None,
        uDivisions=None,
        vDivisions=None,
        uValues=None,
        vValues=None,
        mode: str = "auto",
        distribution: str = "length",
        xDirection=None,
        uAlignment: str = "center",
        vAlignment: str = "center",
        includeBoundary: bool = False,
        uLabels=None,
        vLabels=None,
        approximate: bool = False,
        samples: int = 128,
        mantissa: int = 6,
        tolerance: float = 0.0001,
        silent: bool = False,
        clearance: float = 0.0,
        gridType=None,
        output: str = "edges",
        origin=None,
        rotation: float = 0.0,
        cellSize=None,
        orientation: str = "flat-top",
        angle: float = 45.0,
        radialSpacing=None,
        angularSpacing: float = 30.0,
        centre=None,
        projection: str = "local",
    ):
        """
        Creates a grid on a planar, curved, or NURBS Face.

        ``mode="auto"`` uses an intuitive world-oriented planar grid for planar
        Faces and an intrinsic UV surface grid for non-planar Faces.

        In surface mode, U-family lines are constant-U surface isocurves and
        V-family lines are constant-V isocurves. When the active backend supports
        exact surface isocurves, they are trimmed by the input Face, so a grid on
        a curved/NURBS Face contains genuinely curved Edges rather than projected
        chords.

        Each family can be specified independently. Precedence is:

        1. ``uValues`` / ``vValues``: explicit normalized parameters in [0, 1].
        2. ``uDivisions`` / ``vDivisions``: number of bays.
        3. ``uSpacing`` / ``vSpacing``: physical model-unit spacing; if omitted,
           ``spacing`` is used.

        For a curved surface, there is no unique globally constant separation
        between isocurves. Physical U spacing is therefore measured along the
        central V=0.5 reference curve, and physical V spacing along the central
        U=0.5 reference curve. ``distribution="length"`` uses this same metric
        for division placement; ``distribution="parameter"`` uses equal UV
        increments.

        ``mode="planar"`` can be forced for a planar Face and accepts
        ``xDirection`` to control its U direction. ``mode="surface"`` can be
        forced on any Face to use its native parameterization.

        Exact non-planar surface isocurves require backend support. By default
        this method returns None rather than flattening them if exact native
        curves are unavailable. Set ``approximate=True`` explicitly to permit
        a sampled polyline fallback.

        Parameters
        ----------
        face : topologicpy.Face
            Input Face.
        spacing : float , optional
            Common physical spacing. Default is 1.
        uSpacing, vSpacing : float , optional
            Per-family physical spacing overrides.
        uDivisions, vDivisions : int , optional
            Number of bays in each family.
        uValues, vValues : float or list , optional
            Explicit normalized U/V positions in [0, 1].
        mode : str , optional
            "auto", "planar", or "surface". Default is "auto".
        distribution : str , optional
            "length" or "parameter" for surface division placement.
        xDirection : list , optional
            Preferred planar U direction. Ignored in surface mode.
        uAlignment, vAlignment : str , optional
            "center", "start", or "end" for spacing placement.
        includeBoundary : bool , optional
            Include U/V extrema as grid lines. Default is False.
        uLabels, vLabels : str or list , optional
            "letters", "numbers", a prefix string, or explicit labels.
        approximate : bool , optional
            Permit sampled polylines when native surface isocurves are
            unavailable. Default is False.
        samples : int , optional
            Samples used for physical surface metrics and fallback geometry.
            Does not control exact backend curve geometry. Default is 128.
        mantissa : int , optional
            Decimal precision used in metadata. Default is 6.
        tolerance : float , optional
            Geometric tolerance. Default is 0.0001.
        silent : bool , optional
            Suppress errors/warnings. Default is False.
        clearance : float , optional
            Nonnegative distance from outer/hole boundaries in the Face plane,
            measured in model units. Default is 0. Positive clearance supports
            planar grid mode only and clips the original grid to every region
            returned by Face.ByOffset. Origin, spacing, divisions, labels and
            normalized positions are computed from the original Face. Boundary
            grid lines that no longer intersect the inset region are omitted.
            Complete erosion or a failed offset returns None without reverting
            to the original Face. Exact curved planar boundaries are preserved.

        gridType : str , optional
            "rectangular" (or "regular"), "hexagonal", "diagrid", or "polar".
            None preserves the existing planar/surface grid behavior.
            Explicit patterns require a planar Face. Default is None.
        output : str , optional
            "edges" returns a Cluster, "vertices" a list of unique Vertices,
            and "faces" a list of partition Faces. Default is "edges".
        origin : topologic_core.Vertex or list , optional
            Pattern origin as a Vertex or three coordinates, projected onto the
            face plane. Defaults to the face parameter centre. The original
            origin is retained when applying clearance.
        rotation : float , optional
            Counterclockwise pattern rotation in degrees. Default is 0.
        cellSize : float , optional
            Hexagon side length. Defaults to spacing.
        orientation : str , optional
            Hexagon orientation: "flat-top" or "pointy-top".
            Default is "flat-top".
        angle : float , optional
            Diagrid family directions, plus/minus this angle from local X.
            Between 0 and 90 degrees. Family spacing is perpendicular to each
            line family. Default is 45.
        radialSpacing : float , optional
            Spacing between complete polar rings. Defaults to spacing.
        angularSpacing : float , optional
            Polar ray spacing in degrees, dividing 360 exactly, at most 180.
            Default is 30. Circles are exact when supported by the backend;
            approximate=True permits sampled rings otherwise.
        centre : topologic_core.Vertex or list , optional
            Polar centre, projected onto the face plane. Overrides origin
            for polar patterns. Default is None.
        projection : str , optional
            "local" measures pattern dimensions within the face plane.
            "xy" projects a world XY pattern onto a nonvertical planar Face.
            Default is "local".

        Returns
        -------
        topologic_core.Cluster or list
            Cluster of Edges, list of unique Vertices, or list of Faces.
            Invalid input returns None. Empty grids return None for Edges
            and an empty list for Vertices/Faces.

        Notes
        -----
        ``grid_axis="u"`` denotes a constant-U line (which runs in the surface
        V direction), and vice versa.
        """
        from topologicpy.Cluster import Cluster
        from topologicpy.Edge import Edge
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology
        from topologicpy.Vertex import Vertex

        patterned = (gridType is not None or str(output).lower() != "edges" or
                     origin is not None or rotation != 0 or centre is not None or
                     str(projection).lower() != "local")
        if patterned:
            if (str(mode).lower() not in ("auto", "planar") or any(value is not None for value in
                    (uDivisions,vDivisions,uValues,vValues,uLabels,vLabels))):
                if not silent:
                    print("Grid.OnFace - Error: Patterned grids do not accept surface mode, divisions, values or labels. Returning None.")
                return None
            return Grid._PatternOnFace(face,gridType,output,spacing,uSpacing,vSpacing,
                origin,rotation,cellSize,orientation,angle,radialSpacing,angularSpacing,
                centre,projection,xDirection,includeBoundary,clearance,samples,
                approximate,tolerance,silent)

        tol = Grid._Tolerance(tolerance)

        if not Topology.IsInstance(face, "Face"):
            if not silent:
                print("Grid.OnFace - Error: face is not a valid Face. Returning None.")
            return None

        try:
            samples = max(16, min(int(samples), 4096))
            mantissa = max(0, int(mantissa))
            spacing = abs(float(spacing))
            clearance = float(clearance)
            if not math.isfinite(clearance) or clearance < 0:
                raise ValueError('clearance must be nonnegative and finite.')
            uSpacing = spacing if uSpacing is None else abs(float(uSpacing))
            vSpacing = spacing if vSpacing is None else abs(float(vSpacing))
        except Exception:
            if not silent:
                print("Grid.OnFace - Error: Invalid numeric input. Returning None.")
            return None

        if uValues is None and uDivisions is None and uSpacing <= tol:
            if not silent:
                print("Grid.OnFace - Error: uSpacing is too small. Returning None.")
            return None
        if vValues is None and vDivisions is None and vSpacing <= tol:
            if not silent:
                print("Grid.OnFace - Error: vSpacing is too small. Returning None.")
            return None

        mode = str(mode).lower()
        if mode not in ("auto", "planar", "surface"):
            if not silent:
                print("Grid.OnFace - Error: mode must be auto, planar, or surface. Returning None.")
            return None

        distribution = str(distribution).lower()
        if distribution in ("distance", "physical"):
            distribution = "length"
        elif distribution in ("parametric", "uv"):
            distribution = "parameter"
        if distribution not in ("length", "parameter"):
            if not silent:
                print("Grid.OnFace - Error: distribution must be length or parameter. Returning None.")
            return None

        try:
            planar = Face.IsPlanar(face, silent=True)
        except Exception:
            planar = Topology.IsPlanar(face, tolerance=tol, silent=True)

        actualMode = "planar" if mode == "auto" and planar is True else (
            "surface" if mode == "auto" else mode
        )

        if actualMode == "planar" and planar is False:
            if not silent:
                print("Grid.OnFace - Error: mode='planar' requires a planar Face. Returning None.")
            return None

        clippingFaces = [face]
        if clearance > 0:
            if actualMode != "planar":
                if not silent:
                    print("Grid.OnFace - Error: clearance requires planar grid mode. Returning None.")
                return None
            inset = Face.ByOffset(face, offset=clearance, offsetKey="__grid_clearance__",smooth=False,
                                  stepOffsetKeyA="__grid_clearance_step_a__",stepOffsetKeyB="__grid_clearance_step_b__",
                                  tolerance=tol,epsilon=tol,silent=silent)
            if inset is None:
                return None
            clippingFaces = [inset] if Topology.IsInstance(inset,"Face") else (Topology.Faces(inset,silent=True) or [])
            if not clippingFaces:return None
            sourceBoundaries=[Face.ExternalBoundary(face),*(Face.InternalBoundaries(face) or [])]
            for region in clippingFaces:
                for edge in Topology.Edges(region):
                    for parameter in (0,.25,.5,.75,1):
                        point=Edge.VertexByParameter(edge,parameter)
                        if (point is None or Vertex.IsInternal(point,face,tolerance=tol) is False
                                or min(Vertex.Distance(point,boundary) for boundary in sourceBoundaries)<clearance-tol):
                            if not silent:
                                print("Grid.OnFace - Error: Offset geometry does not satisfy clearance. Returning None.")
                            return None

        resultEdges = []

        # ---------------------------------------------------------------------
        # Planar grid
        # ---------------------------------------------------------------------
        if actualMode == "planar":
            frame = Grid._PlanarFrame(face, xDirection, samples, tol)
            if frame is None:
                if not silent:
                    print("Grid.OnFace - Error: Could not derive planar frame. Returning None.")
                return None

            origin, uDir, vDir, uBounds, vBounds = frame
            uData = Grid._PlanarPositions(
                uBounds, uSpacing, uDivisions, uValues,
                uAlignment, includeBoundary, tol
            )
            vData = Grid._PlanarPositions(
                vBounds, vSpacing, vDivisions, vValues,
                vAlignment, includeBoundary, tol
            )
            if uData is None or vData is None:
                if not silent:
                    print("Grid.OnFace - Error: Could not derive planar positions. Returning None.")
                return None

            uPositions, uDatum = uData
            vPositions, vDatum = vData
            uLabelsResolved = Grid._Labels(len(uPositions), uLabels)
            vLabelsResolved = Grid._Labels(len(vPositions), vLabels)

            families = (
                ("u", uPositions, uBounds, vBounds, uDir, vDir, uDatum, uLabelsResolved),
                ("v", vPositions, vBounds, uBounds, vDir, uDir, vDatum, vLabelsResolved),
            )

            for axis, positions, primaryBounds, secondaryBounds, primaryDir, secondaryDir, datum, labels in families:
                pMin, pMax = primaryBounds
                sMin, sMax = secondaryBounds
                for index, position in enumerate(positions):
                    a = Grid._Add(
                        origin,
                        Grid._Add(
                            Grid._Scale(primaryDir, position),
                            Grid._Scale(secondaryDir, sMin),
                        ),
                    )
                    b = Grid._Add(
                        origin,
                        Grid._Add(
                            Grid._Scale(primaryDir, position),
                            Grid._Scale(secondaryDir, sMax),
                        ),
                    )
                    edge = Edge.ByVertices(
                        [Vertex.ByCoordinates(*a), Vertex.ByCoordinates(*b)],
                        tolerance=tol,
                        silent=True,
                    )
                    clipped = [piece for region in clippingFaces for piece in Grid._Clip(edge, region, tol, strict=clearance > 0)]
                    parameter = (position - pMin) / (pMax - pMin)
                    Grid._Append(
                        resultEdges,
                        clipped,
                        {
                            "grid_source": "OnFace",
                            "grid_mode": "planar",
                            "grid_geometry": "line",
                            "grid_axis": axis,
                            "grid_index": index,
                            "grid_parameter": round(parameter, mantissa),
                            "grid_distance": round(position - pMin, mantissa),
                            "grid_label": labels[index],
                            "grid_is_boundary": abs(parameter) <= 1e-10 or abs(parameter - 1) <= 1e-10,
                            "grid_is_datum": datum is not None and abs(position - datum) <= tol,
                        },
                    )

        # ---------------------------------------------------------------------
        # Intrinsic surface grid
        # ---------------------------------------------------------------------
        else:
            uData = Grid._SurfacePositions(
                face, "u", uSpacing, uDivisions, uValues,
                uAlignment, includeBoundary, distribution, samples, tol
            )
            vData = Grid._SurfacePositions(
                face, "v", vSpacing, vDivisions, vValues,
                vAlignment, includeBoundary, distribution, samples, tol
            )
            if uData is None or vData is None:
                if not silent:
                    print("Grid.OnFace - Error: Could not derive surface positions. Returning None.")
                return None

            nativeIsoAvailable = Core.HasAttribute("Grid", "IsoCurve")
            if not nativeIsoAvailable and not approximate:
                if not silent:
                    print(
                        "Grid.OnFace - Error: Exact surface isocurves are unavailable "
                        "with the active backend. Set approximate=True for a polyline "
                        "fallback. Returning None."
                    )
                return None

            for axis, data, labelsSpec in (
                ("u", uData, uLabels),
                ("v", vData, vLabels),
            ):
                positions, metric, datum = data
                labels = Grid._Labels(len(positions), labelsSpec)

                for index, parameter in enumerate(positions):
                    raw = None
                    if nativeIsoAvailable:
                        try:
                            raw = Core.Grid.IsoCurve(face, axis, parameter)
                        except Exception:
                            raw = None

                    if Topology.IsInstance(raw, "Edge"):
                        clipped = Grid._Clip(raw, face, tol)
                        geometry = "isocurve"
                    elif approximate:
                        clipped = Grid._ApproximateIso(
                            face, axis, parameter, samples, tol
                        )
                        geometry = "polyline"
                    else:
                        clipped = []
                        geometry = "isocurve"

                    distance = Grid._LengthAtParameter(parameter, metric)
                    Grid._Append(
                        resultEdges,
                        clipped,
                        {
                            "grid_source": "OnFace",
                            "grid_mode": "surface",
                            "grid_geometry": geometry,
                            "grid_axis": axis,
                            "grid_index": index,
                            "grid_parameter": round(parameter, mantissa),
                            "grid_distance": round(distance, mantissa),
                            "grid_label": labels[index],
                            "grid_is_boundary": abs(parameter) <= 1e-10 or abs(parameter - 1) <= 1e-10,
                            "grid_is_datum": datum is not None and abs(distance - datum) <= tol,
                        },
                    )

        if not resultEdges:
            if not silent:
                print("Grid.OnFace - Warning: No grid Edges were created. Returning None.")
            return None

        return Cluster.ByTopologies(resultEdges, silent=True)

    @staticmethod
    def Vertices(grid, tolerance: float = 0.0001, silent: bool = False):
        """
        Return unique grid Edge endpoints and intersections in 3D.

        Parameters
        ----------
        grid : topologic_core.Topology or list
            A grid topology (such as the Cluster returned by Grid.OnFace),
            or a list of Edges. Edges need not have been split at crossings.
        tolerance : float, optional
            Model-unit distance used for intersections and deduplication.
            Default is 0.0001.
        silent : bool, optional
            Suppress error messages. Default is False.

        Returns
        -------
        list
            Vertices, with endpoints first, followed by new intersection
            Vertices. Empty input returns an empty list; invalid input or a
            failed native intersection operation returns None.

        Notes
        -----
        PythonOCC splits all Edges in one native operation, supporting exact
        curved Edges as well as straight Edges. TopologicCore uses analytical
        3D segment intersections with bounding-box pruning. Spatial hashing
        deduplicates the output without comparing every pair of Vertices.
        Overlapping Edges contribute their endpoints; an overlap is not
        sampled into an infinite set of intersection points. Input geometry
        is not replaced by the split geometry.
        """
        from topologicpy.Edge import Edge
        from topologicpy.Topology import Topology
        from topologicpy.Vertex import Vertex

        def error(message):
            if not silent:
                print("Grid.Vertices - Error: " + message + " Returning None.")
            return None

        tol = Grid._Tolerance(tolerance)
        if not math.isfinite(tol):
            return error("Tolerance must be finite.")
        if isinstance(grid, (list, tuple)):
            if not all(Topology.IsInstance(edge, "Edge") for edge in grid):
                return error("The input list must contain only Edges.")
            edges = list(grid)
        elif Topology.IsInstance(grid, "Topology"):
            edges = [grid] if Topology.IsInstance(grid, "Edge") else Topology.Edges(grid)
        else:
            return error("The input grid must be a topology or a list of Edges.")
        if not edges:
            return []

        analytical = Topology._IsTopologicCoreBackend()
        vertices, buckets, segments = [], {}, []
        tol2 = tol * tol

        def append(vertex, point=None):
            point = Grid._Coordinates(vertex) if point is None else point
            key = tuple(math.floor(x / tol) for x in point)
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    for dz in (-1, 0, 1):
                        for existing in buckets.get((key[0]+dx, key[1]+dy, key[2]+dz), ()):
                            if sum((point[i]-existing[i])**2 for i in range(3)) <= tol2:
                                return
            buckets.setdefault(key, []).append(point)
            vertices.append(vertex)

        for edge in edges:
            ends = Edge.Vertices(edge, silent=True)
            if not ends:
                return error("Could not extract an Edge's endpoints.")
            for vertex in ends:
                append(vertex)
            if analytical:
                a, b = Grid._Coordinates(ends[0]), Grid._Coordinates(ends[-1])
                segments.append((a, b, [min(a[i], b[i]) for i in range(3)],
                                 [max(a[i], b[i]) for i in range(3)]))

        if not analytical:
            try:
                from OCC.Core.BOPAlgo import BOPAlgo_Splitter
                from OCC.Core.TopAbs import TopAbs_VERTEX
                from topologicpy.pythonocc_backend.topology import _iter_occ_subshapes_unique
                from topologicpy.pythonocc_backend.vertex import Vertex as NativeVertex
                from OCC.Core.TopTools import TopTools_IndexedMapOfShape
                seen = TopTools_IndexedMapOfShape()
                splitter = BOPAlgo_Splitter()
                splitter.SetNonDestructive(True)
                splitter.SetToFillHistory(False)
                splitter.SetFuzzyValue(tol)
                edge_count = 0
                for edge in edges:
                    if not seen.Contains(edge.shape):
                        seen.Add(edge.shape)
                        splitter.AddArgument(edge.shape)
                        edge_count += 1
                if edge_count < 2:
                    return vertices
                splitter.Perform()
                if splitter.HasErrors():
                    return error("Native Edge intersection failed.")
                for shape in _iter_occ_subshapes_unique(splitter.Shape(), TopAbs_VERTEX):
                    append(NativeVertex.ByOcctShape(shape))
                return vertices
            except Exception as exc:
                return error("Native Edge intersection failed: " + str(exc) + ".")

        # Sweep along the longest bounding-box axis; reject pairs whose 3D
        # boxes cannot meet before computing their segment intersection.
        axis = max(range(3), key=lambda i: max(s[3][i] for s in segments)-min(s[2][i] for s in segments))
        segments.sort(key=lambda s: s[2][axis])
        active = []

        def cross(a, b):
            return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]

        for a, b, lower, upper in segments:
            active = [s for s in active if s[3][axis] >= lower[axis]-tol]
            r = Grid._Subtract(b, a)
            rr = Grid._Dot(r, r)
            for c, d, other_lower, other_upper in active:
                if any(upper[i] < other_lower[i]-tol or other_upper[i] < lower[i]-tol for i in range(3)):
                    continue
                s = Grid._Subtract(d, c)
                ss = Grid._Dot(s, s)
                normal = cross(r, s)
                denominator = Grid._Dot(normal, normal)
                if rr == 0 or ss == 0 or denominator <= 1e-24*rr*ss:
                    continue  # Parallel overlaps add no points beyond endpoints.
                delta = Grid._Subtract(c, a)
                t = Grid._Dot(cross(delta, s), normal) / denominator
                u = Grid._Dot(cross(delta, r), normal) / denominator
                if not (-tol/math.sqrt(rr) <= t <= 1+tol/math.sqrt(rr) and
                        -tol/math.sqrt(ss) <= u <= 1+tol/math.sqrt(ss)):
                    continue
                t, u = max(0, min(1, t)), max(0, min(1, u))
                p = Grid._Add(a, Grid._Scale(r, t))
                q = Grid._Add(c, Grid._Scale(s, u))
                if sum((p[i]-q[i])**2 for i in range(3)) <= tol2:
                    point = [(p[i]+q[i])*0.5 for i in range(3)]
                    append(Vertex.ByCoordinates(*point), point)
            active.append((a, b, lower, upper))
        return vertices
