from __future__ import annotations

# REVISION: 2026-08-15 Wire Union semantic promotion 002

import math
from dataclasses import dataclass, field
from .topology import Topology
from .vertex import Vertex
from .edge import Edge
from .occ_utils import make_occ_wire, _positive_tolerance, _copy_with_tolerance
from .helpers import same_vertex, unique_by_uuid



def _make_occ_wire_batch(edges, tolerance=0.0001):
    """
    Builds an OCCT wire from a connected collection of edges in one batch.

    This path is intended for connected branching/non-manifold edge sets for
    which a single head-to-tail ordering does not exist. It also verifies that
    the returned OCCT wire contains every supplied edge, avoiding acceptance
    of a partial result.
    """
    if not edges:
        return None

    try:
        from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_MakeWire
        from OCC.Core.TopAbs import TopAbs_EDGE
        from OCC.Core.TopExp import TopExp_Explorer
        from OCC.Core.TopTools import TopTools_ListOfShape
        from OCC.Core.TopoDS import topods
    except Exception:
        return None

    tolerance = _positive_tolerance(tolerance)
    if tolerance is None:
        return None
    try:
        shapes = [getattr(edge, "shape", None) for edge in edges]
        if any(shape is None or shape.IsNull() for shape in shapes):
            return None
        for repair in (False, True):
            edge_shapes = TopTools_ListOfShape()
            for shape in shapes:
                if repair:
                    shape = _copy_with_tolerance(shape, tolerance, vertices_only=True)
                edge_shapes.Append(topods.Edge(shape))
            maker = BRepBuilderAPI_MakeWire()
            maker.Add(edge_shapes)
            if not maker.IsDone():
                continue
            wire_shape = maker.Wire()
            explorer = TopExp_Explorer(wire_shape, TopAbs_EDGE)
            actual_count = 0
            while explorer.More():
                actual_count += 1
                explorer.Next()
            if actual_count == len(shapes):
                return wire_shape
    except Exception:
        pass
    return None


@dataclass(eq=False)
class Wire(Topology):
    edges: list = field(default_factory=list)

    @staticmethod
    def ByEdges(edges, tolerance=0.0001):
        if edges is None:
            return None

        tolerance = _positive_tolerance(tolerance)
        edges = list(edges)
        if tolerance is None or not all(isinstance(e, Edge) for e in edges):
            return None

        if not edges:
            return None

        # Preserve the established path for ordinary manifold/open/closed
        # wires where all edges can be ordered head-to-tail.
        ordered = Wire._order_edges(
            edges,
            tolerance=tolerance
        )

        if ordered is not None:
            shape = make_occ_wire(ordered, tolerance=tolerance)

            if shape is None:
                return None

            try:
                if shape.IsNull():
                    return None
            except Exception:
                pass

            return Wire(
                shape=shape,
                edges=ordered
            )

        # A connected non-manifold wire may have branch vertices and therefore
        # cannot necessarily be represented by one head-to-tail edge ordering.
        # Build all edges in one OCCT MakeWire batch instead.
        shape = _make_occ_wire_batch(edges, tolerance=tolerance)

        if shape is None:
            return None

        return Wire(
            shape=shape,
            edges=list(edges)
        )

    @staticmethod
    def ByOcctShape(shape, dictionary=None, contents=None, contexts=None, apertures=None):
        """
        Wraps an OCCT wire.

        For ordinary manifold wires, BRepTools_WireExplorer is preferred
        because it yields connectivity/walk order. For branching/non-manifold
        wires, WireExplorer may not visit every stored edge, so a TopExp
        traversal is also collected. If TopExp finds more edges, that complete
        edge collection is retained instead.

        Reusing the original OCCT edge shapes preserves shared-edge identity
        across higher-dimensional topologies.
        """
        walk_edges = []
        all_edges = []

        # Preferred ordering for ordinary manifold/open/closed wires.
        try:
            from OCC.Core.BRepTools import BRepTools_WireExplorer
            from OCC.Core.TopoDS import topods

            occ_wire = topods.Wire(shape)
            wire_explorer = BRepTools_WireExplorer(occ_wire)

            while wire_explorer.More():
                occ_edge = wire_explorer.Current()
                edge = Edge.ByOcctShape(occ_edge)

                if edge is not None:
                    walk_edges.append(edge)

                wire_explorer.Next()

        except Exception:
            walk_edges = []

        # Complete storage traversal. This is essential for branching wires,
        # where WireExplorer may only follow one traversable chain.
        try:
            from OCC.Core.TopAbs import TopAbs_EDGE
            from OCC.Core.TopExp import TopExp_Explorer

            explorer = TopExp_Explorer(
                shape,
                TopAbs_EDGE
            )

            while explorer.More():
                edge = Edge.ByOcctShape(
                    explorer.Current()
                )

                if edge is not None:
                    all_edges.append(edge)

                explorer.Next()

        except Exception:
            all_edges = []

        if all_edges and len(all_edges) > len(walk_edges):
            edges = all_edges
        elif walk_edges:
            edges = walk_edges
        else:
            edges = all_edges

        if not edges:
            return None

        wire = Wire(
            shape=shape,
            edges=edges
        )

        wire.dictionary = dictionary
        wire.contents = list(contents) if contents else []
        wire.contexts = list(contexts) if contexts else []
        wire.apertures = list(apertures) if apertures else []

        return wire

    @staticmethod
    def BoundingRadius(wire, origin):
        """Return the maximum OCCT bounding-box corner distance from origin."""
        if not isinstance(wire, Wire) or not isinstance(origin, Vertex):
            return None
        try:
            from OCC.Core.Bnd import Bnd_Box
            from OCC.Core.BRepBndLib import brepbndlib
            shape = getattr(wire, "shape", None)
            if shape is None or shape.IsNull():
                return None
            box = Bnd_Box()
            brepbndlib.Add(shape, box)
            xmin, ymin, zmin, xmax, ymax, zmax = box.Get()
            ox, oy, oz = float(origin.x), float(origin.y), float(origin.z)
            return max(
                math.sqrt((x-ox)**2 + (y-oy)**2 + (z-oz)**2)
                for x in (xmin, xmax)
                for y in (ymin, ymax)
                for z in (zmin, zmax)
            )
        except Exception:
            return None

    @staticmethod
    def ProjectNormal(wire, face, limit=False, tolerance=0.0001):
        """Project a Wire normally onto a Face using native OCCT geometry."""
        from .face import Face
        if not isinstance(wire, Wire) or not isinstance(face, Face):
            return None
        try:
            from OCC.Core.BRepOffsetAPI import BRepOffsetAPI_NormalProjection
            from OCC.Core.TopAbs import TopAbs_EDGE, TopAbs_WIRE
            from OCC.Core.TopExp import TopExp_Explorer
            from OCC.Core.TopoDS import topods
            source = getattr(wire, "shape", None)
            target = getattr(face, "shape", None)
            if source is None or target is None or source.IsNull() or target.IsNull():
                return None
            projector = BRepOffsetAPI_NormalProjection(target)
            projector.Add(source)
            projector.SetLimit(bool(limit))
            projector.Compute3d(True)
            projector.Build()
            if hasattr(projector, "IsDone") and not projector.IsDone():
                return None
            shape = projector.Projection()
            if shape is None or shape.IsNull():
                return None
            wires = []
            explorer = TopExp_Explorer(shape, TopAbs_WIRE)
            while explorer.More():
                candidate = Wire.ByOcctShape(topods.Wire(explorer.Current()))
                if isinstance(candidate, Wire):
                    wires.append(candidate)
                explorer.Next()
            if len(wires) == 1:
                return wires[0]
            edges = []
            if wires:
                for candidate in wires:
                    edges.extend(candidate.Edges() or [])
            else:
                explorer = TopExp_Explorer(shape, TopAbs_EDGE)
                while explorer.More():
                    edge = Edge.ByOcctShape(topods.Edge(explorer.Current()))
                    if isinstance(edge, Edge):
                        edges.append(edge)
                    explorer.Next()
            return Wire.ByEdges(edges, tolerance=tolerance) if edges else None
        except Exception:
            return None

    @staticmethod
    def Project(wire, face, direction, tolerance=0.0001):
        """Project a Wire onto a Face along a constant direction."""
        from .face import Face
        if not isinstance(wire, Wire) or not isinstance(face, Face):
            return None
        try:
            from OCC.Core.BRepProj import BRepProj_Projection
            from OCC.Core.gp import gp_Dir
            source = getattr(wire, "shape", None)
            target = getattr(face, "shape", None)
            values = [float(direction[0]), float(direction[1]), float(direction[2])]
            if source is None or target is None or source.IsNull() or target.IsNull():
                return None
            projection = BRepProj_Projection(source, target, gp_Dir(*values))
            if not projection.IsDone():
                return None
            wires = []
            projection.Init()
            while projection.More():
                candidate = Wire.ByOcctShape(projection.Current())
                if isinstance(candidate, Wire):
                    wires.append(candidate)
                projection.Next()
            if len(wires) == 1:
                return wires[0]
            if len(wires) > 1:
                edges = []
                for candidate in wires:
                    edges.extend(candidate.Edges() or [])
                return Wire.ByEdges(edges, tolerance=tolerance)
        except Exception:
            pass
        return None

    @staticmethod
    def InterpolateEdge(edgeA, edgeB, fraction, tolerance=0.0001):
        """Create a native B-spline interpolation between two curved Edges."""
        if not isinstance(edgeA, Edge) or not isinstance(edgeB, Edge):
            return None
        try:
            from OCC.Core.BRepAdaptor import BRepAdaptor_Curve
            from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_MakeEdge
            from OCC.Core.GeomAPI import GeomAPI_Interpolate
            from OCC.Core.TColgp import TColgp_HArray1OfPnt
            from OCC.Core.gp import gp_Pnt
            fraction = float(fraction)
            tolerance = abs(float(tolerance))
            closed_a = same_vertex(edgeA.start, edgeA.end, tolerance)
            closed_b = same_vertex(edgeB.start, edgeB.end, tolerance)
            if closed_a != closed_b:
                return None
            periodic = closed_a and closed_b
            count = 16 if periodic else 17
            adaptor_a = BRepAdaptor_Curve(edgeA.shape)
            adaptor_b = BRepAdaptor_Curve(edgeB.shape)
            a0, a1 = float(adaptor_a.FirstParameter()), float(adaptor_a.LastParameter())
            b0, b1 = float(adaptor_b.FirstParameter()), float(adaptor_b.LastParameter())
            points = TColgp_HArray1OfPnt(1, count)
            for index in range(count):
                u = float(index) / float(count if periodic else count - 1)
                pa = adaptor_a.Value(a0 + u * (a1 - a0))
                pb = adaptor_b.Value(b0 + u * (b1 - b0))
                points.SetValue(index + 1, gp_Pnt(
                    (1.0-fraction)*pa.X() + fraction*pb.X(),
                    (1.0-fraction)*pa.Y() + fraction*pb.Y(),
                    (1.0-fraction)*pa.Z() + fraction*pb.Z(),
                ))
            interpolator = GeomAPI_Interpolate(points, periodic, tolerance)
            interpolator.Perform()
            if not interpolator.IsDone():
                return None
            maker = BRepBuilderAPI_MakeEdge(interpolator.Curve())
            if hasattr(maker, "IsDone") and not maker.IsDone():
                return None
            return Edge.ByOcctShape(maker.Edge())
        except Exception:
            return None

    def Union(self, otherTopology, transferDictionary: bool = False, tolerance: float = 0.0001):
        """
        Returns the union of this wire and the input topology.

        For Wire/Wire unions, the generic OCCT Boolean may correctly compute a
        connected branching one-dimensional network but wrap it as a Cluster.
        Topologic permits such a non-manifold connected network to remain a
        Wire. Therefore, after the generic Boolean completes, this method
        promotes the result to a Wire only when every result edge can be
        consumed by Wire.ByEdges without loss.

        Parameters
        ----------
        otherTopology : Topology
            The second input topology.
        transferDictionary : bool , optional
            If True, dictionaries are transferred by the generic Boolean
            operation. Default is False.

        Returns
        -------
        Topology
            The Boolean union result.
        """
        result = Topology.Union(
            self,
            otherTopology,
            transferDictionary,
            tolerance=tolerance
        )

        if result is None:
            return None

        if not isinstance(otherTopology, Wire):
            return result

        if isinstance(result, Wire):
            return result

        try:
            result_edges = result.Edges() or []
        except Exception:
            result_edges = []

        if not result_edges:
            return result

        wire = Wire.ByEdges(
            result_edges
        )

        if wire is None:
            return result

        try:
            wire_edges = wire.Edges() or []
        except Exception:
            return result

        # A connected Wire must preserve every Boolean result Edge. If the
        # reconstruction is partial, retain the original aggregate result.
        if len(wire_edges) != len(result_edges):
            return result

        # Preserve metadata from the generic Boolean result.
        try:
            wire = Topology.SetDictionary(
                wire,
                Topology.GetDictionary(result)
            )
        except Exception:
            try:
                wire.dictionary = getattr(
                    result,
                    "dictionary",
                    {}
                )
            except Exception:
                pass

        for attr in (
            "contents",
            "contexts",
            "apertures",
        ):
            try:
                setattr(
                    wire,
                    attr,
                    list(getattr(result, attr, []) or [])
                )
            except Exception:
                pass

        return wire

    @staticmethod
    def ByVertices(vertices, close=False, tolerance=0.0001):
        if vertices is None:
            return None
        tolerance = _positive_tolerance(tolerance)
        vertices = list(vertices)
        if tolerance is None or not all(isinstance(v, Vertex) for v in vertices):
            return None
        if len(vertices) < 2:
            return None
        edges = []
        for a, b in zip(vertices[:-1], vertices[1:]):
            if not same_vertex(a, b, tolerance):
                e = Edge.ByStartVertexEndVertexTolerance(a, b, tolerance)
                if e is None:
                    return None
                edges.append(e)
        if close and len(vertices) > 2 and not same_vertex(vertices[-1], vertices[0], tolerance):
            e = Edge.ByStartVertexEndVertexTolerance(vertices[-1], vertices[0], tolerance)
            if e is None:
                return None
            edges.append(e)
        if not edges:
            return None
        return Wire.ByEdges(edges, tolerance=tolerance)

    @staticmethod
    def _order_edges(edges, tolerance=0.0001):
        if not edges:
            return []
        unused = list(edges)
        ordered = [unused.pop(0)]
        while unused:
            last = ordered[-1].end
            found_index = None
            found_edge = None
            for i, edge in enumerate(unused):
                if same_vertex(edge.start, last, tolerance):
                    found_index = i
                    found_edge = edge
                    break
                if same_vertex(edge.end, last, tolerance):
                    found_index = i
                    # Reuse the original edge's shape (just orientation-
                    # flipped via .Reversed(), which OCCT keeps IsSame/hash-
                    # equal to the original) instead of fabricating a brand
                    # new edge shape -- Edge.ByStartVertexEndVertex would
                    # sever this edge's identity from any other reference to
                    # it elsewhere in the same result, silently duplicating
                    # its vertices when the two are later merged/deduped.
                    found_edge = None
                    try:
                        found_edge = Edge.ByOcctShape(edge.shape.Reversed())
                    except Exception:
                        found_edge = None
                    if found_edge is None:
                        found_edge = Edge.ByStartVertexEndVertex(edge.end, edge.start, tolerance=tolerance)
                    if found_edge is not None:
                        found_edge.dictionary = edge.dictionary
                    break
            if found_index is None:
                return None
            ordered.append(found_edge)
            unused.pop(found_index)
            if len(ordered) > len(edges) + 1:
                return None
        return ordered

    def Edges(self, hostTopology=None, edges=None):
        result = list(getattr(self, "edges", []) or [])
        if edges is not None:
            edges.extend(result)
            return 0
        return result

    def Vertices(self, hostTopology=None, vertices=None):
        result = []
        for edge in getattr(self, "edges", []) or []:
            if isinstance(edge, Edge):
                result.extend([edge.start, edge.end])
        result = unique_by_uuid([v for v in result if isinstance(v, Vertex)])
        if vertices is not None:
            vertices.extend(result)
            return 0
        return result

    def Wires(self, hostTopology=None, wires=None):
        # BRepGraph Tranche 1: when a host is supplied this method is also
        # the backend utility entry point for same-dimensional adjacency.
        if hostTopology is not None:
            try:
                from .topology import _brepgraph_adjacent_wrappers, TopAbs_WIRE
                native = _brepgraph_adjacent_wrappers(self, hostTopology, TopAbs_WIRE)
            except Exception:
                native = None
            if native is not None:
                result = native
            else:
                result = [self]
        else:
            result = [self]
        if wires is not None:
            wires.extend(result)
            return 0
        return result

    def IsClosed(self, tolerance=0.0001):
        tolerance = _positive_tolerance(tolerance)
        if tolerance is None:
            return False
        try:
            from OCC.Core.BRep import BRep_Tool
            if self.shape is not None and BRep_Tool.IsClosed(self.shape):
                return True
        except Exception:
            pass
        edges = getattr(self, "edges", []) or []
        if not edges:
            return False
        return same_vertex(edges[0].start, edges[-1].end, tolerance)

    @staticmethod
    def ByEdgesCluster(cluster, tolerance: float = 0.0001):
        """
        Not part of the guide's minimum checklist and not called by the
        topologicpy algorithm layer (Wire.ByEdgesCluster there goes through
        Topology.Edges + Wire.ByEdges directly, never through
        Core.Wire.ByEdgesCluster; verified: zero call sites). Real
        best-effort implementation for direct Core callers, matching that
        same recipe: pull the edges out of the input cluster and hand them to
        Wire.ByEdges.
        """
        edges = []
        try:
            cluster.Edges(None, edges)
        except Exception:
            return None
        edges = [e for e in edges if isinstance(e, Edge)]
        if not edges:
            return None
        return Wire.ByEdges(edges, tolerance=tolerance)

    @staticmethod
    def ByWires(wires, tolerance: float = 0.0001):
        """
        Not in the guide's checklist; unreferenced by the algorithm layer.
        Best-effort for direct Core callers: pool every edge and re-stitch into
        one Wire (or one per connected component) via the edge-ordering logic.
        """
        pooled_edges = []
        for w in (wires or []):
            if isinstance(w, Wire):
                pooled_edges.extend(getattr(w, "edges", []) or [])
        pooled_edges = [e for e in pooled_edges if isinstance(e, Edge)]
        if not pooled_edges:
            return None

        # Group edges into connected components (shared endpoints), then
        # order each component into its own wire.
        remaining = list(pooled_edges)
        components = []
        while remaining:
            comp = [remaining.pop(0)]
            changed = True
            while changed:
                changed = False
                for e in list(remaining):
                    if any(
                        same_vertex(e.start, c.start, tolerance)
                        or same_vertex(e.start, c.end, tolerance)
                        or same_vertex(e.end, c.start, tolerance)
                        or same_vertex(e.end, c.end, tolerance)
                        for c in comp
                    ):
                        comp.append(e)
                        remaining.remove(e)
                        changed = True
            components.append(comp)

        result_wires = [w for w in (Wire.ByEdges(comp, tolerance=tolerance) for comp in components) if w is not None]
        if not result_wires:
            return None
        if len(result_wires) == 1:
            return result_wires[0]
        return result_wires

    def Reverse(self, transferDictionaries: bool = False, tolerance: float = 0.0001):
        """
        Not in the guide's checklist; unreferenced by the algorithm layer.
        Instance method for both calling conventions: reverse edge order and swap
        each edge's start/end.
        """
        edges = getattr(self, "edges", []) or []
        if not edges:
            return None
        reversed_edges = []
        for e in reversed(edges):
            if not isinstance(e, Edge):
                return None
            new_edge = Edge.ByStartVertexEndVertex(e.end, e.start)
            if new_edge is None:
                return None
            if transferDictionaries:
                new_edge.dictionary = e.dictionary
            reversed_edges.append(new_edge)
        result = Wire(shape=make_occ_wire(reversed_edges, tolerance=tolerance), edges=reversed_edges)
        if transferDictionaries:
            result.dictionary = self.dictionary
        return result


class WireUtility:
    @staticmethod
    def OffsetEdge(edge, distance, normal, calibrationParameter=0.5, targetDirection=None, tolerance=0.0001):
        """Offset a curved Edge exactly on its supporting plane."""
        if not isinstance(edge, Edge):
            return None
        try:
            from OCC.Core.BRep import BRep_Tool
            from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_MakeEdge
            from OCC.Core.Geom import Geom_OffsetCurve
            from OCC.Core.TopAbs import TopAbs_REVERSED
            from OCC.Core.gp import gp_Dir
            distance = float(distance)
            parameter = float(calibrationParameter)
            nx, ny, nz = [float(value) for value in normal]
            target = [float(value) for value in targetDirection]
            if len(target) != 3:
                return None
            shape = getattr(edge, "shape", None)
            if shape is None or shape.IsNull():
                return None
            curve, first, last = BRep_Tool.Curve(shape)
            if curve is None:
                return None
            first, last = float(first), float(last)
            raw = last + parameter*(first-last) if shape.Orientation() == TopAbs_REVERSED else first + parameter*(last-first)
            magnitude = abs(distance)
            trial = Geom_OffsetCurve(curve, magnitude, gp_Dir(nx, ny, nz))
            source_point = curve.Value(raw)
            offset_point = trial.Value(raw)
            displacement = [offset_point.X()-source_point.X(), offset_point.Y()-source_point.Y(), offset_point.Z()-source_point.Z()]
            if sum(displacement[i]*target[i] for i in range(3)) < 0.0:
                magnitude = -magnitude
            offset_curve = Geom_OffsetCurve(curve, magnitude, gp_Dir(nx, ny, nz))
            maker = BRepBuilderAPI_MakeEdge(offset_curve, first, last)
            if hasattr(maker, "IsDone") and not maker.IsDone():
                return None
            occ_edge = maker.Edge()
            if shape.Orientation() == TopAbs_REVERSED:
                occ_edge.Reverse()
            return Edge.ByOcctShape(occ_edge)
        except Exception:
            return None

    @staticmethod
    def IntersectionVertices(edgeA, edgeB, tolerance=0.0001):
        """Return native finite Edge/Edge intersection Vertices."""
        if not isinstance(edgeA, Edge) or not isinstance(edgeB, Edge):
            return []
        try:
            from OCC.Core.BRep import BRep_Tool
            from OCC.Core.BRepAlgoAPI import BRepAlgoAPI_Section
            from OCC.Core.TopAbs import TopAbs_VERTEX
            from OCC.Core.TopExp import TopExp_Explorer
            from OCC.Core.TopoDS import topods
            section = BRepAlgoAPI_Section(edgeA.shape, edgeB.shape, False)
            try:
                section.Approximation(False)
                section.ComputePCurveOn1(False)
                section.ComputePCurveOn2(False)
            except Exception:
                pass
            section.Build()
            if hasattr(section, "IsDone") and not section.IsDone():
                return []
            result = []
            explorer = TopExp_Explorer(section.Shape(), TopAbs_VERTEX)
            while explorer.More():
                point = BRep_Tool.Pnt(topods.Vertex(explorer.Current()))
                result.append(Vertex.ByCoordinates(point.X(), point.Y(), point.Z()))
                explorer.Next()
            return [vertex for vertex in result if isinstance(vertex, Vertex)]
        except Exception:
            return []

    @staticmethod
    def IsClosed(wire):
        if isinstance(wire, Wire):
            return wire.IsClosed()
        return False

    @staticmethod
    def Length(wire):
        """
        Not part of the guide's minimum checklist and not called by the
        topologicpy algorithm layer (Wire.Length there sums Edge.Length over
        Topology.Edges and never reaches Core; verified: zero call sites).
        Real best-effort implementation for direct Core callers: sum of the
        wire's own edge lengths.
        """
        from .edge import EdgeUtility
        if not isinstance(wire, Wire):
            return None
        edges = getattr(wire, "edges", []) or []
        if not edges:
            return None
        total = 0.0
        for e in edges:
            length = EdgeUtility.Length(e)
            if length is None:
                return None
            total += length
        return total

    @staticmethod
    def Cycles(wire, tolerance: float = 0.0001):
        """
        Not part of the guide's minimum checklist and not called by the
        topologicpy algorithm layer (verified: zero call sites). Real
        best-effort implementation for direct Core callers: finds the
        elementary cycles in the wire's edge/vertex graph (relevant for
        non-manifold wires with branches; a simple open or closed wire -- the
        only kind this backend's Wire.ByEdges/.ByVertices ever build -- has
        at most one cycle, itself, when closed).
        """
        if not isinstance(wire, Wire):
            return []
        edges = getattr(wire, "edges", []) or []
        if not edges:
            return []

        def vkey(v):
            return (round(v.x / tolerance), round(v.y / tolerance), round(v.z / tolerance))

        # Build an undirected adjacency list keyed by rounded vertex position.
        adjacency = {}
        for e in edges:
            ka, kb = vkey(e.start), vkey(e.end)
            adjacency.setdefault(ka, []).append((kb, e))
            adjacency.setdefault(kb, []).append((ka, e))

        visited_edges = set()
        cycles = []
        for e in edges:
            eid = id(e)
            if eid in visited_edges:
                continue
            # Walk forward from e.start through e until we either return to
            # the start (a cycle) or run out of unvisited connections (not a
            # cycle from this edge).
            path_edges = [e]
            visited_edges.add(eid)
            start_key = vkey(e.start)
            current_key = vkey(e.end)
            found_cycle = same_vertex(e.start, e.end, tolerance)
            while not found_cycle:
                next_edge = None
                for (other_key, cand) in adjacency.get(current_key, []):
                    if id(cand) in visited_edges:
                        continue
                    next_edge = cand
                    next_key = other_key
                    break
                if next_edge is None:
                    break
                path_edges.append(next_edge)
                visited_edges.add(id(next_edge))
                current_key = next_key
                if current_key == start_key:
                    found_cycle = True
            if found_cycle and len(path_edges) > 1:
                cycle_wire = Wire.ByEdges(path_edges, tolerance=tolerance)
                if cycle_wire is not None:
                    cycles.append(cycle_wire)
        return cycles

    @staticmethod
    def Split(wire, tolerance: float = 0.0001):
        """
        Not in the guide's checklist; unreferenced by the algorithm layer.
        Best-effort for direct Core callers: split a (possibly branching) wire at
        every vertex of degree != 2 into its maximal simple edge runs.
        """
        if not isinstance(wire, Wire):
            return None
        edges = getattr(wire, "edges", []) or []
        if not edges:
            return None

        def vkey(v):
            return (round(v.x / tolerance), round(v.y / tolerance), round(v.z / tolerance))

        degree = {}
        for e in edges:
            for k in (vkey(e.start), vkey(e.end)):
                degree[k] = degree.get(k, 0) + 1

        branch_points = {k for k, d in degree.items() if d != 2}

        remaining = list(edges)
        runs = []
        while remaining:
            run = [remaining.pop(0)]
            # Extend forward and backward while the joining vertex is not a
            # branch point (degree != 2), matching how a "simple run" between
            # branch points is conventionally defined.
            extended = True
            while extended:
                extended = False
                # forward extension
                last_key = vkey(run[-1].end)
                if last_key not in branch_points:
                    for e in list(remaining):
                        if same_vertex(e.start, run[-1].end, tolerance):
                            run.append(e)
                            remaining.remove(e)
                            extended = True
                            break
                        if same_vertex(e.end, run[-1].end, tolerance):
                            flipped = None
                            try:
                                flipped = Edge.ByOcctShape(e.shape.Reversed())
                            except Exception:
                                flipped = None
                            if flipped is None:
                                flipped = Edge.ByStartVertexEndVertex(e.end, e.start)
                            if flipped is not None:
                                run.append(flipped)
                                remaining.remove(e)
                                extended = True
                                break
                if extended:
                    continue
                # backward extension
                first_key = vkey(run[0].start)
                if first_key not in branch_points:
                    for e in list(remaining):
                        if same_vertex(e.end, run[0].start, tolerance):
                            run.insert(0, e)
                            remaining.remove(e)
                            extended = True
                            break
                        if same_vertex(e.start, run[0].start, tolerance):
                            flipped = None
                            try:
                                flipped = Edge.ByOcctShape(e.shape.Reversed())
                            except Exception:
                                flipped = None
                            if flipped is None:
                                flipped = Edge.ByStartVertexEndVertex(e.end, e.start)
                            if flipped is not None:
                                run.insert(0, flipped)
                                remaining.remove(e)
                                extended = True
                                break
            runs.append(run)

        result = [w for w in (Wire.ByEdges(run, tolerance=tolerance) for run in runs) if w is not None]
        return result if result else None

# Wire -> Shell: find Shells in hostTopology containing this Wire.
def _adjacent_shells(wire, hostTopology, output):
    from .topology import Topology
    from .helpers import same_vertex
    if not isinstance(wire, Wire) or hostTopology is None:
        return 1
    result, we_src, candidates = [], (getattr(wire, "edges", []) or []), []
    Topology.Shells(hostTopology, None, candidates)
    for s in candidates:
        for sf_face in (getattr(s, "faces", []) or []):
            wf = [sf_face.external] if getattr(sf_face, "external", None) else []
            for wf_wire in wf:
                we = getattr(wf_wire, "edges", []) or []
                if len(we) == len(we_src) and all(
                    any(same_vertex(a.start, b.start) and same_vertex(a.end, b.end) for b in we_src)
                    or any(same_vertex(a.start, b.end) and same_vertex(a.end, b.start) for b in we_src)
                    for a in we
                ):
                    result.append(s); break
            if result and result[-1] is s: break
    if output is not None: output.extend(result)
    return 0

def _adjacent_cells(wire, hostTopology, output):
    from .topology import Topology
    from .helpers import same_vertex
    if not isinstance(wire, Wire) or hostTopology is None:
        return 1
    result, we_src, candidates = [], (getattr(wire, "edges", []) or []), []
    Topology.Cells(hostTopology, None, candidates)
    for c in candidates:
        for cs in (getattr(c, "shells", []) or []):
            for cs_face in (getattr(cs, "faces", []) or []):
                wf = [cs_face.external] if getattr(cs_face, "external", None) else []
                for wf_wire in wf:
                    we = getattr(wf_wire, "edges", []) or []
                    if len(we) == len(we_src) and all(
                        any(same_vertex(a.start, b.start) and same_vertex(a.end, b.end) for b in we_src)
                        or any(same_vertex(a.start, b.end) and same_vertex(a.end, b.start) for b in we_src)
                        for a in we
                    ):
                        result.append(c); break
                if result and result[-1] is c: break
            if result and result[-1] is c: break
    if output is not None: output.extend(result)
    return 0


def _make_adjacent(method_name):
    """Return a staticmethod that delegates to topology.method(hostTopology, output)."""
    @staticmethod
    def _impl(topology, hostTopology, output):
        if topology is None:
            return 1
        return getattr(topology, method_name)(hostTopology, output)
    return _impl

WireUtility.AdjacentVertices = _make_adjacent("Vertices")
WireUtility.AdjacentEdges = _make_adjacent("Edges")
WireUtility.AdjacentWires = _make_adjacent("Wires")
WireUtility.AdjacentFaces = _make_adjacent("Faces")
WireUtility.AdjacentCellComplexes = _make_adjacent("CellComplexes")

# ---------------------------------------------------------------------------
# Wire.ByEdgesCluster, Wire.ByWires, Wire.Reverse, WireUtility.Length,
# WireUtility.Cycles, and WireUtility.Split now have real implementations
# defined on the classes above -- do not re-clobber them here (see gotcha
# about stub assignments silently overriding real implementations added
# earlier in the file).
# ---------------------------------------------------------------------------
from .helpers import not_implemented as _not_implemented


def _wire_not_implemented(name, return_value=None):
    def _method(*args, **kwargs):
        return _not_implemented(f"Wire.{name}", return_value)
    return _method


def _wire_utility_not_implemented(name, return_value=None):
    def _method(*args, **kwargs):
        return _not_implemented(f"WireUtility.{name}", return_value)
    return _method
