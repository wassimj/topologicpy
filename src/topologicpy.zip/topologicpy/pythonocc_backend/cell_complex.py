from __future__ import annotations

import math

from dataclasses import dataclass, field
from .topology import Topology, _downward_wrappers
from .cell import Cell
from .wire import Wire
from .cluster import Cluster
from .helpers import unique_by_uuid

try:
    from OCC.Core.BOPAlgo import BOPAlgo_CellsBuilder, BOPAlgo_MakerVolume
    from OCC.Core.BRepAlgoAPI import BRepAlgoAPI_Fuse
    from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_Transform
    from OCC.Core.BRepPrimAPI import BRepPrimAPI_MakeTorus
    from OCC.Core.gp import gp_Ax1, gp_Dir, gp_Pnt, gp_Trsf
    from OCC.Core.TopAbs import (
        TopAbs_VERTEX,
        TopAbs_EDGE,
        TopAbs_FACE,
        TopAbs_SHELL,
        TopAbs_SOLID,
    )
    from OCC.Core.TopExp import TopExp_Explorer
    from OCC.Core.TopTools import TopTools_ListOfShape
    from OCC.Core.BRep import BRep_Builder
    from OCC.Core.TopoDS import TopoDS_CompSolid, topods

except Exception:  # pragma: no cover - allows import without PythonOCC
    BOPAlgo_CellsBuilder = None
    BOPAlgo_MakerVolume = None
    BRepAlgoAPI_Fuse = None
    BRepBuilderAPI_Transform = None
    BRepPrimAPI_MakeTorus = None
    gp_Ax1 = None
    gp_Dir = None
    gp_Pnt = None
    gp_Trsf = None

    TopAbs_VERTEX = None
    TopAbs_EDGE = None
    TopAbs_FACE = None
    TopAbs_SHELL = None
    TopAbs_SOLID = None

    TopExp_Explorer = None
    TopTools_ListOfShape = None
    BRep_Builder = None
    TopoDS_CompSolid = None
    topods = None


def _iter_subshapes(shape, shape_type):
    if TopExp_Explorer is None or shape_type is None:
        return []
    result = []
    explorer = TopExp_Explorer(shape, shape_type)
    while explorer.More():
        result.append(explorer.Current())
        explorer.Next()
    return result


def _as_compsolid(shape):
    """
    BOPAlgo_CellsBuilder.MakeContainers() may yield a plain COMPOUND
    containing the resulting Solids rather than a COMPSOLID, even when every
    Solid shares faces with its neighbours. topologic_core's CellComplex is
    specifically a COMPSOLID, so rebuild one explicitly from the Solid
    sub-shapes whenever the builder didn't already produce one.
    """
    if not CellComplex._has_solid(shape):
        return None
    if not CellComplex._cells_share_faces(shape):
        return None
    try:
        from OCC.Core.TopAbs import TopAbs_COMPSOLID
        if shape.ShapeType() == TopAbs_COMPSOLID:
            return shape
    except Exception:
        pass

    solids = _iter_subshapes(shape, TopAbs_SOLID)
    if not solids or BRep_Builder is None:
        return None
    try:
        builder = BRep_Builder()
        compsolid = TopoDS_CompSolid()
        builder.MakeCompSolid(compsolid)
        for solid in solids:
            builder.Add(compsolid, topods.Solid(solid))
        return compsolid
    except Exception:
        return None


def _shape_same(a, b):
    """OCCT shape equality. Two TopoDS_Shape objects are the same
    topology iff IsSame returns True (coincident + same orientation
    class). Used for shared/non-manifold face detection where
    BOPAlgo_MakerVolume emits distinct Python objects for the same
    geometric face in adjacent cells.
    """
    if a is b:
        return True
    try:
        return bool(a.IsSame(b))
    except Exception:
        return False


def _is_null_shape(shape):
    if shape is None:
        return True
    try:
        return bool(shape.IsNull())
    except Exception:
        return True


def _drop_open_shells(shape):
    """
    Rebuild a single SOLID dropping open (zero-enclosed-volume) shells: closed
    lofts (e.g. CellComplex.Torus) can carry a degenerate open shell that
    inflates the Shell count (2 vs core's 1). A genuine cavity shell encloses
    non-zero volume and is kept; compsolids are untouched.
    """
    if shape is None or _is_null_shape(shape):
        return shape
    try:
        from OCC.Core.TopAbs import TopAbs_SOLID, TopAbs_SHELL
        if shape.ShapeType() != TopAbs_SOLID:
            return shape
    except Exception:
        return shape
    try:
        from OCC.Core.TopExp import TopExp_Explorer
        from OCC.Core.TopoDS import TopoDS_Solid
        from OCC.Core.BRep import BRep_Builder
        from OCC.Core.GProp import GProp_GProps
        from OCC.Core.BRepGProp import brepgprop
    except Exception:
        return shape

    shells = []
    explorer = TopExp_Explorer(shape, TopAbs_SHELL)
    while explorer.More():
        shell = explorer.Current()
        explorer.Next()
        try:
            props = GProp_GProps()
            brepgprop.VolumeProperties(shell, props)
        except Exception:
            continue
        from OCC.Core.BRep import BRep_Tool
        if BRep_Tool.IsClosed(shell) or abs(props.Mass()) > 1e-9:
            shells.append(shell)

    if not shells:
        return shape
    # Count shells actually present to know whether anything was dropped.
    total = 0
    exp2 = TopExp_Explorer(shape, TopAbs_SHELL)
    while exp2.More():
        total += 1
        exp2.Next()
    if total == len(shells):
        return shape

    try:
        builder = BRep_Builder()
        solid = TopoDS_Solid()
        builder.MakeSolid(solid)
        for shell in shells:
            builder.Add(solid, shell)
        from .occ_utils import _orient_valid_solid
        repaired = _orient_valid_solid(solid)
        if repaired is not None:
            import warnings
            warnings.warn("CellComplex: removed open zero-volume auxiliary shell during recovery.", RuntimeWarning, stacklevel=2)
            return repaired
        return shape
    except Exception:
        return shape



# BRepGraph Tranche 2: CellComplex incidence helpers
def _brepgraph_faces_by_cell_incidence(cell_complex, min_count=None, max_count=None):
    """Return Face wrappers classified by distinct Solid ancestry, or None.

    None means the BRepGraph path is unavailable/unreliable and the caller must
    retain the established legacy implementation.  An empty list is an
    authoritative graph result.
    """
    shape = getattr(cell_complex, "shape", None)
    if _is_null_shape(shape):
        return None
    try:
        from ._brepgraph import cached_index as _cached_brepgraph_index
        index = _cached_brepgraph_index(cell_complex, shape)
        native_shapes = (
            index.subshapes_by_ancestor_count(
                TopAbs_FACE,
                TopAbs_SOLID,
                min_count=min_count,
                max_count=max_count,
            )
            if index is not None
            else None
        )
    except Exception:
        native_shapes = None

    if native_shapes is None:
        return None

    result = []
    for native_shape in native_shapes:
        try:
            wrapped = Topology.ByOcctShape(native_shape)
        except Exception:
            wrapped = None
        if wrapped is not None:
            result.append(wrapped)
    return result


@dataclass(eq=False)
class CellComplex(Topology):
    cells: list = field(default_factory=list)

    @staticmethod
    def _has_solid(shape):
        """Check for one solid without collecting or wrapping all cells."""
        if _is_null_shape(shape) or TopExp_Explorer is None:
            return False
        return bool(TopExp_Explorer(shape, TopAbs_SOLID).More())

    @staticmethod
    def _cells_share_faces(shape):
        """Require each solid in a multi-cell result to share a native face.

        Indexed OCCT shape identity ignores orientation, so opposite uses of
        an interface face match. Repeated face uses within one solid do not
        count as adjacency. No Cell/Face wrappers or pairwise scans are needed.
        Single-cell complexes retain their existing supported semantics.
        """
        from OCC.Core.TopTools import TopTools_IndexedMapOfShape

        solids = TopTools_IndexedMapOfShape()
        faces = TopTools_IndexedMapOfShape()
        owners = {}
        adjacent = set()
        explorer = TopExp_Explorer(shape, TopAbs_SOLID)
        while explorer.More():
            solid = explorer.Current()
            explorer.Next()
            if solids.Contains(solid):
                continue
            solid_id = solids.Add(solid)
            face_explorer = TopExp_Explorer(solid, TopAbs_FACE)
            while face_explorer.More():
                face_id = faces.Add(face_explorer.Current())
                face_explorer.Next()
                owner = owners.setdefault(face_id, solid_id)
                if owner != solid_id:
                    adjacent.add(owner)
                    adjacent.add(solid_id)
        count = solids.Extent()
        return count == 1 or (count > 1 and len(adjacent) == count)

    @staticmethod
    def _build_from_shapes(shapes, tolerance=0.0001):
        """
        True non-manifold CellComplex construction: BOPAlgo_MakerVolume partitions the
        Face/Shell/Solid boundary soup into every resulting Solid with shared internal faces
        (BOPAlgo_CellsBuilder wrong here: fed pure Faces it builds 2D face-cells).
        """
        shapes = [s for s in (shapes or []) if not _is_null_shape(s)]
        if not shapes or BOPAlgo_MakerVolume is None:
            return None

        try:
            args = TopTools_ListOfShape()
            for shape in shapes:
                args.Append(shape)
            maker = BOPAlgo_MakerVolume()
            maker.SetArguments(args)
            maker.SetIntersect(True)
            if tolerance:
                try:
                    maker.SetFuzzyValue(float(tolerance))
                except Exception:
                    pass
            maker.Perform()
            if hasattr(maker, "HasErrors") and maker.HasErrors():
                return None
            result_shape = maker.Shape()
        except Exception:
            return None

        if not CellComplex._has_solid(result_shape):
            return None

        solid_count = len(_iter_subshapes(result_shape, TopAbs_SOLID))
        if solid_count >= 2:
            compsolid = _as_compsolid(result_shape)
            if compsolid is None:
                return None
            result_shape = compsolid
        else:
            # A single-solid loft/partition can carry an open, zero-volume
            # shell (e.g. CellComplex.Torus' made-by-Spin solid). topologic_core
            # builds a single clean shell; our BOPAlgo_MakerVolume emits a
            # spurious extra shell on such closed lofts, inflating the Shell
            # count (2 vs 1). Drop zero-volume shells -- a genuine void
            # (cavity) shell encloses non-zero volume and is preserved.
            result_shape = _drop_open_shells(result_shape)

        result = Topology.ByOcctShape(result_shape)
        if isinstance(result, CellComplex):
            return result
        if isinstance(result, Cell):
            # The faces/cells only bounded a single solid: still a valid
            # (single-cell) CellComplex per topologic_core semantics.
            return CellComplex(shape=result_shape, cells=[result])
        return None

    @staticmethod
    def ByCells(cells, tolerance=0.0001):
        """Create a CellComplex from existing solid Cells.

        Existing Solids are assembled with BOPAlgo_CellsBuilder first so split
        parts and shared interface Faces are preserved. MakerVolume remains a
        fallback for cases CellsBuilder cannot assemble. In multi-cell results,
        every cell must share at least one face with another cell.
        """
        from .occ_utils import is_valid_occ_solid, _positive_tolerance
        cells = list(cells or [])
        tolerance = _positive_tolerance(tolerance)
        if tolerance is None or not all(isinstance(c, Cell) and is_valid_occ_solid(getattr(c, "shape", None)) for c in cells):
            return None
        shapes = [c.shape for c in cells]
        if len(shapes) < 1:
            return None
        if len(shapes) == 1:
            if (not CellComplex._has_solid(shapes[0])
                    or not CellComplex._cells_share_faces(shapes[0])):
                return None
            return CellComplex(shape=shapes[0], cells=cells)

        try:
            tolerance = abs(float(tolerance))
        except Exception:
            return None
        if tolerance <= 0.0:
            return None

        if BOPAlgo_CellsBuilder is not None and TopTools_ListOfShape is not None:
            try:
                args = TopTools_ListOfShape()
                for shape in shapes:
                    args.Append(shape)

                builder = BOPAlgo_CellsBuilder()
                builder.SetArguments(args)
                try:
                    builder.SetRunParallel(False)
                except Exception:
                    pass
                try:
                    builder.SetFuzzyValue(tolerance)
                except Exception:
                    pass

                builder.Perform()

                has_errors = False
                try:
                    has_errors = bool(builder.HasErrors())
                except Exception:
                    try:
                        has_errors = bool(builder.ErrorStatus())
                    except Exception:
                        pass

                if not has_errors:
                    builder.AddAllToResult()
                    try:
                        builder.MakeContainers()
                    except Exception:
                        pass

                    result_shape = builder.Shape()
                    if not _is_null_shape(result_shape):
                        solids = _iter_subshapes(result_shape, TopAbs_SOLID)
                        unique_solids = []
                        for solid in solids:
                            if not any(_shape_same(solid, other) for other in unique_solids):
                                unique_solids.append(solid)

                        if len(unique_solids) >= 2:
                            compsolid = _as_compsolid(result_shape)
                            if compsolid is not None:
                                wrapped = Topology.ByOcctShape(compsolid)
                                if isinstance(wrapped, CellComplex):
                                    return wrapped
                                wrapped_cells = []
                                for solid in unique_solids:
                                    item = Topology.ByOcctShape(solid)
                                    if isinstance(item, Cell):
                                        wrapped_cells.append(item)
                                if len(wrapped_cells) == len(unique_solids):
                                    return CellComplex(shape=compsolid, cells=wrapped_cells)
            except Exception:
                pass

        return CellComplex._build_from_shapes(shapes, tolerance)

    @staticmethod
    def ByFaces(faces, tolerance=0.0001, copyAttributes=False):
        from .face import Face
        from .occ_utils import _positive_tolerance
        tolerance = _positive_tolerance(tolerance)
        faces = list(faces or [])
        if tolerance is None or not all(isinstance(f, Face) and not _is_null_shape(getattr(f, "shape", None)) for f in faces):
            return None
        shapes = [f.shape for f in faces]
        if len(shapes) < 1:
            return None
        result = CellComplex._build_from_shapes(shapes, tolerance)
        if result is not None:
            return result
        # BOPAlgo_MakerVolume found no fallback volume (e.g. it errored on a
        # face soup that a simpler single-cell sewing pass would tolerate).
        # Fall back to the single-cell path, same as ByCells does when its
        # own _build_from_shapes call fails.
        cell = Cell.ByFaces(faces, tolerance=tolerance)
        if cell is None:
            return None
        return CellComplex.ByCells([cell], tolerance)


    @staticmethod
    def ByWires(wires, tolerance: float = 0.0001):
        """Create an exact curve-preserving CellComplex from consecutive section Wires."""
        if not isinstance(wires, (list, tuple)):
            return None
        wire_list = [wire for wire in wires if isinstance(wire, Wire)]
        if len(wire_list) < 2:
            return None
        try:
            tolerance = abs(float(tolerance))
        except Exception:
            return None
        if tolerance <= 0.0:
            return None
        cells = []
        for i in range(len(wire_list)-1):
            cell = Cell.ByWires([wire_list[i], wire_list[i+1]], tolerance=tolerance)
            if not isinstance(cell, Cell):
                return None
            cells.append(cell)
        return CellComplex.ByCells(cells, tolerance=tolerance)

    @staticmethod
    def ByTorus(majorRadius=0.5, minorRadius=0.125, uSides=16, tolerance=0.0001, silent=False):
        """Build an exact toroidal CellComplex subdivided into OCCT torus sectors."""
        try:
            majorRadius=float(majorRadius); minorRadius=float(minorRadius)
            uSides=int(uSides); tolerance=abs(float(tolerance))
        except Exception:
            return None
        if majorRadius <= tolerance or minorRadius <= tolerance or minorRadius >= majorRadius or uSides < 3:
            return None
        if any(x is None for x in (BRepPrimAPI_MakeTorus, BRepBuilderAPI_Transform, gp_Ax1, gp_Dir, gp_Pnt, gp_Trsf)):
            return None
        step = 2.0*math.pi/float(uSides)
        try:
            maker=BRepPrimAPI_MakeTorus(majorRadius, minorRadius, step)
            sector=maker.Shape()
        except Exception:
            return None
        if _is_null_shape(sector):
            return None
        axis=gp_Ax1(gp_Pnt(0.0,0.0,0.0), gp_Dir(0.0,0.0,1.0))
        cells=[]
        for i in range(uSides):
            try:
                if i == 0:
                    shape=sector
                else:
                    trsf=gp_Trsf(); trsf.SetRotation(axis, step*float(i))
                    shape=BRepBuilderAPI_Transform(sector, trsf, True).Shape()
            except Exception:
                return None
            if _is_null_shape(shape):
                return None
            cell=Topology.ByOcctShape(shape)
            if not isinstance(cell, Cell):
                return None
            cells.append(cell)
        return CellComplex.ByCells(cells, tolerance=tolerance)

    def Cells(self, hostTopology=None, cells=None):
        result = []

        if not _is_null_shape(getattr(self, "shape", None)):
            try:
                # A single-cell CellComplex can currently carry a Solid directly.
                if self.shape.ShapeType() == TopAbs_SOLID:
                    cell = Topology.ByOcctShape(self.shape)
                    if isinstance(cell, Cell):
                        result = [cell]
                else:
                    result = _downward_wrappers(
                        self,
                        TopAbs_SOLID
                    )
            except Exception:
                result = []

        # Fallback for shapeless/fallback CellComplex instances.
        if not result:
            result = list(getattr(self, "cells", []) or [])

        if cells is not None:
            cells.extend(result)
            return 0

        return result


    def Shells(self, hostTopology=None, shells=None):
        if not _is_null_shape(getattr(self, "shape", None)):
            result = _downward_wrappers(
                self,
                TopAbs_SHELL
            )
        else:
            result = []
            for cell in getattr(self, "cells", []) or []:
                result.extend(cell.Shells())

        if shells is not None:
            shells.extend(result)
            return 0

        return result


    def Faces(self, hostTopology=None, faces=None):
        if not _is_null_shape(getattr(self, "shape", None)):
            result = _downward_wrappers(
                self,
                TopAbs_FACE
            )
        else:
            result = []
            for cell in getattr(self, "cells", []) or []:
                result.extend(cell.Faces())

        if faces is not None:
            faces.extend(result)
            return 0

        return result


    def Edges(self, hostTopology=None, edges=None):
        if not _is_null_shape(getattr(self, "shape", None)):
            result = _downward_wrappers(
                self,
                TopAbs_EDGE
            )
        else:
            result = []
            for cell in getattr(self, "cells", []) or []:
                result.extend(cell.Edges())

        if edges is not None:
            edges.extend(result)
            return 0

        return result


    def Vertices(self, hostTopology=None, vertices=None):
        if not _is_null_shape(getattr(self, "shape", None)):
            result = _downward_wrappers(
                self,
                TopAbs_VERTEX
            )
        else:
            result = []
            for cell in getattr(self, "cells", []) or []:
                result.extend(cell.Vertices())

        if vertices is not None:
            vertices.extend(result)
            return 0

        return result

    def CellComplexes(self, hostTopology=None, cellComplexes=None):
        result = [self]
        if cellComplexes is not None:
            cellComplexes.extend(result)
            return 0
        return result

    def ExternalBoundary(self):
        """
        Returns the outer Shell bounding the union of all of this
        CellComplex's Cells (i.e. its Cells fused together, with internal
        non-manifold boundaries removed).
        """
        cell_shapes = [c.shape for c in self.Cells() if not _is_null_shape(getattr(c, "shape", None))]
        if not cell_shapes or BRepAlgoAPI_Fuse is None:
            return None

        try:
            fused = cell_shapes[0]
            for shape in cell_shapes[1:]:
                op = BRepAlgoAPI_Fuse(fused, shape)
                op.Build()
                if not op.IsDone():
                    return None
                fused = op.Shape()
        except Exception:
            return None

        if _is_null_shape(fused):
            return None

        try:
            explorer = TopExp_Explorer(fused, TopAbs_SHELL)
            if explorer.More():
                outer_shell_shape = explorer.Current()
                return Topology.ByOcctShape(outer_shell_shape)
        except Exception:
            pass
        return Topology.ByOcctShape(fused)

    def InternalBoundaries(self, faces=None):
        result = self.NonManifoldFaces()
        if faces is not None:
            faces.extend(result)
            return 0
        return result

    def NonManifoldFaces(self, faces=None):
        """
        Returns Faces incident to two or more Cells.

        # BRepGraph Tranche 2: CellComplex.NonManifoldFaces
        On OCCT 8 this is an exact Face -> Solid incidence query over the
        CellComplex's cached BRepGraph.  The historical pairwise IsSame scan is
        retained as the authoritative fallback for older/disabled BRepGraph or
        for graph-import cases that cannot be answered safely.
        """
        native = _brepgraph_faces_by_cell_incidence(self, min_count=2, max_count=None)
        if native is not None:
            result = native
            if faces is not None:
                faces.extend(result)
                return 0
            return result

        # Legacy fallback: compare each Cell's unique Faces by native OCCT
        # topology identity.  This intentionally remains unchanged in meaning.
        per_cell = []
        for cell in self.Cells():
            seen = []
            for face in cell.Faces():
                shape = getattr(face, "shape", None)
                if _is_null_shape(shape):
                    continue
                if not any(_shape_same(shape, s) for s, _ in seen):
                    seen.append((shape, face))
            if seen:
                per_cell.append(seen)

        result = []
        used_shapes = []
        for i in range(len(per_cell)):
            for j in range(i + 1, len(per_cell)):
                for s_i, f_i in per_cell[i]:
                    for s_j, _f_j in per_cell[j]:
                        if _shape_same(s_i, s_j):
                            if not any(_shape_same(s_i, existing) for existing in used_shapes):
                                used_shapes.append(s_i)
                                result.append(f_i)
        if faces is not None:
            faces.extend(result)
            return 0
        return result


# ---------------------------------------------------------------------------
# Explicit unsupported CellComplex API
# ---------------------------------------------------------------------------
from .helpers import not_implemented as _not_implemented


def _cell_complex_not_implemented(name, return_value=None):
    def _method(*args, **kwargs):
        return _not_implemented(f"CellComplex.{name}", return_value)
    return _method


CellComplex.ByCellsCluster = staticmethod(
    lambda cluster, transferDictionaries=False, tolerance=0.0001, silent=False: (
        CellComplex.ByCells(
            (Topology.Cells(cluster) if isinstance(cluster, Cluster) else []),
            tolerance=tolerance,
        )
    )
)
# CellComplex.ExternalBoundary and CellComplex.NonManifoldFaces are implemented above.
