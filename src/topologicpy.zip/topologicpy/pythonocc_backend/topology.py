#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
PythonOCC backend Topology class.

This file is intended as a drop-in replacement for:

    pythonocc_backend/topology.py

It implements:
    - Topology.IsInstance
    - Topology.TypeAsString
    - Topology.Dictionary
    - Topology.SetDictionary
    - Topology.Vertices
    - Topology.Edges
    - Topology.Wires
    - Topology.Faces
    - Topology.Shells
    - Topology.ByOcctShape
    - Topology.Merge

The implementation is deliberately defensive. It works with the lightweight
Python backend wrapper classes already used in the smoke tests, while using
real PythonOCC/OCCT operations whenever an OCCT shape is available.
"""

from __future__ import annotations

# REVISION: 2026-08-15 Boolean parity fix 004

import copy
import math
import os
import tempfile
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional

from .helpers import new_uuid as _new_uuid, distance3, vertex_key

from .attribute_manager import AttributeManager
from ._csg_lineage import capture_modifier_if_active as _capture_modifier_only
from ._provenance import (
    transfer_by_history as _provenance_transfer_history,
    transfer_by_modifier as _provenance_transfer_modifier,
    root_dictionary as _provenance_root_dictionary,
    set_root_dictionary as _provenance_set_root_dictionary,
)
from ._brepgraph import (  # BRepGraph Tranche 1
    cached_index as _cached_brepgraph_index,
    shared_shapes as _brepgraph_shared_shapes,
)


# -----------------------------------------------------------------------------
# Optional PythonOCC imports
# -----------------------------------------------------------------------------

try:
    from OCC.Core.TopAbs import (
        TopAbs_VERTEX,
        TopAbs_EDGE,
        TopAbs_WIRE,
        TopAbs_FACE,
        TopAbs_SHELL,
        TopAbs_SOLID,
        TopAbs_COMPSOLID,
        TopAbs_COMPOUND,
    )
    from OCC.Core.TopExp import TopExp_Explorer
    from OCC.Core.TopoDS import TopoDS_Shape, topods
    # pythonocc-core 7.9.0 removed the deprecated topods_Vertex/topods_Edge/...
    # free functions entirely (they raise ImportError, not just a
    # DeprecationWarning as in 7.7.1) -- use the topods module-proxy form and
    # keep these names as aliases so every existing call site below is
    # unaffected. Do not revert to the free-function imports: a single
    # missing name here previously poisoned this entire try/except block,
    # silently nulling out ~40 unrelated OCC symbols (BRepBuilderAPI_Transform,
    # BOPAlgo_CellsBuilder, GProp_GProps, etc.) and breaking Translate/Rotate/
    # Scale/boolean ops/etc. across the whole backend.
    topods_Vertex = topods.Vertex
    topods_Edge = topods.Edge
    topods_Wire = topods.Wire
    topods_Face = topods.Face
    topods_Shell = topods.Shell
    topods_Solid = topods.Solid
    topods_Compound = topods.Compound
    from OCC.Core.TopTools import TopTools_ListOfShape, TopTools_ListIteratorOfListOfShape
    from OCC.Core.BOPAlgo import BOPAlgo_CellsBuilder, BOPAlgo_Splitter
    from OCC.Core.BRepCheck import BRepCheck_Analyzer
    from OCC.Core.ShapeFix import ShapeFix_Shape
    from OCC.Core.gp import gp_Trsf, gp_Pnt, gp_Dir, gp_Ax1, gp_Vec, gp_GTrsf, gp_Mat, gp_XYZ
    from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_Transform, BRepBuilderAPI_GTransform, BRepBuilderAPI_Copy
    from OCC.Core.GProp import GProp_GProps
    from OCC.Core.BRepGProp import brepgprop
    from OCC.Core.BRepAlgoAPI import (
        BRepAlgoAPI_Fuse,
        BRepAlgoAPI_Cut,
        BRepAlgoAPI_Common,
        BRepAlgoAPI_Section,
    )
    from OCC.Core.ShapeUpgrade import ShapeUpgrade_UnifySameDomain
    from OCC.Core.BRepExtrema import BRepExtrema_DistShapeShape
    from OCC.Core.BRepClass3d import BRepClass3d_SolidClassifier
    from OCC.Core.TopAbs import TopAbs_IN as _TopAbs_IN, TopAbs_ON as _TopAbs_ON
except Exception:  # pragma: no cover - allows import without PythonOCC
    TopAbs_VERTEX = TopAbs_EDGE = TopAbs_WIRE = TopAbs_FACE = None
    TopAbs_SHELL = TopAbs_SOLID = TopAbs_COMPSOLID = TopAbs_COMPOUND = None
    TopExp_Explorer = None
    TopoDS_Shape = None
    topods_Vertex = topods_Edge = topods_Wire = topods_Face = None
    topods_Shell = topods_Solid = topods_Compound = None
    TopTools_ListOfShape = None
    TopTools_ListIteratorOfListOfShape = None
    BOPAlgo_CellsBuilder = None
    BOPAlgo_Splitter = None
    BRepCheck_Analyzer = None
    ShapeFix_Shape = None
    gp_Trsf = gp_Pnt = gp_Dir = gp_Ax1 = gp_Vec = gp_GTrsf = gp_Mat = gp_XYZ = None
    BRepBuilderAPI_Transform = BRepBuilderAPI_GTransform = BRepBuilderAPI_Copy = None
    GProp_GProps = None
    brepgprop = None
    BRepAlgoAPI_Fuse = BRepAlgoAPI_Cut = BRepAlgoAPI_Common = BRepAlgoAPI_Section = None
    ShapeUpgrade_UnifySameDomain = None
    BRepExtrema_DistShapeShape = None
    BRepClass3d_SolidClassifier = None
    _TopAbs_IN = _TopAbs_ON = None


# -----------------------------------------------------------------------------
# Basic helpers
# -----------------------------------------------------------------------------

def _not_implemented(name: str):
    print(f"{name} - Not implemented.")
    return None


def _is_null_shape(shape: Any) -> bool:
    if shape is None:
        return True
    if hasattr(shape, "IsNull"):
        try:
            return bool(shape.IsNull())
        except Exception:
            return False
    return False


def _shape_from_topology(topology: Any) -> Any:
    if topology is None:
        return None

    if isinstance(topology, dict):
        return topology.get("shape", None)

    if hasattr(topology, "shape"):
        return getattr(topology, "shape")

    if hasattr(topology, "GetOcctShape"):
        try:
            return topology.GetOcctShape()
        except Exception:
            return None

    if TopoDS_Shape is not None and isinstance(topology, TopoDS_Shape):
        return topology

    return None


def _safe_list(value: Any) -> list:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def _topology_type_name(topology: Any) -> Optional[str]:
    if topology is None:
        return None

    # Graph is not an OCCT topology, but TopologicPy treats it as a recognised
    # object in IsInstance.
    if topology.__class__.__name__ == "Graph":
        return "Graph"

    name = topology.__class__.__name__
    known = {
        "Vertex",
        "Edge",
        "Wire",
        "Face",
        "Shell",
        "Cell",
        "CellComplex",
        "Cluster",
        "Aperture",
        "Context",
        "Graph",
    }
    if name in known:
        return name

    shape = _shape_from_topology(topology)
    if _is_null_shape(shape) or shape is None or not hasattr(shape, "ShapeType"):
        return None

    try:
        st = shape.ShapeType()
    except Exception:
        return None

    if st == TopAbs_VERTEX:
        return "Vertex"
    if st == TopAbs_EDGE:
        return "Edge"
    if st == TopAbs_WIRE:
        return "Wire"
    if st == TopAbs_FACE:
        return "Face"
    if st == TopAbs_SHELL:
        return "Shell"
    if st == TopAbs_SOLID:
        return "Cell"
    if st == TopAbs_COMPSOLID:
        return "CellComplex"
    if st == TopAbs_COMPOUND:
        return "Cluster"

    return None


# -----------------------------------------------------------------------------
# Numeric type IDs
# -----------------------------------------------------------------------------
#
# These mirror the values hardcoded in topologicpy.Topology.TypeID (see
# src/topologicpy/Topology.py) which in turn mirror topologic_core's bitmask
# type ids. Do not change these without also checking that file.

_TYPE_IDS = {
    "Vertex": 1,
    "Edge": 2,
    "Wire": 4,
    "Face": 8,
    "Shell": 16,
    "Cell": 32,
    "CellComplex": 64,
    "Cluster": 128,
    "Aperture": 256,
    "Context": 512,
    "Dictionary": 1024,
    "Graph": 2048,
    "Topology": 4096,
}

# Dimensional ordering (not the bit-flag type IDs above) used to decide
# whether a Vertices/Edges/Wires/Faces/Shells/Cells/CellComplexes call means
# "my own substructure" (target rank <= self rank) or "adjacency/host-scoped
# super-topology search" (target rank > self rank) -- see
# Topology._dispatch_subtopologies.
_TYPE_RANK = {
    "Vertex": 0,
    "Edge": 1,
    "Wire": 2,
    "Face": 3,
    "Shell": 4,
    "Cell": 5,
    "CellComplex": 6,
}


def _type_id_for(topology: Any) -> Optional[int]:
    """
    Resolve the numeric topologic_core-style type id for a topology/graph.

    Uses the same resolution logic as ``_topology_type_name`` (class-name first,
    OCCT ShapeType fallback), so CellComplex (TopAbs_COMPSOLID) is distinguished
    from Cell (TopAbs_SOLID) correctly.
    """
    name = _topology_type_name(topology)
    if name is None:
        return None
    return _TYPE_IDS.get(name)


def _is_topology_like(topology: Any) -> bool:
    t = _topology_type_name(topology)
    return t in {
        "Vertex",
        "Edge",
        "Wire",
        "Face",
        "Shell",
        "Cell",
        "CellComplex",
        "Cluster",
        "Aperture",
        "Context",
    }


def _make_toptools_list(shapes: Iterable[Any]) -> Any:
    if TopTools_ListOfShape is None:
        raise ImportError("PythonOCC TopTools_ListOfShape is not available.")

    result = TopTools_ListOfShape()
    for shape in shapes:
        if not _is_null_shape(shape):
            result.Append(shape)
    return result


def _toptools_list_to_pylist(toptools_list: Any) -> list:
    """
    TopTools_ListOfShape is not directly Python-iterable in this pythonocc
    build -- use the standard OCCT C++ iterator pattern instead.
    """
    if toptools_list is None or TopTools_ListIteratorOfListOfShape is None:
        return []
    result = []
    it = TopTools_ListIteratorOfListOfShape(toptools_list)
    while it.More():
        result.append(it.Value())
        it.Next()
    return result


def _iter_occ_subshapes(shape: Any, shape_type: Any) -> list:
    if _is_null_shape(shape) or TopExp_Explorer is None or shape_type is None:
        return []

    result = []
    explorer = TopExp_Explorer(shape, shape_type)
    while explorer.More():
        result.append(explorer.Current())
        explorer.Next()
    return result

def _iter_occ_subshapes_unique(shape: Any, shape_type: Any) -> list:
    """
    Returns the unique OCCT subshapes of the requested type.

    Uniqueness is determined using the Python hash of each TopoDS_Shape.
    This provides substantially better performance than repeatedly calling
    TopTools_MapOfShape from Python while preserving OCCT shape identity
    semantics for the topology traversal used by the backend.

    Parameters
    ----------
    shape : OCC.Core.TopoDS.TopoDS_Shape
        The input OCCT shape.
    shape_type : OCC.Core.TopAbs.TopAbs_ShapeEnum
        The requested OCCT subshape type.

    Returns
    -------
    list
        The unique OCCT subshapes.
    """
    if _is_null_shape(shape) or TopExp_Explorer is None or shape_type is None:
        return []

    result = []
    seen = set()

    try:
        explorer = TopExp_Explorer(
            shape,
            shape_type
        )

        while explorer.More():
            current = explorer.Current()

            key = hash(current)

            if key not in seen:
                seen.add(key)
                result.append(current)

            explorer.Next()

        return result

    except Exception:
        return []

def _downward_wrappers(topology: Any, shape_type: Any) -> list:
    """Return exact native descendant occurrences of the requested type.

    Public topology extraction must preserve the occurrence-specific OCCT
    orientation and location of each descendant relative to its host.

    BRepGraph stores topology primarily as definition nodes plus incidence
    references. ``Shapes().Shape(node)`` returns the definition shape and is
    therefore not sufficient for public descendant extraction: occurrence
    orientation (for example a REVERSED inner cavity Face of a hollow Cell)
    can be lost.

    TopExp_Explorer remains authoritative here because ``Current()`` returns
    the actual TopoDS occurrence as embedded in the host topology, including
    its accumulated Orientation() and Location().

    BRepGraph remains in use for identity/incidence queries, adjacency,
    shared-topology analysis, CellComplex incidence, CoEdge analysis and
    provenance.
    """
    shape = _shape_from_topology(topology)

    if _is_null_shape(shape):
        return []

    # IMPORTANT:
    # Do not substitute BRepGraph definition shapes here. Public descendant
    # extraction is occurrence-sensitive.
    subshapes = _iter_occ_subshapes_unique(
        shape,
        shape_type,
    )

    result = []

    for subshape in subshapes:
        try:
            item = Topology.ByOcctShape(
                subshape
            )
        except Exception:
            item = None

        if item is not None:
            result.append(item)

    return _deduplicate_by_identity(
        result
    )


def _brepgraph_adjacent_wrappers(topology: Any, hostTopology: Any, shape_type: Any):
    """Return same-dimensional adjacent wrappers using BRepGraph, or ``None``.

    ``None`` is deliberately distinct from an empty list: it means the graph
    path could not answer and the caller must execute its legacy implementation.
    """
    source_shape = _shape_from_topology(topology)
    host_shape = _shape_from_topology(hostTopology)
    if _is_null_shape(source_shape) or _is_null_shape(host_shape):
        return None
    try:
        index = _cached_brepgraph_index(hostTopology, host_shape)
        if index is None:
            return None
        shapes = index.adjacent_shapes(source_shape, shape_type)
    except Exception:
        return None
    if shapes is None:
        return None

    result = []
    for shape in shapes:
        try:
            item = Topology.ByOcctShape(shape)
        except Exception:
            item = None
        if item is not None:
            result.append(item)
    return _deduplicate_by_identity(result)


def _deduplicate_by_identity(items: list) -> list:
    """
    Two wrapper objects extracted from the same underlying OCCT (sub-)shape
    (e.g. two Vertex wrappers built from the shared endpoint of adjacent
    edges) get distinct Python identity and distinct `_uuid`s, but should
    still be treated as the same topological entity. Prefer OCCT shape
    identity (HashCode, consistent with IsSame) over `_uuid` for that reason.
    """
    seen = set()
    result = []
    for item in items:
        shape = getattr(item, "shape", None)
        key = None
        if shape is None and hasattr(item, "IsSame"):
            shape = item
        if shape is not None and not _is_null_shape(shape):
            try:
                key = ("shape", hash(shape))
            except Exception:
                key = None
        if key is None and hasattr(item, "_uuid"):
            key = ("uuid", getattr(item, "_uuid"))
        if key is None:
            key = ("id", id(item))
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def _copy_common_metadata(source: Any, target: Any) -> Any:
    if source is None or target is None:
        return target

    for attr in ("dictionary", "contents", "contexts", "apertures"):
        if hasattr(source, attr) and hasattr(target, attr):
            try:
                setattr(target, attr, getattr(source, attr))
            except Exception:
                pass

    return target


def _merge_backend_dictionaries(a: Any, b: Any) -> Any:
    """
    Merge Python dictionaries and backend dictionary-like objects.

    Later values override earlier values. This function intentionally returns a
    plain Python dict if it cannot construct a backend Dictionary safely.
    """
    def to_python_dict(d):
        if d is None:
            return {}
        if isinstance(d, dict):
            return dict(d)

        # Backend Dictionary used in the current smoke tests stores data in
        # .data and wraps primitive values in attribute classes.
        if hasattr(d, "data") and isinstance(getattr(d, "data"), dict):
            raw = getattr(d, "data")
            out = {}
            for k, v in raw.items():
                if hasattr(v, "Value"):
                    try:
                        out[k] = v.Value()
                        continue
                    except Exception:
                        pass
                if hasattr(v, "value"):
                    out[k] = getattr(v, "value")
                else:
                    out[k] = v
            return out

        if hasattr(d, "Keys") and hasattr(d, "ValueAtKey"):
            try:
                return {k: d.ValueAtKey(k) for k in d.Keys()}
            except Exception:
                return {}

        if hasattr(d, "keys") and hasattr(d, "__getitem__"):
            try:
                return {k: d[k] for k in d.keys()}
            except Exception:
                return {}

        return {}

    result = to_python_dict(a)
    result.update(to_python_dict(b))
    return result


def _transfer_contents(source: Any, target: Any) -> None:
    if source is None or target is None:
        return

    for attr in ("contents", "contexts", "apertures"):
        if hasattr(source, attr) and hasattr(target, attr):
            try:
                current = _safe_list(getattr(target, attr))
                incoming = _safe_list(getattr(source, attr))
                setattr(target, attr, _deduplicate_by_identity(current + incoming))
            except Exception:
                pass


def _postprocess_boolean_result(shape: Any) -> Any:
    """
    Validates and, if necessary, repairs the result of an OCCT boolean operation.

    Parameters
    ----------
    shape : OCC.Core.TopoDS.TopoDS_Shape
        The input OCCT shape.

    Returns
    -------
    OCC.Core.TopoDS.TopoDS_Shape
        The original shape if valid, otherwise the repaired shape if repair
        succeeds.
    """
    if _is_null_shape(shape):
        return shape

    # ------------------------------------------------------------------
    # Fast path: if the boolean result is already valid, return it
    # without running ShapeFix.
    # ------------------------------------------------------------------
    if BRepCheck_Analyzer is not None:
        try:
            analyzer = BRepCheck_Analyzer(
                shape,
                True,   # Geometric controls
                True,   # Run in parallel
            )

            if analyzer.IsValid():
                return shape

        except Exception:
            pass

    # ------------------------------------------------------------------
    # Repair only if validation failed or could not be performed.
    # ------------------------------------------------------------------
    if ShapeFix_Shape is None:
        return shape

    try:
        fixer = ShapeFix_Shape(shape)
        fixer.Perform()

        fixed_shape = fixer.Shape()

        if not _is_null_shape(fixed_shape):
            return fixed_shape

    except Exception:
        pass

    return shape



def _lineage_capture_active() -> bool:
    # True when exact lineage is requested by CSG or public Provenance.
    try:
        from ._csg_lineage import is_active
        return bool(is_active())
    except Exception:
        return False


def _unify_same_domain(shape: Any) -> Any:
    """
    ShapeUpgrade_UnifySameDomain for Merge/Union only.

    # BRepGraph Tranche 3: provenance-aware same-domain unification
    If the incoming result already carries shape-keyed dictionaries, compose
    the unifier's exact BRepTools_History so metadata follows the final native
    Faces/Edges/Solids instead of stopping at the pre-unified Boolean result.
    """
    if _is_null_shape(shape) or ShapeUpgrade_UnifySameDomain is None:
        return shape
    if not _iter_occ_subshapes(shape, TopAbs_SOLID):
        return shape
    try:
        unifier = ShapeUpgrade_UnifySameDomain(shape, True, True, True)
        unifier.Build()
        unified = unifier.Shape()
        if not _is_null_shape(unified):
            try:
                manager = AttributeManager.GetInstance()
                root_dictionary = manager.GetDictionary(shape) if manager.HasDictionary(shape) else None
                _provenance_transfer_history(
                    unified,
                    unifier.History(),
                    [("source", shape, root_dictionary)],
                    root_policy="source",
                    operation="UnifySameDomain",
                )
            except Exception:
                pass
            return unified
    except Exception:
        pass
    return shape


def _solids_share_face(solids: list) -> bool:
    """
    True when the Solids connect via shared FACE boundaries (not only an edge/
    vertex), i.e. one block to promote to COMPSOLID. Adjacency graph on faces
    via TopoDS_Shape.IsSame (robust in this build), then a fully-connected
    check.
    """
    if not solids or len(solids) < 2:
        return False

    from OCC.Core.TopExp import TopExp_Explorer
    from OCC.Core.TopAbs import TopAbs_FACE

    def _faces(solid):
        out = []
        exp = TopExp_Explorer(solid, TopAbs_FACE)
        while exp.More():
            out.append(exp.Current())
            exp.Next()
        return out

    face_sets = [_faces(s) for s in solids]
    if any(len(fs) == 0 for fs in face_sets):
        # Can't reliably determine connectivity; be conservative and refuse.
        return False

    n = len(solids)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for i in range(n):
        for j in range(i + 1, n):
            shared = False
            for fa in face_sets[i]:
                for fb in face_sets[j]:
                    if fa.IsSame(fb):
                        shared = True
                        break
                if shared:
                    break
            if shared:
                union(i, j)

    roots = {find(k) for k in range(n)}
    return len(roots) == 1


def _promote_to_compsolid_if_multi_solid(shape: Any, force: bool = False) -> Any:
    """
    MakeContainers yields a COMPOUND (not COMPSOLID) even for face-sharing solids, so
    rebuild 2+ connected Solids as a CompSolid so ByOcctShape wraps them as a CellComplex.
    force=True (Slice/Imprint/Divide) promotes unconditionally; False (Merge/Impose) only
    when the solids share a face.
    """
    if _is_null_shape(shape):
        return shape
    try:
        if shape.ShapeType() == TopAbs_COMPSOLID:
            return shape
    except Exception:
        return shape

    solids = _iter_occ_subshapes(shape, TopAbs_SOLID)
    if len(solids) < 2:
        return shape

    if not force and not _solids_share_face(solids):
        return shape

    try:
        from OCC.Core.BRep import BRep_Builder
        from OCC.Core.TopoDS import TopoDS_CompSolid, topods
        builder = BRep_Builder()
        compsolid = TopoDS_CompSolid()
        builder.MakeCompSolid(compsolid)
        for solid in solids:
            builder.Add(compsolid, topods.Solid(solid))
        return compsolid
    except Exception:
        return shape


def _collect_boolean_operand_shapes(topology: Any) -> list:
    """
    Collect OCCT shapes to use as boolean operands.

    For wrapper objects that have a valid .shape, use the shape directly.
    For aggregate wrappers with no single shape, collect their component shapes.
    """
    if topology is None:
        return []

    shape = _shape_from_topology(topology)
    if not _is_null_shape(shape):
        return [shape]

    result = []

    # Shell wrapper
    if hasattr(topology, "faces"):
        for face in _safe_list(getattr(topology, "faces")):
            f_shape = _shape_from_topology(face)
            if not _is_null_shape(f_shape):
                result.append(f_shape)

    # Cell wrapper
    if hasattr(topology, "shells"):
        for shell in _safe_list(getattr(topology, "shells")):
            result.extend(_collect_boolean_operand_shapes(shell))

    # CellComplex / Cluster style wrappers
    for attr in ("cells", "topologies", "members"):
        if hasattr(topology, attr):
            for child in _safe_list(getattr(topology, attr)):
                result.extend(_collect_boolean_operand_shapes(child))

    return _deduplicate_by_identity(result)


def _wrap_shape_as_topology(shape: Any, dictionary=None, contents=None, contexts=None, apertures=None) -> Any:
    """
    Convert an OCCT shape into the appropriate local backend wrapper object.
    """
    if _is_null_shape(shape):
        return None

    try:
        shape_type = shape.ShapeType()
    except Exception:
        return None

    if shape_type == TopAbs_VERTEX:
        from .vertex import Vertex
        try:
            return Vertex.ByOcctShape(
                topods_Vertex(shape),
                dictionary=dictionary,
                contents=contents,
                contexts=contexts,
                apertures=apertures,
            )
        except Exception:
            return Vertex(shape=topods_Vertex(shape), dictionary=dictionary or {}, contents=contents or [], contexts=contexts or [], apertures=apertures or [])

    if shape_type == TopAbs_EDGE:
        from .edge import Edge
        try:
            return Edge.ByOcctShape(
                topods_Edge(shape),
                dictionary=dictionary,
                contents=contents,
                contexts=contexts,
                apertures=apertures,
            )
        except Exception:
            return Edge(shape=topods_Edge(shape), dictionary=dictionary or {}, contents=contents or [], contexts=contexts or [], apertures=apertures or [])

    if shape_type == TopAbs_WIRE:
        from .wire import Wire
        try:
            return Wire.ByOcctShape(
                topods_Wire(shape),
                dictionary=dictionary,
                contents=contents,
                contexts=contexts,
                apertures=apertures,
            )
        except Exception:
            # Fallback: build a Wire from its edges.
            edges = [Topology.ByOcctShape(s) for s in _iter_occ_subshapes(shape, TopAbs_EDGE)]
            try:
                return Wire.ByEdges(edges)
            except Exception:
                return Wire(shape=topods_Wire(shape), edges=edges, dictionary=dictionary or {}, contents=contents or [], contexts=contexts or [], apertures=apertures or [])

    if shape_type == TopAbs_FACE:
        from .face import Face
        try:
            return Face.ByOcctShape(
                topods_Face(shape),
                dictionary=dictionary,
                contents=contents,
                contexts=contexts,
                apertures=apertures,
            )
        except Exception:
            try:
                from .wire import Wire
                wires = [Topology.ByOcctShape(s) for s in _iter_occ_subshapes(shape, TopAbs_WIRE)]
                external = wires[0] if wires else None
                internals = wires[1:] if len(wires) > 1 else []
                return Face(shape=topods_Face(shape), external=external, internals=internals, dictionary=dictionary or {}, contents=contents or [], contexts=contexts or [], apertures=apertures or [])
            except Exception:
                return None

    if shape_type == TopAbs_SHELL:
        from .shell import Shell
        faces = [Topology.ByOcctShape(s) for s in _iter_occ_subshapes(shape, TopAbs_FACE)]
        faces = [f for f in faces if f is not None]
        try:
            sh = Shell.ByFaces(faces)
            if sh is not None:
                sh.shape = topods_Shell(shape)
                sh.dictionary = dictionary or {}
                sh.contents = contents or []
                sh.contexts = contexts or []
                sh.apertures = apertures or []
                return sh
        except Exception:
            pass
        return Shell(shape=topods_Shell(shape), faces=faces, dictionary=dictionary or {}, contents=contents or [], contexts=contexts or [], apertures=apertures or [])

    if shape_type in (TopAbs_SOLID, TopAbs_COMPSOLID):
        # Keep validation and invalid-solid recovery in one entry point.
        return Topology.ByOcctShape(shape, dictionary=dictionary,
                                    contents=contents, contexts=contexts,
                                    apertures=apertures)

    if shape_type == TopAbs_COMPOUND:
        # Prefer Cluster as the safest aggregate wrapper for a heterogeneous
        # compound of mixed sub-shape types.
        try:
            from .cluster import Cluster
            from OCC.Core.TopoDS import TopoDS_Iterator
            # Walk DIRECT children only (TopoDS_Iterator), not every
            # sub-shape of every type anywhere in the tree
            # (_iter_occ_subshapes/TopExp_Explorer): a COMPOUND wrapping one
            # COMPSOLID wrapping one SOLID would otherwise be matched once
            # as a COMPSOLID and again as that same nested SOLID, double
            # counting it and defeating the single-child unwrap below.
            children = []
            native_children_changed = False
            it = TopoDS_Iterator(shape)
            while it.More():
                original_child = it.Value()
                child = Topology.ByOcctShape(original_child)
                if child is None:
                    return None
                children.append(child)
                native_child = _shape_from_topology(child)
                if not _is_null_shape(native_child) and not native_child.IsSame(original_child):
                    native_children_changed = True
                it.Next()
            if len(children) == 1:
                # OCCT boolean ops (BRepAlgoAPI_Fuse/Cut/Common/...) always
                # wrap their result in a COMPOUND container even when it is
                # a single piece -- e.g. two fully-overlapping/flush-touching
                # solids fuse into one Solid, but Shape() still hands back a
                # 1-child COMPOUND around it. Unwrap to that single child's
                # own type directly (matching topologic_core's own behavior:
                # a Union of two touching boxes is a plain Cell, not a
                # 1-member Cluster) instead of always forcing a Cluster.
                only = children[0]
                only.dictionary = dictionary or {}
                if contents:
                    only.contents = list(contents)
                if contexts:
                    only.contexts = list(contexts)
                if apertures:
                    only.apertures = list(apertures)
                return only
            if children and all(Topology.IsInstance(c, "Face") for c in children):
                # Multiple coplanar/adjacent Faces (e.g. Merge of two Faces
                # that only partially overlap) form a Shell, not a Cluster
                # -- verified against topologic_core: merging a
                # rectangle-with-a-hole with a second rectangle that only
                # partially covers the hole gives a Shell of Faces.
                from .shell import Shell
                sh = Shell.ByFaces(children)
                if sh is not None:
                    sh.dictionary = dictionary or {}
                    if contents:
                        sh.contents = list(contents)
                    if contexts:
                        sh.contexts = list(contexts)
                    if apertures:
                        sh.apertures = list(apertures)
                    return sh
            if children and len(children) >= 2 and all(Topology.IsInstance(c, "Edge") for c in children):
                # A connected collection of Edges is a Topologic Wire even when
                # it is non-manifold (branch vertices may have degree > 2).
                #
                # The PythonOCC Wire.ByEdges implementation now supports such
                # connected branching networks by using OCCT's batch MakeWire
                # path when a single head-to-tail ordering does not exist.
                # Therefore the old "degree <= 2" restriction is no longer
                # correct here.
                #
                # Only promote when every input Edge belongs to one connected
                # component. A genuinely disjoint edge set remains a Cluster.
                from .wire import Wire
                from .helpers import same_vertex

                n = len(children)
                parent = list(range(n))

                def _find(x):
                    while parent[x] != x:
                        parent[x] = parent[parent[x]]
                        x = parent[x]
                    return x

                for i in range(n):
                    for j in range(i + 1, n):
                        ei, ej = children[i], children[j]

                        if (
                            same_vertex(ei.start, ej.start)
                            or same_vertex(ei.start, ej.end)
                            or same_vertex(ei.end, ej.start)
                            or same_vertex(ei.end, ej.end)
                        ):
                            ra = _find(i)
                            rb = _find(j)

                            if ra != rb:
                                parent[ra] = rb

                if len({_find(i) for i in range(n)}) == 1:
                    w = Wire.ByEdges(children)

                    # Never accept a partial reconstruction. This guards
                    # against any OCCT MakeWire result that silently omits
                    # one or more supplied Edges.
                    if (
                        w is not None
                        and len(getattr(w, "edges", None) or []) == n
                    ):
                        w.dictionary = dictionary or {}

                        if contents:
                            w.contents = list(contents)

                        if contexts:
                            w.contexts = list(contexts)

                        if apertures:
                            w.apertures = list(apertures)

                        return w
            if native_children_changed:
                shape = _compound_of_shapes([_ensure_compound_shape(c) for c in children])
            if hasattr(Cluster, "ByTopologies"):
                cl = Cluster.ByTopologies(children)
                if cl is not None:
                    cl.shape = shape
                    cl.dictionary = dictionary or {}
                    return cl
            return Cluster(shape=shape, topologies=children, dictionary=dictionary or {}, contents=contents or [], contexts=contexts or [], apertures=apertures or [])
        except Exception:
            return None

    return None


def _compound_of_shapes(shapes: Iterable[Any]) -> Any:
    from OCC.Core.BRep import BRep_Builder
    from OCC.Core.TopoDS import TopoDS_Compound
    builder = BRep_Builder()
    compound = TopoDS_Compound()
    builder.MakeCompound(compound)
    for shape in shapes:
        if not _is_null_shape(shape):
            builder.Add(compound, shape)
    return compound

class _SelectedSplitHistory:
    """Combine immutable split images with final selection history by identity."""
    def __init__(self, split_history, shapes):
        from ._csg_lineage import _source_entities
        from ._provenance import _toptools_to_list
        self.entries = []
        for shape in shapes:
            for source in _source_entities(shape):
                if source.ShapeType() not in (TopAbs_VERTEX, TopAbs_EDGE, TopAbs_FACE):
                    continue
                self.entries.append((source,
                    list(_toptools_to_list(split_history.Modified(source))),
                    list(_toptools_to_list(split_history.Generated(source)))))
        self.final_history = None
        self.index = None

    def finish(self, final_history, result_shape):
        from ._provenance import _ResultShapeIndex
        self.final_history = final_history
        self.index = _ResultShapeIndex(result_shape)
        return self

    def _images(self, source, name, column):
        from ._provenance import _toptools_to_list
        candidates = list(_toptools_to_list(getattr(self.final_history, name)(source)))
        for old, modified, generated in self.entries:
            if old.IsSame(source):
                candidates.extend((modified, generated)[column])
        answer = []
        for candidate in candidates:
            target = self.index.resolve(candidate)
            if target is not None and not any(target.IsSame(old) for old in answer):
                answer.append(target)
        return answer

    def Modified(self, source):
        return self._images(source, "Modified", 0)

    def Generated(self, source):
        return self._images(source, "Generated", 1)

    def IsRemoved(self, source):
        if self.index.resolve(source) is not None or self.Modified(source) or self.Generated(source):
            return False
        return bool(self.final_history.IsRemoved(source))


def _make_occ_merge(topology: Any, other_topology: Any = None, transfer_dictionary: bool = False, tolerance: float = 0.0001) -> Any:
    """
    PythonOCC Topology.Merge using BOPAlgo_CellsBuilder while preserving the
    operands' shared interfaces.

    # BRepGraph Tranche 3: exact dictionary provenance
    The CellsBuilder's BRepTools_History supplies subtopology lineage.  The
    result root uses an explicit first-source-wins merge policy rather than
    accidental ``dict.update`` ordering.
    """
    if topology is None:
        return None

    base_shape = _ensure_compound_shape(topology)
    if _is_null_shape(base_shape):
        return None

    if other_topology is None:
        return Topology.ByOcctShape(
            base_shape,
            dictionary=Topology.Dictionary(topology),
            contents=getattr(topology, "contents", []),
            contexts=getattr(topology, "contexts", []),
            apertures=getattr(topology, "apertures", []),
        )

    shapes_a = _collect_boolean_operand_shapes(topology)
    shapes_b = _collect_boolean_operand_shapes(other_topology)
    if not shapes_a or not shapes_b:
        print("Topology.Merge - Error: Could not collect valid OCCT operands. Returning None.")
        return None
    if BOPAlgo_CellsBuilder is None:
        print("Topology.Merge - Error: PythonOCC BOPAlgo_CellsBuilder is not available. Returning None.")
        return None

    try:
        builder = BOPAlgo_CellsBuilder()
        try:
            builder.SetToFillHistory(True)
        except Exception:
            pass
        for shape in shapes_a:
            builder.AddArgument(shape)
        for shape in shapes_b:
            builder.AddArgument(shape)
        builder.SetFuzzyValue(tolerance)
        builder.Perform()
        if hasattr(builder, "HasErrors") and builder.HasErrors():
            print("Topology.Merge - Error: BOPAlgo_CellsBuilder failed. Returning None.")
            return None
        builder.AddAllToResult()
        result_shape = builder.Shape()
        history = builder.History() if (transfer_dictionary or _lineage_capture_active()) else None
    except Exception:
        print("Topology.Merge - Error: BOPAlgo_CellsBuilder raised. Returning None.")
        return None

    if _is_null_shape(result_shape):
        print("Topology.Merge - Error: Boolean result is null. Returning None.")
        return None

    source_shape_a = shapes_a[0] if len(shapes_a) == 1 else _compound_of_shapes(shapes_a)
    source_shape_b = shapes_b[0] if len(shapes_b) == 1 else _compound_of_shapes(shapes_b)
    sources = [
        {
            "role": "self",
            "shape": source_shape_a,
            "dictionary": None,
            "root_dictionary": Topology.Dictionary(topology),
        },
        {
            "role": "other",
            "shape": source_shape_b,
            "dictionary": None,
            "root_dictionary": Topology.Dictionary(other_topology),
        },
    ]
    if transfer_dictionary or _lineage_capture_active():
        try:
            _provenance_transfer_history(
                result_shape,
                history,
                sources,
                root_policy="merge",
                operation="Merge",
            )
        except Exception:
            pass

    result_shape = _postprocess_boolean_result(result_shape)
    result_shape = _unify_same_domain(result_shape)
    result_shape = _promote_to_compsolid_if_multi_solid(result_shape)

    result_dictionary = {}
    if transfer_dictionary:
        result_dictionary = _provenance_root_dictionary(sources, policy="merge")[0]
        _provenance_set_root_dictionary(result_shape, sources, policy="merge")

    result = Topology.ByOcctShape(
        result_shape,
        dictionary=result_dictionary,
        contents=[],
        contexts=[],
        apertures=[],
    )
    if result is None:
        print("Topology.Merge - Error: Could not convert OCCT result to backend topology. Returning None.")
        return None

    _transfer_contents(topology, result)
    _transfer_contents(other_topology, result)
    return result


def _make_occ_union(
    topology: Any,
    other_topology: Any = None,
    transfer_dictionary: bool = False,
    tolerance: float = 0.0001
) -> Any:
    """
    Returns the union of the input topologies using the PythonOCC backend.

    The OCCT Fuse operation is used as the primary Boolean operation.
    Backend-specific semantic normalization is then applied only where
    necessary to preserve Topologic topology semantics.

    In particular:

    - Overlapping or touching solids are fused normally.
    - Disjoint solids remain separate and are wrapped according to the
      resulting OCCT topology.
    - Overlapping coplanar Face/Face unions are unified into a single
      same-domain Face while preserving boundary edge segmentation.
    - Connected Wire/Wire unions are promoted to a Topologic Wire when
      all resulting edges can be retained without loss.

    Parameters
    ----------
    topology : Any
        The first input topology.
    other_topology : Any , optional
        The second input topology. Default is None.
    transfer_dictionary : bool , optional
        If True, the dictionaries of the input topologies are merged and
        assigned to the result. Default is False.

    Returns
    -------
    Any
        The resultant topology, or None if the operation fails.
    """
    if topology is None:
        return None

    base_shape = _ensure_compound_shape(
        topology
    )

    if _is_null_shape(base_shape):
        return None

    # ------------------------------------------------------------------
    # No second operand
    # ------------------------------------------------------------------

    if other_topology is None:
        return Topology.ByOcctShape(
            base_shape,
            dictionary=Topology.Dictionary(
                topology
            ),
            contents=getattr(
                topology,
                "contents",
                []
            ),
            contexts=getattr(
                topology,
                "contexts",
                []
            ),
            apertures=getattr(
                topology,
                "apertures",
                []
            ),
        )

    # ------------------------------------------------------------------
    # Collect OCCT operand shapes
    # ------------------------------------------------------------------

    shapes_a = _collect_boolean_operand_shapes(
        topology
    )

    shapes_b = _collect_boolean_operand_shapes(
        other_topology
    )

    if not shapes_a or not shapes_b:
        print(
            "Topology.Union - Error: Could not collect valid OCCT "
            "operands. Returning None."
        )
        return None

    if BRepAlgoAPI_Fuse is None:
        print(
            "Topology.Union - Error: PythonOCC BRepAlgoAPI_Fuse is "
            "not available. Returning None."
        )
        return None

    # ------------------------------------------------------------------
    # OCCT Fuse
    # ------------------------------------------------------------------

    try:
        if len(shapes_a) == 1:
            shape_a = shapes_a[0]
        else:
            shape_a = _compound_of_shapes(
                shapes_a
            )

        if len(shapes_b) == 1:
            shape_b = shapes_b[0]
        else:
            shape_b = _compound_of_shapes(
                shapes_b
            )

        fuse = BRepAlgoAPI_Fuse(
            shape_a,
            shape_b
        )

        try:
            fuse.SetToFillHistory(True)
        except Exception:
            pass

        fuse.SetFuzzyValue(tolerance)
        fuse.Build()

        if not fuse.IsDone():
            print(
                "Topology.Union - Error: BRepAlgoAPI_Fuse failed. "
                "Returning None."
            )
            return None

        result_shape = fuse.Shape()
        fuse_history = fuse.History() if (transfer_dictionary or _lineage_capture_active()) else None

    except Exception:
        print(
            "Topology.Union - Error: BRepAlgoAPI_Fuse raised. "
            "Returning None."
        )
        return None

    if _is_null_shape(result_shape):
        print(
            "Topology.Union - Error: Boolean result is null. "
            "Returning None."
        )
        return None

    # BRepGraph Tranche 3: Topology.Union provenance
    provenance_sources = [
        {
            "role": "self",
            "shape": shape_a,
            "dictionary": None,
            "root_dictionary": Topology.Dictionary(topology),
        },
        {
            "role": "other",
            "shape": shape_b,
            "dictionary": None,
            "root_dictionary": Topology.Dictionary(other_topology),
        },
    ]
    if transfer_dictionary or _lineage_capture_active():
        try:
            _provenance_transfer_history(
                result_shape,
                fuse_history,
                provenance_sources,
                root_policy="merge",
                operation="Union",
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Face / Face semantic normalization
    #
    # OCCT Fuse preserves the Boolean partition when two coplanar Faces
    # overlap. For example, two overlapping rectangles may be returned as
    # three adjacent Faces contained in a Shell/Compound:
    #
    #     A-only | overlap | B-only
    #
    # Topologic Union semantics require these same-domain regions to form
    # one Face.
    #
    # Unify Faces only. Do NOT unify boundary Edges: their segmentation is
    # valid topology and must be preserved. In the Boolean regression case
    # this converts:
    #
    #     Shell: 3 Faces / 10 Edges / 8 Vertices
    #
    # into:
    #
    #     Face: 1 Face / 8 Edges / 8 Vertices
    #
    # This normalization is deliberately restricted to Face/Face operands.
    # Applying same-domain unification generally to solid results can erase
    # valid Boolean partitions and alter expected topology counts.
    # ------------------------------------------------------------------

    try:
        from .face import Face

        if (
            isinstance(topology, Face)
            and isinstance(other_topology, Face)
            and ShapeUpgrade_UnifySameDomain is not None
        ):
            result_faces = _iter_occ_subshapes_unique(
                result_shape,
                TopAbs_FACE
            )

            if len(result_faces) > 1:
                unifier = ShapeUpgrade_UnifySameDomain(
                    result_shape,
                    False,  # UnifyEdges
                    True,   # UnifyFaces
                    False   # ConcatBSplines
                )

                unifier.Build()

                unified_shape = unifier.Shape()

                if not _is_null_shape(unified_shape):
                    try:
                        manager = AttributeManager.GetInstance()
                        root_dictionary = (
                            manager.GetDictionary(result_shape)
                            if manager.HasDictionary(result_shape)
                            else None
                        )
                        _provenance_transfer_history(
                            unified_shape,
                            unifier.History(),
                            [("source", result_shape, root_dictionary)],
                            root_policy="source",
                            operation="Union.UnifySameDomain",
                        )
                    except Exception:
                        pass
                    result_shape = unified_shape

    except Exception:
        pass

    # ------------------------------------------------------------------
    # Pure 1-D same-domain normalization
    #
    # Do NOT apply general same-domain unification to solid or face
    # results. BRepAlgoAPI_Fuse already gives the desired partitioning
    # there, apart from the explicitly handled Face/Face case above.
    #
    # Pure Edge/Wire operands are different. Fusing two overlapping
    # collinear Edges can leave several split segments instead of the
    # single logical Edge expected by Topologic. Therefore same-domain
    # unification is permitted for purely 1-D results.
    # ------------------------------------------------------------------

    if (
        ShapeUpgrade_UnifySameDomain is not None
        and not _iter_occ_subshapes(
            result_shape,
            TopAbs_SOLID
        )
        and not _iter_occ_subshapes(
            result_shape,
            TopAbs_FACE
        )
    ):
        try:
            unifier = ShapeUpgrade_UnifySameDomain(
                result_shape,
                True,
                True,
                True
            )

            unifier.Build()

            unified_shape = unifier.Shape()

            if not _is_null_shape(unified_shape):
                try:
                    manager = AttributeManager.GetInstance()
                    root_dictionary = (
                        manager.GetDictionary(result_shape)
                        if manager.HasDictionary(result_shape)
                        else None
                    )
                    _provenance_transfer_history(
                        unified_shape,
                        unifier.History(),
                        [("source", result_shape, root_dictionary)],
                        root_policy="source",
                        operation="Union.UnifySameDomain",
                    )
                except Exception:
                    pass
                result_shape = unified_shape

        except Exception:
            pass

    # ------------------------------------------------------------------
    # General Boolean post-processing
    # ------------------------------------------------------------------

    result_shape = _postprocess_boolean_result(
        result_shape
    )

    # ------------------------------------------------------------------
    # Result dictionary
    # ------------------------------------------------------------------

    result_dictionary = {}

    if transfer_dictionary:
        result_dictionary = _provenance_root_dictionary(
            provenance_sources,
            policy="merge",
        )[0]
        _provenance_set_root_dictionary(
            result_shape,
            provenance_sources,
            policy="merge",
        )

    # ------------------------------------------------------------------
    # Wire / Wire semantic normalization
    #
    # A connected branching one-dimensional Fuse result may be stored by
    # OCCT in a Compound even though it represents one valid Topologic
    # non-manifold Wire.
    #
    # Build the Wire directly from the unique resulting OCCT Edges. Accept
    # the promotion only if every Edge survives, so genuinely disconnected
    # results remain aggregates.
    # ------------------------------------------------------------------

    from .wire import Wire

    if (
        isinstance(topology, Wire)
        and isinstance(other_topology, Wire)
    ):
        edge_shapes = _iter_occ_subshapes_unique(
            result_shape,
            TopAbs_EDGE
        )

        edges = [
            Topology.ByOcctShape(
                edge_shape
            )
            for edge_shape in edge_shapes
        ]

        edges = [
            edge
            for edge in edges
            if edge is not None
        ]

        if (
            edges
            and len(edges) == len(edge_shapes)
        ):
            wire_result = Wire.ByEdges(
                edges
            )

            if (
                wire_result is not None
                and len(
                    wire_result.Edges() or []
                ) == len(edges)
            ):
                wire_result.SetDictionary(result_dictionary)

                _transfer_contents(
                    topology,
                    wire_result
                )

                _transfer_contents(
                    other_topology,
                    wire_result
                )

                return wire_result

    # ------------------------------------------------------------------
    # Generic result wrapping
    # ------------------------------------------------------------------

    result = Topology.ByOcctShape(
        result_shape,
        dictionary=result_dictionary,
        contents=[],
        contexts=[],
        apertures=[],
    )

    if result is None:
        print(
            "Topology.Union - Error: Could not convert OCCT result to "
            "backend topology. Returning None."
        )
        return None

    # ------------------------------------------------------------------
    # Contents
    # ------------------------------------------------------------------

    _transfer_contents(
        topology,
        result
    )

    _transfer_contents(
        other_topology,
        result
    )

    return result

# BREP / string serialization helpers
# -----------------------------------------------------------------------------
#
# PythonOCC does not expose a stable, version-independent in-memory string BREP
# API across releases (older builds expose free functions such as
# ``breptools_Write``/``breptools_Read``; newer builds expose them as static
# methods ``BRepTools.Write_s``/``BRepTools.Read_s``). We defensively support
# both, round-tripping through a short-lived temp file since that is the one
# entry point guaranteed to exist in every PythonOCC generation.


def _ensure_compound_shape(topology: Any, _active=None) -> Any:
    """
    Return a valid OCCT shape for a wrapper, building a compound for shapeless
    aggregates (a Cluster constructed via ByTopologies keeps shape=None).
    The compound is temporary: member wrappers and dictionaries are retained.
    A missing member shape or a cyclic aggregate fails the whole operation;
    returning a partial compound would silently discard input geometry.
    """
    shape = _shape_from_topology(topology)
    if not _is_null_shape(shape):
        return shape
    members = getattr(topology, "topologies", None)
    if not members:
        return None
    active = set() if _active is None else _active
    key = id(topology)
    if key in active:
        return None
    active.add(key)
    try:
        member_shapes = []
        for member in members:
            member_shape = _ensure_compound_shape(member, active)
            if _is_null_shape(member_shape):
                return None
            member_shapes.append(member_shape)
        from OCC.Core.TopoDS import TopoDS_Compound
        from OCC.Core.BRep import BRep_Builder
        builder = BRep_Builder()
        compound = TopoDS_Compound()
        builder.MakeCompound(compound)
        for s_ in member_shapes:
            builder.Add(compound, s_)
        return compound
    except Exception:
        return None
    finally:
        active.remove(key)


def _shape_to_brep_text(shape: Any) -> Optional[str]:
    if _is_null_shape(shape):
        return None

    try:
        import OCC.Core.BRepTools as _breptools_module
    except Exception:
        return None

    tmp_path = None
    try:
        fd, tmp_path = tempfile.mkstemp(suffix=".brep")
        os.close(fd)

        wrote = False
        wrote = False
        if hasattr(_breptools_module, "breptools") and hasattr(_breptools_module.breptools, "Write"):
            _breptools_module.breptools.Write(shape, tmp_path)
            wrote = True
        elif hasattr(_breptools_module, "breptools_Write"):
            _breptools_module.breptools_Write(shape, tmp_path)
            wrote = True
        if not wrote:
            return None

        with open(tmp_path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.read()
    except Exception:
        return None
    finally:
        if tmp_path is not None:
            try:
                os.remove(tmp_path)
            except Exception:
                pass


def _shape_from_brep_text(text: Any) -> Any:
    if not isinstance(text, str) or not text:
        return None

    try:
        import OCC.Core.BRepTools as _breptools_module
        from OCC.Core.TopoDS import TopoDS_Shape
        from OCC.Core.BRep import BRep_Builder
    except Exception:
        return None

    tmp_path = None
    try:
        fd, tmp_path = tempfile.mkstemp(suffix=".brep")
        os.close(fd)
        with open(tmp_path, "w", encoding="utf-8") as handle:
            handle.write(text)

        shape = TopoDS_Shape()
        builder = BRep_Builder()

        read_ok = None
        if hasattr(_breptools_module, "breptools") and hasattr(_breptools_module.breptools, "Read"):
            read_ok = _breptools_module.breptools.Read(shape, tmp_path, builder)
        elif hasattr(_breptools_module, "breptools_Read"):
            read_ok = _breptools_module.breptools_Read(shape, tmp_path, builder)

        if read_ok is False or _is_null_shape(shape):
            return None

        return shape
    except Exception:
        return None
    finally:
        if tmp_path is not None:
            try:
                os.remove(tmp_path)
            except Exception:
                pass


# -----------------------------------------------------------------------------
# Public Topology class
# -----------------------------------------------------------------------------

@dataclass(eq=False)
class Topology:
    # Base fields inherited by every wrapper subclass (Vertex, Edge, Wire,
    # Face, Shell, Cell, CellComplex, Cluster, Aperture, Context). These were
    # previously missing entirely, which meant every subclass constructor call
    # such as ``Vertex(shape=..., dictionary=..., contents=..., contexts=...,
    # apertures=...)`` raised "unexpected keyword argument" and no topology
    # object of any kind could be built. Shell and Cell define their own
    # __init__ (which dataclass leaves untouched) and forward to this one via
    # super().__init__(...).
    shape: Any = None
    dictionary: Any = None
    contents: list = field(default_factory=list)
    contexts: list = field(default_factory=list)
    apertures: list = field(default_factory=list)
    _uuid: str = field(default_factory=_new_uuid)

    def __hash__(self) -> int:
        return hash(self._uuid)

    def Type(self) -> Optional[int]:
        """
        Return the numeric topologic_core-style type id. A plain instance method
        so both Core.InstanceCall(topology,'Type') and Topology.Type(topology)
        calling conventions work (inherited by every subclass).
        """
        result = _type_id_for(self)
        if result is None:
            print("Topology.Type - Error: The input topology parameter is not a valid topology or graph. Returning None.")
        return result

    @staticmethod
    def IsInstance(topology: Any, typeName: str) -> bool:
        if typeName is None:
            return False

        requested = str(typeName).strip().lower()
        actual = _topology_type_name(topology)

        if requested == "topology":
            return _is_topology_like(topology)

        if actual is None:
            return False

        return actual.lower() == requested

    def TypeAsString(self) -> Optional[str]:
        """
        Instance method (not @staticmethod) so both calling conventions work:
        Core.Topology.TypeAsString(topology) and
        Core.InstanceCall(topology, 'GetTypeAsString').
        """
        result = _topology_type_name(self)
        if result is None:
            print("Topology.TypeAsString - Error: The input topology parameter is not a valid topology or graph. Returning None.")
        return result

    # Real topologic_core exposes this instance method under the name
    # GetTypeAsString; TopologyUtility/tests may also reference TypeAsString.
    GetTypeAsString = TypeAsString

    def GetDictionary(self):
        if self is None:
            return None

        if isinstance(self, dict):
            return self.get("dictionary", None) or {}

        shape = _shape_from_topology(self)

        if not _is_null_shape(shape):
            manager = AttributeManager.GetInstance()

            if manager.HasDictionary(shape):
                return manager.GetDictionary(shape)

        # Fallback for shapeless wrapper objects.
        return getattr(self, "dictionary", None) or {}


    Dictionary = GetDictionary


    def SetDictionary(self, dictionary: Any):
        if self is None:
            return None

        dictionary = dictionary if dictionary is not None else {}

        if isinstance(self, dict):
            self["dictionary"] = dictionary
            return self

        shape = _shape_from_topology(self)

        if not _is_null_shape(shape):
            AttributeManager.GetInstance().SetDictionary(
                shape,
                dictionary
            )

        # Keep the wrapper attribute as a compatibility mirror.
        try:
            self.dictionary = dictionary
        except Exception:
            pass

        return self

    @staticmethod
    def ByOcctShape(
        shape: Any,
        dictionary=None,
        contents=None,
        contexts=None,
        apertures=None
    ):
        """
        Wraps an existing OCCT shape as the corresponding PythonOCC backend
        topology.

        Shape-keyed dictionaries and relationships are restored from
        AttributeManager so that metadata survives reconstruction of transient
        Python wrappers around the same OCCT topology.
        """
        if _is_null_shape(shape):
            return None

        try:
            shape_type = shape.ShapeType()
        except Exception:
            return None

        manager = AttributeManager.GetInstance()

        dictionary_known = dictionary is not None or manager.HasDictionary(shape)
        contents_known = contents is not None or manager.HasContents(shape)
        contexts_known = contexts is not None or manager.HasContexts(shape)
        apertures_known = apertures is not None or manager.HasApertures(shape)

        if dictionary is None:
            dictionary = manager.GetDictionary(shape) if manager.HasDictionary(shape) else {}
        else:
            manager.SetDictionary(shape, dictionary)
            dictionary = manager.GetDictionary(shape)

        if contents is None:
            contents = manager.GetContents(shape) if manager.HasContents(shape) else []
        else:
            manager.SetContents(shape, _safe_list(contents))
            contents = manager.GetContents(shape)

        if contexts is None:
            contexts = manager.GetContexts(shape) if manager.HasContexts(shape) else []
        else:
            manager.SetContexts(shape, _safe_list(contexts))
            contexts = manager.GetContexts(shape)

        if apertures is None:
            apertures = manager.GetApertures(shape) if manager.HasApertures(shape) else []
        else:
            manager.SetApertures(shape, _safe_list(apertures))
            apertures = manager.GetApertures(shape)

        def _finalize(result):
            if result is None:
                return None

            actual_shape = _shape_from_topology(result)

            if not _is_null_shape(actual_shape):
                if dictionary_known:
                    manager.SetDictionary(actual_shape, dictionary)
                if contents_known:
                    manager.SetContents(actual_shape, contents)
                if contexts_known:
                    manager.SetContexts(actual_shape, contexts)
                if apertures_known:
                    manager.SetApertures(actual_shape, apertures)

            try:
                result.dictionary = dictionary
            except Exception:
                pass
            try:
                result.contents = list(contents)
            except Exception:
                pass
            try:
                result.contexts = list(contexts)
            except Exception:
                pass
            try:
                result.apertures = list(apertures)
            except Exception:
                pass

            return result

        # ------------------------------------------------------------------
        # Vertex / Edge / Wire / Face
        # ------------------------------------------------------------------
        if shape_type in (
            TopAbs_VERTEX,
            TopAbs_EDGE,
            TopAbs_WIRE,
            TopAbs_FACE,
        ):
            return _finalize(
                _wrap_shape_as_topology(
                    shape,
                    dictionary=dictionary,
                    contents=contents,
                    contexts=contexts,
                    apertures=apertures,
                )
            )

        # ------------------------------------------------------------------
        # Shell -- shallow wrapper only.
        # ------------------------------------------------------------------
        if shape_type == TopAbs_SHELL:
            from .shell import Shell
            return _finalize(
                Shell(
                    shape=topods_Shell(shape),
                    faces=[],
                    dictionary=dictionary,
                    contents=contents,
                    contexts=contexts,
                    apertures=apertures,
                )
            )

        # ------------------------------------------------------------------
        # Solid -> Cell -- shallow wrapper only.
        # ------------------------------------------------------------------
        if shape_type == TopAbs_SOLID:
            from .cell import Cell
            from .occ_utils import is_valid_occ_solid
            if is_valid_occ_solid(shape):
                return _finalize(Cell(shape=topods_Solid(shape), shells=[],
                                      dictionary=dictionary, contents=contents,
                                      contexts=contexts, apertures=apertures))
            # An imported Solid container is not proof of a closed volume.
            # Preserve all recoverable shells, rather than pretending they
            # enclose a Cell or fabricating a missing boundary.
            import warnings
            warnings.warn("Topology.ByOcctShape: invalid solid; preserving boundary geometry instead of a Cell.",
                          RuntimeWarning, stacklevel=2)
            from .cluster import Cluster
            shells = _iter_occ_subshapes_unique(shape, TopAbs_SHELL)
            if not shells:
                return None
            recovered = [Topology.ByOcctShape(s) for s in shells]
            if any(s is None for s in recovered):
                return None
            if len(recovered) == 1:
                return _finalize(recovered[0])
            return _finalize(Cluster(shape=_compound_of_shapes(shells), topologies=recovered))

        # ------------------------------------------------------------------
        # CompSolid -> CellComplex, only if every member is a valid Cell.
        # ------------------------------------------------------------------
        if shape_type == TopAbs_COMPSOLID:
            from .cell import Cell
            from .cell_complex import CellComplex
            from .cluster import Cluster
            solids = _iter_occ_subshapes_unique(shape, TopAbs_SOLID)
            if not solids:
                return None
            wrapped = [Topology.ByOcctShape(s) for s in solids]
            if any(c is None for c in wrapped):
                return None
            if len(wrapped) == 1:
                return _finalize(wrapped[0])
            if not all(isinstance(c, Cell) for c in wrapped):
                return _finalize(Cluster(shape=_compound_of_shapes([_shape_from_topology(c) for c in wrapped]),
                                         topologies=wrapped))
            return _finalize(CellComplex(shape=shape, cells=[], dictionary=dictionary,
                                         contents=contents, contexts=contexts, apertures=apertures))

        # ------------------------------------------------------------------
        # Compound
        # ------------------------------------------------------------------
        if shape_type == TopAbs_COMPOUND:
            return _finalize(
                _wrap_shape_as_topology(
                    shape,
                    dictionary=dictionary,
                    contents=contents,
                    contexts=contexts,
                    apertures=apertures,
                )
            )

        return None

    @staticmethod
    def BREPString(topology: Any, version: int = 0) -> Optional[str]:
        """
        Returns the raw OCCT BREP string of the input topology.

        Parameters
        ----------
        topology : Topology
            The input topology.
        version : int, optional
            Retained for API compatibility. The PythonOCC backend writes the
            OCCT BREP format supported by the installed Open CASCADE version.

        Returns
        -------
        str
            The raw OCCT BREP string, or None if serialization fails.
        """
        return Topology.String(topology, version=version)

    @staticmethod
    def String(topology: Any, version: int = 0) -> Optional[str]:
        """
        Returns the raw OCCT BREP string of the input topology.

        This method deliberately serializes only the OCCT topology/geometry.
        It does not wrap the BREP text in JSON or include TopologicPy metadata.

        Parameters
        ----------
        topology : Topology
            The input topology.
        version : int, optional
            Retained for API compatibility. The PythonOCC backend writes the
            OCCT BREP format supported by the installed Open CASCADE version.

        Returns
        -------
        str
            The raw OCCT BREP string, or None if serialization fails.
        """
        shape = _ensure_compound_shape(topology)
        return _shape_to_brep_text(shape)

    @staticmethod
    def ByString(string: Any):
        """
        Reconstructs a topology from a raw OCCT BREP string.

        Parameters
        ----------
        string : str
            The raw OCCT BREP string.

        Returns
        -------
        Topology
            The reconstructed topology, or None if deserialization fails.
        """
        if not isinstance(string, str) or not string.strip():
            return None

        shape = _shape_from_brep_text(string)
        if shape is None:
            return None

        return Topology.ByOcctShape(shape)

    def _dispatch_subtopologies(
        self,
        own_attr,
        shape_type,
        child_attrs,
        recurse_name,
        self_type_name=None,
        hostTopology=None,
        output=None
    ):
        """
        Returns subtopologies of the requested type.

        The method first uses explicitly stored subtopology wrappers when they
        exist and are non-empty. If no stored wrappers are available, it queries
        the native OCCT shape. If that also produces no result, it recursively
        searches child topology collections.

        This supports both Pythonic return-list calls and topologic_core-style
        output-list calls.

        Parameters
        ----------
        self : Topology
            The input topology.
        own_attr : str
            The attribute name containing cached subtopologies of the requested
            type.
        shape_type : OCC.Core.TopAbs.TopAbs_ShapeEnum
            The requested native OCCT shape type.
        child_attrs : tuple
            Attribute names containing lower-level topology collections through
            which the query may recurse.
        recurse_name : str
            The topology query method name used during recursive traversal.
        self_type_name : str , optional
            The Topologic type name corresponding to the requested topology.
        hostTopology : Topology , optional
            The host topology used for super-topology queries.
        output : list , optional
            An output list following the topologic_core calling convention.

        Returns
        -------
        list or int
            The requested subtopologies, or 0 when an output list is supplied.
        """

        if self is None:
            if output is not None:
                return 0
            return None

        # ------------------------------------------------------------------
        # Determine source and target dimensional ranks.
        # ------------------------------------------------------------------

        self_type = _topology_type_name(
            self
        )

        self_rank = _TYPE_RANK.get(
            self_type
        )

        target_rank = (
            _TYPE_RANK.get(
                self_type_name
            )
            if self_type_name
            else None
        )

        # ------------------------------------------------------------------
        # Super-topology / adjacency query.
        # ------------------------------------------------------------------

        if (
            hostTopology is not None
            and self_rank is not None
            and target_rank is not None
            and self_rank < target_rank
            and not hasattr(self, own_attr)
        ):

            result = Topology.SuperTopologies(
                self,
                hostTopology,
                self_type_name
            ) or []

            result = _deduplicate_by_identity(
                result
            )

            if output is not None:
                output.extend(
                    result
                )
                return 0

            return result

        # ------------------------------------------------------------------
        # The topology itself is already of the requested type.
        # ------------------------------------------------------------------

        if (
            self_type_name is not None
            and self_type == self_type_name
        ):

            result = [
                self
            ]

            if output is not None:
                output.extend(
                    result
                )
                return 0

            return result

        result = []

        # ------------------------------------------------------------------
        # 1. Use explicitly stored wrappers when NON-EMPTY.
        #
        # An empty list is not necessarily authoritative. Container wrappers
        # created from native OCCT shapes are intentionally shallow, e.g.:
        #
        #     Cell(shape=solid, shells=[])
        #     Shell(shape=shell, faces=[])
        #
        # Their descendants must therefore be discovered from the OCCT shape.
        # ------------------------------------------------------------------

        if hasattr(
            self,
            own_attr
        ):

            try:
                stored = _safe_list(
                    getattr(
                        self,
                        own_attr
                    )
                )
            except Exception:
                stored = []

            if stored:
                result.extend(
                    stored
                )

        # ------------------------------------------------------------------
        # 2. If no cached wrappers were available, inspect the native OCCT
        #    topology. BRepGraph is preferred on OCCT 8; _downward_wrappers
        #    retains the exact legacy TopExp fallback.
        # ------------------------------------------------------------------

        if not result:
            try:
                result = _downward_wrappers(self, shape_type)
            except Exception:
                result = []

        # ------------------------------------------------------------------
        # 3. Aggregate / wrapper fallback.
        #
        # For shapeless aggregate wrappers such as the lightweight Cluster,
        # recurse through their direct topology members.
        # ------------------------------------------------------------------

        if not result:

            for attr in child_attrs:

                if not hasattr(
                    self,
                    attr
                ):
                    continue

                try:
                    children = _safe_list(
                        getattr(
                            self,
                            attr
                        )
                    )
                except Exception:
                    children = []

                for child in children:

                    if child is None:
                        continue

                    try:
                        child_result = getattr(
                            Topology,
                            recurse_name
                        )(
                            child
                        ) or []

                    except Exception:
                        child_result = []

                    result.extend(
                        child_result
                    )

        # ------------------------------------------------------------------
        # Deduplicate using native identity where possible.
        # ------------------------------------------------------------------

        result = _deduplicate_by_identity(
            result
        )

        if output is not None:
            output.extend(
                result
            )
            return 0

        return result

    def Vertices(self, hostTopology=None, output=None):
        if hasattr(self, "start") and hasattr(self, "end") and not hasattr(self, "vertices"):
            result = [v for v in [getattr(self, "start"), getattr(self, "end")] if v is not None]
            result = _deduplicate_by_identity(result)
            if output is not None:
                output.extend(result)
                return 0
            return result
        return Topology._dispatch_subtopologies(
            self, "vertices", TopAbs_VERTEX, ("edges", "faces", "shells", "cells", "topologies", "members"),
            "Vertices", self_type_name="Vertex", hostTopology=hostTopology, output=output,
        )

    def Edges(self, hostTopology=None, output=None):
        return Topology._dispatch_subtopologies(
            self, "edges", TopAbs_EDGE, ("faces", "shells", "cells", "topologies", "members"),
            "Edges", self_type_name="Edge", hostTopology=hostTopology, output=output,
        )

    def Wires(self, hostTopology=None, output=None):
        if hasattr(self, "external") and getattr(self, "external") is not None:
            result = [getattr(self, "external")]
            result.extend(_safe_list(getattr(self, "internals", [])))
            result = _deduplicate_by_identity(result)
            if output is not None:
                output.extend(result)
                return 0
            return result
        return Topology._dispatch_subtopologies(
            self, "wires", TopAbs_WIRE, ("faces", "shells", "cells", "topologies", "members"),
            "Wires", self_type_name="Wire", hostTopology=hostTopology, output=output,
        )

    def Faces(self, hostTopology=None, output=None):
        return Topology._dispatch_subtopologies(
            self, "faces", TopAbs_FACE, ("shells", "cells", "topologies", "members"),
            "Faces", self_type_name="Face", hostTopology=hostTopology, output=output,
        )

    def Shells(self, hostTopology=None, output=None):
        return Topology._dispatch_subtopologies(
            self, "shells", TopAbs_SHELL, ("cells", "topologies", "members"),
            "Shells", self_type_name="Shell", hostTopology=hostTopology, output=output,
        )

    def Cells(self, hostTopology=None, output=None):
        return Topology._dispatch_subtopologies(
            self, "cells", TopAbs_SOLID, ("topologies", "members"),
            "Cells", self_type_name="Cell", hostTopology=hostTopology, output=output,
        )

    def CellComplexes(self, hostTopology=None, output=None):
        return Topology._dispatch_subtopologies(
            self, "cellComplexes", TopAbs_COMPSOLID, ("topologies", "members"),
            "CellComplexes", self_type_name="CellComplex", hostTopology=hostTopology, output=output,
        )

    def Clusters(self, hostTopology=None, output=None):
        result = [self] if _topology_type_name(self) == "Cluster" else []
        if output is not None:
            output.extend(result)
            return 0
        return result

    def Apertures(self, output=None):
        """
        Returns the apertures attached to this topology.

        The signature intentionally matches topologic_core's output-list calling
        convention: topology.Apertures(output_list).
        """
        if self is None:
            result = []
        else:
            shape = _shape_from_topology(self)
            local = _safe_list(getattr(self, "apertures", []))

            if not _is_null_shape(shape):
                manager = AttributeManager.GetInstance()
                if manager.HasApertures(shape):
                    result = manager.GetApertures(shape)
                else:
                    result = _deduplicate_by_identity(local)
                    if result:
                        manager.SetApertures(shape, result)
            else:
                result = _deduplicate_by_identity(local)

            try:
                self.apertures = list(result)
            except Exception:
                pass

        if output is not None:
            output.extend(result)
            return 0

        return result

    def Contents(self, output=None):
        """Returns the contents attached to this topology."""
        if self is None:
            result = []
        else:
            shape = _shape_from_topology(self)
            local = _safe_list(getattr(self, "contents", []))

            if not _is_null_shape(shape):
                manager = AttributeManager.GetInstance()
                if manager.HasContents(shape):
                    result = manager.GetContents(shape)
                else:
                    result = _deduplicate_by_identity(local)
                    if result:
                        manager.SetContents(shape, result)
            else:
                result = _deduplicate_by_identity(local)

            try:
                self.contents = list(result)
            except Exception:
                pass

        if output is not None:
            output.extend(result)
            return 0

        return result

    def Contexts(self, output=None):
        """Returns the contexts attached to this topology."""
        if self is None:
            result = []
        else:
            shape = _shape_from_topology(self)
            local = _safe_list(getattr(self, "contexts", []))

            if not _is_null_shape(shape):
                manager = AttributeManager.GetInstance()
                if manager.HasContexts(shape):
                    result = manager.GetContexts(shape)
                else:
                    result = _deduplicate_by_identity(local)
                    if result:
                        manager.SetContexts(shape, result)
            else:
                result = _deduplicate_by_identity(local)

            try:
                self.contexts = list(result)
            except Exception:
                pass

        if output is not None:
            output.extend(result)
            return 0

        return result

    def AddContent(self, content: Any):
        """Adds one content topology and persists the relationship by OCCT shape identity."""
        if self is None or content is None:
            return self

        shape = _shape_from_topology(self)

        if not _is_null_shape(shape):
            manager = AttributeManager.GetInstance()
            if manager.HasContents(shape):
                current = manager.GetContents(shape)
            else:
                current = _safe_list(getattr(self, "contents", []))

            current = _deduplicate_by_identity(current + [content])
            manager.SetContents(shape, current)
            self.contents = manager.GetContents(shape)
        else:
            self.contents = _deduplicate_by_identity(
                _safe_list(getattr(self, "contents", [])) + [content]
            )

        return self

    def AddContents(self, contents: Any, typeID: Any = None):
        """Adds multiple contents. typeID is accepted for topologic_core compatibility."""
        for content in _safe_list(contents):
            self.AddContent(content)

        return self

    def AddContext(self, context: Any):
        """Adds one context and persists the relationship by OCCT shape identity."""
        if self is None or context is None:
            return self

        shape = _shape_from_topology(self)

        if not _is_null_shape(shape):
            manager = AttributeManager.GetInstance()
            if manager.HasContexts(shape):
                current = manager.GetContexts(shape)
            else:
                current = _safe_list(getattr(self, "contexts", []))

            current = _deduplicate_by_identity(current + [context])
            manager.SetContexts(shape, current)
            self.contexts = manager.GetContexts(shape)
        else:
            self.contexts = _deduplicate_by_identity(
                _safe_list(getattr(self, "contexts", [])) + [context]
            )

        return self

    def RemoveContents(self, contents: Any):
        """Removes contents using topological identity and persists the result."""
        if self is None:
            return self

        to_remove = _safe_list(contents)
        shape = _shape_from_topology(self)

        if not _is_null_shape(shape):
            manager = AttributeManager.GetInstance()
            if manager.HasContents(shape):
                current = manager.GetContents(shape)
            else:
                current = _safe_list(getattr(self, "contents", []))
        else:
            current = _safe_list(getattr(self, "contents", []))

        kept = []
        for item in current:
            remove = False
            for candidate in to_remove:
                if Topology.IsSame(item, candidate):
                    remove = True
                    break

            if not remove:
                kept.append(item)

        kept = _deduplicate_by_identity(kept)
        self.contents = kept

        if not _is_null_shape(shape):
            manager.SetContents(shape, kept)
            self.contents = manager.GetContents(shape)

        return self

    def RemoveCoplanarFaces(
        self,
        epsilon: float = 0.01,
        tolerance: float = 0.0001
    ):
        """
        Removes coplanar faces using OCCT's ShapeUpgrade_UnifySameDomain.

        Parameters
        ----------
        epsilon : float, optional
            The linear tolerance used by OCCT when determining whether
            neighbouring faces lie on the same geometric domain.
            Default is 0.01.
        tolerance : float, optional
            The sewing tolerance used when the input is a shapeless aggregate
            of independently constructed faces. Default is 0.0001.

        Returns
        -------
        Topology
            The topology with adjacent coplanar faces unified.
        """

        type_name = _topology_type_name(self)

        if type_name in ("Vertex", "Edge", "Wire", "Face"):
            return self

        if ShapeUpgrade_UnifySameDomain is None:
            return self

        shape = _shape_from_topology(self)
        temporary_shape = False

        # ------------------------------------------------------------------
        # Shapeless face soup
        #
        # Cluster.ByTopologies intentionally stores shape=None. This is the
        # common case for imported OBJ meshes. The individual faces therefore
        # need to be sewn once so coincident triangle edges become genuine
        # shared OCCT edges before same-domain unification.
        # ------------------------------------------------------------------

        if _is_null_shape(shape):

            members = _safe_list(
                getattr(self, "topologies", None)
            )

            face_soup = (
                len(members) > 0
                and all(
                    _topology_type_name(member) == "Face"
                    for member in members
                )
            )

            if face_soup:
                try:
                    from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_Sewing

                    sewing = BRepBuilderAPI_Sewing(
                        max(float(tolerance), 1e-12)
                    )

                    count = 0

                    for member in members:
                        member_shape = _shape_from_topology(
                            member
                        )

                        if _is_null_shape(member_shape):
                            continue

                        sewing.Add(
                            member_shape
                        )

                        count += 1

                    if count == 0:
                        return self

                    sewing.Perform()

                    shape = sewing.SewedShape()

                    if _is_null_shape(shape):
                        return self

                    temporary_shape = True

                except Exception:
                    return self

            else:
                # Preserve arbitrary heterogeneous Clusters by constructing
                # an OCCT Compound without discarding any members.
                shape = _ensure_compound_shape(
                    self
                )

                if _is_null_shape(shape):
                    return self

        # ------------------------------------------------------------------
        # Native OCCT same-domain unification.
        #
        # Constructor arguments:
        #
        #   shape
        #   UnifyEdges=False
        #   UnifyFaces=True
        #   ConcatBSplines=False
        #
        # We specifically want face unification. Removing collinear edges or
        # joining curves is a different operation and should not be performed
        # implicitly by RemoveCoplanarFaces.
        # ------------------------------------------------------------------

        try:
            unifier = ShapeUpgrade_UnifySameDomain(
                shape,
                False,
                True,
                False
            )

            if hasattr(
                unifier,
                "SetLinearTolerance"
            ):
                unifier.SetLinearTolerance(
                    max(float(epsilon), 1e-12)
                )

            if hasattr(
                unifier,
                "AllowInternalEdges"
            ):
                unifier.AllowInternalEdges(
                    False
                )

            # The sewn face soup is a temporary shape. OCCT is free to modify
            # it in-place, avoiding unnecessary defensive copying.
            if (
                temporary_shape
                and hasattr(
                    unifier,
                    "SetSafeInputMode"
                )
            ):
                unifier.SetSafeInputMode(
                    False
                )

            unifier.Build()

            unified_shape = unifier.Shape()

            if _is_null_shape(
                unified_shape
            ):
                return self

        except Exception:
            return self

        # ------------------------------------------------------------------
        # Wrap the native result.
        # ------------------------------------------------------------------

        dictionary = Topology.GetDictionary(
            self
        )

        contents = list(
            getattr(
                self,
                "contents",
                []
            ) or []
        )

        contexts = list(
            getattr(
                self,
                "contexts",
                []
            ) or []
        )

        apertures = list(
            getattr(
                self,
                "apertures",
                []
            ) or []
        )

        result = Topology.ByOcctShape(
            unified_shape,
            dictionary=dictionary,
            contents=contents,
            contexts=contexts,
            apertures=apertures
        )

        if result is None:
            return self

        # ------------------------------------------------------------------
        # Simplify a one-face Shell to a Face.
        #
        # ShapeUpgrade_UnifySameDomain preserves the Shell container even when
        # every constituent triangle has collapsed into one OCCT Face. Topologic
        # semantics are cleaner if that result is returned directly as a Face.
        # ------------------------------------------------------------------

        if _topology_type_name(
            result
        ) == "Shell":

            faces = _iter_occ_subshapes_unique(
                unified_shape,
                TopAbs_FACE
            )

            if len(faces) == 1:

                face = Topology.ByOcctShape(
                    faces[0],
                    dictionary=dictionary,
                    contents=contents,
                    contexts=contexts,
                    apertures=apertures
                )

                if face is not None:
                    return face

        return result

    def RemoveCoplanarFacesNative(
        self,
        epsilon: float = 0.01,
        polyhedron: bool = True,
        tolerance: float = 0.0001,
    ):
        """
        Removes redundant coplanar Face boundaries using
        ShapeUpgrade_UnifySameDomain.

        Parameters
        ----------
        epsilon : float , optional
            Linear same-domain tolerance used when determining whether planar Faces
            belong to the same plane. Default is 0.01.
        polyhedron : bool , optional
            If True, the input is assumed to contain planar Faces and the fast
            native path is used directly. If False, every Edge belonging to a
            non-planar Face is protected, preventing OCCT from merging curved,
            analytic, Bezier, or BSpline/NURBS Faces. Default is True.
        tolerance : float , optional
            General linear tolerance. Default is 0.0001.

        Returns
        -------
        tuple
            ``(status, result)``.
        """
        if _topology_type_name(self) == "Cluster":
            return self._EditClusterMembers("RemoveCoplanarFacesNative", epsilon, polyhedron, tolerance)
        type_name = (
            _topology_type_name(self)
            or ""
        )

        if type_name in (
            "Vertex",
            "Edge",
            "Wire",
            "Face",
        ):
            return True, self

        shape = _shape_from_topology(self)

        if _is_null_shape(shape):
            return False, None

        try:
            epsilon = max(
                abs(float(epsilon)),
                1.0e-12,
            )

            tolerance = max(
                abs(float(tolerance)),
                1.0e-12,
            )
        except Exception:
            return False, None

        try:
            from OCC.Core.BRepAdaptor import (
                BRepAdaptor_Surface,
            )
            from OCC.Core.GeomAbs import (
                GeomAbs_Plane,
            )
            from OCC.Core.ShapeUpgrade import (
                ShapeUpgrade_UnifySameDomain,
            )
            from OCC.Core.TopTools import (
                TopTools_MapOfShape,
            )
        except Exception:
            return False, None

        faces_before = (
            _iter_occ_subshapes_unique(
                shape,
                TopAbs_FACE,
            )
            or []
        )

        if len(faces_before) < 2:
            return True, self

        try:
            unifier = (
                ShapeUpgrade_UnifySameDomain(
                    shape,
                    False,  # UnifyEdges
                    True,   # UnifyFaces
                    False,  # ConcatBSplines
                )
            )

            unifier.SetSafeInputMode(
                True
            )

            unifier.SetLinearTolerance(
                max(
                    epsilon,
                    tolerance,
                )
            )

            # ----------------------------------------------------------
            # Curve/NURBS-preserving mode.
            #
            # Keep every Edge belonging to any non-planar Face. OCCT's
            # KeepShape(edge) prevents the connected Faces from being
            # unified across that Edge.
            #
            # A geometrically planar BSpline/NURBS Face is intentionally
            # protected because its surface representation is still a
            # BSpline surface rather than a Geom_Plane.
            # ----------------------------------------------------------

            if not bool(polyhedron):
                protected_edges = (
                    TopTools_MapOfShape()
                )

                for face_shape in faces_before:
                    try:
                        adaptor = (
                            BRepAdaptor_Surface(
                                topods_Face(
                                    face_shape
                                )
                            )
                        )

                        is_plane = (
                            adaptor.GetType()
                            == GeomAbs_Plane
                        )

                    except Exception:
                        is_plane = False

                    if is_plane:
                        continue

                    face_edges = (
                        _iter_occ_subshapes_unique(
                            face_shape,
                            TopAbs_EDGE,
                        )
                        or []
                    )

                    for edge_shape in face_edges:
                        if protected_edges.Contains(
                            edge_shape
                        ):
                            continue

                        protected_edges.Add(
                            edge_shape
                        )

                        unifier.KeepShape(
                            edge_shape
                        )

            unifier.Build()

            unified_shape = (
                unifier.Shape()
            )

            if _is_null_shape(
                unified_shape
            ):
                return False, None

            faces_after = (
                _iter_occ_subshapes_unique(
                    unified_shape,
                    TopAbs_FACE,
                )
                or []
            )

            if len(faces_after) >= len(
                faces_before
            ):
                return True, self

            result = Topology.ByOcctShape(unified_shape)
            if result is None:
                return False, None

            try:
                result.SetDictionary(Topology.GetDictionary(self))
            except Exception:
                try:
                    result.dictionary = Topology.GetDictionary(self)
                except Exception:
                    pass

            for attribute in ("contents", "contexts", "apertures"):
                try:
                    setattr(
                        result,
                        attribute,
                        list(getattr(self, attribute, []) or []),
                    )
                except Exception:
                    pass

            return True, result

        except Exception:
            return False, None

    @staticmethod
    def Deform(
        topology,
        deformation,
        origin=None,
        parameters=None,
        subdivisions: int = 8,
        degree: int = 3,
        transferDictionaries: bool = True,
        tolerance: float = 0.0001,
        silent: bool = False,
    ):
        """
        Deforms a topology by modifying its NURBS control geometry.

        This is a PythonOCC-backend operation. Analytical curves and surfaces
        are converted to bounded B-Spline/NURBS representations, degree-raised
        and knot-refined without changing their shape, and their control points
        are then deformed. Shared 3D edges are modified once and remain the
        authoritative boundaries; face p-curves are rebuilt on the deformed
        support surfaces.

        ``deformation`` may be one of ``"taper"``, ``"twist"`` or ``"bend"``,
        or a callable accepting ``(x, y, z)`` or ``(x, y, z, context)`` and
        returning three coordinates. Named deformations receive their settings
        through ``parameters``.

        Parameters
        ----------
        topology : Topology
            The backend topology to deform.
        deformation : str or callable
            The deformation field. Supported names are ``"taper"``,
            ``"twist"`` and ``"bend"``.
        origin : Vertex, optional
            Origin used by named deformations. If None, the topology centroid
            is used.
        parameters : dict, optional
            Parameters for the named deformation.
        subdivisions : int, optional
            Minimum number of B-Spline knot spans in each active parametric
            direction. Default is 8.
        degree : int, optional
            Minimum B-Spline degree. Existing higher degrees are retained.
            Default is 3.
        transferDictionaries : bool, optional
            If True, copies dictionaries onto corresponding converted
            subtopologies. Default is True.
        tolerance : float, optional
            Geometric tolerance. Default is 0.0001.
        silent : bool, optional
            If True, suppresses diagnostic messages. Default is False.

        Returns
        -------
        Topology
            The deformed topology, or None on failure.
        """
        import inspect
        import math

        def _error(message, error=None):
            if not silent:
                print(f"Topology.Deform - Error: {message} Returning None.")
                if error is not None:
                    print("Error:", error)
            return None

        if not isinstance(topology, Topology):
            return _error("The input topology parameter is not a valid PythonOCC backend topology.")

        source_shape = _shape_from_topology(topology)

        # Cluster.ByTopologies intentionally preserves its direct constituent
        # wrappers and may therefore keep shape=None. Deformation still needs
        # one temporary native Compound to calculate the aggregate bounds and
        # shared deformation context. The Cluster branch below continues to
        # deform and rebuild the cached direct members individually.
        if _is_null_shape(source_shape) and _topology_type_name(topology) == "Cluster":
            source_shape = _ensure_compound_shape(topology)

        if _is_null_shape(source_shape):
            return _error("The input topology does not contain a valid OCCT shape.")

        if parameters is None:
            parameters = {}
        if not isinstance(parameters, dict):
            return _error("The input parameters parameter must be a dictionary.")

        try:
            subdivisions = max(1, int(subdivisions))
            degree = max(1, min(25, int(degree)))
            tolerance = abs(float(tolerance))
        except Exception as error:
            return _error("One or more numeric parameters are invalid.", error)

        if not math.isfinite(tolerance) or tolerance <= 0.0:
            return _error("The input tolerance must be a finite number greater than zero.")

        try:
            from OCC.Core.Bnd import Bnd_Box
            from OCC.Core.BRep import BRep_Builder, BRep_Tool
            from OCC.Core.BRepAdaptor import BRepAdaptor_Surface
            from OCC.Core.BRepBndLib import brepbndlib
            from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_NurbsConvert
            from OCC.Core.BRepLib import breplib
            from OCC.Core.BRepCheck import BRepCheck_Analyzer
            import OCC.Core.BRepTools as _breptools_module
            from OCC.Core.Geom import Geom_BSplineCurve, Geom_BSplineSurface
            from OCC.Core.Geom2d import Geom2d_Curve
            from OCC.Core.GeomAbs import GeomAbs_C1
            from OCC.Core.ShapeBuild import ShapeBuild_Edge
            from OCC.Core.ShapeConstruct import shapeconstruct
            from OCC.Core.ShapeFix import shapefix, ShapeFix_Edge, ShapeFix_Shape
            from OCC.Core.TopAbs import (
                TopAbs_VERTEX,
                TopAbs_EDGE,
                TopAbs_WIRE,
                TopAbs_FACE,
                TopAbs_SHELL,
                TopAbs_SOLID,
                TopAbs_COMPSOLID,
                TopAbs_COMPOUND,
            )
            from OCC.Core.TopExp import TopExp_Explorer
            from OCC.Core.TopLoc import TopLoc_Location
            from OCC.Core.TopoDS import topods
            from OCC.Core.gp import gp_Pnt
        except Exception as error:
            return _error("The PythonOCC deformation dependencies could not be imported.", error)

        # --------------------------------------------------------------
        # Exact evaluated bounds of the input geometry.
        # --------------------------------------------------------------
        try:
            box = Bnd_Box()
            brepbndlib.AddOptimal(source_shape, box, False, False)
            xmin, ymin, zmin, xmax, ymax, zmax = [float(v) for v in box.Get()]
            bounds = [xmin, ymin, zmin, xmax, ymax, zmax]
            if not all(math.isfinite(v) for v in bounds):
                raise RuntimeError("The topology has non-finite bounds.")
        except Exception as error:
            return _error("Could not determine the exact geometric bounds.", error)

        width = xmax - xmin
        length = ymax - ymin
        height = zmax - zmin

        # Named deformation origin. For a custom callback the origin is still
        # exposed in the context when available.
        if origin is None:
            try:
                origin = Topology.CenterOfMass(topology)
            except Exception:
                origin = None

        if origin is not None and all(hasattr(origin, attr) for attr in ("x", "y", "z")):
            try:
                ox = float(origin.x)
                oy = float(origin.y)
                oz = float(origin.z)
            except Exception:
                origin = None

        if origin is None:
            ox = 0.5 * (xmin + xmax)
            oy = 0.5 * (ymin + ymax)
            oz = 0.5 * (zmin + zmax)
            try:
                from .vertex import Vertex
                origin = Vertex.ByCoordinates(ox, oy, oz)
            except Exception:
                origin = None

        context = {
            "xmin": xmin,
            "ymin": ymin,
            "zmin": zmin,
            "xmax": xmax,
            "ymax": ymax,
            "zmax": zmax,
            "width": width,
            "length": length,
            "height": height,
            "center": [
                0.5 * (xmin + xmax),
                0.5 * (ymin + ymax),
                0.5 * (zmin + zmax),
            ],
            "origin": [ox, oy, oz],
            "parameters": dict(parameters),
        }

        # --------------------------------------------------------------
        # Construct the deformation field in the backend.
        # --------------------------------------------------------------
        deformation_name = None
        deformation_function = None
        use_context = True

        if isinstance(deformation, str):
            deformation_name = deformation.strip().lower()

            if deformation_name == "taper":
                ratio_range = parameters.get("ratioRange", [0, 1])
                if not isinstance(ratio_range, (list, tuple)) or len(ratio_range) != 2:
                    return _error("The taper ratioRange must contain exactly two numeric values.")
                try:
                    ratio0 = min(1.0, float(ratio_range[0]))
                    ratio1 = min(1.0, float(ratio_range[1]))
                except Exception as error:
                    return _error("The taper ratioRange contains an invalid value.", error)
                if not all(math.isfinite(v) for v in (ratio0, ratio1)):
                    return _error("The taper ratioRange contains a non-finite value.")

                if abs(ratio0) <= tolerance and abs(ratio1) <= tolerance:
                    return topology

                # A BRep cannot retain the cylinder's existing topological
                # structure if a complete boundary loop is collapsed exactly
                # to one vertex. Keep a tolerance-sized residual scale at the
                # limiting ratio so ratio=1 remains a valid CAD deformation.
                radial_extent = max(abs(width), abs(length), tolerance)
                minimum_scale = max(1.0e-9, min(1.0e-2, tolerance / radial_extent))

                if abs(ratio1 - ratio0) <= tolerance:
                    scale = max(1.0 - 0.5 * (ratio0 + ratio1), minimum_scale)
                    try:
                        return topology.Scale(origin, scale, scale, 1.0)
                    except Exception as error:
                        return _error("Could not apply the constant taper as an exact affine scale.", error)

                def deformation_function(x, y, z, _context):
                    if abs(height) <= tolerance:
                        return [x, y, z]
                    t = (z - zmin) / height
                    ratio = ratio0 + t * (ratio1 - ratio0)
                    scale = max(1.0 - ratio, minimum_scale)
                    return [
                        ox + scale * (x - ox),
                        oy + scale * (y - oy),
                        z,
                    ]

            elif deformation_name == "twist":
                angle_range = parameters.get("angleRange", [45, 90])
                if not isinstance(angle_range, (list, tuple)) or len(angle_range) != 2:
                    return _error("The twist angleRange must contain exactly two numeric values.")
                try:
                    angle0 = float(angle_range[0])
                    angle1 = float(angle_range[1])
                    ang_tolerance = abs(float(parameters.get("angTolerance", 0.01)))
                except Exception as error:
                    return _error("The twist angleRange or angTolerance contains an invalid value.", error)
                if not all(math.isfinite(v) for v in (angle0, angle1, ang_tolerance)):
                    return _error("The twist angleRange or angTolerance contains a non-finite value.")

                if abs(angle0) < ang_tolerance and abs(angle1) < ang_tolerance:
                    return topology

                # A varying twist is undefined over a zero-height domain and
                # geometrically acts as the identity. Return the original
                # wrapper rather than performing a no-op NURBS conversion,
                # preserving the established object-identity contract.
                if abs(height) <= tolerance:
                    return topology

                if abs(angle1 - angle0) < ang_tolerance:
                    try:
                        return topology.Rotate(origin, 0.0, 0.0, 1.0, 0.5 * (angle0 + angle1))
                    except Exception as error:
                        return _error("Could not apply the constant twist as an exact rotation.", error)

                def deformation_function(x, y, z, _context):
                    if abs(height) <= tolerance:
                        return [x, y, z]
                    t = (z - zmin) / height
                    angle = angle0 + t * (angle1 - angle0)
                    radians = math.radians(angle)
                    cosine = math.cos(radians)
                    sine = math.sin(radians)
                    dx = x - ox
                    dy = y - oy
                    return [
                        ox + cosine * dx - sine * dy,
                        oy + sine * dx + cosine * dy,
                        z,
                    ]

            elif deformation_name == "bend":
                try:
                    angle = float(parameters.get("angle", 90.0))
                    ang_tolerance = abs(float(parameters.get("angTolerance", 0.01)))
                except Exception as error:
                    return _error("The bend angle or angTolerance is invalid.", error)
                if not math.isfinite(angle) or not math.isfinite(ang_tolerance):
                    return _error("The bend angle or angTolerance is non-finite.")
                if abs(angle) < ang_tolerance:
                    return topology

                direction = parameters.get("direction", [1, 0, 0])
                if not isinstance(direction, (list, tuple)) or len(direction) != 3:
                    return _error("The bend direction must contain exactly three numeric values.")
                try:
                    dx = float(direction[0])
                    dy = float(direction[1])
                except Exception as error:
                    return _error("The bend direction contains an invalid value.", error)
                magnitude = math.sqrt(dx * dx + dy * dy)
                if not math.isfinite(magnitude) or magnitude <= tolerance:
                    return _error("The XY projection of the bend direction has zero magnitude.")
                dx /= magnitude
                dy /= magnitude
                sx = -dy
                sy = dx
                total_radians = math.radians(angle)

                def deformation_function(x, y, z, _context):
                    if abs(height) <= tolerance or abs(total_radians) <= 1.0e-15:
                        return [x, y, z]

                    axial = z - zmin
                    theta = total_radians * axial / height
                    radius = height / total_radians

                    rx = x - ox
                    ry = y - oy
                    normal_offset = rx * dx + ry * dy
                    side_offset = rx * sx + ry * sy

                    neutral_normal = radius * (1.0 - math.cos(theta))
                    neutral_z = zmin + radius * math.sin(theta)
                    bent_normal = neutral_normal + normal_offset * math.cos(theta)
                    bent_z = neutral_z - normal_offset * math.sin(theta)

                    return [
                        ox + bent_normal * dx + side_offset * sx,
                        oy + bent_normal * dy + side_offset * sy,
                        bent_z,
                    ]

            else:
                return _error(
                    "The named deformation is not supported. Expected 'taper', 'twist', or 'bend'."
                )

        elif callable(deformation):
            deformation_function = deformation
            try:
                signature = inspect.signature(deformation_function)
                positional = [
                    p
                    for p in signature.parameters.values()
                    if p.kind in (
                        inspect.Parameter.POSITIONAL_ONLY,
                        inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    )
                ]
                has_varargs = any(
                    p.kind == inspect.Parameter.VAR_POSITIONAL
                    for p in signature.parameters.values()
                )
                use_context = has_varargs or len(positional) >= 4
            except Exception:
                use_context = True
        else:
            return _error("The deformation parameter must be a supported name or a callable.")

        def _map_point(point):
            x = float(point.X())
            y = float(point.Y())
            z = float(point.Z())
            try:
                if use_context:
                    mapped = deformation_function(x, y, z, context)
                else:
                    mapped = deformation_function(x, y, z)
                if not isinstance(mapped, (list, tuple)) or len(mapped) != 3:
                    raise ValueError("The deformation field must return exactly three coordinates.")
                qx, qy, qz = [float(value) for value in mapped]
                if not all(math.isfinite(value) for value in (qx, qy, qz)):
                    raise ValueError("The deformation field returned a non-finite coordinate.")
                return gp_Pnt(qx, qy, qz)
            except Exception as error:
                raise RuntimeError(
                    f"The deformation field failed at ({x}, {y}, {z}): {error}"
                ) from error

        # A Vertex has no curve or surface control geometry to convert. Map
        # its point directly; routing a vertex-only shape through
        # BRepBuilderAPI_NurbsConvert is unnecessary and is unsupported by
        # some OCCT/pythonocc versions.
        if _topology_type_name(topology) == "Vertex":
            try:
                from .vertex import Vertex

                mapped_point = _map_point(BRep_Tool.Pnt(topods.Vertex(source_shape)))
                result = Vertex.ByCoordinates(
                    float(mapped_point.X()),
                    float(mapped_point.Y()),
                    float(mapped_point.Z()),
                )
            except Exception as error:
                return _error("Could not deform the input Vertex.", error)

            if not isinstance(result, Topology):
                return _error("The deformed point did not produce a valid Vertex.")

            if transferDictionaries:
                try:
                    result.dictionary = copy.deepcopy(Topology.GetDictionary(topology))
                except Exception:
                    pass

            for attr in ("contents", "contexts", "apertures"):
                if hasattr(topology, attr) and hasattr(result, attr):
                    try:
                        setattr(result, attr, copy.deepcopy(getattr(topology, attr)))
                    except Exception:
                        pass

            return result

        # A heterogeneous Cluster must be deformed constituent by constituent.
        # Passing its complete OCCT Compound through NurbsConvert can collapse
        # or reorder the direct member hierarchy.  Capture the deformation
        # field and the bounds/origin context computed from the complete
        # Cluster, then reuse that one field for every direct member.
        if _topology_type_name(topology) == "Cluster":
            from .cluster import Cluster

            def _shared_deformation(x, y, z, _member_context=None):
                if use_context:
                    return deformation_function(x, y, z, context)
                return deformation_function(x, y, z)

            # Prefer the wrappers cached by Cluster.ByTopologies. They retain
            # the intended direct hierarchy even when the native Compound is
            # capable of exposing the same children. Fall back to the direct
            # TopoDS children only when that cache is unavailable.
            members = list(getattr(topology, "topologies", None) or [])

            if not members:
                try:
                    queried = topology.Topologies()
                    members = list(queried or [])
                except Exception:
                    members = []

            if not members:
                try:
                    from OCC.Core.TopoDS import TopoDS_Iterator

                    iterator = TopoDS_Iterator(source_shape)
                    while iterator.More():
                        member = Topology.ByOcctShape(iterator.Value())
                        if isinstance(member, Topology):
                            members.append(member)
                        iterator.Next()
                except Exception:
                    members = []

            members = [member for member in members if isinstance(member, Topology)]
            if not members:
                return _error("Could not retrieve the direct Cluster members.")

            transformed = []
            for member in members:
                transformed_member = Topology.Deform(
                    member,
                    _shared_deformation,
                    origin=origin,
                    parameters={},
                    subdivisions=subdivisions,
                    degree=degree,
                    transferDictionaries=transferDictionaries,
                    tolerance=tolerance,
                    silent=silent,
                )
                if not isinstance(transformed_member, Topology):
                    return _error(
                        "Could not deform a direct Cluster member of type "
                        f"{_topology_type_name(member)}."
                    )
                transformed.append(transformed_member)

            # Build the aggregate explicitly. Cluster.ByTopologies may
            # self-merge or normalize mixed-dimensional members depending on
            # backend version; that is undesirable for a deformation, whose
            # contract is to preserve the direct constituent hierarchy.
            try:
                result_shape = _compound_of_shapes(
                    [_shape_from_topology(member) for member in transformed]
                )
                result = Cluster(
                    shape=result_shape,
                    topologies=transformed,
                    dictionary=(
                        copy.deepcopy(Topology.GetDictionary(topology))
                        if transferDictionaries
                        else {}
                    ),
                    contents=copy.deepcopy(getattr(topology, "contents", []) or []),
                    contexts=copy.deepcopy(getattr(topology, "contexts", []) or []),
                    apertures=copy.deepcopy(getattr(topology, "apertures", []) or []),
                )
            except Exception as error:
                return _error("Could not rebuild the deformed Cluster.", error)

            if not isinstance(result, Cluster):
                return _error("The deformed members did not produce a valid Cluster.")
            return result

        # --------------------------------------------------------------
        # Small OCCT/SWIG compatibility helpers.
        # --------------------------------------------------------------
        def _clean(shape):
            try:
                if hasattr(_breptools_module, "breptools"):
                    _breptools_module.breptools.Clean(shape)
                elif hasattr(_breptools_module, "breptools_Clean"):
                    _breptools_module.breptools_Clean(shape)
                elif hasattr(_breptools_module, "BRepTools") and hasattr(_breptools_module.BRepTools, "Clean_s"):
                    _breptools_module.BRepTools.Clean_s(shape)
            except Exception:
                pass

        def _uv_bounds(face):
            """
            Return finite parameter bounds without calling BRepTools.UVBounds.

            Some pythonocc builds can terminate the interpreter inside the
            UVBounds SWIG wrapper when a converted Face has incomplete native
            state. BRepAdaptor_Surface performs checked Face construction and
            exposes the same trimmed parameter bounds without that unsafe call.
            """
            if face is None or _is_null_shape(face):
                raise RuntimeError("Cannot retrieve UV bounds from a null face.")

            try:
                occ_face = topods.Face(face)
            except Exception as error:
                raise RuntimeError("The supplied shape is not a valid face.") from error

            if _is_null_shape(occ_face):
                raise RuntimeError("The supplied face is null.")

            try:
                adaptor = BRepAdaptor_Surface(occ_face, True)
                bounds = (
                    float(adaptor.FirstUParameter()),
                    float(adaptor.LastUParameter()),
                    float(adaptor.FirstVParameter()),
                    float(adaptor.LastVParameter()),
                )
            except Exception as error:
                raise RuntimeError("Could not retrieve face parameter bounds.") from error

            if not all(math.isfinite(value) for value in bounds):
                raise RuntimeError("The face has non-finite parameter bounds.")

            return bounds

        def _curve_result(edge):
            # Preferred overload: the returned curve remains in its local
            # coordinate system and the associated location is supplied.
            location = TopLoc_Location()
            try:
                curve, first, last = BRep_Tool.Curve(edge, location)
                return curve, float(first), float(last), location
            except Exception:
                pass

            # pythonocc's no-location overload is known to return
            # (curve, first, last) and is also used elsewhere in this backend.
            try:
                curve, first, last = BRep_Tool.Curve(edge)
                return curve, float(first), float(last), TopLoc_Location()
            except Exception as error:
                raise RuntimeError("Could not retrieve edge curve and parameter range.") from error

        def _pcurve_result(edge, face):
            try:
                pcurve, first, last = BRep_Tool.CurveOnSurface(edge, face)
                return pcurve, float(first), float(last)
            except Exception as error:
                raise RuntimeError("Could not retrieve edge p-curve and parameter range.") from error

        def _copy_pcurve(pcurve):
            """Return a concrete Geom2d_Curve handle suitable for BRep_Builder.UpdateEdge.

            In pythonocc, Geom2d_Geometry.Copy() is typed as the abstract base
            Geom2d_Geometry.  Passing that object directly to UpdateEdge makes
            SWIG overload resolution fail even when the underlying OCCT object
            is a curve.  DownCast restores the required Geom2d_Curve handle.
            """
            if pcurve is None:
                return None
            try:
                copied = pcurve.Copy()
                curve = Geom2d_Curve.DownCast(copied)
                if curve is not None:
                    return curve
            except Exception:
                pass
            try:
                curve = Geom2d_Curve.DownCast(pcurve)
                if curve is not None:
                    return curve
            except Exception:
                pass
            return pcurve

        def _edge_parameter(vertex, edge):
            value = BRep_Tool.Parameter(vertex, edge)
            if isinstance(value, (list, tuple)):
                if len(value) == 0:
                    raise RuntimeError("Could not retrieve a vertex parameter on an edge.")
                value = value[-1]
            return float(value)

        def _unique(shapes):
            buckets = {}
            result = []
            for shape in shapes:
                try:
                    key = hash(shape)
                except Exception:
                    key = id(shape)
                bucket = buckets.setdefault(key, [])
                duplicate = False
                for existing in bucket:
                    try:
                        if shape.IsSame(existing):
                            duplicate = True
                            break
                    except Exception:
                        pass
                if not duplicate:
                    bucket.append(shape)
                    result.append(shape)
            return result

        def _explore(shape, shape_type, caster):
            items = []
            explorer = TopExp_Explorer(shape, shape_type)
            while explorer.More():
                items.append(caster(explorer.Current()))
                explorer.Next()
            return items

        def _refine_curve(curve):
            target_degree = max(int(curve.Degree()), degree)
            if target_degree > int(curve.Degree()):
                curve.IncreaseDegree(target_degree)

            current_spans = max(1, int(curve.NbKnots()) - 1)
            if subdivisions > current_spans:
                first = float(curve.Knot(curve.FirstUKnotIndex()))
                last = float(curve.Knot(curve.LastUKnotIndex()))
                if last > first:
                    parametric_tolerance = max(1.0e-12, abs(last - first) * 1.0e-12)
                    for index in range(1, subdivisions):
                        parameter = first + (last - first) * float(index) / float(subdivisions)
                        curve.InsertKnot(parameter, 1, parametric_tolerance, False)

        def _refine_surface(surface):
            target_u_degree = max(int(surface.UDegree()), degree)
            target_v_degree = max(int(surface.VDegree()), degree)
            if target_u_degree > int(surface.UDegree()) or target_v_degree > int(surface.VDegree()):
                surface.IncreaseDegree(target_u_degree, target_v_degree)

            u_spans = max(1, int(surface.NbUKnots()) - 1)
            if subdivisions > u_spans:
                first_u = float(surface.UKnot(surface.FirstUKnotIndex()))
                last_u = float(surface.UKnot(surface.LastUKnotIndex()))
                if last_u > first_u:
                    u_tolerance = max(1.0e-12, abs(last_u - first_u) * 1.0e-12)
                    for index in range(1, subdivisions):
                        parameter = first_u + (last_u - first_u) * float(index) / float(subdivisions)
                        surface.InsertUKnot(parameter, 1, u_tolerance, False)

            v_spans = max(1, int(surface.NbVKnots()) - 1)
            if subdivisions > v_spans:
                first_v = float(surface.VKnot(surface.FirstVKnotIndex()))
                last_v = float(surface.VKnot(surface.LastVKnotIndex()))
                if last_v > first_v:
                    v_tolerance = max(1.0e-12, abs(last_v - first_v) * 1.0e-12)
                    for index in range(1, subdivisions):
                        parameter = first_v + (last_v - first_v) * float(index) / float(subdivisions)
                        surface.InsertVKnot(parameter, 1, v_tolerance, False)

        # --------------------------------------------------------------
        # Convert the complete BRep to NURBS while preserving topology.
        # --------------------------------------------------------------
        try:
            converter = BRepBuilderAPI_NurbsConvert(source_shape, True)
            shape = converter.Shape()
            if _is_null_shape(shape):
                raise RuntimeError("BRepBuilderAPI_NurbsConvert returned a null shape.")
        except Exception as error:
            return _error("OCCT could not convert the topology to NURBS geometry.", error)

        # --------------------------------------------------------------
        # Transfer dictionaries using OCCT's source->modified-shape mapping.
        # The geometry below mutates the converted TShapes in place, so these
        # attributes remain attached to the final result.
        # --------------------------------------------------------------
        if transferDictionaries:
            manager = AttributeManager.GetInstance()

            try:
                manager.CopyDictionary(source_shape, shape)
            except Exception:
                pass

            shape_types = (
                TopAbs_VERTEX,
                TopAbs_EDGE,
                TopAbs_WIRE,
                TopAbs_FACE,
                TopAbs_SHELL,
                TopAbs_SOLID,
                TopAbs_COMPSOLID,
                TopAbs_COMPOUND,
            )

            for shape_type in shape_types:
                source_items = _iter_occ_subshapes_unique(source_shape, shape_type)
                target_items = _iter_occ_subshapes_unique(shape, shape_type)

                for index, source_item in enumerate(source_items):
                    if not manager.HasDictionary(source_item):
                        continue

                    target_item = None
                    try:
                        candidate = converter.ModifiedShape(source_item)
                        if not _is_null_shape(candidate):
                            target_item = candidate
                    except Exception:
                        target_item = None

                    if target_item is None and index < len(target_items):
                        target_item = target_items[index]

                    if target_item is not None and not _is_null_shape(target_item):
                        try:
                            manager.CopyDictionary(source_item, target_item)
                        except Exception:
                            pass

        builder = BRep_Builder()
        shape_edge_tool = ShapeBuild_Edge()
        fix_edge_tool = ShapeFix_Edge()

        # --------------------------------------------------------------
        # Incidence helpers. For a BRep with faces, the face trimming data is
        # authoritative: support surfaces and their p-curves are deformed
        # together, then shared 3D edge curves are regenerated from those
        # p-curves. This avoids independently approximating a nonlinear field
        # on both a surface and its boundary curve.
        # --------------------------------------------------------------
        edges = _unique(_explore(shape, TopAbs_EDGE, topods.Edge))
        faces = _unique(_explore(shape, TopAbs_FACE, topods.Face))

        face_bound_edges = []
        for face in faces:
            face_bound_edges.extend(_explore(face, TopAbs_EDGE, topods.Edge))
        face_bound_edges = _unique(face_bound_edges)

        def _is_face_bound_edge(edge):
            for candidate in face_bound_edges:
                try:
                    if edge.IsSame(candidate):
                        return True
                except Exception:
                    pass
            return False

        def _pcurve_signature(pcurve, first, last):
            try:
                p0 = pcurve.Value(first)
                p1 = pcurve.Value(last)
                pm = pcurve.Value(0.5 * (first + last))
                return tuple(round(float(value), 12) for value in (
                    p0.X(), p0.Y(), pm.X(), pm.Y(), p1.X(), p1.Y()
                ))
            except Exception:
                return id(pcurve)

        # --------------------------------------------------------------
        # 1. Deform stand-alone 3D curves (Edges/Wires that are not trimming
        #    any Face). Face-bound edges are deliberately postponed until the
        #    support surfaces and p-curves have been updated.
        # --------------------------------------------------------------
        for edge in edges:
            if _is_face_bound_edge(edge):
                continue
            try:
                if BRep_Tool.Degenerated(edge):
                    continue

                curve, first, last, location = _curve_result(edge)
                if curve is None:
                    try:
                        fix_edge_tool.FixAddCurve3d(edge)
                    except Exception:
                        pass
                    curve, first, last, location = _curve_result(edge)
                if curve is None:
                    raise RuntimeError("The edge has no usable 3D curve.")

                bspline = Geom_BSplineCurve.DownCast(curve.Copy())
                if bspline is not None:
                    bspline.Segment(first, last)
                else:
                    bspline = shapeconstruct.ConvertCurveToBSpline(
                        curve,
                        first,
                        last,
                        tolerance,
                        GeomAbs_C1,
                        max(2, subdivisions),
                        max(3, degree),
                    )

                if bspline is None:
                    raise RuntimeError("Could not obtain a B-Spline representation of an edge.")

                _refine_curve(bspline)

                transform = location.Transformation()
                inverse_transform = transform.Inverted()
                for index in range(1, int(bspline.NbPoles()) + 1):
                    local_point = bspline.Pole(index)
                    world_point = local_point.Transformed(transform)
                    mapped_world_point = _map_point(world_point)
                    mapped_local_point = mapped_world_point.Transformed(inverse_transform)
                    bspline.SetPole(index, mapped_local_point)

                edge_tolerance = max(tolerance, float(BRep_Tool.Tolerance(edge)))
                try:
                    builder.UpdateEdge(edge, bspline, location, edge_tolerance)
                except Exception:
                    builder.UpdateEdge(edge, bspline, edge_tolerance)
                builder.Range(edge, first, last, True)
                builder.SameParameter(edge, False)
                builder.SameRange(edge, False)

            except Exception as error:
                return _error("Could not deform a stand-alone edge NURBS control net.", error)

        # --------------------------------------------------------------
        # 2. Deform each Face support surface while preserving the original
        #    p-curves in UV space. Moving the support-surface poles leaves its
        #    parametric domain intact, so the p-curves remain the correct trim
        #    definitions. They must, however, be re-attached to the new surface
        #    handle after UpdateFace.
        # --------------------------------------------------------------
        for face in faces:
            try:
                u1, u2, v1, v2 = [float(value) for value in _uv_bounds(face)]
                if not all(math.isfinite(value) for value in (u1, u2, v1, v2)):
                    raise RuntimeError("The face has an unbounded parametric domain.")
                if u2 <= u1 or v2 <= v1:
                    raise RuntimeError("The face has an invalid parametric domain.")

                location = TopLoc_Location()
                try:
                    surface = BRep_Tool.Surface(face, location)
                except Exception:
                    surface = BRep_Tool.Surface(face)
                    location = TopLoc_Location()

                if surface is None:
                    raise RuntimeError("Could not retrieve the face support surface.")

                # Cache p-curves BEFORE changing the support-surface handle.
                # A seam edge occurs twice in the face traversal; retain both
                # distinct p-curves so periodic surfaces remain valid.
                occurrences = _explore(face, TopAbs_EDGE, topods.Edge)
                cache = []
                for occurrence in occurrences:
                    try:
                        pcurve, first, last = _pcurve_result(occurrence, face)
                    except Exception:
                        pcurve = None
                    if pcurve is None:
                        continue
                    pcurve = _copy_pcurve(pcurve)
                    if pcurve is None:
                        continue
                    cache.append({
                        "edge": occurrence,
                        "pcurve": pcurve,
                        "first": float(first),
                        "last": float(last),
                        "signature": _pcurve_signature(pcurve, float(first), float(last)),
                    })

                # Group coedge occurrences by underlying TopoDS_Edge and
                # cache seam status BEFORE changing the support surface.
                grouped = []
                for item in cache:
                    group = None
                    for candidate in grouped:
                        try:
                            if item["edge"].IsSame(candidate["edge"]):
                                group = candidate
                                break
                        except Exception:
                            pass
                    if group is None:
                        try:
                            is_seam = bool(BRep_Tool.IsClosed(item["edge"], face))
                        except Exception:
                            is_seam = False
                        group = {
                            "edge": item["edge"],
                            "items": [],
                            "is_seam": is_seam,
                        }
                        grouped.append(group)
                    if all(existing["signature"] != item["signature"] for existing in group["items"]):
                        group["items"].append(item)

                # Some pythonocc/OCCT combinations expose only one seam half
                # through a face traversal. Explicitly query the reversed edge
                # as a second chance; CurveOnSurface uses edge orientation when
                # selecting between the two p-curves of a closed surface.
                for group in grouped:
                    if not group["is_seam"] or len(group["items"]) >= 2:
                        continue
                    try:
                        reversed_edge = topods.Edge(group["edge"].Reversed())
                        pcurve, first, last = _pcurve_result(reversed_edge, face)
                        if pcurve is not None:
                            pcurve = _copy_pcurve(pcurve)
                            if pcurve is None:
                                continue
                            signature = _pcurve_signature(pcurve, float(first), float(last))
                            if all(existing["signature"] != signature for existing in group["items"]):
                                group["items"].append({
                                    "edge": reversed_edge,
                                    "pcurve": pcurve,
                                    "first": float(first),
                                    "last": float(last),
                                    "signature": signature,
                                })
                    except Exception:
                        pass

                bspline_surface = Geom_BSplineSurface.DownCast(surface.Copy())
                if bspline_surface is not None:
                    bspline_surface.Segment(u1, u2, v1, v2)
                else:
                    bspline_surface = shapeconstruct.ConvertSurfaceToBSpline(
                        surface,
                        u1,
                        u2,
                        v1,
                        v2,
                        tolerance,
                        GeomAbs_C1,
                        max(2, subdivisions),
                        max(3, degree),
                    )

                if bspline_surface is None:
                    raise RuntimeError(
                        "Could not obtain a B-Spline representation of a face support surface."
                    )

                _refine_surface(bspline_surface)

                transform = location.Transformation()
                inverse_transform = transform.Inverted()
                for u_index in range(1, int(bspline_surface.NbUPoles()) + 1):
                    for v_index in range(1, int(bspline_surface.NbVPoles()) + 1):
                        local_point = bspline_surface.Pole(u_index, v_index)
                        world_point = local_point.Transformed(transform)
                        mapped_world_point = _map_point(world_point)
                        mapped_local_point = mapped_world_point.Transformed(inverse_transform)
                        bspline_surface.SetPole(u_index, v_index, mapped_local_point)

                # Remove stale edge representations tied to the old surface.
                for group in grouped:
                    try:
                        shape_edge_tool.RemovePCurve(group["edge"], surface, location)
                    except Exception:
                        try:
                            shape_edge_tool.RemovePCurve(group["edge"], face)
                        except Exception:
                            pass

                face_tolerance = max(tolerance, float(BRep_Tool.Tolerance(face)))
                try:
                    builder.UpdateFace(face, bspline_surface, location, face_tolerance)
                except Exception:
                    builder.UpdateFace(face, bspline_surface, face_tolerance)

                # Reattach the old UV trims to the new support surface. For a
                # closed/periodic face retain both seam p-curves when present.
                for group in grouped:
                    edge = group["edge"]
                    items = group["items"]
                    if not items:
                        continue

                    is_seam = bool(group.get("is_seam", False))
                    edge_tolerance = max(tolerance, float(BRep_Tool.Tolerance(edge)))

                    if is_seam and len(items) >= 2:
                        builder.UpdateEdge(
                            edge,
                            items[0]["pcurve"],
                            items[1]["pcurve"],
                            bspline_surface,
                            location,
                            edge_tolerance,
                        )
                    else:
                        builder.UpdateEdge(
                            edge,
                            items[0]["pcurve"],
                            bspline_surface,
                            location,
                            edge_tolerance,
                        )

                    # Preserve the original trimming parameter range.
                    first = items[0]["first"]
                    last = items[0]["last"]
                    try:
                        builder.Range(edge, face, first, last)
                    except Exception:
                        pass

            except Exception as error:
                return _error("Could not deform a face NURBS control net.", error)

        # --------------------------------------------------------------
        # 3. Rebuild face-bound 3D edge curves FROM the deformed support
        #    surfaces and their preserved p-curves. This is the key BRep
        #    consistency step for nonlinear deformations such as Bend.
        # --------------------------------------------------------------
        for edge in face_bound_edges:
            try:
                if BRep_Tool.Degenerated(edge):
                    continue
                edge_tolerance = max(tolerance, float(BRep_Tool.Tolerance(edge)))

                # Explicitly remove the stale 3D representation;
                # ShapeBuild_Edge.RemoveCurve3d is unconditional, unlike the
                # diagnostic ShapeFix_Edge.FixRemoveCurve3d method.
                shape_edge_tool.RemoveCurve3d(edge)

                built = False
                try:
                    built = bool(breplib.BuildCurve3d(
                        edge,
                        edge_tolerance,
                        GeomAbs_C1,
                        max(3, degree),
                        max(30, subdivisions * 4),
                    ))
                except Exception:
                    try:
                        built = bool(breplib.BuildCurve3d(edge, edge_tolerance))
                    except Exception:
                        built = False

                if not built:
                    try:
                        built = bool(shape_edge_tool.BuildCurve3d(edge))
                    except Exception:
                        built = False

                if not built:
                    try:
                        built = bool(fix_edge_tool.FixAddCurve3d(edge))
                    except Exception:
                        built = False

                curve, _, _, _ = _curve_result(edge)
                if not built and curve is None:
                    raise RuntimeError("Could not rebuild the shared 3D curve from its p-curve(s).")

                builder.SameParameter(edge, False)
                builder.SameRange(edge, False)

            except Exception as error:
                return _error("Could not rebuild a deformed face-bound edge.", error)

        # --------------------------------------------------------------
        # 4. Move vertices onto the regenerated shared 3D curves. When a
        #    vertex belongs to several edges, average their evaluated endpoints
        #    and enlarge the tolerance only by the observed spread.
        # --------------------------------------------------------------
        vertices = _unique(_explore(shape, TopAbs_VERTEX, topods.Vertex))
        edge_vertex_cache = []
        for edge in edges:
            edge_vertices = _unique(_explore(edge, TopAbs_VERTEX, topods.Vertex))
            edge_vertex_cache.append((edge, edge_vertices))

        for vertex in vertices:
            candidates = []
            for edge, edge_vertices in edge_vertex_cache:
                belongs = False
                for edge_vertex in edge_vertices:
                    try:
                        if vertex.IsSame(edge_vertex):
                            belongs = True
                            break
                    except Exception:
                        pass
                if not belongs:
                    continue

                try:
                    if BRep_Tool.Degenerated(edge):
                        continue
                    parameter = _edge_parameter(vertex, edge)
                    curve, _, _, location = _curve_result(edge)
                    if curve is None:
                        continue
                    point = curve.Value(parameter)
                    candidates.append(point.Transformed(location.Transformation()))
                except Exception:
                    continue

            try:
                # A topology vertex is an interpolation constraint, not a
                # control point.  The rebuilt incident curves are approximate
                # under a non-linear deformation, so averaging their evaluated
                # endpoints can move a shared vertex away from the exact image
                # of its source position (most visibly at hole boundaries).
                # Keep the vertex itself exact and use the curve endpoints only
                # to enlarge its tolerance enough to reconcile the BRep.
                world_point = _map_point(BRep_Tool.Pnt(vertex))
                spread = max(
                    (world_point.Distance(point) for point in candidates),
                    default=0.0,
                )

                vertex_location = vertex.Location()
                local_point = world_point.Transformed(vertex_location.Transformation().Inverted())
                vertex_tolerance = max(
                    tolerance,
                    float(BRep_Tool.Tolerance(vertex)),
                    spread + tolerance,
                )
                builder.UpdateVertex(vertex, local_point, vertex_tolerance)

            except Exception as error:
                return _error("Could not update a deformed topology vertex.", error)

        # --------------------------------------------------------------
        # 5. Reconcile all 3D curves and p-curves and then validate. OCCT's
        #    SameParameter operation is specifically intended to bring the 2D
        #    and 3D representations of an edge into agreement.
        # --------------------------------------------------------------
        for edge in edges:
            try:
                if not BRep_Tool.Degenerated(edge):
                    fix_edge_tool.FixSameParameter(edge, tolerance)
                fix_edge_tool.FixVertexTolerance(edge)
            except Exception:
                pass

        try:
            shapefix.SameParameter(shape, True, tolerance)
        except Exception:
            pass

        _clean(shape)

        try:
            analyzer = BRepCheck_Analyzer(shape, True)
            if not analyzer.IsValid():
                # A conservative final healing pass is appropriate here: the
                # topology graph has not been rebuilt, only its geometric
                # representations have been changed.
                try:
                    fixer = ShapeFix_Shape(shape)
                    fixer.SetPrecision(tolerance)
                    fixer.Perform()
                    fixed_shape = fixer.Shape()
                    if not _is_null_shape(fixed_shape):
                        fixed_analyzer = BRepCheck_Analyzer(fixed_shape, True)
                        if fixed_analyzer.IsValid():
                            shape = fixed_shape
                        else:
                            return _error("The deformed OCCT BRep is not valid after healing.")
                    else:
                        return _error("The deformed OCCT BRep is not valid.")
                except Exception:
                    return _error("The deformed OCCT BRep is not valid.")
        except Exception as error:
            return _error("The deformed OCCT BRep could not be validated.", error)

        # --------------------------------------------------------------
        # Wrap the already-native OCCT shape. No BREP serialization roundtrip.
        # --------------------------------------------------------------
        try:
            result = Topology.ByOcctShape(shape)
        except Exception as error:
            return _error("Could not wrap the deformed OCCT shape.", error)

        if not isinstance(result, Topology):
            return _error("The deformed OCCT shape did not produce a valid backend topology.")

        result = Topology._rewrap_preserving_wrapper(result, topology)

        # Preserve wrapper relationships. Dictionary transfer remains governed
        # independently by transferDictionaries.
        for attr in ("contents", "contexts", "apertures"):
            if hasattr(topology, attr) and hasattr(result, attr):
                try:
                    setattr(result, attr, copy.deepcopy(getattr(topology, attr)))
                except Exception:
                    pass

        if transferDictionaries:
            try:
                result.dictionary = copy.deepcopy(Topology.GetDictionary(topology))
            except Exception:
                pass

        return result

    def Distance(
        self,
        otherTopology: Any,
        tolerance: float = 0.0001
    ):
        """
        Returns the shortest Euclidean distance between this topology and the
        input topology.

        For topologies represented by one native OCCT shape, the distance is
        computed directly using BRepExtrema_DistShapeShape.

        For aggregate wrappers without one native OCCT shape, such as a
        heterogeneous Cluster, the constituent native shapes are collected and
        the minimum pairwise distance is returned.

        Parameters
        ----------
        otherTopology : Topology
            The other input topology.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.

        Returns
        -------
        float
            The shortest distance between the two topologies, or None if the
            distance cannot be computed.
        """

        if self is None or otherTopology is None:
            return None

        if BRepExtrema_DistShapeShape is None:
            return None

        # ------------------------------------------------------------------
        # Retrieve native operand shapes.
        #
        # Ordinary topology:
        #     one native OCCT shape.
        #
        # Aggregate wrapper such as Cluster:
        #     one or more constituent native OCCT shapes.
        # ------------------------------------------------------------------

        def _operand_shapes(topology):

            shape = _shape_from_topology(
                topology
            )

            if not _is_null_shape(
                shape
            ):
                return [
                    shape
                ]

            try:
                shapes = _collect_boolean_operand_shapes(
                    topology
                )
            except Exception:
                shapes = []

            if not isinstance(
                shapes,
                list
            ):
                return []

            return [
                shape
                for shape in shapes
                if not _is_null_shape(
                    shape
                )
            ]

        shapes_a = _operand_shapes(
            self
        )

        shapes_b = _operand_shapes(
            otherTopology
        )

        if (
            len(shapes_a) == 0
            or len(shapes_b) == 0
        ):
            return None

        # ------------------------------------------------------------------
        # Compute exact minimum pairwise distance.
        # ------------------------------------------------------------------

        best_distance = None

        for shape_a in shapes_a:

            for shape_b in shapes_b:

                try:
                    dist = BRepExtrema_DistShapeShape(
                        shape_a,
                        shape_b
                    )

                    if not dist.IsDone():
                        return None

                    value = float(
                        dist.Value()
                    )

                except Exception:
                    return None

                # ----------------------------------------------------------
                # Validate the native result.
                # ----------------------------------------------------------

                if not math.isfinite(
                    value
                ):
                    return None

                if value < -abs(
                    float(tolerance)
                ):
                    return None

                # Small numerical negative or positive values represent zero.
                if abs(value) <= tolerance:
                    return 0.0

                if (
                    best_distance is None
                    or value < best_distance
                ):
                    best_distance = value

        if best_distance is None:
            return None

        return best_distance
        
    @staticmethod
    def IsSame(topologyA: Any, topologyB: Any) -> bool:
        """
        Returns True if topologyA and topologyB refer to the same underlying
        topological entity (identity), not merely geometric coincidence.
        Mirrors OCCT TopoDS_Shape.IsSame semantics when shapes are available.
        """
        if topologyA is None or topologyB is None:
            return False
        if topologyA is topologyB:
            return True

        shape_a = _shape_from_topology(topologyA)
        shape_b = _shape_from_topology(topologyB)
        if not _is_null_shape(shape_a) and not _is_null_shape(shape_b):
            try:
                return bool(shape_a.IsSame(shape_b))
            except Exception:
                pass

        uuid_a = getattr(topologyA, "_uuid", None)
        uuid_b = getattr(topologyB, "_uuid", None)
        if uuid_a is not None and uuid_b is not None:
            return uuid_a == uuid_b

        return False

    def Merge(self, otherTopology: Any = None, transferDictionary: bool = False, tolerance: float = 0.0001):
        return _make_occ_merge(
            self,
            otherTopology,
            transfer_dictionary=transferDictionary,
            tolerance=tolerance,
        )

    # Union dissolves the operand interface (-> Cell), unlike Merge which
    # preserves it (-> CellComplex). See _make_occ_union / _make_occ_merge.
    def Union(self, otherTopology: Any, transferDictionary: bool = False, tolerance: float = 0.0001):
        result = _make_occ_union(
            self,
            otherTopology,
            transfer_dictionary=transferDictionary,
            tolerance=tolerance,
        )

        if result is None:
            return None

        # Topologic permits connected non-manifold Wires. OCCT Fuse can return
        # such a connected branching 1-D result as a Compound, which the generic
        # wrapper exposes as a Cluster even though the geometry is one valid
        # Topologic Wire. Normalize only the Wire/Wire case, and only when every
        # result Edge can be retained by Wire.ByEdges.
        try:
            from .wire import Wire

            if (
                isinstance(self, Wire)
                and isinstance(otherTopology, Wire)
                and not isinstance(result, Wire)
            ):
                result_edges = result.Edges() or []

                if result_edges:
                    wire = Wire.ByEdges(result_edges)

                    if (
                        wire is not None
                        and len(wire.Edges() or []) == len(result_edges)
                    ):
                        try:
                            wire.dictionary = Topology.GetDictionary(result)
                        except Exception:
                            pass

                        for attr in (
                            "contents",
                            "contexts",
                            "apertures",
                        ):
                            try:
                                setattr(
                                    wire,
                                    attr,
                                    list(getattr(result, attr, []) or [])
                                )
                            except Exception:
                                pass

                        return wire

        except Exception:
            pass

        return result

    def _binary_boolean(
        self,
        otherTopology: Any,
        occt_op_class,
        transferDictionary: bool = False,
        _empty_result=None,
        tolerance: float = 0.0001
    ):
        """Execute Cut/Common with exact OCCT dictionary provenance.

        # BRepGraph Tranche 3: Topology._binary_boolean
        Difference is asymmetric: its root dictionary follows ``self``.
        Common/Intersect merges root dictionaries deterministically with the
        first source winning conflicting keys.  Subtopology dictionaries follow
        Modified/Generated BRepTools_History images.
        """
        if occt_op_class is None:
            return None

        # ByTopologies clusters retain their members with shape=None. Build
        # native compounds (including nested clusters) before Cut/Common.
        shape_a = _ensure_compound_shape(self)
        shape_b = _ensure_compound_shape(otherTopology)
        if _is_null_shape(shape_a) or _is_null_shape(shape_b):
            return None

        try:
            op = occt_op_class(shape_a, shape_b)
            try:
                op.SetToFillHistory(True)
            except Exception:
                pass
            op.SetFuzzyValue(tolerance)
            op.Build()
            if not op.IsDone():
                return None
            result_shape = op.Shape()
            history = op.History() if (transferDictionary or _lineage_capture_active()) else None
        except Exception:
            return None

        if _is_null_shape(result_shape):
            return None

        if occt_op_class in (BRepAlgoAPI_Cut, BRepAlgoAPI_Common):
            if not _iter_occ_subshapes(result_shape, TopAbs_VERTEX):
                # IsDone() was checked: this is certified empty, not failure.
                return _empty_result

        if occt_op_class is BRepAlgoAPI_Cut:
            operand_dimension = min(
                Topology._max_shape_dimension(shape_a),
                Topology._max_shape_dimension(shape_b),
            )
            if operand_dimension >= 2:
                solids = _iter_occ_subshapes(result_shape, TopAbs_SOLID)
                if not solids:
                    faces = _iter_occ_subshapes(result_shape, TopAbs_FACE)
                    if not faces:
                        return None
                    if Topology._total_face_area(result_shape) <= 1e-9:
                        return None

        sources = [
            {
                "role": "self",
                "shape": shape_a,
                "dictionary": None,
                "root_dictionary": Topology.GetDictionary(self),
            },
            {
                "role": "tool",
                "shape": shape_b,
                "dictionary": None,
                "root_dictionary": Topology.GetDictionary(otherTopology),
            },
        ]
        root_policy = "self" if occt_op_class is BRepAlgoAPI_Cut else "merge"

        # Transfer against the raw algorithm result while its history images are
        # guaranteed to refer to the exact native output entities.
        if transferDictionary or _lineage_capture_active():
            try:
                _provenance_transfer_history(
                    result_shape,
                    history,
                    sources,
                    root_policy=root_policy,
                    operation=("Difference" if occt_op_class is BRepAlgoAPI_Cut else "Intersect"),
                )
            except Exception:
                pass

        result_shape = _postprocess_boolean_result(result_shape)
        if _is_null_shape(result_shape):
            return None

        if transferDictionary:
            _provenance_set_root_dictionary(result_shape, sources, policy=root_policy)

        return Topology.ByOcctShape(result_shape)

    def Difference(self, otherTopology: Any, transferDictionary: bool = False, tolerance: float = 0.0001):
        return self._binary_boolean(otherTopology, BRepAlgoAPI_Cut, transferDictionary, tolerance=tolerance)

    def Intersect(
        self,
        otherTopology,
        transferDictionary: bool = False,
        tolerance: float = 0.0001
    ):
        """
        # BRepGraph Tranche 3: Topology.Intersect wrapper provenance
        Returns the intersection of this topology and the input topology.

        The primary operation uses BRepAlgoAPI_Common. For selected same-type
        intersections, the result is wrapped in a Cluster to match TopologicCore
        result semantics. A single Cell is returned directly; disconnected face
        contacts remain a Cluster.

        For Shell/Shell intersections, the raw OCCT Common result is first
        normalized to a Shell before being wrapped in a Cluster. This avoids
        duplicate coincident edge representations.

        If BRepAlgoAPI_Common returns no topology, BRepAlgoAPI_Section is used as
        a fallback to preserve legitimate lower-dimensional contact such as
        face-, edge-, and vertex-only intersections between higher-dimensional
        topologies.

        Parameters
        ----------
        otherTopology : Topology
            The second input topology.
        transferDictionary : bool , optional
            If True, dictionaries from the input topologies are transferred to
            the result. Default is False.

        Returns
        -------
        Topology
            The resulting topology, or None if no intersection exists.
        """

        tolerance = float(tolerance)
        if not math.isfinite(tolerance) or tolerance < 0:
            raise ValueError("Intersect tolerance must be finite and nonnegative")

        if not isinstance(otherTopology, Topology):
            return None

        from .cluster import Cluster
        from .face import Face
        from .shell import Shell
        from .cell import Cell
        from .cell_complex import CellComplex

        # ------------------------------------------------------------------
        # 1. Standard Boolean Common
        # ------------------------------------------------------------------

        result = self._binary_boolean(
            otherTopology,
            BRepAlgoAPI_Common,
            transferDictionary,
            tolerance=tolerance
        )

        # A lower-dimensional solid Common must not pre-empt face contact.
        # This occurs with disconnected contact regions (for example C-shapes).
        needs_face_contact = (result is not None and isinstance(self, Cell)
                              and isinstance(otherTopology, Cell)
                              and Topology._max_shape_dimension(_shape_from_topology(result)) < 2)
        if result is not None and not needs_face_contact:

            # --------------------------------------------------------------
            # Face / Face
            #
            # The normalized geometry is already correct. TopologicCore
            # exposes this Boolean intersection as a Cluster.
            # --------------------------------------------------------------

            if (
                isinstance(self, Face)
                and isinstance(otherTopology, Face)
            ):
                cluster = Cluster.ByTopologies(
                    [result]
                )

                if cluster is not None:
                    if transferDictionary:
                        cluster.SetDictionary(
                            _provenance_root_dictionary(
                                [
                                    ("self", _shape_from_topology(self), Topology.GetDictionary(self)),
                                    ("other", _shape_from_topology(otherTopology), Topology.GetDictionary(otherTopology)),
                                ],
                                policy="merge",
                            )[0]
                        )

                    return cluster

                return result

            # --------------------------------------------------------------
            # Shell / Shell
            #
            # The normal Boolean path can produce a Cluster whose constituent
            # Faces contain duplicate coincident Edge wrappers.
            #
            # Rebuild the raw Common result and normalize that Compound first.
            # This gives the correct Shell topology before wrapping it in a
            # Cluster.
            # --------------------------------------------------------------

            if (
                isinstance(self, Shell)
                and isinstance(otherTopology, Shell)
            ):
                try:
                    shape_a = _shape_from_topology(
                        self
                    )

                    shape_b = _shape_from_topology(
                        otherTopology
                    )

                    if (
                        not _is_null_shape(shape_a)
                        and not _is_null_shape(shape_b)
                    ):
                        common = BRepAlgoAPI_Common(
                            shape_a,
                            shape_b
                        )

                        common.Build()

                        if common.IsDone():
                            common_shape = common.Shape()

                            if not _is_null_shape(common_shape):
                                # The raw Common result is normally a Compound
                                # containing one or more genuine OCCT Shell
                                # subshapes. Wrap those Shells directly.
                                #
                                # Do not normalize the whole Compound through
                                # _wrap_shape_as_topology here: that path can
                                # rebuild a Shell from independent Face wrappers,
                                # causing shared boundary Edges to be represented
                                # multiple times (24 instead of the correct 12
                                # in the regression case).
                                shell_shapes = _iter_occ_subshapes_unique(
                                    common_shape,
                                    TopAbs_SHELL
                                )

                                normalized_shells = []

                                for shell_shape in shell_shapes:
                                    normalized_shell = Topology.ByOcctShape(
                                        shell_shape
                                    )

                                    if normalized_shell is not None:
                                        normalized_shells.append(
                                            normalized_shell
                                        )

                                if normalized_shells:
                                    # Do not use Cluster.ByTopologies here. In
                                    # this specific Boolean result it can create
                                    # another Compound container whose traversal
                                    # re-exposes coincident Shell boundary Edges.
                                    #
                                    # Instead, keep the genuine OCCT Shell shape
                                    # as the Cluster's underlying shape while
                                    # preserving Cluster as the public semantic
                                    # result type required by Topologic.
                                    if len(normalized_shells) == 1:
                                        normalized_shell = normalized_shells[0]

                                        cluster_dictionary = {}

                                        if transferDictionary:
                                            cluster_dictionary = _merge_backend_dictionaries(
                                                Topology.GetDictionary(self),
                                                Topology.GetDictionary(otherTopology)
                                            )

                                        cluster = Cluster(
                                            shape=getattr(normalized_shell, "shape", None),
                                            topologies=[normalized_shell],
                                            dictionary=cluster_dictionary,
                                            contents=[],
                                            contexts=[],
                                            apertures=[]
                                        )

                                        return cluster

                                    cluster = Cluster.ByTopologies(
                                        normalized_shells
                                    )

                                    if cluster is not None:
                                        if transferDictionary:
                                            cluster.SetDictionary(
                                                _provenance_root_dictionary(
                                                    [
                                                        ("self", _shape_from_topology(self), Topology.GetDictionary(self)),
                                                        ("other", _shape_from_topology(otherTopology), Topology.GetDictionary(otherTopology)),
                                                    ],
                                                    policy="merge",
                                                )[0]
                                            )

                                        return cluster

                except Exception:
                    pass

                return result

            # --------------------------------------------------------------
            # Cell / Cell
            # A single solid intersection is a Cell, not a one-item Cluster.
            # Preserve actual aggregate results when more than one cell exists.
            # --------------------------------------------------------------
            if isinstance(self, Cell) and isinstance(otherTopology, Cell):
                if isinstance(result, Cell):
                    return result
                cells = result.Cells() or []
                if len(cells) == 1:
                    single = cells[0]
                    if transferDictionary:
                        single.SetDictionary(Topology.GetDictionary(result))
                    return single
                return result

            # --------------------------------------------------------------
            # CellComplex / CellComplex
            #
            # IMPORTANT:
            #
            # Do not reconstruct this from the raw BRepAlgoAPI_Common shape.
            # The raw Common result exposes fewer solids than the existing
            # TopologicPy Boolean normalization.
            #
            # Preserve the already-normalized CellComplex result and only
            # wrap it in a Cluster.
            # --------------------------------------------------------------

            if (
                isinstance(self, CellComplex)
                and isinstance(otherTopology, CellComplex)
            ):
                cells = []

                try:
                    result.Cells(
                        None,
                        cells
                    )
                except Exception:
                    cells = []

                if cells:
                    cluster = Cluster.ByTopologies(
                        cells
                    )

                    if cluster is not None:
                        if transferDictionary:
                            cluster.SetDictionary(
                                _provenance_root_dictionary(
                                    [
                                        ("self", _shape_from_topology(self), Topology.GetDictionary(self)),
                                        ("other", _shape_from_topology(otherTopology), Topology.GetDictionary(otherTopology)),
                                    ],
                                    policy="merge",
                                )[0]
                            )

                        return cluster

                return result

            # --------------------------------------------------------------
            # All other intersections retain the normal Boolean result.
            # --------------------------------------------------------------

            return result

        # ------------------------------------------------------------------
        # 2. Lower-dimensional contact fallback
        #
        # BRepAlgoAPI_Common returns an empty Compound for cases such as:
        #
        #     Cell / Cell face contact
        #     Cell / Cell edge contact
        #     Cell / Cell vertex contact
        #
        # BRepAlgoAPI_Section preserves those intersections.
        # ------------------------------------------------------------------

        contact_faces = []
        shape_a = _ensure_compound_shape(self)
        shape_b = _ensure_compound_shape(otherTopology)
        for face_a in _iter_occ_subshapes_unique(shape_a, TopAbs_FACE):
            for face_b in _iter_occ_subshapes_unique(shape_b, TopAbs_FACE):
                common = BRepAlgoAPI_Common(face_a, face_b)
                common.SetToFillHistory(True)
                common.SetFuzzyValue(tolerance)
                common.Build()
                if not common.IsDone():
                    raise RuntimeError("Intersect face-contact Common failed")
                common_shape = common.Shape()
                if _is_null_shape(common_shape):
                    continue
                images = _iter_occ_subshapes_unique(common_shape, TopAbs_FACE)
                if not images:
                    continue
                sources = [
                    {"role": "self", "shape": face_a, "root_dictionary": Topology.GetDictionary(self)},
                    {"role": "tool", "shape": face_b, "root_dictionary": Topology.GetDictionary(otherTopology)},
                ]
                if transferDictionary or _lineage_capture_active():
                    _provenance_transfer_history(common_shape, common.History(), sources,
                                                 root_policy="merge", operation="Intersect")
                for face in images:
                    if not any(face.IsSame(old) for old in contact_faces):
                        contact_faces.append(face)
        if contact_faces:
            members = [Topology.ByOcctShape(face) for face in contact_faces]
            if any(member is None for member in members):
                raise RuntimeError("Intersect could not wrap a native contact face")
            if len(members) == 1:
                return members[0]
            # Preserve disconnected native faces as separate Cluster members;
            # do not stitch them into a Wire/Shell or select only one region.
            contact_result = Cluster.ByTopologies(members)
            if contact_result is None:
                raise RuntimeError("Intersect could not build the contact-face Cluster")
            if transferDictionary:
                contact_result.SetDictionary(_provenance_root_dictionary([
                    ("self", shape_a, Topology.GetDictionary(self)),
                    ("tool", shape_b, Topology.GetDictionary(otherTopology)),
                ], policy="merge")[0])
            return contact_result

        if result is not None:
            # Preserve legitimate edge/vertex Common when no faces exist.
            return result

        if BRepAlgoAPI_Section is None:
            return None

        shape_a = _ensure_compound_shape(
            self
        )

        shape_b = _ensure_compound_shape(
            otherTopology
        )

        if (
            _is_null_shape(shape_a)
            or _is_null_shape(shape_b)
        ):
            return None

        try:
            section = BRepAlgoAPI_Section(
                shape_a,
                shape_b,
                False
            )

            section.SetFuzzyValue(tolerance)
            section.Build()

            if not section.IsDone():
                return None

            section_shape = section.Shape()

        except Exception:
            return None

        if _is_null_shape(section_shape):
            return None

        # ------------------------------------------------------------------
        # Section can return a non-null but empty Compound.
        # A genuine intersection must contain at least one Vertex.
        # ------------------------------------------------------------------

        vertices = _iter_occ_subshapes_unique(
            section_shape,
            TopAbs_VERTEX
        )

        if not vertices:
            return None

        # ------------------------------------------------------------------
        # Normalize the Section result.
        # ------------------------------------------------------------------

        section_result = Topology.ByOcctShape(
            section_shape
        )

        if section_result is None:
            return None

        # ------------------------------------------------------------------
        # Dictionary transfer.
        # ------------------------------------------------------------------

        if transferDictionary:
            dictionary = _provenance_root_dictionary(
                [
                    ("self", _ensure_compound_shape(self), Topology.GetDictionary(self)),
                    ("other", _ensure_compound_shape(otherTopology), Topology.GetDictionary(otherTopology)),
                ],
                policy="merge",
            )[0]

            try:
                section_result = Topology.SetDictionary(
                    section_result,
                    dictionary
                )
            except Exception:
                section_result.dictionary = dictionary

        return section_result
    def XOR(self, otherTopology: Any, transferDictionary: bool = False, tolerance: float = 0.0001):
        # Keep successful nonempty branches; never reinterpret failure as empty.
        empty = object()
        a_minus_b = self._binary_boolean(otherTopology, BRepAlgoAPI_Cut,
                                        transferDictionary, _empty_result=empty, tolerance=tolerance)
        b_minus_a = Topology._binary_boolean(otherTopology, self, BRepAlgoAPI_Cut,
                                            transferDictionary, _empty_result=empty, tolerance=tolerance)
        if a_minus_b is None or b_minus_a is None:
            return None
        pieces = [item for item in (a_minus_b, b_minus_a) if item is not empty]
        if not pieces:
            return None
        if len(pieces) == 1:
            return pieces[0]
        from topologicpy.Cluster import Cluster
        return Cluster.ByTopologies(pieces)

    @staticmethod
    def _max_shape_dimension(shape: Any) -> int:
        """
        Highest topological dimension present in ``shape``: 0=Vertex,
        1=Edge/Wire, 2=Face/Shell, 3=Solid/CompSolid, -1=null/unknown.
        For an aggregate (Compound/Cluster) this is the highest dimension
        found among its subshapes, since a heterogeneous cluster has no
        single ShapeType of its own.
        """
        if _is_null_shape(shape):
            return -1
        try:
            shape_type = shape.ShapeType()
        except Exception:
            return -1
        if shape_type in (TopAbs_SOLID, TopAbs_COMPSOLID):
            return 3
        if shape_type in (TopAbs_SHELL, TopAbs_FACE):
            return 2
        if shape_type in (TopAbs_WIRE, TopAbs_EDGE):
            return 1
        if shape_type == TopAbs_VERTEX:
            return 0
        if _iter_occ_subshapes(shape, TopAbs_SOLID):
            return 3
        if _iter_occ_subshapes(shape, TopAbs_FACE):
            return 2
        if _iter_occ_subshapes(shape, TopAbs_EDGE):
            return 1
        if _iter_occ_subshapes(shape, TopAbs_VERTEX):
            return 0
        return -1

    @staticmethod
    def _total_face_area(shape: Any) -> float:
        """Sum of the surface area of every FACE subshape of ``shape``."""
        if _is_null_shape(shape) or brepgprop is None or GProp_GProps is None:
            return 0.0
        try:
            total = 0.0
            for face_shape in _iter_occ_subshapes(shape, TopAbs_FACE):
                props = GProp_GProps()
                brepgprop.SurfaceProperties(face_shape, props)
                total += props.Mass()
            return total
        except Exception:
            return 0.0

    @staticmethod
    def _piece_belongs_to_any(piece_shape, reference_shapes) -> bool:
        """
        Tell which fuse fragment came from self's material: Solid/Shell references classify by
        centre-of-mass (BRepClass3d_SolidClassifier); Face references use the 2D surface/UV
        FClass2d test, since SolidClassifier is undefined for a bare face.
        """
        if GProp_GProps is None or brepgprop is None:
            return False
        try:
            props = GProp_GProps()
            if piece_shape.ShapeType() == TopAbs_FACE:
                brepgprop.SurfaceProperties(piece_shape, props)
            else:
                brepgprop.VolumeProperties(piece_shape, props)
            center = props.CentreOfMass()
        except Exception:
            return False

        for reference in reference_shapes:
            try:
                if reference.ShapeType() == TopAbs_FACE:
                    if Topology._point_in_face_shape(reference, center, 1e-6):
                        return True
                    continue
                if BRepClass3d_SolidClassifier is None:
                    continue
                classifier = BRepClass3d_SolidClassifier(reference)
                classifier.Perform(center, 1e-6)
                state = classifier.State()
                if state in (_TopAbs_IN, _TopAbs_ON):
                    return True
            except Exception:
                continue
        return False

    @staticmethod
    def _point_in_face_shape(occ_face, pnt, tolerance: float = 0.0001) -> bool:
        """Raw-shape point-in-face test (see _piece_belongs_to_any)."""
        try:
            from OCC.Core.BRep import BRep_Tool
            from OCC.Core.TopoDS import topods
            from OCC.Core.gp import gp_Pnt2d
            from OCC.Core.GeomAPI import GeomAPI_ProjectPointOnSurf
            from OCC.Core.BRepTopAdaptor import BRepTopAdaptor_FClass2d
            from OCC.Core.TopAbs import TopAbs_IN, TopAbs_ON

            face = topods.Face(occ_face)
            surface = BRep_Tool.Surface(face)
            if surface is None:
                return False

            projector = GeomAPI_ProjectPointOnSurf(pnt, surface)
            if projector.NbPoints() < 1:
                return False
            if projector.LowerDistance() > tolerance:
                return False
            u_raw, v_raw = projector.LowerDistanceParameters()

            classifier = BRepTopAdaptor_FClass2d(face, tolerance)
            state = classifier.Perform(gp_Pnt2d(u_raw, v_raw))
            return state in (TopAbs_IN, TopAbs_ON)
        except Exception:
            return False

    def _partition_by(self, otherTopology: Any, transferDictionary: bool = False, promote: bool = True, tolerance: float = 0.0001):
        """
        BOPAlgo_CellsBuilder partition shared by Divide/Slice/Impose/Imprint. Use
        AddAllToResult() -- AddToResult(original) and Modified()/IsDeleted() both fail to
        track Solid-level splits -- then keep only fragments whose centre of mass classifies
        on/in self's original shapes. promote=True (Slice/Imprint/Divide) forces a CellComplex;
        False (Impose) preserves disjoint operands as a Cluster.
        """
        if BOPAlgo_CellsBuilder is None:
            return None
        shapes_a = _collect_boolean_operand_shapes(self)
        shapes_b = _collect_boolean_operand_shapes(otherTopology)
        if not shapes_a or not shapes_b:
            return None
        try:
            builder = BOPAlgo_CellsBuilder()
            for shape in shapes_a:
                builder.AddArgument(shape)
            for shape in shapes_b:
                builder.AddArgument(shape)
            builder.SetFuzzyValue(tolerance)
            builder.Perform()
            if hasattr(builder, "HasErrors") and builder.HasErrors():
                return None

            builder.AddAllToResult()
            all_result_shape = builder.Shape()
        except Exception:
            return None

        if _is_null_shape(all_result_shape):
            return None

        target_type = TopAbs_SOLID
        if all(not _is_null_shape(s) and s.ShapeType() == TopAbs_FACE for s in shapes_a):
            target_type = TopAbs_FACE

        pieces = _iter_occ_subshapes(all_result_shape, target_type)
        kept = [p for p in pieces if Topology._piece_belongs_to_any(p, shapes_a)]
        if not kept:
            return None

        try:
            empty_avoid = TopTools_ListOfShape()
            for piece in kept:
                to_take = TopTools_ListOfShape()
                to_take.Append(piece)
                builder.AddToResult(to_take, empty_avoid)
            builder.MakeContainers()
            result_shape = builder.Shape()
        except Exception:
            return None

        if _is_null_shape(result_shape):
            return None
        result_shape = _postprocess_boolean_result(result_shape)
        if promote:
            result_shape = _promote_to_compsolid_if_multi_solid(result_shape, force=True)

        result_dictionary = {}
        if transferDictionary:
            result_dictionary = _merge_backend_dictionaries(
                Topology.GetDictionary(self), Topology.GetDictionary(otherTopology)
            )
        return Topology.ByOcctShape(result_shape, dictionary=result_dictionary)

    def Divide(self, otherTopology: Any, transferDictionary: bool = False, tolerance: float = 0.0001):
        return self._partition_by(otherTopology, transferDictionary, tolerance=tolerance)

    def _split_by_tool(self, otherTopology: Any, transferDictionary: bool = False, tolerance: float = 0.0001):
        """Split self by a tool while keeping self's fragments.

        # BRepGraph Tranche 3: Topology._split_by_tool
        The result root follows self; exact Modified/Generated lineage from the
        Splitter transfers dictionaries to surviving and newly-created
        subtopologies, including tool-derived interface Faces.
        """
        if BOPAlgo_Splitter is None:
            return None
        shapes_a = _collect_boolean_operand_shapes(self)
        shapes_b = _collect_boolean_operand_shapes(otherTopology)
        if not shapes_a or not shapes_b:
            return None
        try:
            splitter = BOPAlgo_Splitter()
            try:
                splitter.SetToFillHistory(True)
            except Exception:
                pass
            for shape in shapes_a:
                splitter.AddArgument(shape)
            for shape in shapes_b:
                splitter.AddTool(shape)
            splitter.SetFuzzyValue(tolerance)
            splitter.Perform()
            if hasattr(splitter, "HasErrors") and splitter.HasErrors():
                return None
            result_shape = splitter.Shape()
            history = splitter.History() if (transferDictionary or _lineage_capture_active()) else None
        except Exception:
            return None
        if _is_null_shape(result_shape):
            return None

        source_shape_a = shapes_a[0] if len(shapes_a) == 1 else _compound_of_shapes(shapes_a)
        source_shape_b = shapes_b[0] if len(shapes_b) == 1 else _compound_of_shapes(shapes_b)
        sources = [
            {
                "role": "self",
                "shape": source_shape_a,
                "dictionary": None,
                "root_dictionary": Topology.GetDictionary(self),
            },
            {
                "role": "tool",
                "shape": source_shape_b,
                "dictionary": None,
                "root_dictionary": Topology.GetDictionary(otherTopology),
            },
        ]
        if transferDictionary or _lineage_capture_active():
            try:
                _provenance_transfer_history(
                    result_shape,
                    history,
                    sources,
                    root_policy="self",
                    operation="Slice",
                )
            except Exception:
                pass

        result_shape = _postprocess_boolean_result(result_shape)
        result_shape = _promote_to_compsolid_if_multi_solid(result_shape, force=True)
        if transferDictionary:
            _provenance_set_root_dictionary(result_shape, sources, policy="self")
        return Topology.ByOcctShape(result_shape)

    def Slice(self, otherTopology: Any, transferDictionary: bool = False, tolerance: float = 0.0001):
        return self._split_by_tool(otherTopology, transferDictionary, tolerance=tolerance)

    @staticmethod
    def _collect_impose_operand_shapes(topology: Any) -> list:
        """
        Always decompose container types (Wire/Shell/CellComplex/Cluster) into their immediate
        sub-shapes, unlike _collect_boolean_operand_shapes: Impose needs one AddToResult (and
        one material index) per original operand shape, so a merged COMPSOLID would collapse
        separate tool-material groups and lose a cell/face.
        """
        if topology is None:
            return []
        from .wire import Wire as _Wire
        from .shell import Shell as _Shell
        from .cell_complex import CellComplex as _CellComplex
        from .cluster import Cluster as _Cluster

        if isinstance(topology, _Wire):
            children = topology.Edges() or []

        elif isinstance(topology, _Shell):
            children = topology.Faces() or []

        elif isinstance(topology, _CellComplex):
            children = topology.Cells() or []

        elif isinstance(topology, _Cluster):
            children = getattr(topology, "topologies", None) or []

        else:
            children = None

        if children:
            result = []
            for child in children:
                result.extend(Topology._collect_impose_operand_shapes(child))
            return _deduplicate_by_identity(result) if result else []

        shape = _shape_from_topology(topology)
        if _is_null_shape(shape):
            return []
        return [shape]

    def Impose(self, otherTopology: Any, transferDictionary: bool = False, tolerance: float = 0.0001):
        """Impose otherTopology while preserving exact dictionary provenance.

        # BRepGraph Tranche 3: Topology.Impose
        CellsBuilder history supplies source-to-fragment lineage; the result
        root uses deterministic first-source-wins merging.
        """
        if BOPAlgo_CellsBuilder is None:
            return None
        shapes_a = Topology._collect_impose_operand_shapes(self)
        shapes_b = Topology._collect_impose_operand_shapes(otherTopology)
        if not shapes_a or not shapes_b:
            return None
        try:
            builder = BOPAlgo_CellsBuilder()
            try:
                builder.SetToFillHistory(True)
            except Exception:
                pass
            args = TopTools_ListOfShape()
            for shape in shapes_a + shapes_b:
                args.Append(shape)
            builder.SetArguments(args)
            builder.SetFuzzyValue(tolerance)
            builder.Perform()
            if builder.HasErrors():
                return None

            split_history = None
            if transferDictionary or _lineage_capture_active():
                # CellsBuilder exposes the split images only after result
                # population. Freeze them before Impose's selection rewrites
                # the live history. No extra Boolean geometry is computed.
                builder.AddAllToResult()
                if builder.HasErrors():
                    raise RuntimeError("Impose could not populate split history")
                split_history = _SelectedSplitHistory(builder.History(), shapes_a + shapes_b)
                builder.RemoveAllFromResult()
                if builder.HasErrors():
                    raise RuntimeError("Impose could not reset temporary selection")

            for a in shapes_a:
                to_take = TopTools_ListOfShape()
                to_take.Append(a)
                to_avoid = TopTools_ListOfShape()
                for b in shapes_b:
                    to_avoid.Append(b)
                builder.AddToResult(to_take, to_avoid)

            for i, b in enumerate(shapes_b, start=1):
                to_take = TopTools_ListOfShape()
                to_take.Append(b)
                to_avoid = TopTools_ListOfShape()
                builder.AddToResult(to_take, to_avoid, i, True)

            builder.MakeContainers()
            result_shape = builder.Shape()
            history = (split_history.finish(builder.History(), result_shape)
                       if split_history is not None else None)
        except Exception:
            return None
        if _is_null_shape(result_shape):
            return None

        source_shape_a = shapes_a[0] if len(shapes_a) == 1 else _compound_of_shapes(shapes_a)
        source_shape_b = shapes_b[0] if len(shapes_b) == 1 else _compound_of_shapes(shapes_b)
        sources = [
            {
                "role": "self",
                "shape": source_shape_a,
                "dictionary": None,
                "root_dictionary": Topology.GetDictionary(self),
            },
            {
                "role": "other",
                "shape": source_shape_b,
                "dictionary": None,
                "root_dictionary": Topology.GetDictionary(otherTopology),
            },
        ]
        if transferDictionary or _lineage_capture_active():
            try:
                _provenance_transfer_history(
                    result_shape,
                    history,
                    sources,
                    root_policy="merge",
                    operation="Impose",
                )
            except Exception:
                pass

        result_shape = _postprocess_boolean_result(result_shape)
        if transferDictionary:
            _provenance_set_root_dictionary(result_shape, sources, policy="merge")
        return Topology.ByOcctShape(result_shape)

    def Imprint(self, otherTopology: Any, transferDictionary: bool = False, tolerance: float = 0.0001):
        return self._split_by_tool(otherTopology, transferDictionary, tolerance=tolerance)

    # -------------------------------------------------------------------
    # Transform / Translate / Rotate / Scale
    # -------------------------------------------------------------------

    @staticmethod
    def _apply_transform_to_members(topology: Any, apply_one, transfer_dictionaries: bool = True) -> Any:
        """
        # BRepGraph Tranche 3: Topology._apply_transform_to_members root persistence
        Applies a transformation recursively to the direct members of an
        aggregate topology and rebuilds the same aggregate type.

        This is used for heterogeneous Clusters, for which transforming the
        complete OCCT Compound as one shape can alter the intermediate topology
        hierarchy, and as a fallback for aggregate wrappers without a usable
        native OCCT shape.

        Parameters
        ----------
        topology : Topology
            The input aggregate topology.
        apply_one : callable
            A callable that accepts one topology and returns its transformed
            topology.

        Returns
        -------
        Topology
            The transformed aggregate topology, or None if the transformation
            or reconstruction fails.
        """
        type_name = _topology_type_name(
            topology
        )

        # ------------------------------------------------------------------
        # Cluster
        #
        # Always preserve the actual DIRECT constituent hierarchy.
        #
        # ByTopologies clusters retain direct member wrappers with shape=None.
        # Imported native compounds may lack cached wrappers; recover their
        # direct children below rather than flattening their hierarchy.
        # ------------------------------------------------------------------

        if type_name == "Cluster":

            from .cluster import Cluster

            members = []

            try:
                members = topology.Topologies()
            except Exception:
                members = []

            if members is None:
                members = []
            elif not isinstance(members, list):
                try:
                    members = list(members)
                except Exception:
                    members = []

            if len(members) == 0:
                try:
                    members = list(
                        getattr(
                            topology,
                            "topologies",
                            []
                        )
                        or []
                    )
                except Exception:
                    members = []

            # Compound-backed Clusters may not cache their direct wrappers.
            # Recover DIRECT native children without recursively flattening
            # their internal topology.
            if len(members) == 0:
                try:
                    from OCC.Core.TopoDS import TopoDS_Iterator

                    cluster_shape = _shape_from_topology(topology)
                    if not _is_null_shape(cluster_shape):
                        iterator = TopoDS_Iterator(cluster_shape)
                        while iterator.More():
                            member = Topology.ByOcctShape(iterator.Value())
                            if isinstance(member, Topology):
                                members.append(member)
                            iterator.Next()
                except Exception:
                    members = []

            members = [
                member
                for member in members
                if isinstance(
                    member,
                    Topology
                )
            ]

            if len(members) == 0:
                return None

            transformed = []

            for member in members:

                try:
                    transformed_member = apply_one(
                        member
                    )
                except Exception:
                    transformed_member = None

                # Do not silently drop a failed constituent.
                if not isinstance(
                    transformed_member,
                    Topology
                ):
                    return None

                transformed.append(
                    transformed_member
                )

            if len(transformed) != len(members):
                return None

            try:
                result = Cluster.ByTopologies(
                    transformed
                )
            except Exception:
                result = None

            if not isinstance(
                result,
                Cluster
            ):
                return None

            # --------------------------------------------------------------
            # Preserve aggregate metadata.
            # --------------------------------------------------------------

            if transfer_dictionaries:
                try:
                    result.SetDictionary(Topology.GetDictionary(topology))
                except Exception:
                    pass

            try:
                result.contents = list(
                    getattr(
                        topology,
                        "contents",
                        []
                    )
                    or []
                )
            except Exception:
                pass

            try:
                result.contexts = list(
                    getattr(
                        topology,
                        "contexts",
                        []
                    )
                    or []
                )
            except Exception:
                pass

            try:
                result.apertures = list(
                    getattr(
                        topology,
                        "apertures",
                        []
                    )
                    or []
                )
            except Exception:
                pass

            return result

        # ------------------------------------------------------------------
        # CellComplex fallback
        #
        # Normally a shaped CellComplex is transformed natively as one OCCT
        # CompSolid. This branch is primarily for wrappers without a usable
        # shape.
        # ------------------------------------------------------------------

        if type_name == "CellComplex":

            from .cell_complex import CellComplex

            cells = []

            try:
                cells = list(
                    getattr(
                        topology,
                        "cells",
                        []
                    )
                    or []
                )
            except Exception:
                cells = []

            if len(cells) == 0:
                try:
                    cells = topology.Cells()
                except Exception:
                    cells = []

            cells = [
                cell
                for cell in cells
                if isinstance(
                    cell,
                    Topology
                )
            ]

            if len(cells) == 0:
                return None

            transformed = []

            for cell in cells:

                try:
                    transformed_cell = apply_one(
                        cell
                    )
                except Exception:
                    transformed_cell = None

                if not isinstance(
                    transformed_cell,
                    Topology
                ):
                    return None

                transformed.append(
                    transformed_cell
                )

            if len(transformed) != len(cells):
                return None

            try:
                result = CellComplex.ByCells(
                    transformed
                )
            except Exception:
                result = None

            if result is None:
                return None

            if transfer_dictionaries:
                try:
                    result.SetDictionary(Topology.GetDictionary(topology))
                except Exception:
                    pass

            try:
                result.contents = list(
                    getattr(
                        topology,
                        "contents",
                        []
                    )
                    or []
                )
            except Exception:
                pass

            try:
                result.contexts = list(
                    getattr(
                        topology,
                        "contexts",
                        []
                    )
                    or []
                )
            except Exception:
                pass

            try:
                result.apertures = list(
                    getattr(
                        topology,
                        "apertures",
                        []
                    )
                    or []
                )
            except Exception:
                pass

            return result

        return None


    @staticmethod
    def _rewrap_preserving_wrapper(result: Any, original: Any) -> Any:
        """
        Preserves a CellComplex wrapper across transforms even when the underlying
        transformed OCCT result contains only one Solid.
        """
        if result is None:
            return None

        try:
            from .cell import Cell
            from .cell_complex import CellComplex

            if not isinstance(original, CellComplex):
                return result

            if isinstance(result, CellComplex):
                return result

            if isinstance(result, Cell):
                return CellComplex(
                    shape=getattr(result, "shape", None),
                    cells=[],
                    dictionary=Topology.GetDictionary(original),
                    contents=list(getattr(original, "contents", []) or []),
                    contexts=list(getattr(original, "contexts", []) or []),
                    apertures=list(getattr(original, "apertures", []) or []),
                )

        except Exception:
            pass

        return result

    def _apply_gtrsf(
        self,
        gtrsf,
        dictionary_passthrough: bool = True
    ):
        """Apply a general affine transform with exact subtopology lineage.

        # BRepGraph Tranche 3: Topology._apply_gtrsf
        ``ModifiedShape`` maps root/subtopology dictionaries to their exact
        transformed counterparts; no centroid/selector matching is used.
        """
        if _topology_type_name(self) == "Cluster":
            return Topology._apply_transform_to_members(
                self,
                lambda member: Topology._apply_gtrsf(member, gtrsf, dictionary_passthrough),
                transfer_dictionaries=dictionary_passthrough,
            )

        shape = _shape_from_topology(self)
        if not _is_null_shape(shape) and BRepBuilderAPI_GTransform is not None:
            try:
                maker = BRepBuilderAPI_GTransform(shape, gtrsf, True)
                if maker.IsDone():
                    new_shape = maker.Shape()
                    if not _is_null_shape(new_shape):
                        if dictionary_passthrough:
                            try:
                                _provenance_transfer_modifier(
                                    shape,
                                    new_shape,
                                    maker,
                                    root_dictionary=Topology.GetDictionary(self),
                                    operation="GTransform",
                                )
                            except Exception:
                                pass
                        else:
                            # Capture is independent of dictionary writes.
                            _capture_modifier_only(shape, new_shape, maker, "GTransform")
                        result = Topology.ByOcctShape(new_shape)
                        if result is not None:
                            result = Topology._rewrap_preserving_wrapper(result, self)
                            return result
            except Exception:
                pass

        return Topology._apply_transform_to_members(
            self,
            lambda member: Topology._apply_gtrsf(member, gtrsf, dictionary_passthrough),
            transfer_dictionaries=dictionary_passthrough,
        )

    def Translate(self, x: float, y: float, z: float, transferDictionaries: bool = True):
        if self is None:
            return None
        try:
            trsf = gp_Trsf()
            trsf.SetTranslation(gp_Vec(float(x), float(y), float(z)))
        except Exception:
            return None
        return Topology._apply_rigid(self, trsf, bool(transferDictionaries))

    def Rotate(
        self,
        origin: Any,
        x: float,
        y: float,
        z: float,
        angle: float,
        transferDictionaries: bool = True,
    ):
        if self is None:
            return None
        try:
            ox, oy, oz = origin.x, origin.y, origin.z
            axis = gp_Ax1(
                gp_Pnt(float(ox), float(oy), float(oz)),
                gp_Dir(float(x), float(y), float(z)),
            )
            trsf = gp_Trsf()
            trsf.SetRotation(axis, math.radians(float(angle)))
        except Exception:
            return None
        return Topology._apply_rigid(self, trsf, bool(transferDictionaries))

    def Scale(
        self,
        origin: Any,
        x: float,
        y: float,
        z: float,
        transferDictionaries: bool = True,
    ):
        if self is None:
            return None
        try:
            ox, oy, oz = origin.x, origin.y, origin.z
            gtrsf = gp_GTrsf()
            mat = gp_Mat(
                float(x), 0.0, 0.0,
                0.0, float(y), 0.0,
                0.0, 0.0, float(z),
            )
            gtrsf.SetVectorialPart(mat)
            gtrsf.SetTranslationPart(
                gp_XYZ(
                    ox - float(x) * ox,
                    oy - float(y) * oy,
                    oz - float(z) * oz,
                )
            )
        except Exception:
            return None
        return Topology._apply_gtrsf(self, gtrsf, bool(transferDictionaries))

    def Transform(self, *args, transferDictionaries: bool = True):
        """Apply a 4x4/12-scalar affine transform with optional exact metadata lineage."""
        if self is None:
            return None
        try:
            if len(args) == 1 and isinstance(args[0], (list, tuple)):
                flat_or_nested = args[0]
                if len(flat_or_nested) == 4 and isinstance(flat_or_nested[0], (list, tuple)):
                    m = [v for row in flat_or_nested for v in row]
                else:
                    m = list(flat_or_nested)
                tx, ty, tz = m[3], m[7], m[11]
                a00, a01, a02 = m[0], m[1], m[2]
                a10, a11, a12 = m[4], m[5], m[6]
                a20, a21, a22 = m[8], m[9], m[10]
            elif len(args) == 12:
                tx, ty, tz, a00, a01, a02, a10, a11, a12, a20, a21, a22 = args
            else:
                return None

            gtrsf = gp_GTrsf()
            mat = gp_Mat(
                float(a00), float(a01), float(a02),
                float(a10), float(a11), float(a12),
                float(a20), float(a21), float(a22),
            )
            gtrsf.SetVectorialPart(mat)
            gtrsf.SetTranslationPart(gp_XYZ(float(tx), float(ty), float(tz)))
        except Exception:
            return None
        return Topology._apply_gtrsf(self, gtrsf, bool(transferDictionaries))

    @staticmethod
    def _apply_rigid(topology: Any, trsf, transfer_dictionaries: bool = True) -> Any:
        """Apply a rigid transform with exact subtopology dictionary lineage.

        # BRepGraph Tranche 3: Topology._apply_rigid
        BRepBuilderAPI_Transform.ModifiedShape supplies exact one-to-one
        correspondence for root and native subtopologies.
        """
        if _topology_type_name(topology) == "Cluster":
            return Topology._apply_transform_to_members(
                topology,
                lambda member: Topology._apply_rigid(member, trsf, transfer_dictionaries),
                transfer_dictionaries=transfer_dictionaries,
            )

        shape = _shape_from_topology(topology)
        if not _is_null_shape(shape) and BRepBuilderAPI_Transform is not None:
            try:
                maker = BRepBuilderAPI_Transform(shape, trsf, True)
                if maker.IsDone():
                    new_shape = maker.Shape()
                    if not _is_null_shape(new_shape):
                        if transfer_dictionaries:
                            try:
                                _provenance_transfer_modifier(
                                    shape,
                                    new_shape,
                                    maker,
                                    root_dictionary=Topology.GetDictionary(topology),
                                    operation="Transform",
                                )
                            except Exception:
                                pass
                        else:
                            # Capture is independent of dictionary writes.
                            _capture_modifier_only(shape, new_shape, maker, "Transform")
                        result = Topology.ByOcctShape(new_shape)
                        if result is not None:
                            result = Topology._rewrap_preserving_wrapper(result, topology)
                            return result
            except Exception:
                pass

        return Topology._apply_transform_to_members(
            topology,
            lambda member: Topology._apply_rigid(member, trsf, transfer_dictionaries),
            transfer_dictionaries=transfer_dictionaries,
        )

    # -------------------------------------------------------------------
    # Analysis / copy / mass properties
    # -------------------------------------------------------------------

    def GetOcctShape(self):
        return _ensure_compound_shape(self)

    def Analyze(self):
        type_name = _topology_type_name(self) or "Unknown"
        counts = {}
        for label, getter in (
            ("Vertices", "Vertices"), ("Edges", "Edges"), ("Wires", "Wires"),
            ("Faces", "Faces"), ("Shells", "Shells"), ("Cells", "Cells"),
        ):
            try:
                counts[label] = len(getattr(Topology, getter)(self) or [])
            except Exception:
                counts[label] = 0
        return f"{type_name}: " + ", ".join(f"{k}={v}" for k, v in counts.items())

    def Cleanup(self):
        if _topology_type_name(self) == "Cluster":
            return Topology._apply_transform_to_members(
                self, lambda member: member.Cleanup(),
            )
        shape = _shape_from_topology(self)
        if _is_null_shape(shape) or ShapeUpgrade_UnifySameDomain is None:
            return self
        try:
            unifier = ShapeUpgrade_UnifySameDomain(shape, True, True, True)
            unifier.SetSafeInputMode(True)
            unifier.Build()
            new_shape = unifier.Shape()
            if _is_null_shape(new_shape):
                return self
            result = Topology.ByOcctShape(new_shape)
            if result is None:
                return self
            result.SetDictionary(Topology.GetDictionary(self))
            for name in ("contents", "contexts", "apertures"):
                setattr(result, name, list(getattr(self, name, []) or []))
            return result
        except Exception:
            return self

    def Copy(self):
        """
        Creates an independent copy of the topology.

        Native OCCT topologies are copied using BRepBuilderAPI_Copy. Aggregate
        wrappers without a native OCCT shape, such as a lightweight Cluster,
        are copied recursively constituent-by-constituent.

        The topology's parent dictionary is deep-copied. A native copy failure
        is returned as None rather than being concealed by wrapping the original
        OCCT shape.

        Returns
        -------
        Topology
            An independent copy of the topology, or None if copying fails.
        """

        if self is None:
            return None

        type_name = _topology_type_name(
            self
        )

        shape = _shape_from_topology(
            self
        )

        # ------------------------------------------------------------------
        # Aggregate wrappers without one native OCCT shape.
        # ------------------------------------------------------------------

        if _is_null_shape(shape):

            # --------------------------------------------------------------
            # Cluster
            # --------------------------------------------------------------

            if type_name == "Cluster":

                from .cluster import Cluster

                members = []

                try:
                    members = self.Topologies()
                except Exception:
                    members = []

                if not isinstance(
                    members,
                    list
                ):
                    members = []

                if len(members) == 0:
                    try:
                        members = list(
                            getattr(
                                self,
                                "topologies",
                                []
                            )
                            or []
                        )
                    except Exception:
                        members = []

                if len(members) == 0:
                    return None

                copied_members = []

                for member in members:

                    if not isinstance(
                        member,
                        Topology
                    ):
                        return None

                    try:
                        copied_member = member.Copy()
                    except Exception:
                        copied_member = None

                    if not isinstance(
                        copied_member,
                        Topology
                    ):
                        return None

                    copied_members.append(
                        copied_member
                    )

                try:
                    result = Cluster.ByTopologies(
                        copied_members
                    )
                except Exception:
                    result = None

                if not isinstance(
                    result,
                    Cluster
                ):
                    return None

                try:
                    result.dictionary = copy.deepcopy(
                        Topology.GetDictionary(
                            self
                        )
                    )
                except Exception:
                    pass

                return result

            # --------------------------------------------------------------
            # Shapeless CellComplex fallback.
            # --------------------------------------------------------------

            if type_name == "CellComplex":

                from .cell_complex import CellComplex

                try:
                    cells = list(
                        getattr(
                            self,
                            "cells",
                            []
                        )
                        or []
                    )
                except Exception:
                    cells = []

                if len(cells) == 0:
                    try:
                        cells = self.Cells()
                    except Exception:
                        cells = []

                if not isinstance(
                    cells,
                    list
                ) or len(cells) == 0:
                    return None

                copied_cells = []

                for cell in cells:

                    if not isinstance(
                        cell,
                        Topology
                    ):
                        return None

                    try:
                        copied_cell = cell.Copy()
                    except Exception:
                        copied_cell = None

                    if not isinstance(
                        copied_cell,
                        Topology
                    ):
                        return None

                    copied_cells.append(
                        copied_cell
                    )

                try:
                    result = CellComplex.ByCells(
                        copied_cells
                    )
                except Exception:
                    result = None

                if not isinstance(
                    result,
                    CellComplex
                ):
                    return None

                try:
                    result.dictionary = copy.deepcopy(
                        Topology.GetDictionary(
                            self
                        )
                    )
                except Exception:
                    pass

                return result

            # A native topology with no native shape should not silently
            # pretend that it has been copied.
            return None

        # ------------------------------------------------------------------
        # Native OCCT copy.
        # ------------------------------------------------------------------

        if BRepBuilderAPI_Copy is None:
            return None

        try:
            copier = BRepBuilderAPI_Copy(
                shape
            )

            copied_shape = copier.Shape()

        except Exception:
            return None

        if _is_null_shape(
            copied_shape
        ):
            return None

        # Exact copy lineage, including subshapes without dictionaries.
        _capture_modifier_only(shape, copied_shape, copier, "Copy")


        # ------------------------------------------------------------------
        # Wrap copied native topology.
        # ------------------------------------------------------------------

        try:
            result = Topology.ByOcctShape(
                copied_shape
            )
        except Exception:
            result = None

        if result is None:
            return None

        # Preserve explicit wrapper semantics where OCCT normalization may
        # otherwise unwrap a single-member container.
        try:
            result = Topology._rewrap_preserving_wrapper(
                result,
                self
            )
        except Exception:
            pass

        if not isinstance(
            result,
            Topology
        ):
            return None

        # ------------------------------------------------------------------
        # Copy must preserve its Topologic type.
        # ------------------------------------------------------------------

        if _topology_type_name(
            result
        ) != type_name:
            return None

        # ------------------------------------------------------------------
        # Preserve the parent dictionary independently.
        # ------------------------------------------------------------------

        # BRepGraph Tranche 3: Topology.Copy root persistence
        try:
            result.SetDictionary(
                copy.deepcopy(
                    Topology.GetDictionary(self)
                )
            )
        except Exception:
            pass

        return result

    def DeepCopy(self):
        """
        Creates an independent deep copy of the topology.

        The native OCCT topology is duplicated using BRepBuilderAPI_Copy.
        Dictionaries attached to the topology and all of its native
        subtopologies are transferred to their exact copied counterparts using
        the OCCT source-to-copy mapping provided by ModifiedShape.

        Aggregate wrappers without a single native OCCT shape, such as the
        lightweight Cluster, are copied recursively constituent-by-constituent.

        Returns
        -------
        Topology
            An independent deep copy of the topology, or None if copying fails.
        """

        if self is None:
            return None

        type_name = _topology_type_name(
            self
        )

        shape = _shape_from_topology(
            self
        )

        # ------------------------------------------------------------------
        # Shapeless aggregate wrappers
        # ------------------------------------------------------------------

        if _is_null_shape(shape):

            # --------------------------------------------------------------
            # Cluster
            # --------------------------------------------------------------

            if type_name == "Cluster":

                from .cluster import Cluster

                try:
                    members = self.Topologies()
                except Exception:
                    members = []

                if not isinstance(
                    members,
                    list
                ):
                    members = []

                if len(members) == 0:

                    try:
                        members = list(
                            getattr(
                                self,
                                "topologies",
                                []
                            )
                            or []
                        )
                    except Exception:
                        members = []

                if len(members) == 0:
                    return None

                copied_members = []

                for member in members:

                    if not isinstance(
                        member,
                        Topology
                    ):
                        return None

                    try:
                        copied_member = member.DeepCopy()
                    except Exception:
                        copied_member = None

                    if not isinstance(
                        copied_member,
                        Topology
                    ):
                        return None

                    copied_members.append(
                        copied_member
                    )

                try:
                    result = Cluster.ByTopologies(
                        copied_members
                    )
                except Exception:
                    result = None

                if not isinstance(
                    result,
                    Cluster
                ):
                    return None

                try:
                    result.dictionary = copy.deepcopy(
                        Topology.GetDictionary(
                            self
                        )
                    )
                except Exception:
                    pass

                return result

            # --------------------------------------------------------------
            # Shapeless CellComplex
            # --------------------------------------------------------------

            if type_name == "CellComplex":

                from .cell_complex import CellComplex

                try:
                    cells = list(
                        getattr(
                            self,
                            "cells",
                            []
                        )
                        or []
                    )
                except Exception:
                    cells = []

                if len(cells) == 0:

                    try:
                        cells = self.Cells()
                    except Exception:
                        cells = []

                if not isinstance(
                        cells,
                        list
                ) or len(cells) == 0:
                    return None

                copied_cells = []

                for cell in cells:

                    if not isinstance(
                        cell,
                        Topology
                    ):
                        return None

                    try:
                        copied_cell = cell.DeepCopy()
                    except Exception:
                        copied_cell = None

                    if not isinstance(
                        copied_cell,
                        Topology
                    ):
                        return None

                    copied_cells.append(
                        copied_cell
                    )

                try:
                    result = CellComplex.ByCells(
                        copied_cells
                    )
                except Exception:
                    result = None

                if not isinstance(
                        result,
                        CellComplex
                ):
                    return None

                try:
                    result.dictionary = copy.deepcopy(
                        Topology.GetDictionary(
                            self
                        )
                    )
                except Exception:
                    pass

                return result

            return None

        # ------------------------------------------------------------------
        # Native OCCT deep copy
        #
        # copyGeom=True:
        #     duplicate underlying geometry rather than sharing it.
        #
        # copyMesh=True:
        #     duplicate any existing triangulation as well.
        # ------------------------------------------------------------------

        if BRepBuilderAPI_Copy is None:
            return None

        try:
            copier = BRepBuilderAPI_Copy(
                shape,
                True,
                True
            )

            copied_shape = copier.Shape()

        except Exception:
            return None

        if _is_null_shape(
            copied_shape
        ):
            return None

        # Exact copy lineage, including subshapes without dictionaries.
        _capture_modifier_only(shape, copied_shape, copier, "Copy")


        # ------------------------------------------------------------------
        # Transfer dictionaries for the root shape and every subshape.
        #
        # AttributeManager stores dictionaries against native OCCT shape
        # identity. ModifiedShape gives the exact copied counterpart of each
        # original subshape.
        # ------------------------------------------------------------------

        manager = AttributeManager.GetInstance()

        def _transfer_shape_dictionary(
            source_shape,
            target_shape
        ):

            if (
                _is_null_shape(source_shape)
                or _is_null_shape(target_shape)
            ):
                return

            try:

                if not manager.HasDictionary(
                    source_shape
                ):
                    return

                source_dictionary = manager.GetDictionary(
                    source_shape
                )

                manager.SetDictionary(
                    target_shape,
                    copy.deepcopy(
                        source_dictionary
                    )
                )

            except Exception:
                pass

        # Root dictionary.
        _transfer_shape_dictionary(
            shape,
            copied_shape
        )

        # ------------------------------------------------------------------
        # Native subtopology dictionaries.
        # ------------------------------------------------------------------

        shape_types = (
            TopAbs_VERTEX,
            TopAbs_EDGE,
            TopAbs_WIRE,
            TopAbs_FACE,
            TopAbs_SHELL,
            TopAbs_SOLID,
            TopAbs_COMPSOLID,
        )

        for shape_type in shape_types:

            try:
                source_subshapes = _iter_occ_subshapes_unique(
                    shape,
                    shape_type
                )
            except Exception:
                source_subshapes = []

            for source_subshape in source_subshapes:

                # No dictionary means there is nothing to transfer.
                try:
                    if not manager.HasDictionary(
                        source_subshape
                    ):
                        continue
                except Exception:
                    continue

                # ----------------------------------------------------------
                # Ask OCCT for the exact corresponding copied subshape.
                # ----------------------------------------------------------

                try:
                    copied_subshape = copier.ModifiedShape(
                        source_subshape
                    )
                except Exception:
                    copied_subshape = None

                if _is_null_shape(
                    copied_subshape
                ):
                    continue

                _transfer_shape_dictionary(
                    source_subshape,
                    copied_subshape
                )

        # ------------------------------------------------------------------
        # Wrap copied native topology.
        # ------------------------------------------------------------------

        try:
            result = Topology.ByOcctShape(
                copied_shape
            )
        except Exception:
            result = None

        if result is None:
            return None

        # Preserve wrapper semantics such as CellComplex where required.
        try:
            result = Topology._rewrap_preserving_wrapper(
                result,
                self
            )
        except Exception:
            pass

        if not isinstance(
            result,
            Topology
        ):
            return None

        # ------------------------------------------------------------------
        # Deep copy must preserve the original Topologic type.
        # ------------------------------------------------------------------

        if _topology_type_name(
            result
        ) != type_name:
            return None

        # ------------------------------------------------------------------
        # Keep the wrapper-level parent dictionary mirror synchronized.
        # ------------------------------------------------------------------

        try:
            result.dictionary = copy.deepcopy(
                Topology.GetDictionary(
                    self
                )
            )
        except Exception:
            pass

        return result

    def CenterOfMass(self):
        from .vertex import Vertex
        from .wire import Wire
        from .face import Face, FaceUtility
        shape = _shape_from_topology(self)

        type_name = _topology_type_name(self)

        # A Vertex has no mass: its center of mass IS its own coordinates.
        # GProp `LinearProperties` on a bare TopoDS_Vertex yields the origin.
        if type_name == "Vertex" and hasattr(self, "x"):
            return Vertex.ByCoordinates(float(self.x), float(self.y), float(self.z))

        # Cluster: average member centroids (matches topologic_core; VolumeProperties
        # over the compound is wrong for mixed-dimension clusters).
        members = getattr(self, "topologies", None)
        if type_name == "Cluster" and members:
            pts = []
            for member in members:
                c = Topology.CenterOfMass(member)
                if c is not None and hasattr(c, "x"):
                    pts.append((float(c.x), float(c.y), float(c.z)))
            if pts:
                n = len(pts)
                return Vertex.ByCoordinates(
                    sum(p[0] for p in pts) / n,
                    sum(p[1] for p in pts) / n,
                    sum(p[2] for p in pts) / n,
                )

        # For faces with internal boundaries (holes), calculate centroid correctly
        # by subtracting hole contributions from the outer face
        internals = getattr(self, 'internals', []) or []
        if internals and hasattr(self, 'external') and self.external is not None:
            # Calculate outer face centroid and area
            outer_face = Face.ByWire(self.external)
            if outer_face is not None:
                outer_com = Topology.CenterOfMass(outer_face)
                outer_area = FaceUtility.Area(outer_face)
                
                if outer_com is not None and outer_area and outer_area > 0:
                    # Subtract hole contributions
                    cx = outer_com.x * outer_area
                    cy = outer_com.y * outer_area
                    cz = outer_com.z * outer_area
                    total_area = outer_area
                    
                    for wire in internals:
                        if isinstance(wire, Wire):
                            hole_face = Face.ByWire(wire)
                            if hole_face is not None:
                                hole_com = Topology.CenterOfMass(hole_face)
                                hole_area = FaceUtility.Area(hole_face)
                                if hole_com is not None and hole_area and hole_area > 0:
                                    cx -= hole_com.x * hole_area
                                    cy -= hole_com.y * hole_area
                                    cz -= hole_com.z * hole_area
                                    total_area -= hole_area
                    
                    if total_area > 0:
                        return Vertex.ByCoordinates(cx / total_area, cy / total_area, cz / total_area)
        
        if not _is_null_shape(shape) and GProp_GProps is not None and brepgprop is not None:
            try:
                props = GProp_GProps()
                type_name = _topology_type_name(self)
                if type_name in ("Cell", "CellComplex", "Cluster"):
                    brepgprop.VolumeProperties(shape, props)
                elif type_name in ("Face", "Shell"):
                    brepgprop.SurfaceProperties(shape, props)
                else:
                    brepgprop.LinearProperties(shape, props)
                center = props.CentreOfMass()
                return Vertex.ByCoordinates(center.X(), center.Y(), center.Z())
            except Exception:
                pass

        vertices = Topology.Vertices(self) or []
        if not vertices:
            return None
        n = len(vertices)
        cx = sum(v.x for v in vertices) / n
        cy = sum(v.y for v in vertices) / n
        cz = sum(v.z for v in vertices) / n
        return Vertex.ByCoordinates(cx, cy, cz)

    Centroid = CenterOfMass

    # -------------------------------------------------------------------
    # Structural queries: SubTopologies / SuperTopologies / SharedTopologies /
    # SelectSubtopology / SelfMerge
    # -------------------------------------------------------------------

    _SUBTOPOLOGY_GETTERS = {
        "vertex": "Vertices", "edge": "Edges", "wire": "Wires", "face": "Faces",
        "shell": "Shells", "cell": "Cells", "cellcomplex": "CellComplexes",
        "cluster": "Clusters", "aperture": "Apertures",
    }

    def SubTopologies(self, typeName: str = None, hostTopology: Any = None, output=None):
        getter_name = Topology._SUBTOPOLOGY_GETTERS.get(str(typeName).strip().lower()) if typeName else None
        if getter_name is None:
            result = []
        else:
            result = getattr(Topology, getter_name)(self) or []
        if output is not None:
            output.extend(result)
            return 0
        return result


    def SuperTopologies(self, hostTopology: Any, typeName: str, output=None):
        """
        Returns the requested super-topologies of ``self`` inside
        ``hostTopology``.

        Uses exact OCCT ancestry when possible, but preserves TopologicPy's
        historical compatibility with independently wrapped or reconstructed
        coincident subtopologies by falling back to vertex-key containment.
        """
        getter_name = (
            Topology._SUBTOPOLOGY_GETTERS.get(
                str(typeName).strip().lower()
            )
            if typeName
            else None
        )

        result = []

        if getter_name is None or hostTopology is None:
            if output is not None:
                output.extend(result)
                return 0
            return result

        source_name = (_topology_type_name(self) or "").lower()
        target_name = str(typeName).strip().lower()

        type_map = {
            "vertex": TopAbs_VERTEX,
            "edge": TopAbs_EDGE,
            "wire": TopAbs_WIRE,
            "face": TopAbs_FACE,
            "shell": TopAbs_SHELL,
            "cell": TopAbs_SOLID,
            "cellcomplex": TopAbs_COMPSOLID,
            "cluster": TopAbs_COMPOUND,
        }

        source_type = type_map.get(source_name)
        target_type = type_map.get(target_name)

        self_shape = _shape_from_topology(self)
        host_shape = _shape_from_topology(hostTopology)

        # BRepGraph Tranche 1: exact indexed reverse incidence on OCCT 8.
        # Returning an empty list is authoritative; returning None means the
        # adapter could not answer and the established ancestry paths below
        # remain the fallback.
        if (
            source_type is not None
            and target_type is not None
            and not _is_null_shape(self_shape)
            and not _is_null_shape(host_shape)
        ):
            try:
                index = _cached_brepgraph_index(hostTopology, host_shape)
                ancestor_shapes = (
                    index.super_shapes(self_shape, target_type)
                    if index is not None
                    else None
                )
            except Exception:
                ancestor_shapes = None

            if ancestor_shapes is not None:
                for ancestor_shape in ancestor_shapes:
                    try:
                        wrapped = Topology.ByOcctShape(ancestor_shape)
                    except Exception:
                        wrapped = None
                    if wrapped is not None:
                        result.append(wrapped)

                result = _deduplicate_by_identity(result)
                if output is not None:
                    output.extend(result)
                    return 0
                return result

        # Face -> Cell ancestry needs a host-side native remap because boolean /
        # container construction can preserve the same geometric Face while giving
        # the query wrapper a different OCCT TShape identity. Keep all other
        # SuperTopologies behavior unchanged because Wire direction relies on the
        # historical Vertex -> Edge ordering semantics below.
        if (
            source_name == "face"
            and target_name == "cell"
            and source_type is not None
            and target_type is not None
            and not _is_null_shape(self_shape)
            and not _is_null_shape(host_shape)
        ):
            try:
                source_shapes = Topology._NativeMatchingShapes(
                    host_shape,
                    [self],
                    source_type,
                    0.0001,
                )

                if source_shapes:
                    ancestor_shapes = Topology._NativeAncestors(
                        host_shape,
                        source_shapes,
                        source_type,
                        target_type,
                    )

                    for ancestor_shape in ancestor_shapes or []:
                        try:
                            wrapped = Topology.ByOcctShape(ancestor_shape)
                        except Exception:
                            wrapped = None
                        if wrapped is not None:
                            result.append(wrapped)

                    result = _deduplicate_by_identity(result)

                    if result:
                        if output is not None:
                            output.extend(result)
                            return 0
                        return result
            except Exception:
                result = []

        # 1. Fast exact OCCT ancestry.
        if (
            source_type is not None
            and target_type is not None
            and not _is_null_shape(self_shape)
            and not _is_null_shape(host_shape)
        ):
            try:
                from OCC.Core.TopExp import TopExp
                from OCC.Core.TopTools import (
                    TopTools_IndexedDataMapOfShapeListOfShape,
                    TopTools_ListIteratorOfListOfShape,
                )

                ancestor_map = TopTools_IndexedDataMapOfShapeListOfShape()

                TopExp.MapShapesAndAncestors(
                    host_shape,
                    source_type,
                    target_type,
                    ancestor_map,
                )

                if ancestor_map.Contains(self_shape):
                    shape_list = ancestor_map.FindFromKey(self_shape)
                    iterator = TopTools_ListIteratorOfListOfShape(shape_list)

                    while iterator.More():
                        ancestor_shape = iterator.Value()

                        try:
                            same_as_self = ancestor_shape.IsSame(self_shape)
                        except Exception:
                            same_as_self = False

                        if not same_as_self:
                            wrapped = Topology.ByOcctShape(ancestor_shape)
                            if wrapped is not None:
                                result.append(wrapped)

                        iterator.Next()

                    result = _deduplicate_by_identity(result)

                    if output is not None:
                        output.extend(result)
                        return 0
                    return result

            except Exception:
                pass

        # 2. Compatibility fallback.
        #
        # This deliberately preserves the pre-audit backend semantics.
        try:
            candidates = getattr(Topology, getter_name)(hostTopology) or []

            self_vertices = {
                vertex_key(vertex)
                for vertex in (Topology.Vertices(self) or [])
                if hasattr(vertex, "x")
            }

            if self_vertices:
                for candidate in candidates:
                    try:
                        if Topology.IsSame(candidate, self):
                            continue
                    except Exception:
                        pass

                    candidate_vertices = {
                        vertex_key(vertex)
                        for vertex in (Topology.Vertices(candidate) or [])
                        if hasattr(vertex, "x")
                    }

                    if self_vertices.issubset(candidate_vertices):
                        result.append(candidate)

        except Exception:
            result = []

        result = _deduplicate_by_identity(result)

        if output is not None:
            output.extend(result)
            return 0

        return result

    # -------------------------------------------------------------------
    # Backend Audit V1: performance-critical native operations
    # -------------------------------------------------------------------
    @staticmethod
    def _ImmediateSuperTypeName(topology, hostTopology):
        t = (_topology_type_name(topology) or "").lower()
        h = (_topology_type_name(hostTopology) or "").lower()
        if t == "vertex" and h in ("edge", "wire", "face", "shell", "cell", "cellcomplex", "cluster"):
            return "edge"
        if t == "edge":
            if h == "wire": return "wire"
            if h in ("face", "shell", "cell", "cellcomplex", "cluster"): return "face"
        if t == "wire" and h in ("face", "shell", "cell", "cellcomplex", "cluster"):
            return "face"
        if t == "face":
            if h == "shell": return "shell"
            if h in ("cell", "cellcomplex", "cluster"): return "cell"
        if t == "shell" and h in ("cell", "cellcomplex", "cluster"):
            return "cell"
        if t == "cell" and h in ("cellcomplex", "cluster"):
            return "cellcomplex"
        return None

    def DegreeNative(self, hostTopology):
        super_type = Topology._ImmediateSuperTypeName(self, hostTopology)
        if super_type is None:
            return 0
        return len(self.SuperTopologies(hostTopology, super_type) or [])

    def OpenEdgesNative(self):
        """
        Returns the geometrically open boundary edges of this topology.

        Periodic OCCT faces can contain seam edges. A seam edge may have only
        one distinct adjacent Face while occurring twice on that Face with
        opposite co-edge orientations. Such an edge is not a true open
        boundary and is therefore excluded.

        Returns
        -------
        list
            The open boundary Edges.
        """
        edges = Topology.Edges(self) or []

        if len(edges) == 0:
            return []

        try:
            from OCC.Core.BRep import BRep_Tool
            from OCC.Core.TopoDS import topods
        except Exception:
            return [
                edge
                for edge in edges
                if edge.DegreeNative(self) < 2
            ]

        result = []

        for edge in edges:
            try:
                degree = edge.DegreeNative(self)
            except Exception:
                degree = 0

            if degree >= 2:
                continue

            is_seam = False

            if degree == 1:
                try:
                    faces = edge.SuperTopologies(
                        self,
                        "Face"
                    ) or []
                except Exception:
                    faces = []

                edge_shape = getattr(
                    edge,
                    "shape",
                    None
                )

                if edge_shape is not None:
                    for face in faces:
                        face_shape = getattr(
                            face,
                            "shape",
                            None
                        )

                        if face_shape is None:
                            continue

                        try:
                            if BRep_Tool.IsClosed(
                                topods.Edge(edge_shape),
                                topods.Face(face_shape)
                            ):
                                is_seam = True
                                break
                        except Exception:
                            continue

            if not is_seam:
                result.append(edge)

        return result

    def OpenFacesNative(self):
        return [f for f in (Topology.Faces(self) or []) if f.DegreeNative(self) < 1]

    def OpenVerticesNative(self):
        return [v for v in (Topology.Vertices(self) or []) if v.DegreeNative(self) < 2]

    def IsPlanarNative(self, mantissa: int = 6, tolerance: float = 0.0001):
        vertices = Topology.Vertices(self) or []
        if len(vertices) <= 3:
            return True
        points = [(round(float(v.x), int(mantissa)), round(float(v.y), int(mantissa)), round(float(v.z), int(mantissa))) for v in vertices]
        tol = max(abs(float(tolerance)), 1.0e-15)
        p0 = points[0]
        p1 = None
        for p in points[1:]:
            dx, dy, dz = p[0]-p0[0], p[1]-p0[1], p[2]-p0[2]
            if dx*dx + dy*dy + dz*dz > tol*tol:
                p1 = p
                break
        if p1 is None:
            return True
        ax, ay, az = p1[0]-p0[0], p1[1]-p0[1], p1[2]-p0[2]
        a2 = ax*ax + ay*ay + az*az
        normal = None
        for p in points[1:]:
            bx, by, bz = p[0]-p0[0], p[1]-p0[1], p[2]-p0[2]
            b2 = bx*bx + by*by + bz*bz
            nx, ny, nz = ay*bz-az*by, az*bx-ax*bz, ax*by-ay*bx
            n2 = nx*nx + ny*ny + nz*nz
            if a2 > 0.0 and b2 > 0.0 and n2 > (tol*tol)*a2:
                normal = (nx, ny, nz)
                break
        if normal is None:
            return True
        nx, ny, nz = normal
        norm = math.sqrt(nx*nx + ny*ny + nz*nz)
        if norm <= 0.0:
            return True
        nx, ny, nz = nx/norm, ny/norm, nz/norm
        for p in points:
            d = abs(nx*(p[0]-p0[0]) + ny*(p[1]-p0[1]) + nz*(p[2]-p0[2]))
            if d > tol:
                return False
        return True

    def ShortestEdgeNative(self, otherTopology, tolerance: float = 0.0001):
        if BRepExtrema_DistShapeShape is None:
            return False, None
        def operand_shapes(topology):
            shape = _shape_from_topology(topology)
            if not _is_null_shape(shape):
                return [shape]
            try:
                shapes = _collect_boolean_operand_shapes(topology) or []
            except Exception:
                shapes = []
            return [s for s in shapes if not _is_null_shape(s)]
        shapes_a, shapes_b = operand_shapes(self), operand_shapes(otherTopology)
        if not shapes_a or not shapes_b:
            return False, None
        best = None
        best_p = best_q = None
        for sa in shapes_a:
            for sb in shapes_b:
                try:
                    dss = BRepExtrema_DistShapeShape(sa, sb)
                    if not dss.IsDone() or dss.NbSolution() < 1:
                        continue
                    value = float(dss.Value())
                    if not math.isfinite(value):
                        continue
                    if best is None or value < best:
                        best = value
                        best_p = dss.PointOnShape1(1)
                        best_q = dss.PointOnShape2(1)
                        if value <= tolerance:
                            return True, None
                except Exception:
                    continue
        if best is None or best_p is None or best_q is None:
            return False, None
        if best <= tolerance:
            return True, None
        try:
            from OCC.Core.BRepBuilderAPI import BRepBuilderAPI_MakeEdge
            maker = BRepBuilderAPI_MakeEdge(best_p, best_q)
            if not maker.IsDone():
                return False, None
            result = Topology.ByOcctShape(maker.Edge())
            return (True, result) if result is not None else (False, None)
        except Exception:
            return False, None

    def MergeAllNative(self, otherTopologies, tolerance: float = 0.0001):
        if BOPAlgo_CellsBuilder is None:
            return None
        operands = [self] + list(otherTopologies or [])
        shapes = []
        for operand in operands:
            try:
                operand_shapes = _collect_boolean_operand_shapes(operand) or []
            except Exception:
                operand_shapes = []
            if not operand_shapes:
                shape = _shape_from_topology(operand)
                if not _is_null_shape(shape):
                    operand_shapes = [shape]
            shapes.extend([s for s in operand_shapes if not _is_null_shape(s)])
        if len(shapes) < 2:
            return None
        try:
            builder = BOPAlgo_CellsBuilder()
            if hasattr(builder, "SetRunParallel"):
                try: builder.SetRunParallel(True)
                except Exception: pass
            for shape in shapes:
                builder.AddArgument(shape)
            builder.Perform()
            if hasattr(builder, "HasErrors") and builder.HasErrors():
                return None
            builder.AddAllToResult()
            result_shape = builder.Shape()
        except Exception:
            return None
        if _is_null_shape(result_shape):
            return None
        result_shape = _postprocess_boolean_result(result_shape)
        result_shape = _unify_same_domain(result_shape)
        result_shape = _promote_to_compsolid_if_multi_solid(result_shape)
        if _is_null_shape(result_shape):
            return None
        result = Topology.ByOcctShape(result_shape, dictionary={}, contents=[], contexts=[], apertures=[])
        if result is None:
            return None
        for operand in operands:
            try: _transfer_contents(operand, result)
            except Exception: pass
        return result

    @staticmethod
    def _SameAsAny(topology, candidates):
        for candidate in candidates or []:
            try:
                if Topology.IsSame(topology, candidate): return True
            except Exception:
                pass
        return False

    @staticmethod
    def _RebuildFromMembers(members, tolerance: float = 0.0001):
        if len(members) < 1: return None
        if len(members) == 1: return members[0]
        from .cluster import Cluster
        cluster = Cluster.ByTopologies(members)
        if cluster is None: return None
        try: return cluster.SelfMerge(tolerance=tolerance)
        except TypeError:
            try: return cluster.SelfMerge()
            except Exception: return cluster
        except Exception: return cluster

    def _NativeMatchingShapes(
        hostShape,
        candidates,
        shapeType,
        tolerance: float = 0.0001,
    ):
        """
        Returns native OCCT subshapes of hostShape matching the supplied
        candidates.

        Matching is deliberately conservative:

        1. OCCT topological identity (IsSame / IsPartner) is preferred.
        2. If construction of the host has copied the underlying TShape,
           geometric equivalence is used as a fallback.

        The geometric fallback is type-specific and tolerance-aware:
        Vertices are compared by native point distance; Edges by exact length
        and several points sampled along the native curve in both possible
        orientations; Faces by area, centre of mass, and boundary-vertex
        signature.

        This is necessary because constructors such as Wire.ByEdges may create
        a new OCCT container whose constituent subshapes are geometrically
        identical to the supplied TopologicPy objects but are no longer
        IsSame() to them.
        """
        if _is_null_shape(hostShape):
            return []

        try:
            tolerance = max(abs(float(tolerance)), 1.0e-12)
        except Exception:
            tolerance = 0.0001

        candidate_shapes = []

        for candidate in candidates or []:
            candidate_shape = _shape_from_topology(candidate)

            if (
                _is_null_shape(candidate_shape)
                and hasattr(candidate, "ShapeType")
            ):
                candidate_shape = candidate

            if _is_null_shape(candidate_shape):
                continue

            try:
                if candidate_shape.ShapeType() != shapeType:
                    continue
            except Exception:
                continue

            candidate_shapes.append(candidate_shape)

        if len(candidate_shapes) < 1:
            return []

        native_shapes = []

        try:
            if hostShape.ShapeType() == shapeType:
                native_shapes.append(hostShape)
        except Exception:
            pass

        native_shapes.extend(
            _iter_occ_subshapes_unique(
                hostShape,
                shapeType,
            )
            or []
        )

        # --------------------------------------------------------------
        # Small native helpers
        # --------------------------------------------------------------

        def _point_tuple(vertex_shape):
            try:
                from OCC.Core.BRep import BRep_Tool

                point = BRep_Tool.Pnt(
                    topods.Vertex(vertex_shape)
                )

                return (
                    float(point.X()),
                    float(point.Y()),
                    float(point.Z()),
                )
            except Exception:
                return None

        def _distance_points(a, b):
            if a is None or b is None:
                return float("inf")

            dx = a[0] - b[0]
            dy = a[1] - b[1]
            dz = a[2] - b[2]

            return math.sqrt(
                dx * dx
                + dy * dy
                + dz * dz
            )

        def _shape_center(shape):
            try:
                props = GProp_GProps()
                st = shape.ShapeType()

                if st == TopAbs_FACE:
                    brepgprop.SurfaceProperties(
                        shape,
                        props,
                    )
                elif st == TopAbs_EDGE:
                    brepgprop.LinearProperties(
                        shape,
                        props,
                    )
                else:
                    return None

                point = props.CentreOfMass()

                return (
                    float(point.X()),
                    float(point.Y()),
                    float(point.Z()),
                )
            except Exception:
                return None

        def _edge_length(edge_shape):
            try:
                props = GProp_GProps()

                brepgprop.LinearProperties(
                    topods.Edge(edge_shape),
                    props,
                )

                return float(props.Mass())
            except Exception:
                return None

        def _face_area(face_shape):
            try:
                props = GProp_GProps()

                brepgprop.SurfaceProperties(
                    topods.Face(face_shape),
                    props,
                )

                return float(props.Mass())
            except Exception:
                return None

        def _edge_samples(edge_shape):
            try:
                from OCC.Core.BRepAdaptor import BRepAdaptor_Curve

                adaptor = BRepAdaptor_Curve(
                    topods.Edge(edge_shape)
                )

                first = float(
                    adaptor.FirstParameter()
                )

                last = float(
                    adaptor.LastParameter()
                )

                if (
                    not math.isfinite(first)
                    or not math.isfinite(last)
                ):
                    return None

                parameters = (
                    0.0,
                    0.125,
                    0.25,
                    0.5,
                    0.75,
                    0.875,
                    1.0,
                )

                result = []

                for u in parameters:
                    parameter = (
                        first
                        + (last - first) * u
                    )

                    point = adaptor.Value(
                        parameter
                    )

                    result.append(
                        (
                            float(point.X()),
                            float(point.Y()),
                            float(point.Z()),
                        )
                    )

                return result

            except Exception:
                return None

        def _vertex_signature(shape):
            points = []

            for vertex_shape in (
                _iter_occ_subshapes_unique(
                    shape,
                    TopAbs_VERTEX,
                )
                or []
            ):
                point = _point_tuple(
                    vertex_shape
                )

                if point is not None:
                    points.append(point)

            if len(points) < 1:
                return []

            scale = max(
                tolerance,
                1.0e-12,
            )

            return sorted(
                (
                    int(round(point[0] / scale)),
                    int(round(point[1] / scale)),
                    int(round(point[2] / scale)),
                )
                for point in points
            )

        def _same_identity(a, b):
            try:
                if a.IsSame(b):
                    return True
            except Exception:
                pass

            try:
                if a.IsPartner(b):
                    return True
            except Exception:
                pass

            return False

        def _same_vertex(a, b):
            return (
                _distance_points(
                    _point_tuple(a),
                    _point_tuple(b),
                )
                <= tolerance
            )

        def _same_edge(a, b):
            length_a = _edge_length(a)
            length_b = _edge_length(b)

            if (
                length_a is None
                or length_b is None
            ):
                return False

            length_scale = max(
                1.0,
                abs(length_a),
                abs(length_b),
            )

            if (
                abs(length_a - length_b)
                > tolerance * length_scale
            ):
                return False

            samples_a = _edge_samples(a)
            samples_b = _edge_samples(b)

            if (
                samples_a is None
                or samples_b is None
                or len(samples_a) != len(samples_b)
            ):
                return False

            direct_error = max(
                _distance_points(pa, pb)
                for pa, pb in zip(
                    samples_a,
                    samples_b,
                )
            )

            reverse_error = max(
                _distance_points(pa, pb)
                for pa, pb in zip(
                    samples_a,
                    reversed(samples_b),
                )
            )

            return (
                min(
                    direct_error,
                    reverse_error,
                )
                <= tolerance
            )

        def _same_face(a, b):
            area_a = _face_area(a)
            area_b = _face_area(b)

            if (
                area_a is None
                or area_b is None
            ):
                return False

            area_scale = max(
                1.0,
                abs(area_a),
                abs(area_b),
            )

            if (
                abs(area_a - area_b)
                > tolerance * area_scale
            ):
                return False

            center_a = _shape_center(a)
            center_b = _shape_center(b)

            if (
                center_a is None
                or center_b is None
                or _distance_points(
                    center_a,
                    center_b,
                )
                > tolerance
            ):
                return False

            signature_a = _vertex_signature(a)
            signature_b = _vertex_signature(b)

            if (
                signature_a
                and signature_b
                and signature_a != signature_b
            ):
                return False

            return True

        def _same_geometry(a, b):
            if shapeType == TopAbs_VERTEX:
                return _same_vertex(a, b)

            if shapeType == TopAbs_EDGE:
                return _same_edge(a, b)

            if shapeType == TopAbs_FACE:
                return _same_face(a, b)

            return False

        # --------------------------------------------------------------
        # Match every host subshape against the supplied candidates.
        #
        # Keep host-side shapes in the result because ShapeBuild_ReShape
        # must remove the subshape that actually belongs to hostShape,
        # not an independently constructed coincident candidate.
        # --------------------------------------------------------------

        result = []

        for native_shape in native_shapes:
            matched = False

            for candidate_shape in candidate_shapes:
                if _same_identity(
                    native_shape,
                    candidate_shape,
                ):
                    matched = True
                    break

            if not matched:
                for candidate_shape in candidate_shapes:
                    if _same_geometry(
                        native_shape,
                        candidate_shape,
                    ):
                        matched = True
                        break

            if matched:
                duplicate = False

                for existing in result:
                    if _same_identity(
                        native_shape,
                        existing,
                    ):
                        duplicate = True
                        break

                if not duplicate:
                    result.append(
                        native_shape
                    )

        return result
    def _NativeAncestors(
        hostShape,
        sourceShapes,
        sourceType,
        ancestorType,
    ):
        """
        Returns the unique native OCCT ancestors of the supplied source
        subshapes within hostShape.

        This implementation deliberately avoids relying exclusively on
        TopExp.MapShapesAndAncestors. The corresponding pythonocc binding has
        varied between releases and can silently fail to populate the map.

        Instead, the method enumerates candidate ancestors in the host and
        checks whether each contains one of the supplied host-side source
        subshapes by OCCT topological identity (IsSame / IsPartner).

        Parameters
        ----------
        hostShape : OCC.Core.TopoDS.TopoDS_Shape
            The host OCCT shape.
        sourceShapes : list
            Host-side OCCT source subshapes.
        sourceType : OCC.Core.TopAbs.TopAbs_ShapeEnum
            The source subshape type.
        ancestorType : OCC.Core.TopAbs.TopAbs_ShapeEnum
            The desired ancestor type.

        Returns
        -------
        list
            The unique matching ancestor OCCT shapes.
        """
        if _is_null_shape(hostShape) or not sourceShapes:
            return []

        source_shapes = [
            shape
            for shape in sourceShapes
            if not _is_null_shape(shape)
        ]

        if len(source_shapes) < 1:
            return []

        def _same_shape(a, b):
            try:
                if a.IsSame(b):
                    return True
            except Exception:
                pass

            try:
                if a.IsPartner(b):
                    return True
            except Exception:
                pass

            return False

        def _append_unique(items, candidate):
            for existing in items:
                if _same_shape(
                    existing,
                    candidate,
                ):
                    return

            items.append(candidate)

        # --------------------------------------------------------------
        # Enumerate candidate ancestors. TopExp_Explorer does not
        # necessarily return the root shape when its type already equals
        # ancestorType, so include hostShape explicitly in that case.
        # --------------------------------------------------------------

        ancestors = []

        try:
            if hostShape.ShapeType() == ancestorType:
                ancestors.append(hostShape)
        except Exception:
            pass

        for ancestor in (
            _iter_occ_subshapes_unique(
                hostShape,
                ancestorType,
            )
            or []
        ):
            _append_unique(
                ancestors,
                ancestor,
            )

        if len(ancestors) < 1:
            return []

        # --------------------------------------------------------------
        # An ancestor matches when one of its source-type subshapes is
        # the same host-side OCCT subshape as one of sourceShapes.
        #
        # Include the ancestor itself when sourceType == ancestorType,
        # although current removal paths normally query a lower type.
        # --------------------------------------------------------------

        result = []

        for ancestor in ancestors:
            contained_sources = []

            try:
                if ancestor.ShapeType() == sourceType:
                    contained_sources.append(
                        ancestor
                    )
            except Exception:
                pass

            contained_sources.extend(
                _iter_occ_subshapes_unique(
                    ancestor,
                    sourceType,
                )
                or []
            )

            matched = False

            for contained in contained_sources:
                for source in source_shapes:
                    if _same_shape(
                        contained,
                        source,
                    ):
                        matched = True
                        break

                if matched:
                    break

            if matched:
                _append_unique(
                    result,
                    ancestor,
                )

        return result
    def _FinalizeNativeEdit(self, editedShape, tolerance: float = 0.0001):
        """
        Wraps the result of a native topology-editing operation.

        If deletion leaves an invalid higher-dimensional container, only the
        container is reconstructed from surviving exact OCCT Faces, Edges, or
        Vertices. The underlying curves and surfaces are not approximated.
        """
        if _is_null_shape(editedShape):
            return None

        try:
            tolerance = max(abs(float(tolerance)), 1.0e-12)
        except Exception:
            tolerance = 0.0001

        try:
            dictionary = Topology.GetDictionary(self)
        except Exception:
            dictionary = getattr(self, "dictionary", {})

        contents = list(getattr(self, "contents", []) or [])
        contexts = list(getattr(self, "contexts", []) or [])
        apertures = list(getattr(self, "apertures", []) or [])

        def attach_metadata(result):
            if result is None:
                return None

            try:
                result.SetDictionary(dictionary)
            except Exception:
                try:
                    result.dictionary = dictionary
                except Exception:
                    pass

            for name, values in (
                ("contents", contents),
                ("contexts", contexts),
                ("apertures", apertures),
            ):
                try:
                    setattr(result, name, list(values))
                except Exception:
                    pass

            return result

        valid = True
        if BRepCheck_Analyzer is not None:
            try:
                valid = bool(BRepCheck_Analyzer(editedShape, True, True).IsValid())
            except Exception:
                valid = True

        if valid:
            try:
                result = Topology.ByOcctShape(
                    editedShape,
                    dictionary=dictionary,
                    contents=contents,
                    contexts=contexts,
                    apertures=apertures,
                )
                if result is not None:
                    return attach_metadata(result)
            except Exception:
                pass

        try:
            from .cluster import Cluster
        except Exception:
            Cluster = None

        for shape_type in (TopAbs_FACE, TopAbs_EDGE, TopAbs_VERTEX):
            native_shapes = _iter_occ_subshapes_unique(editedShape, shape_type) or []
            if not native_shapes:
                continue

            wrappers = []
            for native_shape in native_shapes:
                try:
                    wrapper = Topology.ByOcctShape(native_shape)
                except Exception:
                    wrapper = None
                if wrapper is not None:
                    wrappers.append(wrapper)

            if not wrappers:
                continue

            if len(wrappers) == 1:
                return attach_metadata(wrappers[0])

            if Cluster is None:
                return None

            try:
                cluster = Cluster.ByTopologies(wrappers)
            except Exception:
                cluster = None

            if cluster is None:
                return None

            try:
                result = cluster.SelfMerge(tolerance=tolerance)
            except TypeError:
                try:
                    result = cluster.SelfMerge()
                except Exception:
                    result = cluster
            except Exception:
                result = cluster

            return attach_metadata(result)

        return None

    def _FinalizeNativeRemoval(self, edited_shape, tolerance: float = 0.0001):
        """Distinguish complete deletion from failure to wrap surviving geometry."""
        if _is_null_shape(edited_shape):
            # ReShape returns a null shape when the root is removed.
            return True, None
        result = self._FinalizeNativeEdit(edited_shape, tolerance=tolerance)
        if result is not None:
            return True, result
        try:
            # Query the kernel directly: a failed traversal must not be treated
            # as an empty result by the defensive enumeration helpers.
            if (edited_shape.ShapeType() == TopAbs_VERTEX
                    or TopExp_Explorer(edited_shape, TopAbs_VERTEX).More()):
                return False, None
            return True, None
        except Exception:
            return False, None

    def _EditClusterMembers(self, method, *args, **kwargs):
        """Edit direct members without losing unrelated Cluster geometry.

        Removal may return (True, None) for a completely deleted member.
        A failed member aborts the edit. Nested clusters retain their hierarchy
        and aggregate metadata.
        """
        from .cluster import Cluster

        members = self.Topologies() or []
        if not members:
            # Imported native compounds may not cache direct member wrappers.
            try:
                from OCC.Core.TopoDS import TopoDS_Iterator
                shape = _shape_from_topology(self)
                if _is_null_shape(shape):
                    return False, None
                iterator = TopoDS_Iterator(shape)
                while iterator.More():
                    member = Topology.ByOcctShape(iterator.Value())
                    if not isinstance(member, Topology):
                        return False, None
                    members.append(member)
                    iterator.Next()
            except Exception:
                return False, None
            if not members:
                return False, None
        edited = []
        changed = False
        for member in members:
            try:
                status, result = getattr(member, method)(*args, **kwargs)
            except Exception:
                return False, None
            if status is not True:
                return False, None
            if result is not None:
                if not isinstance(result, Topology):
                    return False, None
                edited.append(result)
            changed = changed or result is not member
        if not changed:
            return True, self
        if not edited:
            return True, None
        result = Cluster.ByTopologies(edited)
        if result is None:
            return False, None
        result.SetDictionary(Topology.GetDictionary(self))
        for name in ("contents", "contexts", "apertures"):
            setattr(result, name, list(getattr(self, name, []) or []))
        return True, result

    def RemoveFacesNative(self, faces, tolerance: float = 0.0001):
        """
        Removes the specified Faces using OCCT ShapeBuild_ReShape while
        preserving surviving analytic and BSpline/NURBS surfaces exactly.
        """
        if _topology_type_name(self) == "Cluster":
            return self._EditClusterMembers("RemoveFacesNative", faces, tolerance)
        shape = _shape_from_topology(self)
        if _is_null_shape(shape):
            return False, None

        try:
            tolerance = max(abs(float(tolerance)), 1.0e-12)
        except Exception:
            return False, None

        matching_faces = Topology._NativeMatchingShapes(shape, faces, TopAbs_FACE, tolerance)
        if not matching_faces:
            return True, self

        try:
            from OCC.Core.ShapeBuild import ShapeBuild_ReShape

            reshaper = ShapeBuild_ReShape()
            for face_shape in matching_faces:
                reshaper.Remove(face_shape)

            edited_shape = reshaper.Apply(shape)
            return self._FinalizeNativeRemoval(edited_shape, tolerance=tolerance)

        except Exception:
            return False, None

    def RemoveEdgesNative(self, edges, tolerance: float = 0.0001):
        """
        Removes the specified Edges using native OCCT topology editing.

        Edges incident to Faces remove those incident Faces, preserving the
        established cascading-removal semantics. Free Edges are removed
        directly. Surviving curve geometry remains exact.
        """
        if _topology_type_name(self) == "Cluster":
            return self._EditClusterMembers("RemoveEdgesNative", edges, tolerance)
        shape = _shape_from_topology(self)
        if _is_null_shape(shape):
            return False, None

        try:
            tolerance = max(abs(float(tolerance)), 1.0e-12)
        except Exception:
            return False, None

        matching_edges = Topology._NativeMatchingShapes(shape, edges, TopAbs_EDGE, tolerance)
        if not matching_edges:
            return True, self

        try:
            from OCC.Core.ShapeBuild import ShapeBuild_ReShape
            from OCC.Core.TopTools import TopTools_MapOfShape
        except Exception:
            return False, None

        incident_faces = Topology._NativeAncestors(
            shape,
            matching_edges,
            TopAbs_EDGE,
            TopAbs_FACE,
        )

        remove_shapes = []
        seen = TopTools_MapOfShape()

        for remove_shape in list(incident_faces) + list(matching_edges):
            try:
                if seen.Contains(remove_shape):
                    continue
                seen.Add(remove_shape)
            except Exception:
                pass
            remove_shapes.append(remove_shape)

        try:
            reshaper = ShapeBuild_ReShape()
            for remove_shape in remove_shapes:
                reshaper.Remove(remove_shape)

            edited_shape = reshaper.Apply(shape)
            return self._FinalizeNativeRemoval(edited_shape, tolerance=tolerance)

        except Exception:
            return False, None

    def RemoveVerticesNative(self, vertices, tolerance: float = 0.0001):
        """
        Removes the specified Vertices using native OCCT topology editing.

        Removal cascades through incident Edges and then incident Faces,
        preserving the established TopologicPy semantics while retaining exact
        surviving curve and surface geometry.
        """
        if _topology_type_name(self) == "Cluster":
            return self._EditClusterMembers("RemoveVerticesNative", vertices, tolerance)
        shape = _shape_from_topology(self)
        if _is_null_shape(shape):
            return False, None

        try:
            tolerance = max(abs(float(tolerance)), 1.0e-12)
        except Exception:
            return False, None

        matching_vertices = Topology._NativeMatchingShapes(
            shape,
            vertices,
            TopAbs_VERTEX,
            tolerance,
        )
        if not matching_vertices:
            return True, self

        try:
            from OCC.Core.ShapeBuild import ShapeBuild_ReShape
            from OCC.Core.TopTools import TopTools_MapOfShape
        except Exception:
            return False, None

        incident_edges = Topology._NativeAncestors(
            shape,
            matching_vertices,
            TopAbs_VERTEX,
            TopAbs_EDGE,
        )

        incident_faces = (
            Topology._NativeAncestors(
                shape,
                incident_edges,
                TopAbs_EDGE,
                TopAbs_FACE,
            )
            if incident_edges
            else []
        )

        remove_shapes = []
        seen = TopTools_MapOfShape()

        for remove_shape in (
            list(incident_faces)
            + list(incident_edges)
            + list(matching_vertices)
        ):
            try:
                if seen.Contains(remove_shape):
                    continue
                seen.Add(remove_shape)
            except Exception:
                pass
            remove_shapes.append(remove_shape)

        try:
            reshaper = ShapeBuild_ReShape()
            for remove_shape in remove_shapes:
                reshaper.Remove(remove_shape)

            edited_shape = reshaper.Apply(shape)
            return self._FinalizeNativeRemoval(edited_shape, tolerance=tolerance)

        except Exception:
            return False, None

    # -------------------------------------------------------------------
    # Native performance-critical operations (Backend Audit V2)
    # -------------------------------------------------------------------

    def RemoveCollinearEdgesNative(
        self,
        angTolerance: float = 0.1,
        polyhedron: bool = True,
        tolerance: float = 0.0001,
    ):
        """
        Removes redundant collinear Edge boundaries using
        ShapeUpgrade_UnifySameDomain.

        Parameters
        ----------
        angTolerance : float , optional
            Maximum angular deviation in degrees between linear Edges that may be
            unified. Default is 0.1.
        polyhedron : bool , optional
            If True, the input is assumed to contain only linear Edge geometry and
            the fast native path is used directly. If False, vertices incident to
            curved Edges are protected so those curves cannot be merged or altered.
            Default is True.
        tolerance : float , optional
            Linear tolerance used by OCCT when deciding whether Edge domains may be
            unified. Default is 0.0001.

        Returns
        -------
        tuple
            ``(status, result)``.
        """
        if _topology_type_name(self) == "Cluster":
            return self._EditClusterMembers("RemoveCollinearEdgesNative", angTolerance, polyhedron, tolerance)
        type_name = (
            _topology_type_name(self)
            or ""
        )

        if type_name in (
            "Vertex",
            "Edge",
        ):
            return True, self

        shape = _shape_from_topology(self)

        if _is_null_shape(shape):
            return False, None

        try:
            ang_tolerance = max(
                abs(float(angTolerance)),
                0.0,
            )

            tolerance = max(
                abs(float(tolerance)),
                1.0e-12,
            )
        except Exception:
            return False, None

        try:
            from OCC.Core.BRepAdaptor import (
                BRepAdaptor_Curve,
            )
            from OCC.Core.GeomAbs import (
                GeomAbs_Line,
            )
            from OCC.Core.ShapeUpgrade import (
                ShapeUpgrade_UnifySameDomain,
            )
            from OCC.Core.TopTools import (
                TopTools_MapOfShape,
            )
        except Exception:
            return False, None

        edges_before = (
            _iter_occ_subshapes_unique(
                shape,
                TopAbs_EDGE,
            )
            or []
        )

        if len(edges_before) < 2:
            return True, self

        try:
            unifier = (
                ShapeUpgrade_UnifySameDomain(
                    shape,
                    True,   # UnifyEdges
                    False,  # UnifyFaces
                    False,  # ConcatBSplines
                )
            )

            unifier.SetSafeInputMode(
                True
            )

            unifier.SetLinearTolerance(
                tolerance
            )

            unifier.SetAngularTolerance(
                math.radians(
                    ang_tolerance
                )
            )

            # ----------------------------------------------------------
            # Curve-preserving mode.
            #
            # Keep every vertex belonging to a non-linear Edge. OCCT's
            # KeepShape(vertex) prevents connected Edges from being merged
            # through that vertex.
            #
            # Thus:
            #
            # Line -- Line -- Arc -- Line -- Line
            #
            # can become:
            #
            # Line -------- Arc -------- Line
            #
            # while the Arc remains the exact original OCCT curve.
            # ----------------------------------------------------------

            if not bool(polyhedron):
                protected_vertices = (
                    TopTools_MapOfShape()
                )

                for edge_shape in edges_before:
                    try:
                        adaptor = BRepAdaptor_Curve(
                            topods_Edge(edge_shape)
                        )

                        is_linear = (
                            adaptor.GetType()
                            == GeomAbs_Line
                        )

                    except Exception:
                        is_linear = False

                    if is_linear:
                        continue

                    vertices = (
                        _iter_occ_subshapes_unique(
                            edge_shape,
                            TopAbs_VERTEX,
                        )
                        or []
                    )

                    for vertex_shape in vertices:
                        if protected_vertices.Contains(
                            vertex_shape
                        ):
                            continue

                        protected_vertices.Add(
                            vertex_shape
                        )

                        unifier.KeepShape(
                            vertex_shape
                        )

            unifier.Build()

            unified_shape = unifier.Shape()

            if _is_null_shape(
                unified_shape
            ):
                return False, None

            edges_after = (
                _iter_occ_subshapes_unique(
                    unified_shape,
                    TopAbs_EDGE,
                )
                or []
            )

            if len(edges_after) >= len(
                edges_before
            ):
                return True, self

            result = Topology.ByOcctShape(unified_shape)
            if result is None:
                return False, None

            try:
                result.SetDictionary(Topology.GetDictionary(self))
            except Exception:
                try:
                    result.dictionary = Topology.GetDictionary(self)
                except Exception:
                    pass

            for attribute in ("contents", "contexts", "apertures"):
                try:
                    setattr(
                        result,
                        attribute,
                        list(getattr(self, attribute, []) or []),
                    )
                except Exception:
                    pass

            return True, result

        except Exception:
            return False, None

    def PrincipalAxesNative(self, mantissa: int = 6):
        """
        Returns mass-property principal axes for non-degenerate native BReps.

        The returned axes are ordered from the smallest principal moment of
        inertia to the largest, corresponding to the longest-to-shortest
        geometric directions for anisotropic objects. Symmetric/degenerate
        cases deliberately return ``status=False`` so the established PCA
        implementation can resolve the ambiguity.
        """
        type_name = _topology_type_name(self)
        if type_name not in ("Face", "Shell", "Cell", "CellComplex"):
            return False, None

        shape = _shape_from_topology(self)
        if _is_null_shape(shape):
            return False, None

        try:
            from OCC.Core.BRepGProp import brepgprop
            from OCC.Core.GProp import GProp_GProps
            from OCC.Core.gp import gp_Ax1, gp_Dir

            props = GProp_GProps()

            if type_name in ("Cell", "CellComplex"):
                brepgprop.VolumeProperties(
                    shape,
                    props,
                    False,
                    False,
                    False,
                )
            else:
                brepgprop.SurfaceProperties(
                    shape,
                    props,
                    False,
                    False,
                )

            if abs(float(props.Mass())) <= 1.0e-15:
                return False, None

            principal = props.PrincipalProperties()

            axes_raw = [
                principal.FirstAxisOfInertia(),
                principal.SecondAxisOfInertia(),
                principal.ThirdAxisOfInertia(),
            ]

            center = props.CentreOfMass()
            pairs = []

            for axis in axes_raw:
                x = float(axis.X())
                y = float(axis.Y())
                z = float(axis.Z())

                norm = math.sqrt(x * x + y * y + z * z)
                if norm <= 1.0e-15:
                    return False, None

                x /= norm
                y /= norm
                z /= norm

                moment = float(
                    props.MomentOfInertia(
                        gp_Ax1(
                            center,
                            gp_Dir(x, y, z),
                        )
                    )
                )

                if not math.isfinite(moment):
                    return False, None

                pairs.append([moment, [x, y, z]])

            pairs.sort(key=lambda item: item[0])
            moments = [item[0] for item in pairs]

            scale = max(abs(value) for value in moments)
            if scale <= 1.0e-15:
                return False, None

            # Principal directions are not unique when moments are equal. Use
            # the established PCA path in those cases rather than returning an
            # arbitrary OCCT basis that could change canonical orientation.
            degeneracy_tolerance = max(scale * 1.0e-10, 1.0e-14)
            for i in range(3):
                for j in range(i + 1, 3):
                    if abs(moments[i] - moments[j]) <= degeneracy_tolerance:
                        return False, None

            axes = [list(item[1]) for item in pairs]

            # Deterministic sign: make the largest-magnitude component of each
            # axis positive. Axis sign is physically arbitrary.
            for axis in axes:
                dominant = max(range(3), key=lambda index: abs(axis[index]))
                if axis[dominant] < 0.0:
                    axis[0] *= -1.0
                    axis[1] *= -1.0
                    axis[2] *= -1.0

            # Return a right-handed orthonormal frame.
            cross = [
                axes[0][1] * axes[1][2] - axes[0][2] * axes[1][1],
                axes[0][2] * axes[1][0] - axes[0][0] * axes[1][2],
                axes[0][0] * axes[1][1] - axes[0][1] * axes[1][0],
            ]
            handedness = (
                cross[0] * axes[2][0]
                + cross[1] * axes[2][1]
                + cross[2] * axes[2][2]
            )
            if handedness < 0.0:
                axes[2][0] *= -1.0
                axes[2][1] *= -1.0
                axes[2][2] *= -1.0

            precision = max(0, int(mantissa))
            axes = [
                [round(component, precision) for component in axis]
                for axis in axes
            ]

            return True, axes

        except Exception:
            return False, None


    # -------------------------------------------------------------------
    # Backend Audit V3: native mesh / geometry / OBB extraction
    # -------------------------------------------------------------------

    def BoundingBoxOBBNative(self, optimal: bool = True):
        """Returns native OCCT oriented-bounding-box data."""
        shape = _ensure_compound_shape(self)
        if _is_null_shape(shape):
            return None

        try:
            from OCC.Core.Bnd import Bnd_OBB
            from OCC.Core.BRepBndLib import brepbndlib

            obb = Bnd_OBB()
            brepbndlib.AddOBB(
                shape,
                obb,
                True,          # use triangulation when available
                bool(optimal), # search tighter candidate axes
                False,         # do not inflate by BRep tolerances
            )

            if obb.IsVoid():
                return None

            center = obb.Center()
            xd = obb.XDirection()
            yd = obb.YDirection()
            zd = obb.ZDirection()

            return {
                "center": [float(center.X()), float(center.Y()), float(center.Z())],
                "xdir": [float(xd.X()), float(xd.Y()), float(xd.Z())],
                "ydir": [float(yd.X()), float(yd.Y()), float(yd.Z())],
                "zdir": [float(zd.X()), float(zd.Y()), float(zd.Z())],
                "half_sizes": [
                    abs(float(obb.XHSize())),
                    abs(float(obb.YHSize())),
                    abs(float(obb.ZHSize())),
                ],
            }
        except Exception:
            return None

    @staticmethod
    def _MeshDeflectionNative(shape, tolerance: float = 0.0001):
        """Derives a scale-aware OCCT meshing deflection."""
        tol = max(abs(float(tolerance)), 1.0e-9)
        try:
            from OCC.Core.Bnd import Bnd_Box
            from OCC.Core.BRepBndLib import brepbndlib

            bbox = Bnd_Box()
            brepbndlib.AddOptimal(shape, bbox, True, False)
            if not bbox.IsVoid():
                xmin, ymin, zmin, xmax, ymax, zmax = bbox.Get()
                dx = float(xmax) - float(xmin)
                dy = float(ymax) - float(ymin)
                dz = float(zmax) - float(zmin)
                diagonal = math.sqrt(dx * dx + dy * dy + dz * dz)
                if math.isfinite(diagonal) and diagonal > tol:
                    # 0.5% of the model diagonal is a practical CAD tessellation
                    # default: sufficiently fine for geometric export without
                    # creating pathological triangle counts on curved surfaces.
                    return max(tol, diagonal * 0.005)
        except Exception:
            pass
        return tol

    @staticmethod
    def _TriangulationForFaceNative(face_shape):
        """Returns ``(triangulation, location)`` for an OCCT face."""
        try:
            from OCC.Core.BRep import BRep_Tool
            from OCC.Core.TopLoc import TopLoc_Location

            face_shape = topods_Face(face_shape)
            location = TopLoc_Location()
            triangulation = BRep_Tool.Triangulation(face_shape, location)

            if triangulation is None:
                return None, None
            if hasattr(triangulation, "IsNull") and triangulation.IsNull():
                return None, None

            # pythonocc issue #1444 documents versions where the output
            # TopLoc_Location passed to BRep_Tool.Triangulation is not updated
            # correctly. A face's own Location is the safe fallback for normal
            # BRep placement transforms.
            try:
                face_location = face_shape.Location()
                if (
                    hasattr(location, "IsIdentity")
                    and location.IsIdentity()
                    and hasattr(face_location, "IsIdentity")
                    and not face_location.IsIdentity()
                ):
                    location = face_location
            except Exception:
                pass

            return triangulation, location
        except Exception:
            return None, None

    @staticmethod
    def _TriangleCoordinatesNative(face_shape, tolerance: float = 0.0001):
        """Extracts correctly located/oriented triangle coordinates."""
        try:
            from OCC.Core.TopAbs import TopAbs_REVERSED

            triangulation, location = Topology._TriangulationForFaceNative(face_shape)
            if triangulation is None:
                return None

            transform = None
            try:
                if location is not None and not location.IsIdentity():
                    transform = location.Transformation()
            except Exception:
                transform = None

            reversed_face = (face_shape.Orientation() == TopAbs_REVERSED)
            tol2 = max(abs(float(tolerance)), 1.0e-12) ** 2
            result = []

            def point_xyz(index):
                point = triangulation.Node(int(index))
                if transform is not None:
                    try:
                        point = point.Transformed(transform)
                    except Exception:
                        point.Transform(transform)
                return [float(point.X()), float(point.Y()), float(point.Z())]

            for i in range(1, int(triangulation.NbTriangles()) + 1):
                triangle = triangulation.Triangle(i)
                n1, n2, n3 = triangle.Get()
                if reversed_face:
                    n2, n3 = n3, n2

                p1 = point_xyz(n1)
                p2 = point_xyz(n2)
                p3 = point_xyz(n3)

                ax = p2[0] - p1[0]
                ay = p2[1] - p1[1]
                az = p2[2] - p1[2]
                bx = p3[0] - p1[0]
                by = p3[1] - p1[1]
                bz = p3[2] - p1[2]
                cx = ay * bz - az * by
                cy = az * bx - ax * bz
                cz = ax * by - ay * bx
                area_measure2 = cx * cx + cy * cy + cz * cz

                if area_measure2 <= tol2 * tol2:
                    continue

                result.append([p1, p2, p3])

            return result
        except Exception:
            return None

    def Tessellate(
        self,
        quality="medium",
        linearDeflection=None,
        angularDeflection=None,
        relative=True,
        parallel=True,
        weld=True,
        weldTolerance=0.0001,
        remesh=True,
        mantissa=6,
    ):
        """
        Returns an indexed triangular tessellation of this topology.

        The underlying OCCT BRep is meshed directly. Analytic, Bezier, and
        BSpline/NURBS geometry therefore remains exact until OCCT performs the
        tessellation.
        """
        shape = _ensure_compound_shape(self)

        if _is_null_shape(shape):
            return None

        if not isinstance(
            quality,
            str,
        ):
            return None

        quality_name = (
            quality.strip().lower()
        )

        presets = {
            "coarse": {
                "linear": 0.0200,
                "angle": 25.0,
            },
            "medium": {
                "linear": 0.0100,
                "angle": 15.0,
            },
            "fine": {
                "linear": 0.0025,
                "angle": 8.0,
            },
        }

        if quality_name not in presets:
            return None

        try:
            precision = max(
                0,
                int(mantissa),
            )

            weld_tolerance = max(
                abs(float(weldTolerance)),
                1.0e-12,
            )

        except Exception:
            return None

        # --------------------------------------------------------------
        # Resolve the topology scale.
        # --------------------------------------------------------------

        diagonal = None

        try:
            from OCC.Core.Bnd import Bnd_Box
            from OCC.Core.BRepBndLib import (
                brepbndlib,
            )

            bbox = Bnd_Box()

            brepbndlib.AddOptimal(
                shape,
                bbox,
                False,
                False,
            )

            if not bbox.IsVoid():
                (
                    xmin,
                    ymin,
                    zmin,
                    xmax,
                    ymax,
                    zmax,
                ) = bbox.Get()

                dx = float(xmax) - float(xmin)
                dy = float(ymax) - float(ymin)
                dz = float(zmax) - float(zmin)

                diagonal = math.sqrt(
                    dx * dx
                    + dy * dy
                    + dz * dz
                )

        except Exception:
            diagonal = None

        if (
            diagonal is None
            or not math.isfinite(diagonal)
            or diagonal <= 1.0e-12
        ):
            diagonal = 1.0

        # --------------------------------------------------------------
        # Linear deflection.
        #
        # TopologicPy resolves relative deflection against the whole
        # topology bounding-box diagonal rather than relying on OCCT's
        # per-edge relative-deflection semantics.
        # --------------------------------------------------------------

        if linearDeflection is None:
            linear = max(
                diagonal
                * presets[quality_name]["linear"],
                1.0e-12,
            )

        else:
            try:
                value = abs(
                    float(linearDeflection)
                )
            except Exception:
                return None

            if (
                not math.isfinite(value)
                or value <= 0.0
            ):
                return None

            if bool(relative):
                linear = max(
                    diagonal * value,
                    1.0e-12,
                )
            else:
                linear = value

        # --------------------------------------------------------------
        # Angular deflection.
        # --------------------------------------------------------------

        try:
            angle_deg = (
                presets[quality_name]["angle"]
                if angularDeflection is None
                else abs(
                    float(
                        angularDeflection
                    )
                )
            )
        except Exception:
            return None

        if (
            not math.isfinite(angle_deg)
            or angle_deg <= 0.0
            or angle_deg >= 180.0
        ):
            return None

        try:
            from OCC.Core.BRepMesh import (
                BRepMesh_IncrementalMesh,
            )
            from OCC.Core.TopAbs import (
                TopAbs_FACE,
                TopAbs_REVERSED,
            )
            from OCC.Core.TopExp import (
                TopExp_Explorer,
            )

        except Exception:
            return None

        # --------------------------------------------------------------
        # Clear cached triangulation when requested.
        #
        # Support both older module-style and newer static-class
        # pythonocc BRepTools bindings.
        # --------------------------------------------------------------

        if bool(remesh):
            cleaned = False

            try:
                from OCC.Core.BRepTools import (
                    breptools,
                )

                if hasattr(
                    breptools,
                    "Clean",
                ):
                    try:
                        breptools.Clean(
                            shape,
                            True,
                        )
                    except TypeError:
                        breptools.Clean(
                            shape
                        )

                    cleaned = True

            except Exception:
                pass

            if not cleaned:
                try:
                    from OCC.Core.BRepTools import (
                        BRepTools,
                    )

                    if hasattr(
                        BRepTools,
                        "Clean_s",
                    ):
                        try:
                            BRepTools.Clean_s(
                                shape,
                                True,
                            )
                        except TypeError:
                            BRepTools.Clean_s(
                                shape
                            )

                        cleaned = True

                    elif hasattr(
                        BRepTools,
                        "Clean",
                    ):
                        try:
                            BRepTools.Clean(
                                shape,
                                True,
                            )
                        except TypeError:
                            BRepTools.Clean(
                                shape
                            )

                        cleaned = True

                except Exception:
                    pass

        # --------------------------------------------------------------
        # Mesh once at the requested quality.
        # --------------------------------------------------------------

        try:
            mesher = BRepMesh_IncrementalMesh(
                shape,
                float(linear),
                False,
                math.radians(
                    float(angle_deg)
                ),
                bool(parallel),
            )

            if (
                hasattr(
                    mesher,
                    "IsDone",
                )
                and not mesher.IsDone()
            ):
                return None

        except Exception:
            return None

        vertices = []
        faces = []
        face_sources = []

        buckets = {}
        inv_tolerance = (
            1.0 / weld_tolerance
        )

        def add_point(coords):
            point = [
                round(
                    float(value),
                    precision,
                )
                for value in coords
            ]

            if not bool(weld):
                vertices.append(point)
                return len(vertices) - 1

            key = tuple(
                int(
                    math.floor(
                        value * inv_tolerance
                    )
                )
                for value in point
            )

            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    for dz in (-1, 0, 1):
                        neighbor = (
                            key[0] + dx,
                            key[1] + dy,
                            key[2] + dz,
                        )

                        for index in buckets.get(
                            neighbor,
                            [],
                        ):
                            existing = (
                                vertices[index]
                            )

                            if (
                                abs(
                                    existing[0]
                                    - point[0]
                                )
                                <= weld_tolerance
                                and abs(
                                    existing[1]
                                    - point[1]
                                )
                                <= weld_tolerance
                                and abs(
                                    existing[2]
                                    - point[2]
                                )
                                <= weld_tolerance
                            ):
                                return index

            index = len(vertices)

            vertices.append(point)

            buckets.setdefault(
                key,
                [],
            ).append(index)

            return index

        explorer = TopExp_Explorer(
            shape,
            TopAbs_FACE,
        )

        source_index = 0

        while explorer.More():
            try:
                face_shape = topods_Face(
                    explorer.Current()
                )
            except Exception:
                explorer.Next()
                source_index += 1
                continue

            triangulation, location = (
                Topology._TriangulationForFaceNative(
                    face_shape
                )
            )

            if triangulation is not None:
                transform = None

                try:
                    if (
                        location is not None
                        and not location.IsIdentity()
                    ):
                        transform = (
                            location.Transformation()
                        )
                except Exception:
                    transform = None

                reversed_face = (
                    face_shape.Orientation()
                    == TopAbs_REVERSED
                )

                def coords_at(
                    node_index,
                ):
                    point = (
                        triangulation.Node(
                            int(node_index)
                        )
                    )

                    if transform is not None:
                        try:
                            point = (
                                point.Transformed(
                                    transform
                                )
                            )
                        except Exception:
                            point.Transform(
                                transform
                            )

                    return [
                        float(point.X()),
                        float(point.Y()),
                        float(point.Z()),
                    ]

                for triangle_index in range(
                    1,
                    int(
                        triangulation.NbTriangles()
                    )
                    + 1,
                ):
                    triangle = (
                        triangulation.Triangle(
                            triangle_index
                        )
                    )

                    n1, n2, n3 = (
                        triangle.Get()
                    )

                    if reversed_face:
                        n2, n3 = n3, n2

                    indices = [
                        add_point(
                            coords_at(n1)
                        ),
                        add_point(
                            coords_at(n2)
                        ),
                        add_point(
                            coords_at(n3)
                        ),
                    ]

                    if len(set(indices)) == 3:
                        faces.append(indices)
                        face_sources.append(
                            source_index
                        )

            explorer.Next()
            source_index += 1

        # --------------------------------------------------------------
        # Topologies below Face dimension.
        # --------------------------------------------------------------

        if len(faces) == 0:
            try:
                for vertex in (
                    Topology.Vertices(self)
                    or []
                ):
                    if hasattr(
                        vertex,
                        "x",
                    ):
                        add_point(
                            [
                                vertex.x,
                                vertex.y,
                                vertex.z,
                            ]
                        )
            except Exception:
                pass

        metadata = {
            "source": "occt",
            "quality": quality_name,
            "linearDeflection": float(
                linear
            ),
            "angularDeflection": float(
                angle_deg
            ),
            "relative": bool(relative),
            "parallel": bool(parallel),
            "weld": bool(weld),
            "weldTolerance": float(
                weld_tolerance
            ),
            "remesh": bool(remesh),
            "vertexCount": len(vertices),
            "faceCount": len(faces),
            "triangleCount": len(faces),
            "quadCount": 0,
            "cellCount": 0,
        }

        return {
            "schema": "topologicpy.mesh/1",
            "vertices": vertices,
            "faces": faces,
            "cells": [],
            "metadata": metadata,
            "faceSources": face_sources,
            "verts": vertices,
            "tris": faces,
            "quads": [],
            "tets": [],
        }

    def _GeometryDataNative(self, triangulate_faces: bool = False, mesh_all_faces: bool = False, mantissa: int = 6, tolerance: float = 0.0001):
        """
        Shared extraction engine used by Geometry, MeshData, and Triangulate.

        It preserves Geometry's historic tolerance-aware coordinate merging but
        replaces the O(n^2) scan with a spatial hash. When faces must be
        triangulated, the entire BRep is meshed once in OCCT.
        """
        shape = _shape_from_topology(self)
        if _is_null_shape(shape):
            return None

        type_name = _topology_type_name(self)
        if type_name == "Cluster":
            return None

        try:
            from OCC.Core.BRepMesh import BRepMesh_IncrementalMesh
            from OCC.Core.BRepTools import BRepTools_WireExplorer, breptools
            from OCC.Core.TopTools import TopTools_IndexedMapOfShape

            precision = max(0, int(mantissa))
            threshold = max(
                1.0e-4,
                10.0 ** (-(max(precision, 3) - 1)),
            )
            inv_threshold = 1.0 / threshold

            coordinates = []
            buckets = {}

            def bucket_key(coords):
                return tuple(
                    int(math.floor(float(value) * inv_threshold))
                    for value in coords
                )

            def add_coordinate(coords):
                c = [round(float(value), precision) for value in coords]
                key = bucket_key(c)

                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        for dz in (-1, 0, 1):
                            neighbor = (key[0] + dx, key[1] + dy, key[2] + dz)
                            for index in buckets.get(neighbor, []):
                                existing = coordinates[index]
                                if (
                                    abs(existing[0] - c[0]) <= threshold
                                    and abs(existing[1] - c[1]) <= threshold
                                    and abs(existing[2] - c[2]) <= threshold
                                ):
                                    return index

                index = len(coordinates)
                coordinates.append(c)
                buckets.setdefault(key, []).append(index)
                return index

            def wrapper_coords(vertex):
                return [float(vertex.x), float(vertex.y), float(vertex.z)]

            source_vertices = (
                [self]
                if type_name == "Vertex"
                else (Topology.Vertices(self) or [])
            )
            source_edges = (
                [self]
                if type_name == "Edge"
                else (Topology.Edges(self) or [])
            )
            source_faces = (
                [self]
                if type_name == "Face"
                else (Topology.Faces(self) or [])
            )
            source_cells = (
                [self]
                if type_name == "Cell"
                else (Topology.Cells(self) or [])
            )

            for vertex in source_vertices:
                add_coordinate(wrapper_coords(vertex))

            base_vertex_count = len(coordinates)

            original_edges = []
            for edge in source_edges:
                edge_vertices = Topology.Vertices(edge) or []
                if len(edge_vertices) < 2:
                    continue
                i0 = add_coordinate(wrapper_coords(edge_vertices[0]))
                i1 = add_coordinate(wrapper_coords(edge_vertices[-1]))
                original_edges.append([i0, i1])

            face_should_mesh = []
            requires_mesh = False
            for face in source_faces:
                face_vertices = Topology.Vertices(face) or []
                face_wires = Topology.Wires(face) or []
                has_holes = len(face_wires) > 1
                # Geometry(triangulate=True) historically delegates every
                # face to Face.Triangulate, including curved faces with very
                # few topological vertices. Topology.Triangulate, by contrast,
                # only triangulates faces containing more than three vertices.
                # Keep both semantics while sharing one extraction engine.
                should_mesh = (
                    has_holes
                    or (
                        bool(triangulate_faces)
                        and (bool(mesh_all_faces) or len(face_vertices) > 3)
                    )
                )
                face_should_mesh.append(should_mesh)
                requires_mesh = requires_mesh or should_mesh

            if requires_mesh:
                linear_deflection = Topology._MeshDeflectionNative(shape, tolerance)
                mesher = BRepMesh_IncrementalMesh(
                    shape,
                    float(linear_deflection),
                    False,
                    0.5,
                    True,
                )
                try:
                    mesher.Perform()
                except Exception:
                    pass
                if hasattr(mesher, "IsDone") and not mesher.IsDone():
                    return None

            output_faces = []
            face_sources = []

            for source_index, face in enumerate(source_faces):
                face_shape = _shape_from_topology(face)
                if _is_null_shape(face_shape):
                    return None

                if face_should_mesh[source_index]:
                    triangles = Topology._TriangleCoordinatesNative(
                        face_shape,
                        tolerance=tolerance,
                    )
                    if not triangles:
                        return None
                    for triangle in triangles:
                        indices = [add_coordinate(point) for point in triangle]
                        if len(set(indices)) == 3:
                            output_faces.append(indices)
                            face_sources.append(source_index)
                    continue

                # Preserve an existing triangular face unchanged and preserve
                # Geometry's non-triangulated polygon behavior using the
                # ordered outer boundary.
                try:
                    outer_wire = breptools.OuterWire(topods_Face(face_shape))
                    explorer = BRepTools_WireExplorer(outer_wire)
                    indices = []
                    while explorer.More():
                        vertex_shape = explorer.CurrentVertex()
                        vertex = Topology.ByOcctShape(vertex_shape)
                        if vertex is None or not hasattr(vertex, "x"):
                            return None
                        index = add_coordinate(wrapper_coords(vertex))
                        if not indices or indices[-1] != index:
                            indices.append(index)
                        explorer.Next()

                    if len(indices) > 1 and indices[0] == indices[-1]:
                        indices.pop()

                    if len(indices) >= 3:
                        output_faces.append(indices)
                        face_sources.append(source_index)
                    else:
                        return None
                except Exception:
                    return None

            # Build a native source-face map once so cell connectivity can be
            # expressed in terms of source-face indices. Map semantics use
            # OCCT shape identity (orientation-insensitive IsSame behavior).
            source_face_map = TopTools_IndexedMapOfShape()
            for face in source_faces:
                face_shape = _shape_from_topology(face)
                if _is_null_shape(face_shape):
                    return None
                source_face_map.Add(face_shape)

            source_cell_faces = []
            for cell in source_cells:
                indices = []
                for face in Topology.Faces(cell) or []:
                    face_shape = _shape_from_topology(face)
                    if _is_null_shape(face_shape):
                        continue
                    source_index = int(source_face_map.FindIndex(face_shape))
                    if source_index > 0:
                        indices.append(source_index - 1)
                source_cell_faces.append(indices)

            return {
                "vertices": coordinates,
                "original_edges": original_edges,
                "faces": output_faces,
                "face_sources": face_sources,
                "source_faces": source_faces,
                "source_cell_faces": source_cell_faces,
                "base_vertex_count": base_vertex_count,
            }

        except Exception:
            return None

    def GeometryNative(self, triangulate: bool = False, mantissa: int = 6, tolerance: float = 0.0001):
        """Dictionary-free native implementation of Topology.Geometry."""
        data = self._GeometryDataNative(
            triangulate_faces=bool(triangulate),
            mesh_all_faces=True,
            mantissa=mantissa,
            tolerance=tolerance,
        )
        if not isinstance(data, dict):
            return None

        base_vertex_count = int(data.get("base_vertex_count", 0))
        return {
            "vertices": data.get("vertices", []),
            "edges": data.get("original_edges", []),
            "faces": data.get("faces", []),
            # Preserve the current dictionary-free Geometry shape: the
            # topology path historically appends empty dictionaries for the
            # original vertices only, while edge/face lists remain empty.
            "vertex_dicts": [{} for _ in range(base_vertex_count)],
            "edge_dicts": [],
            "face_dicts": [],
        }

    def TriangulateDataNative(self, tolerance: float = 0.0001):
        """Returns triangle coordinates grouped by source face."""
        data = self._GeometryDataNative(
            triangulate_faces=True,
            mesh_all_faces=False,
            mantissa=12,
            tolerance=tolerance,
        )
        if not isinstance(data, dict):
            return None

        source_faces = data.get("source_faces", [])
        faces = data.get("faces", [])
        sources = data.get("face_sources", [])
        vertices = data.get("vertices", [])

        if len(faces) != len(sources):
            return None

        records = [
            {
                "source_face": source_face,
                "keep_source": False,
                "triangles": [],
            }
            for source_face in source_faces
        ]

        source_vertex_counts = [
            len(Topology.Vertices(face) or [])
            for face in source_faces
        ]
        source_wire_counts = [
            len(Topology.Wires(face) or [])
            for face in source_faces
        ]

        for source_index, count in enumerate(source_vertex_counts):
            if count == 3 and source_wire_counts[source_index] <= 1:
                records[source_index]["keep_source"] = True

        for face_indices, source_index in zip(faces, sources):
            source_index = int(source_index)
            if records[source_index]["keep_source"]:
                continue
            if len(face_indices) != 3:
                return None
            records[source_index]["triangles"].append(
                [vertices[int(index)] for index in face_indices]
            )

        for record in records:
            if not record["keep_source"] and not record["triangles"]:
                return None

        return records

    def MeshDataFastNative(self, mode: int = 1, mantissa: int = 6, tolerance: float = 0.0001):
        """
        Creates MeshData directly from native triangulation when doing so does
        not alter the established dictionary output.

        The historical MeshData method reports existing dictionaries even when
        ``transferDictionaries`` is False; that flag controls dictionary
        transfer to newly triangulated entities, not whether dictionaries are
        returned. If any exported source vertex/edge/face/cell already carries
        a dictionary, return None so the public method uses the preserved V2
        implementation.
        """
        try:
            type_name = _topology_type_name(self)
            dictionary_items = []
            dictionary_items.extend(
                [self] if type_name == "Vertex" else (Topology.Vertices(self) or [])
            )
            dictionary_items.extend(
                [self] if type_name == "Edge" else (Topology.Edges(self) or [])
            )
            dictionary_items.extend(
                [self] if type_name == "Face" else (Topology.Faces(self) or [])
            )
            dictionary_items.extend(
                [self] if type_name == "Cell" else (Topology.Cells(self) or [])
            )

            for item in dictionary_items:
                dictionary = Topology.GetDictionary(item)
                if isinstance(dictionary, dict) and len(dictionary) > 0:
                    return None
        except Exception:
            # If dictionary state cannot be established reliably, prefer the
            # proven implementation rather than risk dropping metadata.
            return None

        # MeshData historically calls Topology.Triangulate first, whose
        # classic behavior only triangulates faces with >3 vertices.
        data = self._GeometryDataNative(
            triangulate_faces=True,
            mesh_all_faces=False,
            mantissa=mantissa,
            tolerance=tolerance,
        )
        if not isinstance(data, dict):
            return None

        vertices = list(data.get("vertices", []))
        faces_by_vertex = [list(face) for face in data.get("faces", [])]
        face_sources = list(data.get("face_sources", []))
        source_cell_faces = list(data.get("source_cell_faces", []))

        if faces_by_vertex:
            edge_lookup = {}
            edges = []
            faces_by_edge = []

            for face in faces_by_vertex:
                if len(face) < 3:
                    return None
                face_edge_indices = []
                for i in range(len(face)):
                    a = int(face[i])
                    b = int(face[(i + 1) % len(face)])
                    if a == b:
                        return None
                    key = (a, b) if a < b else (b, a)
                    edge_index = edge_lookup.get(key)
                    if edge_index is None:
                        edge_index = len(edges)
                        edge_lookup[key] = edge_index
                        edges.append([a, b])
                    face_edge_indices.append(edge_index)
                faces_by_edge.append(face_edge_indices)
        else:
            edges = [list(edge) for edge in data.get("original_edges", [])]
            faces_by_edge = []

        source_to_output = {}
        for output_index, source_index in enumerate(face_sources):
            source_to_output.setdefault(int(source_index), []).append(output_index)

        cells = []
        for source_face_indices in source_cell_faces:
            output_indices = []
            seen = set()
            for source_index in source_face_indices:
                for output_index in source_to_output.get(int(source_index), []):
                    if output_index not in seen:
                        seen.add(output_index)
                        output_indices.append(output_index)
            cells.append(output_indices)

        # Preserve legacy semantics exactly: only the integer value 1 selects
        # edge-indexed faces. All other values select vertex-indexed faces.
        faces = faces_by_edge if mode == 1 else faces_by_vertex

        return {
            "mode": mode,
            "vertices": vertices,
            "edges": edges,
            "faces": faces,
            "cells": cells,
            "vertex_dicts": [{} for _ in vertices],
            "edge_dicts": [{} for _ in edges],
            "face_dicts": [{} for _ in faces],
            "cell_dicts": [{} for _ in cells],
        }
    def BoundingBoxNative(self, mantissa: int = 6):
        """
        Returns the precise native axis-aligned bounds:
        ``[xmin, ymin, zmin, xmax, ymax, zmax]``.
        """
        shape = _ensure_compound_shape(self)
        if _is_null_shape(shape):
            return None

        try:
            from OCC.Core.Bnd import Bnd_Box
            from OCC.Core.BRepBndLib import brepbndlib

            bbox = Bnd_Box()
            brepbndlib.AddOptimal(
                shape,
                bbox,
                True,   # useTriangulation
                False,  # useShapeTolerance
            )

            if bbox.IsVoid():
                return None

            values = list(bbox.Get())
            if len(values) != 6:
                return None

            precision = max(0, int(mantissa))
            return [
                round(float(value), precision)
                for value in values
            ]

        except Exception:
            return None

    def MeshDataNative(self, mode: int = 1, mantissa: int = 6):
        """
        Creates mesh-data connectivity using indexed native OCCT shape maps.

        The input is expected to have already been copied/triangulated by the
        public method, preserving the existing MeshData semantics.
        """
        try:
            from OCC.Core.TopTools import TopTools_IndexedMapOfShape

            type_name = _topology_type_name(self)

            vertices = (
                [self]
                if type_name == "Vertex"
                else (Topology.Vertices(self) or [])
            )
            edges = (
                [self]
                if type_name == "Edge"
                else (Topology.Edges(self) or [])
            )
            faces = (
                [self]
                if type_name == "Face"
                else (Topology.Faces(self) or [])
            )
            cells = (
                [self]
                if type_name == "Cell"
                else (Topology.Cells(self) or [])
            )

            def make_map(items):
                indexed = TopTools_IndexedMapOfShape()
                for item in items:
                    shape = _shape_from_topology(item)
                    if _is_null_shape(shape):
                        return None
                    indexed.Add(shape)
                return indexed

            vertex_map = make_map(vertices)
            edge_map = make_map(edges)
            face_map = make_map(faces)

            if vertex_map is None or edge_map is None or face_map is None:
                return None

            def find_zero_based(indexed, item):
                shape = _shape_from_topology(item)
                if _is_null_shape(shape):
                    return None
                index = int(indexed.FindIndex(shape))
                if index <= 0:
                    return None
                return index - 1

            precision = max(0, int(mantissa))

            vertex_coordinates = [
                [
                    round(float(vertex.x), precision),
                    round(float(vertex.y), precision),
                    round(float(vertex.z), precision),
                ]
                for vertex in vertices
            ]

            edge_connectivity = []
            for edge in edges:
                edge_vertices = Topology.Vertices(edge) or []
                if len(edge_vertices) < 2:
                    return None

                indices = [
                    find_zero_based(vertex_map, edge_vertices[0]),
                    find_zero_based(vertex_map, edge_vertices[-1]),
                ]
                if any(index is None for index in indices):
                    return None
                edge_connectivity.append(indices)

            face_connectivity = []
            for face in faces:
                if int(mode) == 1:
                    items = Topology.Edges(face) or []
                    indexed = edge_map
                else:
                    items = Topology.Vertices(face) or []
                    indexed = vertex_map

                indices = [
                    find_zero_based(indexed, item)
                    for item in items
                ]
                if any(index is None for index in indices):
                    return None
                face_connectivity.append(indices)

            cell_connectivity = []
            for cell in cells:
                cell_faces = Topology.Faces(cell) or []
                indices = [
                    find_zero_based(face_map, face)
                    for face in cell_faces
                ]
                if any(index is None for index in indices):
                    return None
                cell_connectivity.append(indices)

            def python_dictionary(item):
                try:
                    dictionary = Topology.GetDictionary(item)
                    if isinstance(dictionary, dict):
                        return dict(dictionary)
                except Exception:
                    pass
                return {}

            return {
                "mode": mode,
                "vertices": vertex_coordinates,
                "edges": edge_connectivity,
                "faces": face_connectivity,
                "cells": cell_connectivity,
                "vertex_dicts": [
                    python_dictionary(vertex)
                    for vertex in vertices
                ],
                "edge_dicts": [
                    python_dictionary(edge)
                    for edge in edges
                ],
                "face_dicts": [
                    python_dictionary(face)
                    for face in faces
                ],
                "cell_dicts": [
                    python_dictionary(cell)
                    for cell in cells
                ],
            }

        except Exception:
            return None

    def AdjacentCells(self, hostTopology: Any, output=None):
        """
        Returns Cells in ``hostTopology`` that share at least one native OCCT
        Face with this Cell.

        Adjacency is determined by native Face identity, not geometric
        coincidence. The method follows the topologic_core output-list calling
        convention when ``output`` is supplied.
        """
        result = []
        host_shape = _shape_from_topology(hostTopology)
        self_shape = _shape_from_topology(self)

        if _is_null_shape(host_shape) or _is_null_shape(self_shape):
            if output is not None:
                output.extend(result)
                return 0
            return result

        try:
            if self_shape.ShapeType() != TopAbs_SOLID:
                if output is not None:
                    output.extend(result)
                    return 0
                return result
        except Exception:
            if output is not None:
                output.extend(result)
                return 0
            return result

        def _same_shape(a, b):
            try:
                return bool(a.IsSame(b))
            except Exception:
                return False

        # Candidate host Cells, including the root when the host itself is a Cell.
        host_cells = []
        try:
            if host_shape.ShapeType() == TopAbs_SOLID:
                host_cells.append(host_shape)
        except Exception:
            pass
        host_cells.extend(
            _iter_occ_subshapes_unique(host_shape, TopAbs_SOLID) or []
        )

        # Resolve the source Cell to the actual host-side Cell. In the common
        # case this is an IsSame match. If a container constructor copied the
        # solid TShape, identify the source host Cell by the greatest number of
        # corresponding Faces, using the established Face matcher only to map
        # the query Cell back into the host.
        source_cells = [
            candidate
            for candidate in host_cells
            if _same_shape(candidate, self_shape)
        ]

        if not source_cells:
            try:
                source_faces = _iter_occ_subshapes_unique(
                    self_shape,
                    TopAbs_FACE,
                ) or []
                mapped_faces = Topology._NativeMatchingShapes(
                    host_shape,
                    source_faces,
                    TopAbs_FACE,
                    0.0001,
                )

                best_count = 0
                best_cells = []
                for candidate in host_cells:
                    candidate_faces = _iter_occ_subshapes_unique(
                        candidate,
                        TopAbs_FACE,
                    ) or []
                    count = sum(
                        1
                        for candidate_face in candidate_faces
                        if any(
                            _same_shape(candidate_face, mapped_face)
                            for mapped_face in mapped_faces
                        )
                    )
                    if count > best_count:
                        best_count = count
                        best_cells = [candidate]
                    elif count == best_count and count > 0:
                        best_cells.append(candidate)

                source_cells = best_cells if best_count > 0 else []
            except Exception:
                source_cells = []

        if not source_cells:
            if output is not None:
                output.extend(result)
                return 0
            return result

        for source_cell in source_cells:
            source_faces = _iter_occ_subshapes_unique(
                source_cell,
                TopAbs_FACE,
            ) or []

            for candidate in host_cells:
                if _same_shape(candidate, source_cell):
                    continue

                candidate_faces = _iter_occ_subshapes_unique(
                    candidate,
                    TopAbs_FACE,
                ) or []

                if any(
                    _same_shape(source_face, candidate_face)
                    for source_face in source_faces
                    for candidate_face in candidate_faces
                ):
                    try:
                        wrapped = Topology.ByOcctShape(candidate)
                    except Exception:
                        wrapped = None
                    if wrapped is not None:
                        result.append(wrapped)

        result = _deduplicate_by_identity(result)

        if output is not None:
            output.extend(result)
            return 0
        return result


    def SharedTopologies(self, otherTopology: Any, typeID: Any = None, output=None):
        """
        Returns shared subtopologies using native OCCT identity whenever both
        operands carry OCCT shapes.

        Geometric coincidence alone is deliberately not treated as sharing.
        ``TopoDS_Shape.IsSame`` is orientation-insensitive but location-aware,
        which is the required identity relation for a subshape genuinely shared
        by two host topologies.
        """
        type_name = None
        if isinstance(typeID, str):
            type_name = typeID.strip().lower()
        elif isinstance(typeID, int):
            for name, tid in _TYPE_IDS.items():
                if tid == typeID:
                    type_name = name.lower()
                    break

        getter_name = (
            Topology._SUBTOPOLOGY_GETTERS.get(type_name)
            if type_name
            else "Vertices"
        )

        if getter_name is None or otherTopology is None:
            if output is not None:
                return 0
            return []

        # BRepGraph Tranche 1: determine exact sharing from one graph containing
        # both roots. The old pairwise IsSame implementation below remains the
        # fallback for pythonocc-core < 8 and lightweight/shapeless topologies.
        native_type_map = {
            "vertex": TopAbs_VERTEX,
            "edge": TopAbs_EDGE,
            "wire": TopAbs_WIRE,
            "face": TopAbs_FACE,
            "shell": TopAbs_SHELL,
            "cell": TopAbs_SOLID,
            "cellcomplex": TopAbs_COMPSOLID,
            "cluster": TopAbs_COMPOUND,
        }
        requested_native_type = native_type_map.get(type_name or "vertex")
        shape_a = _shape_from_topology(self)
        shape_b = _shape_from_topology(otherTopology)
        if (
            requested_native_type is not None
            and not _is_null_shape(shape_a)
            and not _is_null_shape(shape_b)
        ):
            try:
                shared_native = _brepgraph_shared_shapes(
                    shape_a, shape_b, requested_native_type
                )
            except Exception:
                shared_native = None

            if shared_native is not None:
                result = []
                for shared_shape in shared_native:
                    try:
                        wrapped = Topology.ByOcctShape(shared_shape)
                    except Exception:
                        wrapped = None
                    if wrapped is not None:
                        result.append(wrapped)
                result = _deduplicate_by_identity(result)
                if output is not None:
                    output.extend(result)
                    return 0
                return result

        try:
            my_items = getattr(Topology, getter_name)(self) or []
            other_items = getattr(Topology, getter_name)(otherTopology) or []
        except Exception:
            my_items = []
            other_items = []

        def _same_native_shape(a, b):
            shape_a = _shape_from_topology(a)
            shape_b = _shape_from_topology(b)
            if _is_null_shape(shape_a) or _is_null_shape(shape_b):
                return False
            try:
                return bool(shape_a.IsSame(shape_b))
            except Exception:
                return False

        result = []

        for item in my_items:
            item_shape = _shape_from_topology(item)
            matched = False

            # Native topology: require genuine OCCT sharing. Do not fall back
            # to coordinates/UUIDs when both sides have native shapes.
            if not _is_null_shape(item_shape):
                for other in other_items:
                    other_shape = _shape_from_topology(other)
                    if _is_null_shape(other_shape):
                        continue
                    if _same_native_shape(item, other):
                        matched = True
                        break
            else:
                # Lightweight/shapeless compatibility only.
                if hasattr(item, "x") and hasattr(item, "y") and hasattr(item, "z"):
                    key = vertex_key(item)
                    matched = any(
                        _is_null_shape(_shape_from_topology(other))
                        and hasattr(other, "x")
                        and hasattr(other, "y")
                        and hasattr(other, "z")
                        and vertex_key(other) == key
                        for other in other_items
                    )
                else:
                    uuid = getattr(item, "_uuid", None)
                    if uuid is not None:
                        matched = any(
                            _is_null_shape(_shape_from_topology(other))
                            and getattr(other, "_uuid", None) == uuid
                            for other in other_items
                        )

            if matched:
                result.append(item)

        result = _deduplicate_by_identity(result)

        if output is not None:
            output.extend(result)
            return 0
        return result

    def SelectSubtopology(self, selector: Any, typeID: int = 8):
        type_name = None
        for name, tid in _TYPE_IDS.items():
            if tid == typeID:
                type_name = name
                break
        getter_name = Topology._SUBTOPOLOGY_GETTERS.get((type_name or "face").lower())
        candidates = getattr(Topology, getter_name)(self) or [] if getter_name else []
        if not candidates:
            return None

        selector_shape = _shape_from_topology(selector)
        best = None
        best_distance = None
        for candidate in candidates:
            candidate_shape = _shape_from_topology(candidate)
            distance = None
            if (
                not _is_null_shape(selector_shape)
                and not _is_null_shape(candidate_shape)
                and BRepExtrema_DistShapeShape is not None
            ):
                try:
                    dist_calc = BRepExtrema_DistShapeShape(selector_shape, candidate_shape)
                    if dist_calc.IsDone():
                        distance = dist_calc.Value()
                except Exception:
                    distance = None
            if distance is None and hasattr(selector, "x"):
                center = Topology.CenterOfMass(candidate)
                if center is not None:
                    distance = distance3(selector, center)
            if distance is not None and (best_distance is None or distance < best_distance):
                best_distance = distance
                best = candidate
        return best

    def SelfMerge(self, tolerance: float = 0.0001):
        """
        Normalize a topology aggregate to the cleanest logical topology type.

        The normalization pipeline is intentionally structural-first:

        1. Non-Cluster inputs are returned unchanged.
        2. Nested Clusters are flattened to direct constituents.
        3. Duplicate native constituents are removed by topology identity.
        4. Lower-dimensional constituents already contained in higher-dimensional
        direct constituents are removed.
        5. Same-dimensional groups are promoted using the cheapest appropriate
        constructor (Edges -> Wire, Faces -> Cell/Shell, Cells -> CellComplex).
        6. The expensive cell reconstruction pipeline is used only when the cheaper
        CellComplex construction cannot produce a connected native result.

        A heterogeneous result that cannot be represented by one logical topology
        remains a Cluster.
        """
        from .cluster import Cluster as _Cluster
        from .vertex import Vertex as _Vertex
        from .edge import Edge as _Edge
        from .wire import Wire as _Wire
        from .face import Face as _Face
        from .shell import Shell as _Shell
        from .cell import Cell as _Cell
        from .cell_complex import CellComplex as _CellComplex

        try:
            tol = abs(float(tolerance))
        except Exception:
            tol = 0.0001
        if tol <= 0.0:
            tol = 0.0001

        # SelfMerge normalizes aggregates. A definite non-Cluster topology is
        # already a single logical topology and must not incur OCCT unification.
        if not isinstance(self, _Cluster):
            return self

        rank_by_type = {
            _Vertex: 0,
            _Edge: 1,
            _Wire: 2,
            _Face: 3,
            _Shell: 4,
            _Cell: 5,
            _CellComplex: 6,
        }

        native_type_by_rank = {
            0: TopAbs_VERTEX,
            1: TopAbs_EDGE,
            2: TopAbs_WIRE,
            3: TopAbs_FACE,
            4: TopAbs_SHELL,
            5: TopAbs_SOLID,
        }

        def _rank(item):
            for cls, value in rank_by_type.items():
                if isinstance(item, cls):
                    return value
            return -1

        def _same_native(a, b):
            if a is b:
                return True
            sa = _shape_from_topology(a)
            sb = _shape_from_topology(b)
            if _is_null_shape(sa) or _is_null_shape(sb):
                return False
            try:
                return bool(sa.IsSame(sb))
            except Exception:
                return False

        def _direct_members(cluster):
            members = list(getattr(cluster, "topologies", None) or [])
            if members:
                return [m for m in members if isinstance(m, Topology)]

            # A Cluster reconstructed from a native COMPOUND may not have its
            # Python-side topologies list populated. Recover DIRECT children only.
            shape = _shape_from_topology(cluster)
            if _is_null_shape(shape):
                return []

            try:
                if shape.ShapeType() != TopAbs_COMPOUND:
                    return []
                from OCC.Core.TopoDS import TopoDS_Iterator
                result = []
                iterator = TopoDS_Iterator(shape)
                while iterator.More():
                    child = Topology.ByOcctShape(iterator.Value())
                    if child is not None:
                        result.append(child)
                    iterator.Next()
                return result
            except Exception:
                return []

        def _flatten_clusters(items):
            flattened = []
            stack = list(reversed(items or []))
            visited_clusters = set()

            while stack:
                item = stack.pop()
                if not isinstance(item, Topology):
                    continue

                if isinstance(item, _Cluster):
                    marker = id(item)
                    if marker in visited_clusters:
                        continue
                    visited_clusters.add(marker)
                    children = _direct_members(item)
                    if children:
                        stack.extend(reversed(children))
                        continue

                flattened.append(item)

            return flattened

        def _unique(items):
            # _deduplicate_by_identity is O(n) and uses native OCCT identity when
            # available. Do a final IsSame guard only inside equal-hash collisions
            # implicitly handled by that helper.
            return _deduplicate_by_identity([i for i in items if isinstance(i, Topology)])

        def _is_descendant_of(candidate, parent):
            candidate_rank = _rank(candidate)
            parent_rank = _rank(parent)
            if candidate_rank < 0 or parent_rank <= candidate_rank:
                return False

            candidate_shape = _shape_from_topology(candidate)
            parent_shape = _shape_from_topology(parent)

            if not _is_null_shape(candidate_shape) and not _is_null_shape(parent_shape):
                target_type = native_type_by_rank.get(candidate_rank)
                if target_type is not None:
                    try:
                        for subshape in _iter_occ_subshapes_unique(parent_shape, target_type):
                            try:
                                if subshape.IsSame(candidate_shape):
                                    return True
                            except Exception:
                                pass
                    except Exception:
                        pass

            # Lightweight/shapeless fallback for backend objects that explicitly
            # retain their constituent wrappers.
            attrs_by_rank = {
                0: ("vertices",),
                1: ("edges",),
                2: ("wires",),
                3: ("faces",),
                4: ("shells",),
                5: ("cells",),
            }
            for attr in attrs_by_rank.get(candidate_rank, ()):
                for child in list(getattr(parent, attr, None) or []):
                    if child is candidate or _same_native(child, candidate):
                        return True

            return False

        def _remove_redundant(items):
            items = _unique(items)
            if len(items) < 2:
                return items

            ranked = sorted(
                enumerate(items),
                key=lambda pair: _rank(pair[1]),
                reverse=True,
            )

            keep = [True] * len(items)

            for low_index, low in enumerate(items):
                low_rank = _rank(low)
                if low_rank < 0:
                    continue

                for original_index, high in ranked:
                    if original_index == low_index:
                        continue
                    if _rank(high) <= low_rank:
                        break
                    if _is_descendant_of(low, high):
                        keep[low_index] = False
                        break

            return [item for i, item in enumerate(items) if keep[i]]

        def _cellcomplex_connected_result(candidate):
            """Return a connected Cell/CellComplex result, otherwise None."""
            if not isinstance(candidate, (_Cell, _CellComplex)):
                return None

            shape = _shape_from_topology(candidate)
            if _is_null_shape(shape):
                return None

            try:
                solids = _iter_occ_subshapes_unique(shape, TopAbs_SOLID)
            except Exception:
                solids = []

            # A single resulting solid is logically a Cell.
            if len(solids) == 1:
                try:
                    wrapped = Topology.ByOcctShape(solids[0])
                    return wrapped if isinstance(wrapped, _Cell) else candidate
                except Exception:
                    return candidate if isinstance(candidate, _Cell) else None

            if len(solids) < 2:
                return candidate if isinstance(candidate, _Cell) else None

            parent = list(range(len(solids)))

            def _find(x):
                while parent[x] != x:
                    parent[x] = parent[parent[x]]
                    x = parent[x]
                return x

            def _union(a, b):
                ra = _find(a)
                rb = _find(b)
                if ra != rb:
                    parent[ra] = rb

            # Adjacent cells in a genuine CellComplex share native Faces after the
            # CellsBuilder/volume reconstruction. Hash buckets avoid O(F^2) scans;
            # IsSame confirms identity inside a bucket.
            face_buckets = {}
            for solid_index, solid in enumerate(solids):
                try:
                    faces = _iter_occ_subshapes_unique(solid, TopAbs_FACE)
                except Exception:
                    faces = []

                for face in faces:
                    try:
                        key = hash(face)
                    except Exception:
                        key = id(face)

                    bucket = face_buckets.setdefault(key, [])
                    for other_index, other_face in bucket:
                        try:
                            same = bool(face.IsSame(other_face))
                        except Exception:
                            same = False
                        if same:
                            _union(solid_index, other_index)
                    bucket.append((solid_index, face))

            roots = {_find(i) for i in range(len(solids))}
            if len(roots) == 1:
                return candidate

            # Do not label disconnected solids as one CellComplex merely because a
            # COMPSOLID container can technically be constructed around them.
            return None

        def _normalize_cells(cells):
            cells = _unique([c for c in cells if isinstance(c, _Cell)])
            if not cells:
                return None
            if len(cells) == 1:
                return cells[0]

            # Cheap/native assembly first. CellComplex.ByCells begins with one
            # CellsBuilder pass and is substantially cheaper than _self_merge_cells.
            candidate = None
            try:
                candidate = _CellComplex.ByCells(cells, tolerance=tol)
            except TypeError:
                try:
                    candidate = _CellComplex.ByCells(cells, tol)
                except Exception:
                    candidate = None
            except Exception:
                candidate = None

            connected = _cellcomplex_connected_result(candidate)
            if connected is not None:
                return connected

            # If the cheap builder produced a real native aggregate but its solids
            # are disconnected, that is a definitive structural result: they are
            # not one CellComplex. Do not launch the expensive subdivision pipeline.
            candidate_shape = _shape_from_topology(candidate)
            if isinstance(candidate, _CellComplex) and not _is_null_shape(candidate_shape):
                return _Cluster.ByTopologies(cells)

            # Expensive subdivision/reconstruction is a fallback only when the
            # cheap path could not produce a usable native result at all.
            try:
                candidate = Topology._self_merge_cells(cells, tol)
            except Exception:
                candidate = None

            connected = _cellcomplex_connected_result(candidate)
            if connected is not None:
                return connected

            return _Cluster.ByTopologies(cells)

        def _normalize_cellcomplexes(cell_complexes):
            cell_complexes = _unique([c for c in cell_complexes if isinstance(c, _CellComplex)])
            if not cell_complexes:
                return None
            if len(cell_complexes) == 1:
                return cell_complexes[0]

            cells = []
            for cc in cell_complexes:
                direct = list(getattr(cc, "cells", None) or [])
                if direct:
                    cells.extend([c for c in direct if isinstance(c, _Cell)])
                    continue

                shape = _shape_from_topology(cc)
                if _is_null_shape(shape):
                    continue
                try:
                    for solid in _iter_occ_subshapes_unique(shape, TopAbs_SOLID):
                        wrapped = Topology.ByOcctShape(solid)
                        if isinstance(wrapped, _Cell):
                            cells.append(wrapped)
                except Exception:
                    pass

            if cells:
                normalized = _normalize_cells(cells)
                if normalized is not None:
                    return normalized

            return _Cluster.ByTopologies(cell_complexes)

        def _normalize_faces(faces):
            faces = _unique([f for f in faces if isinstance(f, _Face)])
            if not faces:
                return None
            if len(faces) == 1:
                return faces[0]

            # Highest valid promotion first: a closed face soup is a Cell.
            try:
                cell = _Cell.ByFaces(faces, tolerance=tol, silent=True)
            except TypeError:
                try:
                    cell = _Cell.ByFaces(faces, tolerance=tol)
                except Exception:
                    cell = None
            except Exception:
                cell = None

            if isinstance(cell, _Cell) and not _is_null_shape(_shape_from_topology(cell)):
                return cell

            try:
                shell = _Shell.ByFaces(faces, tolerance=tol, silent=True)
            except TypeError:
                try:
                    shell = _Shell.ByFaces(faces, tolerance=tol)
                except Exception:
                    shell = None
            except Exception:
                shell = None

            if isinstance(shell, _Shell):
                shell_shape = _shape_from_topology(shell)
                if not _is_null_shape(shell_shape):
                    try:
                        if shell_shape.ShapeType() == TopAbs_SHELL:
                            return shell
                    except Exception:
                        pass

                    # Sewing can legitimately produce several disconnected Shells
                    # inside a COMPOUND. Preserve them as a Cluster instead of
                    # mislabelling the compound as one Shell.
                    try:
                        sewn_shells = _iter_occ_subshapes_unique(shell_shape, TopAbs_SHELL)
                    except Exception:
                        sewn_shells = []

                    wrapped_shells = []
                    for sewn_shell in sewn_shells:
                        try:
                            wrapped = Topology.ByOcctShape(sewn_shell)
                        except Exception:
                            wrapped = None
                        if isinstance(wrapped, _Shell):
                            wrapped_shells.append(wrapped)

                    wrapped_shells = _unique(wrapped_shells)
                    if len(wrapped_shells) == 1:
                        return wrapped_shells[0]
                    if len(wrapped_shells) > 1:
                        return _Cluster.ByTopologies(wrapped_shells)

                return shell

            return _Cluster.ByTopologies(faces)

        def _normalize_wires(wires):
            wires = _unique([w for w in wires if isinstance(w, _Wire)])
            if not wires:
                return None
            if len(wires) == 1:
                return wires[0]

            edges = []
            for wire in wires:
                direct = list(getattr(wire, "edges", None) or [])
                if direct:
                    edges.extend([e for e in direct if isinstance(e, _Edge)])
                    continue
                shape = _shape_from_topology(wire)
                if _is_null_shape(shape):
                    continue
                try:
                    for edge_shape in _iter_occ_subshapes_unique(shape, TopAbs_EDGE):
                        wrapped = Topology.ByOcctShape(edge_shape)
                        if isinstance(wrapped, _Edge):
                            edges.append(wrapped)
                except Exception:
                    pass

            if edges:
                merged = Topology._merge_edges_into_wires(edges, tol)
                if merged is not None:
                    return merged

            return _Cluster.ByTopologies(wires)

        def _normalize_edges(edges):
            edges = _unique([e for e in edges if isinstance(e, _Edge)])
            if not edges:
                return None
            if len(edges) == 1:
                return edges[0]
            merged = Topology._merge_edges_into_wires(edges, tol)
            return merged if merged is not None else _Cluster.ByTopologies(edges)

        def _normalize_vertices(vertices):
            vertices = _unique([v for v in vertices if isinstance(v, _Vertex)])
            if not vertices:
                return None
            if len(vertices) == 1:
                return vertices[0]
            return _Cluster.ByTopologies(vertices)

        members = _direct_members(self)
        members = _flatten_clusters(members)
        members = _remove_redundant(members)

        if not members:
            return self
        if len(members) == 1:
            return members[0]

        groups = {rank: [] for rank in range(7)}
        residual = []

        for member in members:
            rank = _rank(member)
            if rank >= 0:
                groups[rank].append(member)
            else:
                residual.append(member)

        normalized = []

        normalizers = {
            6: _normalize_cellcomplexes,
            5: _normalize_cells,
            4: lambda values: values[0] if len(values) == 1 else _Cluster.ByTopologies(_unique(values)),
            3: _normalize_faces,
            2: _normalize_wires,
            1: _normalize_edges,
            0: _normalize_vertices,
        }

        for rank in range(6, -1, -1):
            values = groups[rank]
            if not values:
                continue
            try:
                piece = normalizers[rank](values)
            except Exception:
                piece = None
            if piece is not None:
                normalized.append(piece)
            else:
                normalized.extend(values)

        normalized.extend(residual)
        normalized = _flatten_clusters(normalized)
        normalized = _remove_redundant(normalized)

        if not normalized:
            return self
        if len(normalized) == 1:
            return normalized[0]

        result = _Cluster.ByTopologies(normalized)
        return result if result is not None else self

    @staticmethod
    def _self_merge_cells(members, tolerance=0.0001):
        """
        Port of topologic_core Topology::SelfMerge for all-cell members: CellsBuilder -> unique
        faces -> BOPAlgo_MakerVolume rebuild -> a SECOND CellsBuilder pass re-including the
        original cells. The re-inclusion is what discovers finer subdivisions and reproduces
        core's exact cell counts for overlapping subdivided CellComplexes.
        """
        try:
            from OCC.Core.BOPAlgo import BOPAlgo_MakerVolume
        except Exception:
            return None

        shapes = [m.shape for m in members if not _is_null_shape(getattr(m, "shape", None))]
        if not shapes:
            return None

        try:
            args1 = TopTools_ListOfShape()
            for s in shapes:
                args1.Append(s)
            cb1 = BOPAlgo_CellsBuilder()
            cb1.SetArguments(args1)
            cb1.Perform()
            if cb1.HasErrors() or cb1.HasWarnings():
                return None
            cb1.AddAllToResult()

            discarded = [s for s in shapes if cb1.IsDeleted(s)]

            seen_hashes = set()
            occt_faces = []
            explorer = TopExp_Explorer(cb1.Shape(), TopAbs_FACE)
            while explorer.More():
                face = explorer.Current()
                h = hash(face)
                if h not in seen_hashes:
                    seen_hashes.add(h)
                    occt_faces.append(face)
                explorer.Next()

            args2 = TopTools_ListOfShape()
            for f in occt_faces:
                args2.Append(f)
            volume_maker = BOPAlgo_MakerVolume()
            volume_maker.SetArguments(args2)
            volume_maker.SetRunParallel(False)
            volume_maker.SetIntersect(True)
            volume_maker.SetFuzzyValue(0.0)
            volume_maker.Perform()
            volume_maker_ok = not (volume_maker.HasErrors() or volume_maker.HasWarnings())
            if volume_maker_ok:
                discarded.extend(f for f in occt_faces if volume_maker.IsDeleted(f))

            other_shapes = [s for s in shapes if s.ShapeType() != TopAbs_FACE]

            final_args = []
            if volume_maker_ok:
                final_args.append(volume_maker.Shape())
            final_args.extend(discarded)
            final_args.extend(other_shapes)

            if len(final_args) == 1:
                return Topology.ByOcctShape(volume_maker.Shape())

            args3 = TopTools_ListOfShape()
            for s in final_args:
                args3.Append(s)
            cb2 = BOPAlgo_CellsBuilder()
            cb2.SetArguments(args3)
            cb2.Perform()
            if cb2.HasErrors():
                return None
            cb2.AddAllToResult()
            cb2.MakeContainers()
            result_shape = cb2.Shape()
        except Exception:
            return None

        if _is_null_shape(result_shape):
            return None
        result_shape = _postprocess_boolean_result(result_shape)
        result_shape = _promote_to_compsolid_if_multi_solid(result_shape, force=True)
        return Topology.ByOcctShape(result_shape)

    @staticmethod
    def _merge_edges_into_wires(edges, tolerance=0.0001):
        """
        Merge connected Edge components into Wires in near-linear time.

        The previous implementation repeatedly attempted to add every remaining
        Edge to a growing BRepBuilderAPI_MakeWire, leading to quadratic behaviour
        on large or disjoint edge collections. This implementation first builds an
        endpoint-incidence graph with a tolerance-aware spatial hash, then invokes
        Wire.ByEdges once per connected component.
        """
        import math

        from .edge import Edge as _Edge
        from .wire import Wire as _Wire
        from .cluster import Cluster as _Cluster
        from .helpers import same_vertex

        try:
            tol = abs(float(tolerance))
        except Exception:
            tol = 0.0001
        if tol <= 0.0:
            tol = 0.0001

        edges = _deduplicate_by_identity([
            edge
            for edge in (edges or [])
            if isinstance(edge, _Edge)
            and not _is_null_shape(_shape_from_topology(edge))
        ])

        if not edges:
            return None
        if len(edges) == 1:
            return edges[0]

        canonical_vertices = []
        grid = {}

        def _vertex_id(vertex):
            if vertex is None:
                return None

            try:
                x = float(vertex.x)
                y = float(vertex.y)
                z = float(vertex.z)
            except Exception:
                return None

            cell = (
                math.floor(x / tol),
                math.floor(y / tol),
                math.floor(z / tol),
            )

            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    for dz in (-1, 0, 1):
                        for vertex_index in grid.get(
                            (cell[0] + dx, cell[1] + dy, cell[2] + dz),
                            (),
                        ):
                            existing = canonical_vertices[vertex_index]
                            try:
                                if same_vertex(vertex, existing, tol):
                                    return vertex_index
                            except Exception:
                                pass

            vertex_index = len(canonical_vertices)
            canonical_vertices.append(vertex)
            grid.setdefault(cell, []).append(vertex_index)
            return vertex_index

        edge_nodes = []
        node_to_edges = {}

        for edge_index, edge in enumerate(edges):
            a = _vertex_id(getattr(edge, "start", None))
            b = _vertex_id(getattr(edge, "end", None))
            edge_nodes.append((a, b))

            if a is not None:
                node_to_edges.setdefault(a, []).append(edge_index)
            if b is not None:
                node_to_edges.setdefault(b, []).append(edge_index)

        unseen = set(range(len(edges)))
        components = []

        while unseen:
            seed = unseen.pop()
            stack = [seed]
            component = [seed]

            while stack:
                edge_index = stack.pop()
                a, b = edge_nodes[edge_index]

                for node in (a, b):
                    if node is None:
                        continue
                    for neighbor_edge in node_to_edges.get(node, ()):
                        if neighbor_edge in unseen:
                            unseen.remove(neighbor_edge)
                            stack.append(neighbor_edge)
                            component.append(neighbor_edge)

            components.append(component)

        wires = []

        for component in components:
            component_edges = [edges[i] for i in component]

            if len(component_edges) == 1:
                # A single Edge is already the simplest correct topology.
                wires.append(component_edges[0])
                continue

            try:
                wire = _Wire.ByEdges(component_edges, tolerance=tol)
            except TypeError:
                try:
                    wire = _Wire.ByEdges(component_edges, tol)
                except Exception:
                    wire = None
            except Exception:
                wire = None

            if wire is None:
                # Preserve all data rather than dropping a failed component.
                fallback = _Cluster.ByTopologies(component_edges)
                if fallback is not None:
                    wires.append(fallback)
            else:
                wires.append(wire)

        if not wires:
            return None
        if len(wires) == 1:
            return wires[0]

        return _Cluster.ByTopologies(wires)


# -----------------------------------------------------------------------------
# TopologyUtility namespace
# -----------------------------------------------------------------------------
#
# The developer guide (section 3 / Appendix A) lists TopologyUtility as a
# required namespace, noting it "can alias Topology if Core exposes it that
# way." backend.py and __init__.py already import TopologyUtility from this
# module; without this alias the whole pythonocc_backend package fails to
# import (ImportError: cannot import name 'TopologyUtility').
TopologyUtility = Topology
