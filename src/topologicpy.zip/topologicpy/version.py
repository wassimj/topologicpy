# Set topologicpy version number
__version__ = '0.9.92'
