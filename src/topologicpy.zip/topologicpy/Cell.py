# Copyright (C) 2026
# Wassim Jabi <wassim.jabi@gmail.com>
#
# This program is free software: you can redistribute it and/or modify it under
# the terms of the GNU Lesser General Public License as published by the Free Software
# Foundation, either version 3.0 of the License, or (at your option) any later
# version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
# details.
#
# You should have received a copy of the GNU Lesser General Public License along with
# this program. If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

from topologicpy.Core import Core
    
class Cell():
    def _NativeCell(methodName: str, *args, silent: bool = False, **kwargs):
        """Call a PythonOCC-only native Cell constructor without silent approximation."""
        from topologicpy.Topology import Topology
        try:
            if Topology._IsTopologicCoreBackend():
                if not silent:
                    print(f"Cell.{methodName[2:] if methodName.startswith('By') else methodName} - Error: polyhedron=False requires the PythonOCC backend. Returning None.")
                return None
        except Exception:
            return None
        method = getattr(Core.Cell, methodName, None)
        if not callable(method):
            if not silent:
                print(f"Cell.{methodName[2:] if methodName.startswith('By') else methodName} - Error: Native backend constructor is unavailable. Returning None.")
            return None
        try:
            return method(*args, **kwargs)
        except Exception:
            return None

    def _PlaceNativeCell(cell, origin=None, direction=[0, 0, 1], sourceOrigin=None, tolerance: float = 0.0001, silent: bool = False):
        """Orient and place a canonical native Cell using TopologicPy transforms."""
        from topologicpy.Vertex import Vertex
        from topologicpy.Topology import Topology
        if not Topology.IsInstance(cell, "Cell"):
            return None
        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.Origin()
        if sourceOrigin is None:
            sourceOrigin = [0.0, 0.0, 0.0]
        if not Topology.IsInstance(sourceOrigin, "Vertex"):
            try:
                sourceOrigin = Vertex.ByCoordinates(sourceOrigin[0], sourceOrigin[1], sourceOrigin[2])
            except Exception:
                return None
        return Topology.OrientAndPlace(cell, originA=sourceOrigin, originB=origin, dirA=[0, 0, 1], dirB=direction, transferDictionaries=False, tolerance=tolerance, silent=silent)

    @staticmethod
    def Area(cell, mantissa: int = 6):
        """
        Returns the surface area of the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The cell.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.

        Returns
        -------
        float
            The surface area of the input cell.

        """
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology

        faces = Topology.Faces(cell)
        area = 0.0
        for aFace in faces:
            area = area + Face.Area(aFace)
        return round(area, mantissa)

    @staticmethod
    def Box(origin = None,
            width: float = 1,
            length: float = 1,
            height: float = 1,
            uSides: int = 1,
            vSides: int = 1,
            wSides: int = 1,
            direction: list = [0, 0, 1],
            placement: str ="center",
            tolerance: float = 0.0001,
            silent: bool = False):
        """
        Creates a box.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the box. Default is None which results in the box being placed at (0, 0, 0).
        width : float , optional
            The width of the box. Default is 1.
        length : float , optional
            The length of the box. Default is 1.
        height : float , optional
            The height of the box.
        uSides : int , optional
            The number of sides along the width. Default is 1.
        vSides : int , optional
            The number of sides along the length. Default is 1.
        wSides : int , optional
            The number of sides along the height. Default is 1.
        direction : list , optional
            The vector representing the up direction of the box. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the box. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        topologic_core.Cell
            The created box.

        """
        return Cell.Prism(origin=origin, width=width, length=length, height=height,
                          uSides=uSides, vSides=vSides, wSides=wSides,
                          direction=direction, placement=placement, tolerance=tolerance, silent=silent)

    # @staticmethod
    # def ByFaces(faces: list,
    #             planarize: bool = False,
    #             transferDictionaries: bool = False,
    #             tolerance: float = 0.0001,
    #             silent: bool = False):
    #     """
    #     Creates a cell from the input list of faces.

    #     Parameters
    #     ----------
    #     faces : list
    #         The input list of faces.
    #     planarize : bool, optional
    #         If set to True, the input faces are planarized before building the cell. Otherwise, they are not.
    #         Default is False.
    #     transferDictionaries : bool , optional
    #         If set to True, any dictionaries in the faces are transferred to the faces of the created Cell.
    #         Otherwise, they are not. Default is False.
    #     tolerance : float , optional
    #         The desired tolerance. Default is 0.0001.
    #     silent : bool , optional
    #         If set to True, error and warning messages are suppressed. Default is False.

    #     Returns
    #     -------
    #     topologic_core.Cell
    #         The created cell.

    #     """
    #     from topologicpy.Vertex import Vertex
    #     from topologicpy.Wire import Wire
    #     from topologicpy.Face import Face
    #     from topologicpy.Cluster import Cluster
    #     from topologicpy.Topology import Topology
    #     from topologicpy.Dictionary import Dictionary

    #     def _fail(message):
    #         if not silent:
    #             print(message)
    #         return None

    #     if not isinstance(faces, list):
    #         return _fail("Cell.ByFaces - Error: The input faces parameter is not a valid list. Returning None.")

    #     face_list = [face for face in faces if Topology.IsInstance(face, "Face")]
    #     if len(face_list) < 3:
    #         return _fail("Cell.ByFaces - Error: The input faces parameter does not contain at least three valid faces. Returning None.")

    #     # First attempt: use the input faces directly.
    #     cell = Core.Cell.ByFaces(face_list, tolerance)
    #     if Topology.IsInstance(cell, "Cell"):
    #         return cell

    #     # Second attempt: rebuild each face from its closed external and internal boundaries.
    #     clean_faces = []
    #     for face in face_list:
    #         external_boundary = Face.ExternalBoundary(face)
    #         if not Topology.IsInstance(external_boundary, "Wire") or not Wire.IsClosed(external_boundary):
    #             continue

    #         internal_boundaries = Face.InternalBoundaries(face)
    #         closed_internal_boundaries = []

    #         for internal_boundary in internal_boundaries:
    #             if Topology.IsInstance(internal_boundary, "Wire") and Wire.IsClosed(internal_boundary):
    #                 closed_internal_boundaries.append(internal_boundary)
    #             elif not silent:
    #                 print("Cell.ByFaces - Warning: Found an open internal boundary. Skipping it.")

    #         clean_face = Face.ByWires(external_boundary, closed_internal_boundaries, tolerance=tolerance, silent=True)
    #         if Topology.IsInstance(clean_face, "Face"):
    #             clean_faces.append(clean_face)
    #         elif isinstance(clean_face, list):
    #             clean_faces.extend([f for f in clean_face if Topology.IsInstance(f, "Face")])

    #     if len(clean_faces) >= 3:
    #         cell = Core.Cell.ByFaces(clean_faces, tolerance)
    #         if Topology.IsInstance(cell, "Cell"):
    #             return cell

    #     if not silent:
    #         print("Cell.ByFaces - Warning: Could not construct cell from cleaned faces. Trying vertex-fused reconstruction.")

    #     # Third attempt: fuse all vertices and rebuild the faces with shared vertex instances.
    #     all_vertices = []
    #     closed_wires = []

    #     source_faces = clean_faces if len(clean_faces) >= 3 else face_list

    #     for face in source_faces:
    #         wire = Face.Wire(face)
    #         if Topology.IsInstance(wire, "Wire") and Wire.IsClosed(wire):
    #             closed_wires.append(wire)
    #             all_vertices.extend(Topology.Vertices(wire))

    #     if len(closed_wires) < 3 or len(all_vertices) < 4:
    #         return _fail("Cell.ByFaces - Error: Could not find enough closed face wires to construct a cell. Returning None.")

    #     fused_vertices = Vertex.Fuse(all_vertices, tolerance=tolerance)
    #     if not isinstance(fused_vertices, list) or len(fused_vertices) < 4:
    #         return _fail("Cell.ByFaces - Error: Could not fuse enough vertices to construct a cell. Returning None.")

    #     reconstructed_faces = []

    #     for wire in closed_wires:
    #         wire_vertices = Topology.Vertices(wire)
    #         reconstructed_vertices = []

    #         for vertex in wire_vertices:
    #             vertex_index = Vertex.Index(vertex, fused_vertices, tolerance=tolerance)
    #             if vertex_index is not None:
    #                 reconstructed_vertices.append(fused_vertices[vertex_index])

    #         if len(reconstructed_vertices) < 3:
    #             continue

    #         reconstructed_wire = Wire.ByVertices(reconstructed_vertices, close=True, tolerance=tolerance, silent=True)
    #         if not Topology.IsInstance(reconstructed_wire, "Wire"):
    #             continue

    #         reconstructed_face = Face.ByWire(reconstructed_wire, tolerance=tolerance, silent=True)
    #         if Topology.IsInstance(reconstructed_face, "Face"):
    #             reconstructed_faces.append(reconstructed_face)
    #         elif isinstance(reconstructed_face, list):
    #             reconstructed_faces.extend([f for f in reconstructed_face if Topology.IsInstance(f, "Face")])

    #     if len(reconstructed_faces) < 3:
    #         return _fail("Cell.ByFaces - Error: Could not reconstruct enough valid faces. Returning None.")

    #     face_list = reconstructed_faces

    #     if planarize:
    #         planarized_faces = []

    #         for face in face_list:
    #             planarized_face = Face.Planarize(face, tolerance=tolerance)
    #             if Topology.IsInstance(planarized_face, "Face"):
    #                 planarized_faces.append(planarized_face)

    #         if len(planarized_faces) < 3:
    #             return _fail("Cell.ByFaces - Error: Could not planarize enough valid faces. Returning None.")

    #         enlarged_faces = []

    #         for face in planarized_faces:
    #             enlarged_face = Face.ByOffset(face, offset=-tolerance * 10, tolerance=tolerance, silent=True)
    #             if Topology.IsInstance(enlarged_face, "Face"):
    #                 enlarged_faces.append(enlarged_face)
    #             elif isinstance(enlarged_face, list):
    #                 enlarged_faces.extend([f for f in enlarged_face if Topology.IsInstance(f, "Face")])

    #         if len(enlarged_faces) < 3:
    #             return _fail("Cell.ByFaces - Error: Could not enlarge enough valid faces. Returning None.")

    #         cell = Core.Cell.ByFaces(enlarged_faces, tolerance)
    #         if not Topology.IsInstance(cell, "Cell"):
    #             return _fail("Cell.ByFaces - Error: The planarized cell construction failed. Returning None.")

    #         candidate_faces = Topology.Faces(cell)
    #         exterior_faces = []

    #         for face in candidate_faces:
    #             centroid = Topology.Centroid(face)
    #             normal = Face.Normal(face)

    #             test_vertex = Topology.Translate(centroid,
    #                                             x=normal[0] * 0.01,
    #                                             y=normal[1] * 0.01,
    #                                             z=normal[2] * 0.01,
    #                                             transferDictionaries=False,
    #                                             silent=True)

    #             if not Vertex.IsInternal(test_vertex, cell, tolerance=tolerance):
    #                 exterior_faces.append(face)

    #         final_faces = []

    #         for face in exterior_faces:
    #             external_boundary = Face.ExternalBoundary(face)
    #             vertices = Topology.Vertices(face)
    #             cycles = Wire.Cycles(external_boundary, maxVertices=len(vertices))

    #             if not isinstance(cycles, list) or len(cycles) < 1:
    #                 continue

    #             final_face = Face.ByWire(cycles[0], tolerance=tolerance, silent=True)
    #             if Topology.IsInstance(final_face, "Face"):
    #                 final_faces.append(final_face)
    #             elif isinstance(final_face, list):
    #                 final_faces.extend([f for f in final_face if Topology.IsInstance(f, "Face")])

    #         if len(final_faces) < 3:
    #             return _fail("Cell.ByFaces - Error: Could not extract enough final faces after planarization. Returning None.")

    #         cell = Core.Cell.ByFaces(final_faces, tolerance)
    #         if not Topology.IsInstance(cell, "Cell"):
    #             return _fail("Cell.ByFaces - Error: The final planarized cell construction failed. Returning None.")

    #     else:
    #         cell = Core.Cell.ByFaces(face_list, tolerance)
    #         if not Topology.IsInstance(cell, "Cell"):
    #             return _fail("Cell.ByFaces - Error: The operation failed. Returning None.")

    #     if transferDictionaries:
    #         cell_faces = Topology.Faces(cell)
    #         source_cluster = Cluster.ByTopologies(faces)

    #         for cell_face in cell_faces:
    #             internal_vertex = Topology.InternalVertex(cell_face, tolerance=tolerance)
    #             enclosing_faces = Vertex.EnclosingFaces(internal_vertex,
    #                                                     source_cluster,
    #                                                     exclusive=False,
    #                                                     tolerance=tolerance)

    #             if isinstance(enclosing_faces, list) and len(enclosing_faces) > 0:
    #                 dictionaries = [Topology.Dictionary(face) for face in enclosing_faces]
    #                 merged_dictionary = Dictionary.ByMergedDictionaries(dictionaries, silent=silent)
    #                 Topology.SetDictionary(cell_face, merged_dictionary)

    #     return cell

    @staticmethod
    def ByFaces(
        faces: list,
        planarize: bool = False,
        transferDictionaries: bool = False,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Creates a Cell from the input list of Faces.

        The supplied Faces are passed directly to the active backend so their
        supporting surfaces and boundary curves are preserved. If construction
        fails, the method may retry sewing with a slightly larger tolerance and
        may self-merge the original Faces. It never reconstructs Faces from their
        Wires, Edges, or Vertices.

        If ``planarize`` is True, the Faces are explicitly planarized before Cell
        construction. This intentionally replaces their original support surfaces.

        Parameters
        ----------
        faces : list
            The input list of Faces.
        planarize : bool , optional
            If True, planarize the input Faces before constructing the Cell.
            Default is False.
        transferDictionaries : bool , optional
            If True, transfer dictionaries from the input Faces to the
            corresponding Faces of the created Cell. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If True, suppress error and warning messages. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created Cell, or None if construction fails.
        """
        import math

        from topologicpy.Cluster import Cluster
        from topologicpy.Dictionary import Dictionary
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology
        from topologicpy.Vertex import Vertex

        def _fail(message):
            if not silent:
                print(message)
            return None

        if not isinstance(faces, list):
            return _fail(
                "Cell.ByFaces - Error: The input faces parameter is not a valid "
                "list. Returning None."
            )

        source_faces = [
            face for face in faces
            if Topology.IsInstance(face, "Face")
        ]

        if len(source_faces) != len(faces):
            return _fail("Cell.ByFaces - Error: One or more input Faces are invalid. Returning None.")

        if len(source_faces) < 3:
            return _fail(
                "Cell.ByFaces - Error: The input faces parameter does not contain "
                "at least three valid Faces. Returning None."
            )

        try:
            tolerance = abs(float(tolerance))
        except Exception:
            return _fail(
                "Cell.ByFaces - Error: The input tolerance parameter is invalid. "
                "Returning None."
            )

        if not math.isfinite(tolerance) or tolerance <= 0.0:
            return _fail(
                "Cell.ByFaces - Error: The tolerance must be greater than zero. "
                "Returning None."
            )

        construction_faces = source_faces

        if planarize:
            construction_faces = []

            for face in source_faces:
                try:
                    planarized_face = Face.Planarize(
                        face,
                        tolerance=tolerance
                    )
                except Exception:
                    planarized_face = None

                if not Topology.IsInstance(planarized_face, "Face"):
                    return _fail(
                        "Cell.ByFaces - Error: Could not planarize one or more "
                        "input Faces. Returning None."
                    )

                construction_faces.append(planarized_face)

        def _build(candidate_faces, sewing_tolerance):
            try:
                candidate = Core.Cell.ByFaces(
                    candidate_faces,
                    sewing_tolerance
                )
            except Exception:
                candidate = None

            return (
                candidate
                if Topology.IsInstance(candidate, "Cell")
                else None
            )

        # First attempt: pass the Faces directly to the backend.
        cell = _build(construction_faces, tolerance)

        # Final repair attempt: sew/self-merge the original Face topology without
        # reconstructing any Face from Wires, Edges, or Vertices.
        if not Topology.IsInstance(cell, "Cell"):
            try:
                merged = Topology.SelfMerge(
                    Cluster.ByTopologies(construction_faces),
                    tolerance=tolerance,
                    silent=True
                )
            except Exception:
                merged = None

            if Topology.IsInstance(merged, "Cell"):
                cell = merged

            elif Topology.IsInstance(merged, "CellComplex"):
                try:
                    cells = Topology.Cells(merged)
                except Exception:
                    cells = []

                if isinstance(cells, list) and len(cells) == 1:
                    cell = cells[0]

            elif Topology.IsInstance(merged, "Shell"):
                try:
                    merged_faces = Topology.Faces(merged)
                except Exception:
                    merged_faces = []

                if isinstance(merged_faces, list) and len(merged_faces) >= 3:
                    cell = _build(merged_faces, tolerance)

        if not Topology.IsInstance(cell, "Cell"):
            return _fail(
                "Cell.ByFaces - Error: Could not construct a Cell without "
                "rebuilding the supplied Faces. Returning None."
            )

        if transferDictionaries:
            try:
                cell_faces = Topology.Faces(cell)
                source_cluster = Cluster.ByTopologies(source_faces)
            except Exception:
                cell_faces = []
                source_cluster = None

            for cell_face in cell_faces:
                try:
                    selector = Topology.InternalVertex(
                        cell_face,
                        tolerance=tolerance
                    )

                    if not Topology.IsInstance(selector, "Vertex"):
                        selector = Topology.Centroid(cell_face)

                    enclosing_faces = Vertex.EnclosingFaces(
                        selector,
                        source_cluster,
                        exclusive=False,
                        tolerance=tolerance
                    )
                except Exception:
                    enclosing_faces = []

                if not isinstance(enclosing_faces, list) or not enclosing_faces:
                    continue

                dictionaries = [
                    Topology.Dictionary(face)
                    for face in enclosing_faces
                ]

                dictionaries = [
                    dictionary for dictionary in dictionaries
                    if dictionary is not None
                ]

                if not dictionaries:
                    continue

                merged_dictionary = Dictionary.ByMergedDictionaries(
                    dictionaries,
                    silent=True
                )

                if merged_dictionary is not None:
                    Topology.SetDictionary(
                        cell_face,
                        merged_dictionary,
                        silent=True
                    )

        return cell

    @staticmethod
    def ByFacesCluster(cluster, planarize: bool = False, transferDictionaries: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Creates a cell by merging the faces within the input cluster.

        Parameters
        ----------
        cluster : topologic_core.Cluster
            The input cluster of faces.
        planarize : bool, optional
            If set to True, the input faces are planarized before building the cell. Otherwise, they are not.
            Default is False.
        transferDictionaries : bool , optional
            If set to True, any dictionaries in the faces are transferred to the faces of the created cell.
            Otherwise, they are not. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created cell.

        """

        from topologicpy.Topology import Topology

        if not Topology.IsInstance(cluster, "Cluster"):
            if not silent:
                print("Cell.ByFacesCluster - Error: The input cluster parameter is not a valid topologic cluster. Returning None.")
            return None
        faces = Topology.Faces(cluster)
        return Cell.ByFaces(faces, planarize=planarize, transferDictionaries=transferDictionaries, tolerance=tolerance, silent=silent)

    @staticmethod
    def ByOffset(
        cell,
        offset: float = 1.0,
        tolerance: float = 0.0001,
        silent: bool = False,
        polyhedron: bool = True
    ):
        """
        Creates an offset Cell from the input Cell.

        When ``polyhedron`` is True, each original Vertex is displaced by the sum
        of the offset incident-Face normals. The original polygonal Faces are then
        reconstructed using the shared displaced Vertices and sewn into a Cell.

        The polygonal pathway accepts only planar Faces with linear boundary Edges.
        Use ``polyhedron=False`` for Cells containing curved Edges or non-planar
        supporting surfaces.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input Cell.
        offset : float , optional
            The desired offset distance. Positive and negative values are accepted.
            Default is 1.0.
        tolerance : float , optional
            The desired topology tolerance. Default is 0.0001.
        silent : bool , optional
            If True, error and warning messages are suppressed. Default is False.
        polyhedron : bool , optional
            If True, use the polygonal offset pathway. If False, delegate to the
            native backend offset operation. Default is True.

        Returns
        -------
        topologic_core.Topology
            The created offset topology. The result may fail to be a Cell if the
            offset produces degenerate or self-intersecting Faces.
        """
        import math

        from topologicpy.Cluster import Cluster
        from topologicpy.Edge import Edge
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology
        from topologicpy.Vertex import Vertex
        from topologicpy.Vector import Vector
        from topologicpy.Wire import Wire

        def _error(message):
            if not silent:
                print(message)
            return None

        if not Topology.IsInstance(cell, "Cell"):
            return _error(
                "Cell.ByOffset - Error: The input cell parameter is not a valid "
                "Cell. Returning None."
            )

        try:
            offset = float(offset)
            tolerance = abs(float(tolerance))
        except Exception:
            return _error(
                "Cell.ByOffset - Error: The offset or tolerance parameter is "
                "invalid. Returning None."
            )

        if not math.isfinite(offset):
            return _error(
                "Cell.ByOffset - Error: The offset parameter must be finite. "
                "Returning None."
            )

        if not math.isfinite(tolerance) or tolerance <= 0.0:
            return _error(
                "Cell.ByOffset - Error: The tolerance must be greater than zero. "
                "Returning None."
            )

        if abs(offset) <= tolerance:
            return cell

        if not polyhedron:
            result = Cell._NativeCell(
                "ByOffset",
                cell,
                offset=offset,
                tolerance=tolerance,
                silent=silent
            )

            if not Topology.IsInstance(result, "Topology"):
                return _error(
                    "Cell.ByOffset - Error: Native offset failed. Returning None."
                )

            return result

        source_faces = Topology.Faces(
            cell,
            silent=True
        ) or []

        source_vertices = Topology.Vertices(
            cell,
            silent=True
        ) or []

        source_faces = [
            face for face in source_faces
            if Topology.IsInstance(face, "Face")
        ]

        source_vertices = [
            vertex for vertex in source_vertices
            if Topology.IsInstance(vertex, "Vertex")
        ]

        if len(source_faces) < 4 or len(source_vertices) < 4:
            return _error(
                "Cell.ByOffset - Error: The input Cell does not contain enough "
                "valid Faces or Vertices. Returning None."
            )

        # The polygonal pathway must not convert curved Edges or non-planar
        # supporting surfaces into straight polygonal approximations.
        for face in source_faces:
            if Face.IsPlanar(
                face,
                tolerance=tolerance,
                silent=True
            ) is not True:
                return _error(
                    "Cell.ByOffset - Error: The input Cell contains a non-planar "
                    "Face. Use polyhedron=False. Returning None."
                )

            boundaries = [
                Face.ExternalBoundary(
                    face,
                    silent=True
                )
            ]

            boundaries.extend(
                Face.InternalBoundaries(face) or []
            )

            for boundary in boundaries:
                if not Topology.IsInstance(boundary, "Wire"):
                    return _error(
                        "Cell.ByOffset - Error: Could not retrieve a valid Face "
                        "boundary. Returning None."
                    )

                if not Wire.IsPolyline(
                    boundary,
                    tolerance=tolerance,
                    silent=True
                ):
                    return _error(
                        "Cell.ByOffset - Error: The input Cell contains curved "
                        "boundary Edges. Use polyhedron=False. Returning None."
                    )

        # --------------------------------------------------------------
        # Create one displaced Vertex for every source Vertex.
        #
        # The displaced Vertices are shared by all reconstructed Faces, avoiding
        # both ReplaceVertices and independently generated coincident Vertices.
        # --------------------------------------------------------------

        offset_vertices = []

        for vertex in source_vertices:
            incident_faces = Topology.SuperTopologies(
                vertex,
                hostTopology=cell,
                topologyType="face"
            ) or []

            incident_faces = [
                face for face in incident_faces
                if Topology.IsInstance(face, "Face")
            ]

            if not incident_faces:
                return _error(
                    "Cell.ByOffset - Error: Could not determine the incident "
                    "Faces of a Cell Vertex. Returning None."
                )

            offset_normals = []

            for face in incident_faces:
                normal = Face.Normal(
                    face,
                    mantissa=None,
                    silent=True
                )

                if not isinstance(normal, (list, tuple)) or len(normal) != 3:
                    return _error(
                        "Cell.ByOffset - Error: Could not determine an incident "
                        "Face normal. Returning None."
                    )

                try:
                    normal = Vector.SetMagnitude(
                        normal,
                        offset
                    )
                except Exception:
                    normal = None

                if not isinstance(normal, (list, tuple)) or len(normal) != 3:
                    return _error(
                        "Cell.ByOffset - Error: Could not scale an incident Face "
                        "normal. Returning None."
                    )

                offset_normals.append(normal)

            displacement = Vector.Sum(offset_normals)

            if (
                not isinstance(displacement, (list, tuple))
                or len(displacement) != 3
            ):
                return _error(
                    "Cell.ByOffset - Error: Could not calculate a Vertex offset "
                    "vector. Returning None."
                )

            try:
                displaced_vertex = Topology.Translate(
                    vertex,
                    x=float(displacement[0]),
                    y=float(displacement[1]),
                    z=float(displacement[2]),
                    transferDictionaries=True,
                    silent=True
                )
            except Exception:
                displaced_vertex = None

            if not Topology.IsInstance(displaced_vertex, "Vertex"):
                return _error(
                    "Cell.ByOffset - Error: Could not create an offset Vertex. "
                    "Returning None."
                )

            offset_vertices.append(displaced_vertex)

        def offset_vertex(source_vertex):
            try:
                index = Vertex.Index(
                    source_vertex,
                    source_vertices,
                    tolerance=tolerance
                )
            except Exception:
                index = None

            if not isinstance(index, int):
                return None

            if index < 0 or index >= len(offset_vertices):
                return None

            return offset_vertices[index]

        def offset_wire(source_wire):
            if not Topology.IsInstance(source_wire, "Wire"):
                return None

            ordered_edges = Wire._OrderedEdges(
                source_wire,
                tolerance=tolerance,
                silent=True
            )

            if not isinstance(ordered_edges, list) or not ordered_edges:
                return None

            source_wire_vertices = [
                Edge.StartVertex(
                    edge,
                    silent=True
                )
                for edge in ordered_edges
            ]

            if not all(
                Topology.IsInstance(vertex, "Vertex")
                for vertex in source_wire_vertices
            ):
                return None

            new_wire_vertices = [
                offset_vertex(vertex)
                for vertex in source_wire_vertices
            ]

            if not all(
                Topology.IsInstance(vertex, "Vertex")
                for vertex in new_wire_vertices
            ):
                return None

            result = Wire.ByVertices(
                new_wire_vertices,
                close=True,
                tolerance=tolerance,
                silent=True
            )

            if not Topology.IsInstance(result, "Wire"):
                return None

            dictionary = Topology.Dictionary(
                source_wire,
                silent=True
            )

            if dictionary:
                updated = Topology.SetDictionary(
                    result,
                    dictionary,
                    silent=True
                )

                if Topology.IsInstance(updated, "Wire"):
                    result = updated

            return result

        # --------------------------------------------------------------
        # Reconstruct each polygonal Face using the shared displaced Vertices.
        # --------------------------------------------------------------

        offset_faces = []

        for source_face in source_faces:
            source_external = Face.ExternalBoundary(
                source_face,
                silent=True
            )

            offset_external = offset_wire(
                source_external
            )

            if not Topology.IsInstance(offset_external, "Wire"):
                return _error(
                    "Cell.ByOffset - Error: Could not construct an offset external "
                    "boundary. Returning None."
                )

            offset_internals = []

            for source_internal in Face.InternalBoundaries(source_face) or []:
                offset_internal = offset_wire(
                    source_internal
                )

                if not Topology.IsInstance(offset_internal, "Wire"):
                    return _error(
                        "Cell.ByOffset - Error: Could not construct an offset "
                        "internal boundary. Returning None."
                    )

                offset_internals.append(offset_internal)

            offset_face = Face.ByWires(
                offset_external,
                offset_internals,
                tolerance=tolerance,
                silent=True
            )

            if not Topology.IsInstance(offset_face, "Face"):
                return _error(
                    "Cell.ByOffset - Error: Could not construct an offset Face. "
                    "Returning None."
                )

            dictionary = Topology.Dictionary(
                source_face,
                silent=True
            )

            if dictionary:
                updated = Topology.SetDictionary(
                    offset_face,
                    dictionary,
                    silent=True
                )

                if Topology.IsInstance(updated, "Face"):
                    offset_face = updated

            offset_faces.append(offset_face)

        # Prefer Cell.ByFaces because it validates that the reconstructed Faces
        # form a Cell while retaining their shared displaced Vertices.
        result = Cell.ByFaces(
            offset_faces,
            tolerance=tolerance,
            silent=True
        )

        # If the offset is self-intersecting or no longer closes, return the sewn
        # topology when possible, matching the historical method's broader
        # Topology return contract.
        if not Topology.IsInstance(result, "Topology"):
            try:
                result = Topology.SelfMerge(
                    Cluster.ByTopologies(
                        offset_faces,
                        silent=True
                    ),
                    tolerance=tolerance,
                    silent=True
                )
            except Exception:
                result = None

        if not Topology.IsInstance(result, "Topology"):
            return _error(
                "Cell.ByOffset - Error: Could not construct the offset topology. "
                "Returning None."
            )

        dictionary = Topology.Dictionary(
            cell,
            silent=True
        )

        if dictionary:
            updated = Topology.SetDictionary(
                result,
                dictionary,
                silent=True
            )

            if Topology.IsInstance(updated, "Topology"):
                result = updated

        return result

    @staticmethod
    def ByShell(shell, planarize: bool = False, tolerance: float = 0.0001, silent: bool = False):
        """
        Creates a cell from the input shell.

        Parameters
        ----------
        shell : topologic_core.Shell
            The input shell. The shell must be closed for this method to succeed.
        planarize : bool, optional
            If set to True, the input faces of the input shell are planarized before building the cell. Otherwise, they are not. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created cell.

        """
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(shell, "Shell"):
            if not silent:
                print("Cell.ByShell - Error: The input shell parameter is not a valid topologic shell. Returning None.")
            return None
        faces = Topology.SubTopologies(shell, subTopologyType="face")
        return Cell.ByFaces(faces, planarize=planarize, tolerance=tolerance, silent=silent)
    
    
    @staticmethod
    def ByShells(externalBoundary, internalBoundaries: list = [], tolerance: float = 0.0001, silent: bool = False):
        """
        Creates a cell from the input external boundary (closed shell) and the input list of internal boundaries (closed shells).

        Parameters
        ----------
        externalBoundary : topologic_core.Shell
            The input external boundary.
        internalBoundaries : list , optional
            The input list of internal boundaries (closed shells). Default is an empty list.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created cell.

        """
        from topologicpy.Shell import Shell
        from topologicpy.Cluster import Cluster
        from topologicpy.Topology import Topology
        
        if not Topology.IsInstance(externalBoundary, "Shell"):
            if not silent:
                print("Cell.ByShells - Error: The input externalBoundary parameter is not a valid topologic shell. Returning None.")
            return None
        if not Shell.IsClosed(externalBoundary):
            if not silent:
                print("Cell.ByShells - Error: The input externalBoundary parameter is not a closed topologic shell. Returning None.")
            return None
        ibList = []
        for s in internalBoundaries:
            if not Topology.IsInstance(s, "Shell") or not Shell.IsClosed(s, silent=silent):
                if not silent:
                    print("Cell.ByShells - Error: Invalid or open internal shell. Returning None.")
                return None
            inner = Cell.ByShell(s, tolerance=tolerance, silent=silent)
            if not Topology.IsInstance(inner, "Cell"):
                return None
            ibList.append(inner)
        cell = Cell.ByShell(externalBoundary, tolerance=tolerance, silent=silent)
        if not Topology.IsInstance(cell, "Cell"):
            return None
        if len(ibList) > 0:
            inner_cluster =Cluster.ByTopologies(ibList)
            cell = Topology.Difference(cell, inner_cluster, tolerance=tolerance)
            if not Topology.IsInstance(cell, "Cell"):
                if not silent:
                    print("Cell.ByShells - Error: Could not create cell. Returning None.")
                return None
        return cell

    @staticmethod
    def ByThickenedFace(
        face,
        thickness: float = 1.0,
        bothSides: bool = True,
        wSides: int = 1,
        reverse: bool = False,
        polyhedron: bool = True,
        tolerance: float = 0.0001,
        silent: bool = False,
    ):
        """
        Creates a Cell by thickening the input Face.

        Planar Faces bounded only by linear Edges use a fast polyhedral prism
        path when possible. Curved-edge or non-planar Faces use the native
        backend thickening operation so that their actual surface geometry and
        local normals are preserved.

        Parameters
        ----------
        face : topologicpy.Face
            The input Face.
        thickness : float, optional
            The desired thickness. Default is 1.0.
        bothSides : bool, optional
            If True, thicken equally to both sides. Otherwise thicken to one
            side. Default is True.
        wSides : int, optional
            Number of divisions through the thickness for the polygonal
            fallback path. Default is 1.
        reverse : bool, optional
            If True, reverse the thickening direction. Default is False.
        polyhedron : bool, optional
            If False, use the native curve-preserving thickening path directly.
            If True, planar polygonal Faces use the fast/fallback polyhedral
            path. Curved or non-planar Faces are still handled natively because
            a single global extrusion normal is not geometrically valid for
            them. Default is True.
        tolerance : float, optional
            The desired tolerance. Default is 0.0001.
        silent : bool, optional
            If True, suppress error messages. Default is False.
        
        Returns
        -------
        topologicpy.Cell
            The resulting Cell, or None if construction fails.
        """
        import math

        from topologicpy.Topology import Topology
        from topologicpy.Face import Face
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Vertex import Vertex

        if not Topology.IsInstance(face, "Face"):
            if not silent:
                print(
                    "Cell.ByThickenedFace - Error: "
                    "Input is not a valid Face. Returning None."
                )
            return None

        try:
            thickness = float(thickness)
            wSides = int(wSides)
            tolerance = abs(float(tolerance))
        except Exception:
            if not silent:
                print(
                    "Cell.ByThickenedFace - Error: "
                    "Invalid numerical input. Returning None."
                )
            return None

        if (
            not math.isfinite(thickness)
            or not math.isfinite(tolerance)
            or thickness <= tolerance
            or wSides < 1
            or thickness / float(wSides) <= tolerance
        ):
            if not silent:
                print(
                    "Cell.ByThickenedFace - Error: "
                    "Invalid thickness or wSides. Returning None."
                )
            return None

        # Explicit curve-preserving/native mode.
        if not polyhedron:
            result = Cell._NativeCell(
                "ByThickenedFace",
                face,
                thickness=thickness,
                bothSides=bothSides,
                reverse=reverse,
                tolerance=tolerance,
                silent=silent,
            )
            if result is None and not silent:
                print(
                    "Cell.ByThickenedFace - Error: "
                    "Native thickening failed. Returning None."
                )
            return result

        # ------------------------------------------------------------------
        # Classify the input geometry before choosing a construction path.
        # ------------------------------------------------------------------

        try:
            is_planar = (
                Face.IsPlanar(
                    face,
                    tolerance=tolerance,
                    silent=True,
                )
                is True
            )
        except Exception:
            is_planar = False

        try:
            face_edges = Topology.Edges(
                face,
                silent=True,
            ) or []
        except Exception:
            face_edges = []

        try:
            all_linear = (
                len(face_edges) > 0
                and all(
                    Edge.IsLinear(
                        edge,
                        tolerance=tolerance,
                        silent=True,
                    )
                    is True
                    for edge in face_edges
                )
            )
        except Exception:
            all_linear = False

        # ------------------------------------------------------------------
        # Curved / non-planar Face
        # ------------------------------------------------------------------
        #
        # The polygonal fallback below translates the entire Face using one
        # global normal and builds side Faces from Edge endpoints. That is only
        # geometrically valid for a planar polygon. Periodic BSpline Faces such
        # as a Catenoid may also contain seam Edges whose start/end vertices are
        # coincident, which makes endpoint-based side construction degenerate.
        #
        # Therefore any non-planar Face or Face with curved Edges must use the
        # native thickening operator.
        # ------------------------------------------------------------------

        if not is_planar or not all_linear:
            if wSides != 1 and not silent:
                print(
                    "Cell.ByThickenedFace - Warning: "
                    "wSides is ignored for curved or non-planar Faces because "
                    "they require native surface thickening."
                )

            result = Cell._NativeCell(
                "ByThickenedFace",
                face,
                thickness=thickness,
                bothSides=bothSides,
                reverse=reverse,
                tolerance=tolerance,
                silent=True,
            )

            if Topology.IsInstance(result, "Cell"):
                return result

            if not silent:
                print(
                    "Cell.ByThickenedFace - Error: "
                    "Curved or non-planar Faces require native surface "
                    "thickening, but the native operation failed or is "
                    "unavailable. Returning None."
                )
            return None

        # ------------------------------------------------------------------
        # Planar polygonal Face
        # ------------------------------------------------------------------

        normal = Face.Normal(
            face,
            mantissa=None,
            silent=True,
        )

        if not isinstance(normal, (list, tuple)) or len(normal) != 3:
            if not silent:
                print(
                    "Cell.ByThickenedFace - Error: "
                    "Could not compute face normal. Returning None."
                )
            return None

        nx, ny, nz = [float(value) for value in normal]
        magnitude = math.sqrt(
            nx * nx
            + ny * ny
            + nz * nz
        )

        if magnitude <= tolerance:
            return None

        nx /= magnitude
        ny /= magnitude
        nz /= magnitude

        if reverse:
            nx, ny, nz = -nx, -ny, -nz

        # ------------------------------------------------------------------
        # Fast path: planar polygon + one thickness division.
        # ------------------------------------------------------------------

        if wSides == 1:
            base_face = face

            if bothSides:
                base_face = Topology.Translate(
                    face,
                    -0.5 * thickness * nx,
                    -0.5 * thickness * ny,
                    -0.5 * thickness * nz,
                    silent=True,
                )

            if Topology.IsInstance(base_face, "Face"):
                result = Cell._NativeCell(
                    "ByPrism",
                    base_face,
                    vector=[
                        thickness * nx,
                        thickness * ny,
                        thickness * nz,
                    ],
                    tolerance=tolerance,
                    silent=True,
                )

                if Topology.IsInstance(result, "Cell"):
                    return result

        # ------------------------------------------------------------------
        # Existing generic planar/polyhedral fallback.
        # ------------------------------------------------------------------

        step = thickness / float(wSides)

        if bothSides:
            offsets = [
                -0.5 * thickness + step * i
                for i in range(wSides + 1)
            ]
        else:
            offsets = [
                step * i
                for i in range(wSides + 1)
            ]

        layers = []

        for offset in offsets:
            layer = Topology.Translate(
                face,
                nx * offset,
                ny * offset,
                nz * offset,
            )

            if not Topology.IsInstance(layer, "Face"):
                return None

            layers.append(
                (offset, layer)
            )

        faces_all = [
            layers[0][1],
            layers[-1][1],
        ]

        for i in range(len(layers) - 1):
            offset_a, face_a = layers[i]
            offset_b, _ = layers[i + 1]
            delta = offset_b - offset_a

            edges_a = Topology.Edges(
                face_a,
                silent=True,
            ) or []

            if not edges_a:
                return None

            for edge_a in edges_a:
                if not Topology.IsInstance(
                    edge_a,
                    "Edge",
                ):
                    continue

                edge_b = Topology.Translate(
                    edge_a,
                    nx * delta,
                    ny * delta,
                    nz * delta,
                    silent=True,
                )

                if not Topology.IsInstance(
                    edge_b,
                    "Edge",
                ):
                    return None

                a0 = Edge.StartVertex(edge_a)
                a1 = Edge.EndVertex(edge_a)
                b0 = Edge.StartVertex(edge_b)
                b1 = Edge.EndVertex(edge_b)

                if not all(
                    Topology.IsInstance(v, "Vertex")
                    for v in (a0, a1, b0, b1)
                ):
                    return None

                ordered = [
                    a0,
                    a1,
                    b1,
                    b0,
                ]

                side_edges = []

                for j in range(4):
                    va = ordered[j]
                    vb = ordered[(j + 1) % 4]

                    # Defensive guard. This should not occur on the planar,
                    # all-linear path, but do not ask Edge to construct a
                    # zero-length Edge if malformed input reaches here.
                    try:
                        same = Topology.IsSame(va, vb)
                    except Exception:
                        same = False

                    if same:
                        side_edges = []
                        break

                    edge = Edge.ByStartVertexEndVertex(
                        va,
                        vb,
                        tolerance=tolerance,
                        silent=True,
                    )

                    if not Topology.IsInstance(
                        edge,
                        "Edge",
                    ):
                        side_edges = []
                        break

                    side_edges.append(edge)

                if len(side_edges) != 4:
                    return None

                side_wire = Wire.ByEdges(
                    side_edges,
                    tolerance=tolerance,
                    silent=True,
                )

                if not Topology.IsInstance(
                    side_wire,
                    "Wire",
                ):
                    return None

                side_face = Face.ByWire(
                    side_wire,
                    tolerance=tolerance,
                    silent=True,
                )

                if not Topology.IsInstance(
                    side_face,
                    "Face",
                ):
                    return None

                faces_all.append(
                    side_face
                )

        result = Cell.ByFaces(
            faces_all,
            tolerance=tolerance,
            silent=True,
        )

        if not Topology.IsInstance(
            result,
            "Cell",
        ):
            if not silent:
                print(
                    "Cell.ByThickenedFace - Error: "
                    "Cell.ByFaces did not return a valid Cell. "
                    "Returning None."
                )
            return None

        return result

    @staticmethod
    def ByThickenedShell(shell, direction: list = [0, 0, 1], thickness: float = 1.0, bothSides: bool = True, reverse: bool = False,
                            planarize: bool = False, tolerance: float = 0.0001, silent: bool = False, polyhedron: bool = True):
        """
        Creates a cell by thickening the input shell. The shell must be open.

        Parameters
        ----------
        shell : topologic_core.Shell
            The input shell to be thickened.
        thickness : float , optional
            The desired thickness. Default is 1.0.
        bothSides : bool
            If True, the cell will be lofted to each side of the shell. Otherwise, it will be lofted along the input direction. Default is True.
        reverse : bool
            If True, the cell will be lofted along the opposite of the input direction. Default is False.
        planarize : bool, optional
            If set to True, the input faces of the input shell are planarized before building the cell. Otherwise, they are not. Default is False.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created cell.

        """
        if not polyhedron:
            result = Cell._NativeCell("ByThickenedShell", shell, thickness=thickness, bothSides=bothSides, reverse=reverse, tolerance=tolerance, silent=silent)
            if result is None and not silent: print("Cell.ByThickenedShell - Error: Native thickening failed. Returning None.")
            return result
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Cluster import Cluster
        from topologicpy.Topology import Topology
        if not Topology.IsInstance(shell, "Shell"):
            if not silent:
                print("Cell.ByThickenedShell - Error: The input shell parameter is not a valid topologic Shell. Returning None.")
            return None
        if reverse == True and bothSides == False:
            thickness = -thickness
        if bothSides:
            bottomShell = Topology.Translate(shell, -direction[0]*0.5*thickness, -direction[1]*0.5*thickness, -direction[2]*0.5*thickness)
            topShell = Topology.Translate(shell, direction[0]*0.5*thickness, direction[1]*0.5*thickness, direction[2]*0.5*thickness)
        else:
            bottomShell = shell
            topShell = Topology.Translate(shell, direction[0]*thickness, direction[1]*thickness, direction[2]*thickness)
        cellFaces = Shell.Faces(bottomShell) + Shell.Faces(topShell)
        bottomWire = Shell.ExternalBoundary(bottomShell, tolerance=tolerance)
        bottomEdges = Wire.Edges(bottomWire)
        for bottomEdge in bottomEdges:
            topEdge = Topology.Translate(bottomEdge, direction[0]*thickness, direction[1]*thickness, direction[2]*thickness)
            sideEdge1 = Edge.ByVertices([Edge.StartVertex(bottomEdge), Edge.StartVertex(topEdge)], tolerance=tolerance, silent=silent)
            sideEdge2 = Edge.ByVertices([Edge.EndVertex(bottomEdge), Edge.EndVertex(topEdge)], tolerance=tolerance, silent=silent)
            cellWire = Topology.SelfMerge(Cluster.ByTopologies([bottomEdge, sideEdge1, topEdge, sideEdge2]), tolerance=tolerance)
            cellFace = Face.ByWire(cellWire, tolerance=tolerance)
            cellFaces.append(cellFace)
        return Cell.ByFaces(cellFaces, planarize=planarize, tolerance=tolerance)
    
    @staticmethod
    def ByWires(wires: list,
                close: bool = False,
                triangulate: bool = True,
                planarize: bool = False,
                mantissa: int = 6,
                tolerance: float = 0.0001,
                silent: bool = False,
                polyhedron: bool = True):
        """
        Creates a cell by lofting through the input list of wires.

        Unlike the older implementation, this version does NOT require
        corresponding wires to have the same number of edges. Each pair of
        wires is re-parameterized by normalized perimeter length and resampled
        at a common set of breakpoints before side faces are created.

        Parameters
        ----------
        wires : list
            The input list of wires.
        close : bool , optional
            If set to True, the last wire is also connected to the first wire.
            Default is False.
        triangulate : bool , optional
            If set to True, side and cap faces are triangulated where needed.
            Default is True.
        planarize : bool, optional
            If set to True, the created faces are planarized before building
            the cell. Otherwise, they are not. Default is False.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created cell.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Topology import Topology

        # Exact curve-preserving loft path. The existing faceted path below is
        # deliberately left untouched and remains the default.
        if not polyhedron:
            if close:
                if not silent:
                    print("Cell.ByWires - Error: close=True is not supported for curve-preserving solid lofts. Returning None.")
                return None
            if not isinstance(wires, (list, tuple)):
                if not silent:
                    print("Cell.ByWires - Error: The input wires parameter is not a valid list. Returning None.")
                return None
            native_wires = [wire for wire in wires if Topology.IsInstance(wire, "Wire")]
            if len(native_wires) < 2:
                if not silent:
                    print("Cell.ByWires - Error: At least two valid Wires are required. Returning None.")
                return None
            for wire in native_wires:
                if not Wire.IsClosed(wire, tolerance=tolerance, silent=True):
                    if not silent:
                        print("Cell.ByWires - Error: All section Wires must be closed. Returning None.")
                    return None
            result = Cell._NativeCell("ByWires", native_wires, tolerance=tolerance, silent=silent)
            if not Topology.IsInstance(result, "Cell"):
                if not silent:
                    print("Cell.ByWires - Error: Native curve-preserving loft failed. Returning None.")
                return None
            return result

        def _coords(v):
            return [Vertex.X(v), Vertex.Y(v), Vertex.Z(v)]

        def _distance(v1, v2):
            x1, y1, z1 = _coords(v1)
            x2, y2, z2 = _coords(v2)
            dx = x2 - x1
            dy = y2 - y1
            dz = z2 - z1
            return (dx*dx + dy*dy + dz*dz) ** 0.5

        def _lerp(v1, v2, t):
            x1, y1, z1 = _coords(v1)
            x2, y2, z2 = _coords(v2)
            return Vertex.ByCoordinates(
                x1 + (x2 - x1) * t,
                y1 + (y2 - y1) * t,
                z1 + (z2 - z1) * t
            )

        def _ordered_vertices_from_edges(wire):
            """
            Attempts to reconstruct the ordered vertices of a wire from its edges.
            Returns a closed loop as unique vertices without repeating the first
            vertex at the end.
            """
            edges = Topology.Edges(wire)
            if not edges or len(edges) < 1:
                return None

            unused = edges[:]
            first_edge = unused.pop(0)

            sv = Edge.StartVertex(first_edge)
            ev = Edge.EndVertex(first_edge)
            ordered = [sv, ev]

            while unused:
                current = ordered[-1]
                found = False
                for i, e in enumerate(unused):
                    es = Edge.StartVertex(e)
                    ee = Edge.EndVertex(e)
                    if Topology.IsSame(es, current):
                        ordered.append(ee)
                        unused.pop(i)
                        found = True
                        break
                    elif Topology.IsSame(ee, current):
                        ordered.append(es)
                        unused.pop(i)
                        found = True
                        break
                if not found:
                    break

            if len(ordered) < 3:
                return None

            # Remove repeated closure vertex if present
            if Topology.IsSame(ordered[0], ordered[-1]):
                ordered = ordered[:-1]

            return ordered

        def _ordered_vertices(wire):
            """
            Tries to get ordered vertices from Wire.Vertices if available,
            otherwise reconstructs from edges.
            """
            verts = None
            try:
                verts = Wire.Vertices(wire)
            except:
                verts = None

            if isinstance(verts, list) and len(verts) >= 3:
                # Remove repeated closure vertex if present
                if Topology.IsSame(verts[0], verts[-1]):
                    verts = verts[:-1]
                return verts

            return _ordered_vertices_from_edges(wire)

        def _wire_parameters(verts):
            """
            Returns:
                seg_lengths: list of segment lengths
                cum_lengths: cumulative lengths starting at 0
                total_length: total perimeter length
                params: normalized parameter values at each vertex in [0,1)
            """
            n = len(verts)
            seg_lengths = []
            cum_lengths = [0.0]
            total = 0.0
            for i in range(n):
                v1 = verts[i]
                v2 = verts[(i + 1) % n]
                d = _distance(v1, v2)
                seg_lengths.append(d)
                total += d
                cum_lengths.append(total)

            if total <= tolerance:
                return None, None, None, None

            params = [cum_lengths[i] / total for i in range(n)]
            return seg_lengths, cum_lengths, total, params

        def _vertex_at_parameter(verts, seg_lengths, cum_lengths, total_length, u):
            """
            Returns a vertex sampled on the closed polyline at normalized
            parameter u in [0,1).
            """
            if u >= 1.0:
                u = 0.0
            if u < 0.0:
                u = u % 1.0

            target = u * total_length
            n = len(seg_lengths)

            for i in range(n):
                a = cum_lengths[i]
                b = cum_lengths[i + 1]
                if target <= b or i == n - 1:
                    seg_len = seg_lengths[i]
                    if seg_len <= tolerance:
                        return verts[i]
                    t = (target - a) / seg_len
                    t = max(0.0, min(1.0, t))
                    return _lerp(verts[i], verts[(i + 1) % len(verts)], t)

            return verts[0]

        def _rotate_list(values, k):
            k = k % len(values)
            return values[k:] + values[:k]

        def _best_rotated_vertices(verts_a, verts_b):
            """
            Rotate verts_b so its seam/start best aligns with verts_a.
            This helps when wires are equivalent loops but start at different
            vertices. It does not solve all correspondence issues, but it
            improves many practical cases.
            """
            if len(verts_b) < 2:
                return verts_b

            a0 = verts_a[0]
            best_i = 0
            best_d = None
            for i, vb in enumerate(verts_b):
                d = _distance(a0, vb)
                if best_d is None or d < best_d:
                    best_d = d
                    best_i = i
            return _rotate_list(verts_b, best_i)

        def _face_by_vertices(vertices):
            """
            Creates a face from the supplied vertices by explicitly building a
            closed edge loop. Returns None on failure.
            """
            if not isinstance(vertices, list) or len(vertices) < 3:
                return None

            # Remove consecutive duplicate vertices
            cleaned = []
            for v in vertices:
                if len(cleaned) == 0:
                    cleaned.append(v)
                else:
                    if _distance(cleaned[-1], v) > tolerance:
                        cleaned.append(v)

            if len(cleaned) < 3:
                return None

            # Remove repeated closure vertex if present
            if _distance(cleaned[0], cleaned[-1]) <= tolerance:
                cleaned = cleaned[:-1]

            if len(cleaned) < 3:
                return None

            edges = []
            n = len(cleaned)
            for i in range(n):
                v1 = cleaned[i]
                v2 = cleaned[(i + 1) % n]
                if _distance(v1, v2) > tolerance:
                    e = Edge.ByVertices([v1, v2], tolerance=tolerance, silent=True)
                    if e:
                        edges.append(e)

            if len(edges) < 3:
                return None

            try:
                # IMPORTANT: do NOT use orient=True for a closed loop
                w = Wire.ByEdges(edges, orient=False, tolerance=tolerance, silent=True)
                if not Topology.IsInstance(w, "Wire"):
                    return None
                return Face.ByWire(w, tolerance=tolerance)
            except:
                return None

        def _triangulated_faces_from_loop_pair(verts1, verts2):
            """
            Creates side faces between two resampled closed loops.
            """
            local_faces = []
            n = len(verts1)
            for i in range(n):
                a0 = verts1[i]
                a1 = verts1[(i + 1) % n]
                b1 = verts2[(i + 1) % n]
                b0 = verts2[i]

                # Skip fully collapsed strips
                if (_distance(a0, a1) <= tolerance and
                    _distance(b0, b1) <= tolerance):
                    continue

                if triangulate:
                    f1 = _face_by_vertices([a0, a1, b1])
                    f2 = _face_by_vertices([a0, b1, b0])
                    if f1:
                        local_faces.append(f1)
                    if f2:
                        local_faces.append(f2)
                else:
                    f = _face_by_vertices([a0, a1, b1, b0])
                    if f:
                        local_faces.append(f)
                    else:
                        # fallback to triangles
                        f1 = _face_by_vertices([a0, a1, b1])
                        f2 = _face_by_vertices([a0, b1, b0])
                        if f1:
                            local_faces.append(f1)
                        if f2:
                            local_faces.append(f2)
            return local_faces

        def _loft_faces_between_wires(wire1, wire2):
            """
            Resamples two wires at a shared set of normalized perimeter parameters
            and returns the side faces between them.
            """
            verts1 = _ordered_vertices(wire1)
            verts2 = _ordered_vertices(wire2)

            if not isinstance(verts1, list) or len(verts1) < 3:
                return []
            if not isinstance(verts2, list) or len(verts2) < 3:
                return []

            verts2 = _best_rotated_vertices(verts1, verts2)

            seg1, cum1, total1, params1 = _wire_parameters(verts1)
            seg2, cum2, total2, params2 = _wire_parameters(verts2)

            if total1 is None or total2 is None:
                return []

            # Shared sampling parameters from both loops
            merged = sorted(set(
                [round(p, mantissa) for p in params1] +
                [round(p, mantissa) for p in params2]
            ))

            # Ensure 0 exists
            if len(merged) == 0 or abs(merged[0]) > (10 ** (-mantissa)):
                merged = [0.0] + merged

            # Remove 1.0 if it appears due to rounding; closed loops use [0,1)
            cleaned = []
            for u in merged:
                if abs(u - 1.0) <= (10 ** (-mantissa)):
                    continue
                if len(cleaned) == 0 or abs(cleaned[-1] - u) > (10 ** (-mantissa)):
                    cleaned.append(u)
            merged = cleaned

            if len(merged) < 3:
                return []

            sample1 = [_vertex_at_parameter(verts1, seg1, cum1, total1, u) for u in merged]
            sample2 = [_vertex_at_parameter(verts2, seg2, cum2, total2, u) for u in merged]

            return _triangulated_faces_from_loop_pair(sample1, sample2)

        if not isinstance(wires, list):
            if not silent:
                print("Cell.ByWires - Error: The input wires parameter is not a valid list. Returning None.")
            return None

        wires = [w for w in wires if Topology.IsInstance(w, "Wire")]
        if len(wires) < 2:
            if not silent:
                print("Cell.ByWires - Error: The input wires parameter contains less than two valid topologic wires. Returning None.")
            return None

        faces = []

        # End caps
        cap1 = Face.ByWire(wires[0], tolerance=tolerance)
        cap2 = Face.ByWire(wires[-1], tolerance=tolerance)
        if cap1:
            faces.append(cap1)
        if cap2:
            faces.append(cap2)

        if triangulate:
            triangulated_caps = []
            for face in faces:
                try:
                    if len(Topology.Vertices(face)) > 3:
                        triangulated_caps += Face.Triangulate(face, tolerance=tolerance)
                    else:
                        triangulated_caps.append(face)
                except:
                    triangulated_caps.append(face)
            faces = triangulated_caps

        # Consecutive lofting
        pair_count = len(wires) - 1
        for i in range(pair_count):
            loft_faces = _loft_faces_between_wires(wires[i], wires[i + 1])
            faces += [f for f in loft_faces if f]

        # If close=True, also connect last wire back to first
        if close:
            loft_faces = _loft_faces_between_wires(wires[-1], wires[0])
            faces += [f for f in loft_faces if f]

        faces = [f for f in faces if Topology.IsInstance(f, "Face")]
        if len(faces) < 4:
            if not silent:
                print("Cell.ByWires - Error: Could not create sufficient faces for a valid cell. Returning None.")
            return None

        cell = Cell.ByFaces(faces, planarize=planarize, tolerance=tolerance, silent=silent)
        if not cell:
            shell = Shell.ByFaces(faces, tolerance=tolerance)
            if Topology.IsInstance(shell, "Shell"):
                geom = Topology.Geometry(shell, mantissa=mantissa)
                cell = Topology.ByGeometry(geom['vertices'], geom['edges'], geom['faces'])

            if not Topology.IsInstance(cell, "Cell"):
                if not silent:
                    print("Cell.ByWires - Error: Could not create a cell. Returning None.")
                return None

        return cell

    @staticmethod
    def ByWiresCluster(cluster, close: bool = False, triangulate: bool = True, planarize: bool = False, tolerance: float = 0.0001, silent: bool = False, polyhedron: bool = True):
        """
        Creates a cell by lofting through the input cluster of wires.

        Parameters
        ----------
        cluster : Cluster
            The input Cluster of wires.
        close : bool , optional
            If set to True, the last wire in the cluster of input wires will be connected to the first wire in the cluster of input wires. Default is False.
        triangulate : bool , optional
            If set to True, the faces will be triangulated. Default is True.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.

        Raises
        ------
        Exception
            Raises an exception if the two wires in the list do not have the same number of edges.

        Returns
        -------
        topologic_core.Cell
            The created cell.

        """
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(cluster, "Cluster"):
            if not silent:
                print("Cell.ByWiresCluster - Error: The input cluster parameter is not a valid topologic cluster. Returning None.")
            return None
        wires = Topology.Wires(cluster)
        return Cell.ByWires(wires, close=close, triangulate=triangulate, planarize=planarize, tolerance=tolerance, silent=silent, polyhedron=polyhedron)

    @staticmethod
    def Capsule(origin = None,
                radius: float = 0.25,
                height: float = 1,
                uSides: int = 16,
                vSidesEnds: int = 8,
                vSidesMiddle: int = 1,
                direction: list = [0, 0, 1],
                placement: str = "center",
                tolerance: float = 0.0001,
                silent: bool = False,
                polyhedron: bool = True):
        """
        Creates a capsule shape. A capsule is a cylinder with hemispherical ends.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The location of the origin of the capsule. Default is None which results
            in the capsule being placed at (0, 0, 0).
        radius : float , optional
            The radius of the capsule. Default is 0.25.
        height : float , optional
            The height of the capsule. Default is 1.
        uSides : int , optional
            The number of circle segments of the capsule. Default is 16.
        vSidesEnds : int , optional
            The number of vertical segments of the end hemispheres. Default is 8.
        vSidesMiddle : int , optional
            The number of vertical segments of the middle cylinder. Default is 1.
        direction : list , optional
            The vector representing the up direction of the capsule. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the capsule. This can
            be "bottom", "center", or "lowerleft". It is case insensitive. Default
            is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created cell.
        """
        from topologicpy.Topology import Topology
        from topologicpy.Vertex import Vertex

        if not polyhedron:
            if not Topology.IsInstance(origin, "Vertex"):
                origin = Vertex.Origin()
            capsule = Cell._NativeCell("ByCapsule", radius=radius, height=height, tolerance=tolerance, silent=silent)
            if not Topology.IsInstance(capsule, "Cell"):
                return None
            p = str(placement).lower().strip()
            source = [0.0, 0.0, 0.0]
            if p == "bottom":
                source = [0.0, 0.0, -0.5*float(height)]
            elif p == "lowerleft":
                source = [-abs(float(radius)), -abs(float(radius)), -0.5*float(height)]
            elif p != "center":
                if not silent:
                    print('Cell.Capsule - Error: placement must be "center", "bottom", or "lowerleft". Returning None.')
                return None
            return Cell._PlaceNativeCell(capsule, origin, direction, source, tolerance, silent)

        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)

        if not Topology.IsInstance(origin, "Vertex"):
            if not silent:
                print("Cell.Capsule - Error: The input origin parameter is not a valid topologic vertex. Returning None.")
            return None

        cyl_height = height - radius*2

        if cyl_height <= 0:
            capsule = Cell.Sphere(
                origin=Vertex.Origin(),
                radius=radius,
                uSides=uSides,
                vSides=vSidesEnds*2,
                tolerance=tolerance,
                silent=silent
            )
        else:
            cyl = Cell.Cylinder(
                origin=Vertex.Origin(),
                radius=radius,
                height=cyl_height,
                uSides=uSides,
                vSides=vSidesMiddle,
                direction=[0, 0, 1],
                placement="center",
                tolerance=tolerance
            )

            o1 = Vertex.ByCoordinates(0, 0, cyl_height*0.5)
            o2 = Vertex.ByCoordinates(0, 0, -cyl_height*0.5)

            s1 = Cell.Sphere(
                origin=o1,
                radius=radius,
                uSides=uSides,
                vSides=vSidesEnds*2,
                tolerance=tolerance,
                silent=silent
            )

            s2 = Cell.Sphere(
                origin=o2,
                radius=radius,
                uSides=uSides,
                vSides=vSidesEnds*2,
                tolerance=tolerance,
                silent=silent
            )

            capsule = Topology.Union(cyl, s1, tolerance=tolerance)
            capsule = Topology.Union(capsule, s2, tolerance=tolerance)

        if not Topology.IsInstance(capsule, "Cell"):
            if not silent:
                print("Cell.Capsule - Error: Could not create the capsule. Returning None.")
            return None

        placement = placement.lower()

        xOffset = 0
        yOffset = 0
        zOffset = 0

        if placement == "bottom":
            zOffset = -height*0.5
        elif placement == "lowerleft":
            xOffset = -radius
            yOffset = -radius
            zOffset = -height*0.5

        capsule = Topology.OrientAndPlace(
            capsule,
            originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
            originB=origin,
            dirA=[0, 0, 1],
            dirB=direction,
            transferDictionaries=False,
            tolerance=tolerance,
            silent=silent
        )

        return capsule

    @staticmethod
    def CHS(origin= None, radius: float = 1.0, height: float = 1.0, thickness: float = 0.25, sides: int = 16, direction: list = [0, 0, 1], placement: str = "center", tolerance: float = 0.0001, silent: bool = False):
        """
        Creates a circular hollow section (CHS).

        Parameters
        ----------
        origin : topologic_core.Vertex, optional
            The location of the origin of the CHS. Default is None which results in the CHS being placed at (0, 0, 0).
        radius : float , optional
            The outer radius of the CHS. Default is 1.0.
        thickness : float , optional
            The thickness of the CHS. Default is 0.25.
        height : float , optional
            The height of the CHS. Default is 1.0.
        sides : int , optional
            The desired number of sides of the CSH. Default is 16.
        direction : list , optional
            The vector representing the up direction of the RHS. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the RHS. This can be "center", "bottom", "top", "lowerleft", "upperleft", "lowerright", "upperright". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created cell.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology

        if thickness >= radius:
            if not silent:
                print("Cell.CHS - Error: The thickness value is larger than or equal to the outer radius value. Returning None.")
            return None
        if origin == None:
            origin = Vertex.Origin()
        bottom_face = Face.CHS(origin = Vertex.Origin(),radius=radius, thickness=thickness, sides=sides, direction=[0,0,1], placement="center", tolerance=tolerance, silent=silent)
        if not Topology.IsInstance(bottom_face, "face"):
            if not silent:
                print("Cell.CSH - Error: Could not create the base face. Returning None.")
            return None
        return_cell = Cell.ByThickenedFace(bottom_face, thickness=height, bothSides=True, reverse=False, tolerance=tolerance, silent=silent)
        if not Topology.IsInstance(return_cell, "cell"):
            if not silent:
                print("Cell.CSH - Error: Could not create the cell. Returning None.")
            return None
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "bottom":
            zOffset = height*0.5
        elif placement.lower() == "top":
            zOffset = -height*0.5
        elif placement.lower() == "lowerleft":
            xOffset = radius
            yOffset = radius
            zOffset = height*0.5
        elif placement.lower() == "upperleft":
            xOffset = radius
            yOffset = -radius
            zOffset = -height*0.5
        elif placement.lower() == "lowerright":
            xOffset = -radius
            yOffset = radius
            zOffset = height*0.5
        elif placement.lower() == "upperright":
            xOffset = -radius
            yOffset = -radius
            zOffset = -height*0.5
        return_cell = Topology.OrientAndPlace(return_cell,
                                            originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                            originB=origin,
                                            dirA=[0, 0, 1],
                                            dirB=direction,
                                            transferDictionaries = False,
                                            tolerance = tolerance,
                                            silent = silent)
        return return_cell


    @staticmethod
    def Compactness(cell, reference = "sphere", mantissa: int = 6) -> float:
        """
        Returns the compactness measure of the input cell. If the reference is "sphere", this is also known as 'sphericity' (https://en.wikipedia.org/wiki/Sphericity).

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.
        reference : str , optional
            The desired reference to which to compare this compactness. The options are "sphere" and "cube". It is case insensitive. Default is "sphere".
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.

        Returns
        -------
        float
            The compactness of the input cell.

        """
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology
        import math

        faces = Topology.Faces(cell)
        area = 0.0
        for aFace in faces:
            area = area + abs(Face.Area(aFace))
        volume = abs(Cell.Volume(cell, mantissa=mantissa))
        compactness  = 0
        #From https://en.wikipedia.org/wiki/Sphericity
        if area > 0:
            if reference.lower() == "sphere":
                compactness = (((math.pi)**(1/3))*((6*volume)**(2/3)))/area
            else:
                compactness = 6*(volume**(2/3))/area
        else:
            print("Cell.Compactness - Error: cell surface area is not positive. Returning None.")
            return None
        return round(compactness, mantissa)
    
    @staticmethod
    def Cone(origin = None, baseRadius: float = 0.5, topRadius: float = 0, height: float = 1, uSides: int = 16, vSides: int = 1, direction: list = [0, 0, 1],
                 dirZ: float = 1, placement: str = "center", mantissa: int = 6, tolerance: float = 0.0001, silent: bool = False, polyhedron: bool = True):
        """
        Creates a cone.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The location of the origin of the cone. Default is None which results in the cone being placed at (0, 0, 0).
        baseRadius : float , optional
            The radius of the base circle of the cone. Default is 0.5.
        topRadius : float , optional
            The radius of the top circle of the cone. Default is 0.
        height : float , optional
            The height of the cone. Default is 1.
        uSides : int , optional
            The number of circle segments of the cylinder. Default is 16.
        vSides : int , optional
            The number of vertical segments of the cylinder. Default is 1.
        direction : list , optional
            The vector representing the up direction of the cone. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the cone. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        mantissa : int , optional
            The desired length of the mantissa. Default is 6
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.

        Returns
        -------
        topologic_core.Cell
            The created cone.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Cluster import Cluster
        from topologicpy.Topology import Topology
        import math

        if not polyhedron:
            if not Topology.IsInstance(origin, "Vertex"):
                origin = Vertex.Origin()
            cone = Cell._NativeCell("ByCone", baseRadius=baseRadius, topRadius=topRadius, height=height, tolerance=tolerance, silent=silent)
            if not Topology.IsInstance(cone, "Cell"):
                return None
            p = str(placement).lower().strip()
            r = max(abs(float(baseRadius)), abs(float(topRadius)))
            source = [0.0, 0.0, 0.0]
            if p == "bottom":
                source = [0.0, 0.0, -0.5*float(height)]
            elif p == "lowerleft":
                source = [-r, -r, -0.5*float(height)]
            elif p != "center":
                if not silent:
                    print('Cell.Cone - Error: placement must be "center", "bottom", or "lowerleft". Returning None.')
                return None
            return Cell._PlaceNativeCell(cone, origin, direction, source, tolerance, silent)

        def createCone(baseWire, topWire, baseVertex, topVertex, tolerance=0.0001):
            if baseWire == None and topWire == None:
                raise Exception("Cell.Cone - Error: Both radii of the cone cannot be zero at the same time")
            elif baseWire == None:
                apex = baseVertex
                wire = topWire
            elif topWire == None:
                apex = topVertex
                wire = baseWire
            else:
                return Cell.ByWires([baseWire, topWire])
            vertices = Topology.Vertices(wire)
            faces = [Face.ByWire(wire, tolerance=tolerance)]
            for i in range(0, len(vertices)-1):
                w = Wire.ByVertices([apex, vertices[i], vertices[i+1]])
                f = Face.ByWire(w, tolerance=tolerance)
                faces.append(f)
            w = Wire.ByVertices([apex, vertices[-1], vertices[0]])
            f = Face.ByWire(w, tolerance=tolerance)
            faces.append(f)
            return Cell.ByFaces(faces, tolerance=tolerance)
        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)
        if not Topology.IsInstance(origin, "Vertex"):
            print("Cell.Cone - Error: The input origin parameter is not a valid topologic vertex. Returning None.")
            return None
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "center":
            xOffset = 0
            yOffset = 0
            zOffset = -height*0.5
        elif placement.lower() == "lowerleft":
            xOffset = max(baseRadius, topRadius)
            yOffset = max(baseRadius, topRadius)
            zOffset = 0

        baseZ = Vertex.Z(origin) + zOffset
        topZ = Vertex.Z(origin) + zOffset + height
        baseV = []
        topV = []
        for i in range(uSides):
            angle = math.radians(360/uSides)*i
            if baseRadius > 0:
                baseX = math.cos(angle)*baseRadius + Vertex.X(origin, mantissa=mantissa) + xOffset
                baseY = math.sin(angle)*baseRadius + Vertex.Y(origin, mantissa=mantissa) + yOffset
                baseZ = Vertex.Z(origin, mantissa=mantissa) + zOffset
                baseV.append(Vertex.ByCoordinates(baseX,baseY,baseZ))
            if topRadius > 0:
                topX = math.cos(angle)*topRadius + Vertex.X(origin, mantissa=mantissa) + xOffset
                topY = math.sin(angle)*topRadius + Vertex.Y(origin, mantissa=mantissa) + yOffset
                topV.append(Vertex.ByCoordinates(topX,topY,topZ))
        if baseRadius > 0:
            baseWire = Wire.ByVertices(baseV)
        else:
            baseWire = None
        if topRadius > 0:
            topWire = Wire.ByVertices(topV)
        else:
            topWire = None
        baseVertex = Vertex.ByCoordinates(Vertex.X(origin, mantissa=mantissa)+xOffset, Vertex.Y(origin, mantissa=mantissa)+yOffset, Vertex.Z(origin, mantissa=mantissa)+zOffset)
        topVertex = Vertex.ByCoordinates(Vertex.X(origin, mantissa=mantissa)+xOffset, Vertex.Y(origin, mantissa=mantissa)+yOffset, Vertex.Z(origin, mantissa=mantissa)+zOffset+height)
        cone = createCone(baseWire, topWire, baseVertex, topVertex, tolerance=tolerance)
        if cone == None:
            print("Cell.Cone - Error: Could not create a cone. Returning None.")
            return None
        
        if vSides > 1:
            cutting_planes = []
            baseX = Vertex.X(origin, mantissa=mantissa) + xOffset
            baseY = Vertex.Y(origin, mantissa=mantissa) + yOffset
            size = max(baseRadius, topRadius)*3
            for i in range(1, vSides):
                baseZ = Vertex.Z(origin, mantissa=mantissa) + zOffset + float(height)/float(vSides)*i
                tool_origin = Vertex.ByCoordinates(baseX, baseY, baseZ)
                cutting_planes.append(Face.ByWire(Wire.Rectangle(origin=tool_origin, width=size, length=size), tolerance=tolerance))
            cutting_planes_cluster = Cluster.ByTopologies(cutting_planes)
            shell = Cell.Shells(cone)[0]
            shell = Topology.Slice(shell,cutting_planes_cluster)
            cone = Cell.ByShell(shell)
        cone = Topology.Orient(cone, origin=origin, dirA=[0, 0, 1], dirB=direction)
        return cone
  
    @staticmethod
    def ContainmentStatus(cell, vertex, tolerance: float = 0.0001) -> int:
        """
        Returns the containment status of the input vertex in relationship to the input cell

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.
        vertex : topologic_core.Vertex
            The input vertex.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.

        Returns
        -------
        int
            Returns 0 if the vertex is inside, 1 if it is on the boundary of, and 2 if it is outside the input cell.

        """
        from topologicpy.Topology import Topology
        import math

        if not Topology.IsInstance(cell, "Cell"):
            print("Cell.ContainmentStatus - Error: The input cell parameter is not a valid topologic cell. Returning None.")
            return None
        if not Topology.IsInstance(vertex, "Vertex"):
            print("Cell.ContainmentStatus - Error: The input vertex parameter is not a valid topologic vertex. Returning None.")
            return None
        
        # Core.CellUtility.Contains does not seem to respect the input tolerance. Thus we need to send eight additional vertices
        # to check if any are contained and take the average result.
        
        test_vertices = [vertex]
        if tolerance > 0:
            test_cell = Cell.Prism(origin=vertex, width=tolerance*2, length=tolerance*2, height=tolerance*2, tolerance=tolerance)
            test_vertices.extend(Topology.Vertices(test_cell))
        try:
            av_results = []
            for v in test_vertices:
                
                result  = Core.CellUtility.Contains(cell, v, tolerance)
                if result == 0:
                    status = 0
                elif result == 1:
                    status = 1
                else:
                    status = 2
                av_results.append(status)
            return min(av_results)
            
        except:
            print("Cell.ContainmentStatus - Error: Could not determine containment status. Returning None.")
            return None
    
    @staticmethod
    def CrossShape(origin=None,
            width=1,
            length=1,
            height=1,
            a=0.25,
            b=0.25,
            c=None,
            d=None,
            flipHorizontal = False,
            flipVertical = False,
            direction=[0,0,1],
            placement="center",
            tolerance=0.0001,
            silent=False):
        """
        Creates a Cross-shape.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The location of the origin of the T-shape. Default is None which results in the Cross-shape being placed at (0, 0, 0).
        width : float , optional
            The overall width of the Cross-shape. Default is 1.0.
        length : float , optional
            The overall length of the Cross-shape. Default is 1.0.
        height : float , optional
            The overall height of the C-shape. Default is 1.0.
        a : float , optional
            The hortizontal thickness of the vertical arm of the Cross-shape. Default is 0.25.
        b : float , optional
            The vertical thickness of the horizontal arm of the Cross-shape. Default is 0.25.
        c : float , optional
            The distance of the vertical symmetry axis measured from the left side of the Cross-shape. Default is None which results in the Cross-shape being symmetrical on the Y-axis.
        d : float , optional
            The distance of the horizontal symmetry axis measured from the bottom side of the Cross-shape. Default is None which results in the Cross-shape being symmetrical on the X-axis.
        direction : list , optional
            The vector representing the up direction of the Cross-shape. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the Cross-shape. This can be "center", "lowerleft", "upperleft", "lowerright", "upperright". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created Cross-shape cell.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology

        if not isinstance(width, int) and not isinstance(width, float):
            if not silent:
                print("Cell.CrossShape - Error: The width input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(length, int) and not isinstance(length, float):
            if not silent:
                print("Cell.CrossShape - Error: The length input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(a, int) and not isinstance(a, float):
            if not silent:
                print("Cell.CrossShape - Error: The a input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(b, int) and not isinstance(b, float):
            if not silent:
                print("Cell.CrossShape - Error: The b input parameter is not a valid number. Returning None.")
            return None
        if c == None:
            c = width/2
        if d == None:
            d = length/2
        if not isinstance(c, int) and not isinstance(c, float):
            if not silent:
                print("Cell.CrossShape - Error: The c input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(d, int) and not isinstance(d, float):
            if not silent:
                print("Cell.CrossShape - Error: The d input parameter is not a valid number. Returning None.")
        if width <= tolerance:
            if not silent:
                print("Cell.CrossShape - Error: The width input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if length <= tolerance:
            if not silent:
                print("Cell.CrossShape - Error: The length input parameter must be a positive number  greater than the tolerance input parameter. Returning None.")
            return None
        if a <= tolerance:
            if not silent:
                print("Cell.CrossShape - Error: The a input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if b <= tolerance:
            if not silent:
                print("Cell.CrossShape - Error: The b input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if c <= tolerance:
            if not silent:
                print("Cell.CrossShape - Error: The c input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if d <= tolerance:
            if not silent:
                print("Cell.CrossShape - Error: The d input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if a >= (width - tolerance*2):
            if not silent:
                print("Cell.CrossShape - Error: The a input parameter must be less than the width input parameter. Returning None.")
            return None
        if b >= (length - tolerance*2):
            if not silent:
                print("Cell.CrossShape - Error: The b input parameter must be less than the length input parameter. Returning None.")
            return None
        if c <= (tolerance + a/2):
            if not silent:
                print("Cell.CrossShape - Error: The c input parameter must be more than half the a input parameter. Returning None.")
            return None
        if d <= (tolerance + b/2):
            if not silent:
                print("Cell.CrossShape - Error: The c input parameter must be more than half the b input parameter. Returning None.")
            return None
        if c >= (width - tolerance - a/2):
            if not silent:
                print("Cell.CrossShape - Error: The c input parameter must be less than the width minus half the a input parameter. Returning None.")
            return None
        if d >= (length - tolerance - b/2):
            if not silent:
                print("Cell.CrossShape - Error: The c input parameter must be less than the width minus half the b input parameter. Returning None.")
            return None
        if origin == None:
            origin = Vertex.Origin()
        if not Topology.IsInstance(origin, "vertex"):
            if not silent:
                print("Cell.CrossShape - Error: The origin input parameter is not a valid topologic vertex. Returning None.")
            return None
        if not isinstance(direction, list):
            if not silent:
                print("Cell.CrossShape - Error: The direction input parameter is not a valid list. Returning None.")
            return None
        if not len(direction) == 3:
            if not silent:
                print("Cell.CrossShape - Error: The direction input parameter is not a valid vector. Returning None.")
            return None
        cross_shape_face = Face.CrossShape(origin=origin,
                                   width=width,
                                   length=length,
                                   a=a,
                                   b=b,
                                   c=c,
                                   d=d,
                                   flipHorizontal=flipHorizontal,
                                   flipVertical=flipVertical,
                                   direction=direction,
                                   placement=placement,
                                   tolerance=tolerance,
                                   silent=silent)
        return_cell = Cell.ByThickenedFace(cross_shape_face, thickness=height, bothSides=True, reverse=False,
                            tolerance=tolerance, silent=silent)
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "bottom":
            zOffset = height*0.5
        elif placement.lower() == "top":
            zOffset = -height*0.5
        elif placement.lower() == "lowerleft":
            xOffset = width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperleft":
            xOffset = width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        elif placement.lower() == "lowerright":
            xOffset = -width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperright":
            xOffset = -width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        return_cell = Topology.OrientAndPlace(return_cell,
                                           originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                           originB=origin,
                                           dirA=[0, 0, 1],
                                           dirB=direction,
                                           transferDictionaries = False,
                                           tolerance = tolerance,
                                           silent = silent)
        return return_cell
    
    @staticmethod
    def CShape(origin=None,
            width=1,
            length=1,
            height=1,
            wSides=1,
            a=0.25,
            b=0.25,
            c=0.25,
            flipHorizontal = False,
            flipVertical = False,
            direction=[0,0,1],
            placement="center",
            mantissa=6,
            tolerance=0.0001,
            silent=False):
        """
        Creates a C-shape.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The location of the origin of the C-shape. Default is None which results in the C-shape being placed at (0, 0, 0).
        width : float , optional
            The overall width of the C-shape. Default is 1.0.
        length : float , optional
            The overall length of the C-shape. Default is 1.0.
        height : float , optional
            The overall height of the C-shape. Default is 1.0.
        wSides : int , optional
            The desired number of sides along the Z-axis. Default is 1.
        a : float , optional
            The hortizontal thickness of the vertical arm of the C-shape. Default is 0.25.
        b : float , optional
            The vertical thickness of the bottom horizontal arm of the C-shape. Default is 0.25.
        c : float , optional
            The vertical thickness of the top horizontal arm of the C-shape. Default is 0.25.
        flipHorizontal : bool , optional
            if set to True, the shape is flipped horizontally. Default is False.
        flipVertical : bool , optional
            if set to True, the shape is flipped vertically. Default is False.
        direction : list , optional
            The vector representing the up direction of the C-shape. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the C-shape. This can be "center", "lowerleft", "upperleft", "lowerright", "upperright". It is case insensitive. Default is "center".
        mantissa: int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created C-shape cell.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.Topology import Topology

        if not isinstance(width, int) and not isinstance(width, float):
            if not silent:
                print("Cell.CShape - Error: The width input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(length, int) and not isinstance(length, float):
            if not silent:
                print("Cell.CShape - Error: The length input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(height, int) and not isinstance(height, float):
            if not silent:
                print("Cell.CShape - Error: The height input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(a, int) and not isinstance(a, float):
            if not silent:
                print("Cell.CShape - Error: The a input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(b, int) and not isinstance(b, float):
            if not silent:
                print("Cell.CShape - Error: The b input parameter is not a valid number. Returning None.")
            return None
        if width <= tolerance:
            if not silent:
                print("Cell.CShape - Error: The width input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if length <= tolerance:
            if not silent:
                print("Cell.CShape - Error: The length input parameter must be a positive number  greater than the tolerance input parameter. Returning None.")
            return None
        if height <= tolerance:
            if not silent:
                print("Cell.CShape - Error: The height input parameter must be a positive number  greater than the tolerance input parameter. Returning None.")
            return None
        if a <= tolerance:
            if not silent:
                print("Cell.CShape - Error: The a input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if b <= tolerance:
            if not silent:
                print("Cell.CShape - Error: The b input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if c <= tolerance:
            if not silent:
                print("Cell.CShape - Error: The c input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if a >= (width - tolerance):
            if not silent:
                print("Cell.CShape - Error: The a input parameter must be less than the width input parameter. Returning None.")
            return None
        if b+c >= (length - tolerance):
            if not silent:
                print("Cell.CShape - Error: The b and c input parameters must add to less than the length input parameter. Returning None.")
            return None
        if origin == None:
            origin = Vertex.Origin()
        if not Topology.IsInstance(origin, "vertex"):
            if not silent:
                print("Cell.CShape - Error: The origin input parameter is not a valid topologic vertex. Returning None.")
            return None
        if not isinstance(direction, list):
            if not silent:
                print("Cell.CShape - Error: The direction input parameter is not a valid list. Returning None.")
            return None
        if not len(direction) == 3:
            if not silent:
                print("Cell.CShape - Error: The direction input parameter is not a valid vector. Returning None.")
            return None        
        c_shape_wire = Wire.CShape(origin=origin,
                                   width=width,
                                   length=length,
                                   a=a,
                                   b=b,
                                   c=c,
                                   flipHorizontal=flipHorizontal,
                                   flipVertical=flipVertical,
                                   direction=[0,0,1],
                                   placement="center",
                                   tolerance=tolerance,
                                   silent=silent)
        distance = height/wSides
        wires = [c_shape_wire]
        for i in range(wSides):
            c_shape_wire = Topology.Translate(c_shape_wire, 0, 0, distance)
            wires.append(c_shape_wire)
        return_cell = Cell.ByWires(wires, triangulate=False, mantissa=mantissa, tolerance=tolerance, silent=silent)
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "center":
            zOffset = -height*0.5
        elif placement.lower() == "bottom":
            zOffset = 0
        elif placement.lower() == "top":
            zOffset = -height
        elif placement.lower() == "lowerleft":
            xOffset = width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperleft":
            xOffset = width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        elif placement.lower() == "lowerright":
            xOffset = -width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperright":
            xOffset = -width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        return_cell = Topology.OrientAndPlace(return_cell,
                                           originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                           originB=origin,
                                           dirA=[0, 0, 1],
                                           dirB=direction,
                                           transferDictionaries = False,
                                           tolerance = tolerance,
                                           silent = silent)
        return return_cell
    
    @staticmethod
    def Cube(origin = None,
             size: float = 1,
            uSides: int = 1,
            vSides: int = 1,
            wSides: int = 1,
            direction: list = [0, 0, 1],
            placement: str ="center",
            tolerance: float = 0.0001,
            silent: bool = False):
        """
        Creates a cube.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the cube. Default is None which results in the cube being placed at (0, 0, 0).
        size : float , optional
            The size of the cube. Default is 1.
        uSides : int , optional
            The number of sides along the width. Default is 1.
        vSides : int , optional
            The number of sides along the length. Default is 1.
        wSides : int , optional
            The number of sides along the height. Default is 1.
        direction : list , optional
            The vector representing the up direction of the cube. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the cube. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        topologic_core.Cell
            The created cube.

        """
        return Cell.Prism(origin=origin,
                          width=size,
                          length=size,
                          height=size,
                          uSides=uSides,
                          vSides=vSides,
                          wSides=wSides,
                          direction=direction,
                          placement=placement,
                          tolerance=tolerance,
                          silent=silent)
    
    @staticmethod
    def Cylinder(
        origin=None,
        radius: float = 0.5,
        height: float = 1,
        uSides: int = 16,
        vSides: int = 1,
        polyhedron: bool = True,
        direction: list = [0, 0, 1],
        placement: str = "center",
        mantissa: int = 6,
        tolerance: float = 0.0001,
        silent: bool = False
    ):
        """
        Creates a cylinder.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The location of the origin of the cylinder.
        radius : float , optional
            The radius of the cylinder. Default is 0.5.
        height : float , optional
            The height of the cylinder. Default is 1.
        uSides : int , optional
            The number of circumferential segments. Default is 16.
        vSides : int , optional
            The number of vertical segments. Default is 1.
        polyhedron : bool , optional
            If True, creates a faceted cylinder. If False, creates an exact
            curved cylinder on the PythonOCC backend. Default is True.
        direction : list , optional
            The cylinder axis. Default is [0, 0, 1].
        placement : str , optional
            "bottom", "center", or "lowerleft". Default is "center".
        mantissa : int , optional
            The desired mantissa. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created Cell.
        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Cluster import Cluster
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.Origin()

        try:
            radius = abs(float(radius))
            height = abs(float(height))
            uSides = int(uSides)
            vSides = int(vSides)
            tolerance = abs(float(tolerance))
        except Exception:
            return None

        if radius <= tolerance or height <= tolerance:
            return None

        if uSides < 3 or vSides < 1:
            return None

        placement = str(placement).lower().strip()
        if placement not in ["bottom", "center", "lowerleft"]:
            return None

        # Exact curved cylinder.
        if not polyhedron:
            cylinder = Cell._NativeCell(
                "ByCylinder",
                radius=radius,
                height=height,
                tolerance=tolerance,
                silent=True,
            )

            if not Topology.IsInstance(cylinder, "Cell"):
                return None

            source = [0.0, 0.0, 0.0]

            if placement == "bottom":
                source = [0.0, 0.0, -0.5 * height]
            elif placement == "lowerleft":
                source = [-radius, -radius, -0.5 * height]

            return Cell._PlaceNativeCell(
                cylinder,
                origin,
                direction,
                source,
                tolerance,
                True,
            )

        # Placement of polygonal base.
        x_offset = 0.0
        y_offset = 0.0
        z_offset = 0.0

        if placement == "center":
            z_offset = -0.5 * height

        elif placement == "lowerleft":
            x_offset = radius
            y_offset = radius

        base_origin = Vertex.ByCoordinates(
            Vertex.X(origin, mantissa=None) + x_offset,
            Vertex.Y(origin, mantissa=None) + y_offset,
            Vertex.Z(origin, mantissa=None) + z_offset,
        )

        base_wire = Wire.Circle(
            origin=base_origin,
            radius=radius,
            sides=uSides,
            fromAngle=0,
            toAngle=360,
            close=True,
            direction=[0, 0, 1],
            placement="center",
            polyline=True,
            tolerance=tolerance,
            silent=True,
        )

        if not Topology.IsInstance(base_wire, "Wire"):
            if not silent:
                print("Cell.Cylinder - Error: Could not create the base wire. Returning None.")
            return None

        base_face = Face.ByWire(
            base_wire,
            tolerance=tolerance,
            silent=True,
        )

        if not Topology.IsInstance(base_face, "Face"):
            return None

        # PythonOCC: direct exact extrusion of the polygonal Face.
        if not Topology._IsTopologicCoreBackend():
            cylinder = Cell._NativeCell(
                "ByPrism",
                base_face,
                vector=[0.0, 0.0, height],
                tolerance=tolerance,
                silent=True,
            )

        # TopologicCore: retain historical polyhedral construction.
        else:
            cylinder = Cell.ByThickenedFace(
                face=base_face,
                thickness=height,
                bothSides=False,
                reverse=False,
                tolerance=tolerance,
                silent=silent,
                polyhedron=True,
            )

        if not Topology.IsInstance(cylinder, "Cell"):
            return None

        # Vertical subdivisions.
        if vSides > 1:
            cutting_planes = []

            base_x = Vertex.X(origin, mantissa=None) + x_offset
            base_y = Vertex.Y(origin, mantissa=None) + y_offset
            size = radius * 3.0

            for i in range(1, vSides):
                z = (
                    Vertex.Z(origin, mantissa=None)
                    + z_offset
                    + height * float(i) / float(vSides)
                )

                tool_origin = Vertex.ByCoordinates(
                    base_x,
                    base_y,
                    z,
                )

                cutting_face = Face.ByWire(
                    Wire.Rectangle(
                        origin=tool_origin,
                        width=size,
                        length=size,
                    ),
                    tolerance=tolerance,
                    silent=True,
                )

                if Topology.IsInstance(cutting_face, "Face"):
                    cutting_planes.append(cutting_face)

            if cutting_planes:
                cutters = Cluster.ByTopologies(cutting_planes)

                sliced = Topology.Slice(
                    cylinder,
                    cutters,
                )

                if sliced is not None:
                    candidate = CellComplex.ExternalBoundary(sliced)
                    if Topology.IsInstance(candidate, "Cell"):
                        cylinder = candidate

        return Topology.Orient(
            cylinder,
            origin=origin,
            dirA=[0, 0, 1],
            dirB=direction,
            tolerance=tolerance,
            silent=True,
        )
    
    @staticmethod
    def Decompose(cell, tiltAngle: float = 10, tolerance: float = 0.0001) -> dict:
        """
        Decomposes the input cell into its logical components. This method assumes that the positive Z direction is UP.

        Parameters
        ----------
        cell : topologic_core.Cell
            the input cell.
        tiltAngle : float , optional
            The threshold tilt angle in degrees to determine if a face is vertical, horizontal, or tilted. The tilt angle is measured from the nearest cardinal direction. Default is 10.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.

        Returns
        -------
        dictionary
            A dictionary with the following keys and values:
            1. "verticalFaces": list of vertical faces
            2. "topHorizontalFaces": list of top horizontal faces
            3. "bottomHorizontalFaces": list of bottom horizontal faces
            4. "inclinedFaces": list of inclined faces
            5. "verticalApertures": list of vertical apertures
            6. "topHorizontalApertures": list of top horizontal apertures
            7. "bottomHorizontalApertures": list of bottom horizontal apertures
            8. "inclinedApertures": list of inclined apertures

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Vector import Vector
        from topologicpy.Aperture import Aperture
        from topologicpy.Topology import Topology

        def angleCode(f, up, tiltAngle):
            dirA = Face.Normal(f)
            ang = round(Vector.Angle(dirA, up), 2)
            if abs(ang - 90) < tiltAngle:
                code = 0
            elif abs(ang) < tiltAngle:
                code = 1
            elif abs(ang - 180) < tiltAngle:
                code = 2
            else:
                code = 3
            return code

        def getApertures(topology):
            return Topology.Apertures(topology)

        if not Topology.IsInstance(cell, "Cell"):
            print("Cell.Decompose - Error: The input cell parameter is not a valid topologic cell. Returning None.")
            return None
        verticalFaces = []
        topHorizontalFaces = []
        bottomHorizontalFaces = []
        inclinedFaces = []
        verticalApertures = []
        topHorizontalApertures = []
        bottomHorizontalApertures = []
        inclinedApertures = []
        tiltAngle = abs(tiltAngle)
        faces = Cell.Faces(cell)
        zList = []
        for f in faces:
            zList.append(Vertex.Z(Topology.Centroid(f)))
        zMin = min(zList)
        zMax = max(zList)
        up = [0, 0, 1]
        for aFace in faces:
            aCode = angleCode(aFace, up, tiltAngle)

            if aCode == 0:
                verticalFaces.append(aFace)
                verticalApertures += getApertures(aFace)
            elif aCode == 1:
                if abs(Vertex.Z(Topology.Centroid(aFace)) - zMin) <= tolerance:
                    bottomHorizontalFaces.append(aFace)
                    bottomHorizontalApertures += getApertures(aFace)
                else:
                    topHorizontalFaces.append(aFace)
                    topHorizontalApertures += getApertures(aFace)
            elif aCode == 2:
                if abs(Vertex.Z(Topology.Centroid(aFace)) - zMax) <= tolerance:
                    topHorizontalFaces.append(aFace)
                    topHorizontalApertures += getApertures(aFace)
                else:
                    bottomHorizontalFaces.append(aFace)
                    bottomHorizontalApertures += getApertures(aFace)
            elif aCode == 3:
                inclinedFaces.append(aFace)
                inclinedApertures += getApertures(aFace)
        d = {
            "verticalFaces" : verticalFaces,
            "topHorizontalFaces" : topHorizontalFaces,
            "bottomHorizontalFaces" : bottomHorizontalFaces,
            "inclinedFaces" : inclinedFaces,
            "verticalApertures" : verticalApertures,
            "topHorizontalApertures" : topHorizontalApertures,
            "bottomHorizontalApertures" : bottomHorizontalApertures,
            "inclinedApertures" : inclinedApertures
            }
        return d

    @staticmethod
    def Dodecahedron(origin= None,
                     radius: float = 0.5,
                     direction: list = [0, 0, 1],
                     placement: str ="center",
                     tolerance: float = 0.0001,
                     silent: bool = False):
        """
        Creates a dodecahedron. See https://en.wikipedia.org/wiki/Dodecahedron.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the dodecahedron. Default is None which results in the dodecahedron being placed at (0, 0, 0).
        radius : float , optional
            The radius of the dodecahedron's circumscribed sphere. Default is 0.5.
        direction : list , optional
            The vector representing the up direction of the dodecahedron. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the dodecahedron. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        topologic_core.Cell
            The created dodecahedron.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Face import Face
        from topologicpy.Cluster import Cluster
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)
        if not Topology.IsInstance(origin, "Vertex"):
            if not silent:
                print("Cell.Dodecahedron - Error: The input origin parameter is not a valid topologic vertex. Returning None.")
            return None
        pen = Face.Circle(sides=5, radius=0.5)
        pentagons = [pen]
        edges = Topology.Edges(pen)
        for edge in edges:
            o = Topology.Centroid(edge)
            e_dir = Edge.Direction(edge)
            pentagons.append(Topology.Rotate(pen, origin=o, axis=e_dir, angle=116.565))

        cluster = Cluster.ByTopologies(pentagons)
        
        cluster2 = Topology.Rotate(cluster, origin=Vertex.Origin(), axis=[1, 0, 0], angle=180)
        vertices = Topology.Vertices(cluster)
        zList = [Vertex.Z(v) for v in vertices]
        # Round away the ~1e-17 float noise topologic kernels leave on the
        # equator vertices. Without this, zList starts with several distinct
        # near-zero values (e.g. -1e-17 / +2e-17) and zoffset = zList[1]-
        # zList[0] collapse to 0.0, mis-translating the mirrored half by the
        # ring step and leaving the two halves 0.5 apart. topologic_core's
        # kernel welds across that gap anyway, but the PythonOCC backend's
        # sewing cannot, producing two half-shells and a corrupt Dodecahedron.
        zList = [round(Vertex.Z(v), 6) for v in vertices]
        zList = list(set(zList))
        zList.sort()
        zoffset = zList[1] - zList[0]
        total_height = zList[-1] - zList[0]
        cluster2 = Topology.Translate(cluster2, 0, 0, total_height+zoffset)
        pentagons += Topology.Faces(cluster2)
        dodecahedron = Cell.ByFaces(pentagons, tolerance=tolerance)
        if not Topology.IsInstance(dodecahedron, "cell"):
            if not silent:
                print("Cell.Dodecahedron - Error: Could not create the cell. Returning None.")
            return None
        centroid = Topology.Centroid(dodecahedron)
        dodecahedron = Topology.Translate(dodecahedron, -Vertex.X(centroid), -Vertex.Y(centroid), -Vertex.Z(centroid))
        vertices = Topology.Vertices(dodecahedron)
        d = Vertex.Distance(Vertex.Origin(), vertices[0])
        # Make sure the distance from the origin to the vertices is equal to the radius.
        dodecahedron = Topology.Scale(dodecahedron, origin=Vertex.Origin(), x=radius/d, y=radius/d, z=radius/d)
        if placement == "bottom":
            dodecahedron = Topology.Translate(dodecahedron, 0, 0, radius)
        elif placement == "lowerleft":
            dodecahedron = Topology.Translate(dodecahedron, radius, radius, radius)
        
        # The direct Cell.ByFaces result is already a correct, transform-safe
        # dodecahedron. The old geometry-rebuild step (SelfMerge/ByGeometry ->
        # RemoveCoplanarFaces) was a workaround for a pythonocc backend that
        # produced a broken half-shell cell; with the backend fixed it now
        # DEGRADES the solid (pythonocc: 12 -> 10 faces; core: 12 -> 14), so it
        # is only used as a last-resort fallback if the direct cell is invalid.
        if not Topology.IsInstance(dodecahedron, "cell"):
            try:
                dodecahedron = Cell.ByFaces(Topology.Faces(dodecahedron, silent=True), tolerance=tolerance, silent=True)
            except Exception:
                try:
                    dodecahedron = Cell.ByShell(dodecahedron, tolerance=tolerance, silent=True)
                except Exception:
                    dodecahedron = None
        dodecahedron = Topology.OrientAndPlace(dodecahedron,
                                           originA=Vertex.Origin(),
                                           originB=origin,
                                           dirA=[0, 0, 1],
                                           dirB=direction,
                                           transferDictionaries = False,
                                           tolerance = tolerance,
                                           silent = silent)
        return dodecahedron

    @staticmethod
    def Edges(cell) -> list:
        """
        Returns the edges of the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.

        Returns
        -------
        list
            The list of edges.

        """
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(cell, "Cell"):
            print("Cell.Edges - Error: The input cell parameter is not a valid topologic cell. Returning None.")
            return None
        edges = Topology.Edges(cell)
        return edges

    @staticmethod
    def Egg(origin= None,
            height: float = 1.0,
            uSides: int = 16,
            vSides: int = 8,
            direction: list = [0, 0, 1],
            placement: str = "center",
            tolerance: float = 0.0001,
            silent: bool = False):
        """
        Creates an egg-shaped cell.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the sphere. Default is None which results in the egg-shaped cell being placed at (0, 0, 0).
        height : float , optional
            The desired height of of the egg-shaped cell. Default is 1.0.
        uSides : int , optional
            The desired number of sides along the longitude of the egg-shaped cell. Default is 16.
        vSides : int , optional
            The desired number of sides along the latitude of the egg-shaped cell. Default is 8.
        direction : list , optional
            The vector representing the up direction of the egg-shaped cell. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the egg-shaped cell. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created egg-shaped cell.

        """

        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Topology import Topology
        from topologicpy.Dictionary import Dictionary

        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)
        if not Topology.IsInstance(origin, "Vertex"):
            print("Cell.Sphere - Error: The input origin parameter is not a valid topologic vertex. Returning None.")
            return None
        
        coords = [[0.0, 0.0, -0.5],
                 [0.074748, 0.0, -0.494015],
                 [0.140819, 0.0, -0.473222],
                 [0.204118, 0.0, -0.438358],
                 [0.259512, 0.0, -0.391913],
                 [0.304837, 0.0, -0.335519],
                 [0.338649, 0.0, -0.271416],
                 [0.361307, 0.0, -0.202039],
                 [0.375678, 0.0, -0.129109],
                 [0.381294, 0.0, -0.053696],
                 [0.377694, 0.0, 0.019874],
                 [0.365135, 0.0, 0.091978],
                 [0.341482, 0.0, 0.173973],
                 [0.300154, 0.0, 0.276001],
                 [0.252928, 0.0, 0.355989],
                 [0.206605, 0.0, 0.405813],
                 [0.157529, 0.0, 0.442299],
                 [0.10604, 0.0, 0.472092],
                 [0.05547, 0.0, 0.491784],
                 [0.0, 0.0, 0.5]]
        verts = [Vertex.ByCoordinates(coord) for coord in coords]
        c = Wire.ByVertices(verts, close=False)
        new_verts = []
        for i in range(vSides+1):
            new_verts.append(Wire.VertexByParameter(c, i/vSides))
        c = Wire.ByVertices(new_verts, close=False)
        egg = Topology.Spin(c, origin=Vertex.Origin(), triangulate=False, direction=[0, 0, 1], angle=360, sides=uSides, tolerance=tolerance)
        if Topology.IsInstance(egg, "CellComplex"):
            egg = CellComplex.ExternalBoundary(egg)
        if Topology.IsInstance(egg, "Shell"):
            egg = Cell.ByShell(egg)
        egg = Topology.Scale(egg, origin=Vertex.Origin(), x=height, y=height, z=height)
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "bottom":
            zOffset = 0
        elif placement.lower() == "lowerleft":
            bb = Topology.BoundingBox(egg)
            d = Topology.Dictionary(bb)
            width = Dictionary.ValueAtKey(d, 'width')
            length = Dictionary.ValueAtKey(d, 'length')
            xOffset = width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        egg = Topology.OrientAndPlace(egg,
                                      originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                      originB=origin,
                                      dirA=[0, 0, 1],
                                      dirB=direction,
                                      transferDictionaries = False,
                                      tolerance = tolerance,
                                      silent = silent)
        
        return egg
    
    @staticmethod
    def ExternalBoundary(cell, tolerance: float = 0.0001, silent: bool = False):
        """
        Returns the external boundary of the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Shell
            The external boundary of the input cell.

        """
        from topologicpy.Topology import Topology
        from topologicpy.Helper import Helper
        from topologicpy.Shell import Shell

        if not Topology.IsInstance(cell, "Cell"):
            if not silent:
                print("Cell.ExternalBoundary - Error: The input cell parameter is not a valid topologic cell. Returning None.")
            return None
        
        shells = Topology.Shells(cell)
        closed_shells = []
        temp_cells = []
        for shell in shells:
            try:
                temp_cell = Cell.ByShell(shell, silent=True)
                if Topology.IsInstance(temp_cell, "cell"):
                    closed_shells.append(shell)
                    temp_cells.append(temp_cell)
            except:
                pass
        volumes = [Cell.Volume(c) for c in temp_cells]
        closed_shells = Helper.Sort(closed_shells, volumes, silent=silent)
        return closed_shells[-1]
    
    @staticmethod
    def Faces(cell, silent: bool = False) -> list:
        """
        Returns the faces of the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        list
            The list of faces.

        """
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(cell, "Cell"):
            if not silent:
                print("Cell.Faces - Error: The input cell parameter is not a valid topologic cell. Returning None.")
            return None
        faces = Topology.Faces(cell)
        return faces

    @staticmethod
    def Hyperboloid(origin = None,
                    baseRadius: float = 0.5,
                    topRadius: float = 0.5,
                    height: float = 1,
                    sides: int = 24,
                    direction: list = [0, 0, 1],
                    twist: float = 60,
                    placement: str = "center",
                    mantissa: int = 6,
                    tolerance: float = 0.0001,
                    silent: bool = False):
        """
        Creates a hyperboloid.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The location of the origin of the hyperboloid. Default is None which results in the hyperboloid being placed at (0, 0, 0).
        baseRadius : float , optional
            The radius of the base circle of the hyperboloid. Default is 0.5.
        topRadius : float , optional
            The radius of the top circle of the hyperboloid. Default is 0.5.
        height : float , optional
            The height of the cone. Default is 1.
        sides : int , optional
            The number of sides of the cone. Default is 24.
        direction : list , optional
            The vector representing the up direction of the hyperboloid. Default is [0, 0, 1].
        twist : float , optional
            The angle to twist the base cylinder. Default is 60.
        placement : str , optional
            The description of the placement of the origin of the hyperboloid. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        mantissa : int , optional
            The desired length of the mantissa. Default is 6
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created hyperboloid.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Cluster import Cluster
        from topologicpy.Topology import Topology
        import math

        def createHyperboloid(baseVertices, topVertices, tolerance=0.0001):
            baseWire = Wire.ByVertices(baseVertices, close=True)
            topWire = Wire.ByVertices(topVertices, close=True)
            baseFace = Face.ByWire(baseWire, tolerance=tolerance)
            topFace = Face.ByWire(topWire, tolerance=tolerance)
            faces = [baseFace, topFace]
            for i in range(0, len(baseVertices)-1):
                w = Wire.ByVertices([baseVertices[i], topVertices[i], topVertices[i+1]], close=True)
                f = Face.ByWire(w, tolerance=tolerance)
                faces.append(f)
                w = Wire.ByVertices([baseVertices[i+1], baseVertices[i], topVertices[i+1]], close=True)
                f = Face.ByWire(w, tolerance=tolerance)
                faces.append(f)
            w = Wire.ByVertices([baseVertices[-1], topVertices[-1], topVertices[0]], close=True)
            f = Face.ByWire(w, tolerance=tolerance)
            faces.append(f)
            w = Wire.ByVertices([baseVertices[0], baseVertices[-1], topVertices[0]], close=True)
            f = Face.ByWire(w, tolerance=tolerance)
            faces.append(f)
            returnTopology = Cell.ByFaces(faces, tolerance=tolerance)
            if returnTopology == None:
                returnTopology = Cluster.ByTopologies(faces)
            return returnTopology
        
        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)
        if not Topology.IsInstance(origin, "Vertex"):
            if not silent:
                print("Cell.Hyperboloid - Error: The input origin parameter is not a valid topologic vertex. Returning None.")
            return None
        w_origin = Vertex.Origin()
        baseV = []
        topV = []
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "center":
            zOffset = -height*0.5
        elif placement.lower() == "lowerleft":
            xOffset = max(baseRadius, topRadius)
            yOffset = max(baseRadius, topRadius)
        baseZ = Vertex.Z(w_origin) + zOffset
        topZ = Vertex.Z(w_origin) + zOffset + height
        for i in range(sides):
            angle = math.radians(360/sides)*i
            if baseRadius > 0:
                baseX = math.sin(angle+math.radians(twist))*baseRadius + Vertex.X(w_origin, mantissa=mantissa) + xOffset
                baseY = math.cos(angle+math.radians(twist))*baseRadius + Vertex.Y(w_origin, mantissa=mantissa) + yOffset
                baseZ = Vertex.Z(w_origin, mantissa=mantissa) + zOffset
                baseV.append(Vertex.ByCoordinates(baseX,baseY,baseZ))
            if topRadius > 0:
                topX = math.sin(angle-math.radians(twist))*topRadius + Vertex.X(w_origin, mantissa=mantissa) + xOffset
                topY = math.cos(angle-math.radians(twist))*topRadius + Vertex.Y(w_origin, mantissa=mantissa) + yOffset
                topV.append(Vertex.ByCoordinates(topX,topY,topZ))

        hyperboloid = createHyperboloid(baseV, topV, tolerance=tolerance)
        if hyperboloid == None:
            if not silent:
                print("Cell.Hyperboloid - Error: Could not create the cell. Returning None.")
            return None
        
        hyperboloid = Topology.OrientAndPlace(hyperboloid,
                                              originA=Vertex.Origin(),
                                              originB=origin,
                                              dirA=[0, 0, 1],
                                              dirB=direction,
                                              transferDictionaries = False,
                                              tolerance = tolerance,
                                              silent = silent)
        return hyperboloid
    
    @staticmethod
    def Icosahedron(origin= None,
                    radius: float = 0.5,
                    direction: list = [0, 0, 1],
                    placement: str ="center",
                    tolerance: float = 0.0001,
                    silent: bool = True):
        """
        Creates an icosahedron. See https://en.wikipedia.org/wiki/Icosahedron.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the icosahedron. Default is None which results in the icosahedron being placed at (0, 0, 0).
        radius : float , optional
            The radius of the icosahedron's circumscribed sphere. Default is 0.5.
        direction : list , optional
            The vector representing the up direction of the icosahedron. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the icosahedron. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool, optional
            If set to True, suppresses warning and error messages. Default is False.
        
        Returns
        -------
        topologic_core.Cell
            The created icosahedron.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology
        import math

        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)
        if not Topology.IsInstance(origin, "Vertex"):
            if not silent:
                print("Cell.Icosahedron - Error: The input origin parameter is not a valid topologic vertex. Returning None.")
            return None
        rect1 = Wire.Rectangle(width=(1+math.sqrt(5))/2, length=1)
        rect2 = Wire.Rectangle(width=1, length=(1+math.sqrt(5))/2)
        rect2 = Topology.Rotate(rect2, origin=Vertex.Origin(), axis=[1, 0, 0], angle=90)
        rect3 = Wire.Rectangle(width=1, length=(1+math.sqrt(5))/2)
        rect3 = Topology.Rotate(rect3, origin=Vertex.Origin(), axis=[0, 1, 0], angle=90)
        vertices = Topology.Vertices(rect1)
        v1, v2, v3, v4 = vertices
        vertices = Topology.Vertices(rect2)
        v5, v6, v7, v8 = vertices
        vertices = Topology.Vertices(rect3)
        v9, v10, v11, v12 = vertices
        f1 = Face.ByVertices([v1,v8,v4])
        f2 = Face.ByVertices([v1,v4,v5])
        f3 = Face.ByVertices([v3,v2,v6])
        f4 = Face.ByVertices([v2,v3,v7])
        f5 = Face.ByVertices([v10,v9,v2])
        f6 = Face.ByVertices([v10,v9,v1])
        f7 = Face.ByVertices([v12,v11,v4])
        f8 = Face.ByVertices([v12,v11,v3])
        f9 = Face.ByVertices([v8,v7,v9])
        f10 = Face.ByVertices([v8,v7,v12])
        f11 = Face.ByVertices([v5,v6,v10])
        f12 = Face.ByVertices([v5,v6,v11])
        f13 = Face.ByVertices([v8,v1,v9])
        f14 = Face.ByVertices([v9,v2,v7])
        f15 = Face.ByVertices([v7,v3,v12])
        f16 = Face.ByVertices([v8,v12,v4])
        f17 = Face.ByVertices([v1,v5,v10])
        f18 = Face.ByVertices([v10,v2,v6])
        f19 = Face.ByVertices([v6,v3,v11])
        f20 = Face.ByVertices([v11,v4,v5])

        icosahedron = Cell.ByFaces([f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,
                        f11,f12,f13,f14,f15,f16,f17,f18,f19,f20], tolerance=tolerance)
        if not Topology.IsInstance(icosahedron, "cell"):
            if not silent:
                print("Cell.Icosahedron - Error: Could not create the cell. Returning None.")
            return None
        sf = 1.051*0.5 # To inscribe it in a sphere of radius 0.5
        icosahedron = Topology.Scale(icosahedron, origin=Vertex.Origin(), x=sf, y=sf, z=sf)
        sf = radius/0.5
        icosahedron = Topology.Scale(icosahedron, origin=Vertex.Origin(), x=sf, y=sf, z=sf)
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement == "bottom":
            zOffset = radius
        elif placement == "lowerleft":
            xOffset = yOffset = zOffset = radius
        
        icosahedron = Topology.OrientAndPlace(icosahedron,
                                              originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                              originB=origin,
                                              dirA=[0, 0, 1],
                                              dirB=direction,
                                              transferDictionaries = False,
                                              tolerance = tolerance,
                                              silent = silent)
        return icosahedron

    @staticmethod
    def Inflate(
        cell,
        faces: list,
        maxDistance: float = None,
        angTolerance: float = 1.0,
        mantissa: int = 6,
        tolerance: float = 0.0001,
        silent: bool = False,
    ):
        """
        Inflates the input cell until its faces collide with the input limiting faces.

        Each face of the cell moves outwards along its own normal direction while
        remaining parallel to its original plane. A moving face stops at the first
        distance at which any part of that face, one of its edges, or one of its
        vertices collides with any input limiting face. The limiting face does not
        need to be parallel to the moving cell face. If the moving face is
        already in contact with an analytical face and its inflation direction
        is tangent to that analytical face, the contact is treated as sliding
        contact and does not stop the inflation.

        The method translates the supporting planes of the cell faces and recomputes
        the cell vertices from the intersections of their incident translated planes.
        It does not project vertices independently. After every accepted face movement,
        every face is rebuilt explicitly from external and internal boundary loops
        ordered by traversing their connected edges. The rebuilt topology may be a Cell or a Cluster of faces; either is
        retained for subsequent processing. A single self-merge attempt is made after
        all face movements have been completed.

        This method is intended for planar, polyhedral cells whose incidence graph
        remains valid during inflation. It works best with simple cells in which each
        vertex is defined by three independent incident face planes.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.
        faces : list
            The list of limiting analytical faces.
        maxDistance : float , optional
            The maximum permitted outward movement of each cell face. If set to None,
            the required sweep distance is derived from the limiting-face vertices.
            Default is None.
        angTolerance : float , optional
            The angular tolerance in degrees used to identify sliding contact. If
            the inflation direction is parallel to an analytical-face plane within
            this tolerance, that analytical face does not block the movement.
            Default is 1.0.
        mantissa : int , optional
            The number of decimal places used to create replacement vertices.
            Default is 6.
        tolerance : float , optional
            The desired geometric tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error, warning, and information messages are suppressed.
            Default is False.

        Returns
        -------
        topologic_core.Topology
            The inflated topology. This is normally a Cell, but it may be a Cluster
            when the rebuilt faces cannot be self-merged into a Cell.

        Notes
        -----
        Collision is detected using the swept volume of each moving cell face. The
        intersection of that swept volume with a limiting face captures face, edge,
        and vertex contact. Tangential contact is ignored so that the moving face can
        slide along an analytical face. The earliest positive blocking travel
        distance among all remaining limiting faces is used.

        The method preserves the original cell incidence graph. It does not support
        an inflation event that requires splitting a face, creating a new vertex,
        removing a face, or otherwise changing that incidence graph. Intermediate
        rebuilt results are allowed to remain Clusters because subsequent movement
        calculations use the supporting planes and faces rather than Cell-only API
        operations. Boundary order is derived by traversing edge connectivity rather
        than relying on generic subtopology enumeration, which is not ordered.
        """
        from topologicpy.Cluster import Cluster
        from topologicpy.Dictionary import Dictionary
        from topologicpy.Edge import Edge
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire

        import math
        import numpy as np

        def _message(kind, text):
            if not silent:
                print(f"Cell.Inflate - {kind}: {text}")

        def _coordinates(vertex):
            coordinates = Vertex.Coordinates(
                vertex,
                outputType="xyz",
                mantissa=None,
            )
            if not isinstance(coordinates, list) or len(coordinates) != 3:
                return None
            try:
                return np.asarray(coordinates, dtype=float)
            except Exception:
                return None

        def _unit(vector):
            try:
                vector = np.asarray(vector, dtype=float)
                magnitude = float(np.linalg.norm(vector))
            except Exception:
                return None
            if magnitude <= tolerance:
                return None
            return vector / magnitude

        def _self_merge(topology, topology_type=None):
            if topology is None:
                return None
            if topology_type and Topology.IsInstance(topology, topology_type):
                return topology
            try:
                merged = Topology.SelfMerge(
                    topology,
                    transferDictionaries=False,
                    tolerance=tolerance,
                    silent=True,
                )
            except TypeError:
                try:
                    merged = Topology.SelfMerge(
                        topology,
                        tolerance=tolerance,
                    )
                except Exception:
                    merged = None
            except Exception:
                merged = None

            if topology_type and not Topology.IsInstance(merged, topology_type):
                return None
            return merged

        def _intersect(topology_a, topology_b):
            try:
                return Topology.Intersect(
                    topology_a,
                    topology_b,
                    tranDict=False,
                    tolerance=tolerance,
                    silent=True,
                )
            except TypeError:
                try:
                    return Topology.Intersect(
                        topology_a,
                        topology_b,
                        tolerance=tolerance,
                        silent=True,
                    )
                except Exception:
                    return None
            except Exception:
                return None

        def _collision(topology_a, topology_b):
            intersection = _intersect(topology_a, topology_b)
            if Topology.IsInstance(intersection, "Topology"):
                return intersection
            return None

        def _projection_distance(point, origin, direction):
            return float(np.dot(direction, point - origin))

        def _sweep_distance(origin, direction):
            if maxDistance is not None:
                return maxDistance

            maximum = None
            for limiting_item in limiting_data:
                for point in limiting_item["positions"]:
                    distance = _projection_distance(point, origin, direction)
                    if distance > tolerance:
                        if maximum is None or distance > maximum:
                            maximum = distance

            if maximum is None:
                return None
            return maximum + tolerance * 10.0

        def _collision_distance(source_face, direction):
            source_centroid = Topology.Centroid(source_face, silent=True)
            source_origin = _coordinates(source_centroid)
            if source_origin is None:
                return None, None

            try:
                source_vertices = Topology.Vertices(
                    source_face,
                    silent=True,
                ) or []
            except Exception:
                source_vertices = []

            source_positions = []
            for source_vertex in source_vertices:
                position = _coordinates(source_vertex)
                if position is not None:
                    source_positions.append(position)

            if len(source_positions) == 0:
                source_positions = [source_origin]

            sweep_distance = _sweep_distance(source_origin, direction)
            if sweep_distance is None or sweep_distance <= tolerance:
                return None, None

            try:
                source_normal = Face.Normal(
                    source_face,
                    outputType="xyz",
                    mantissa=max(mantissa, 8),
                )
            except Exception:
                source_normal = None
            source_normal = _unit(source_normal)
            if source_normal is None:
                return None, None

            reverse = float(np.dot(source_normal, direction)) < 0.0

            # Prefer the backend's native prism/thickening operation. This
            # preserves the exact planar source Face and delegates the sweep to
            # OCCT on the PythonOCC backend. Retain the polygonal pathway only
            # as a compatibility fallback for TopologicCore.
            try:
                swept_cell = Cell.ByThickenedFace(
                    source_face,
                    thickness=sweep_distance,
                    bothSides=False,
                    reverse=reverse,
                    tolerance=tolerance,
                    silent=True,
                    polyhedron=False,
                )
            except Exception:
                swept_cell = None

            if not Topology.IsInstance(swept_cell, "Cell"):
                try:
                    swept_cell = Cell.ByThickenedFace(
                        source_face,
                        thickness=sweep_distance,
                        bothSides=False,
                        reverse=reverse,
                        tolerance=tolerance,
                        silent=True,
                        polyhedron=True,
                    )
                except Exception:
                    swept_cell = None

            if not Topology.IsInstance(swept_cell, "Cell"):
                swept_cell = _self_merge(swept_cell, "Cell")
            if not Topology.IsInstance(swept_cell, "Cell"):
                return None, None

            tangent_threshold = math.sin(math.radians(angTolerance))
            best_distance = None
            best_limiter = None

            for limiting_item in limiting_data:
                limiting_normal = limiting_item["normal"]
                limiting_constant = limiting_item["constant"]
                normal_speed = float(np.dot(limiting_normal, direction))

                # The inflation direction lies in the analytical-face plane.
                # Existing or future coplanar contact is sliding contact and must
                # not stop this face.
                if abs(normal_speed) <= tangent_threshold:
                    continue

                signed_distances = [
                    float(np.dot(limiting_normal, point) - limiting_constant)
                    for point in source_positions
                ]

                initial_intersection = _collision(
                    source_face,
                    limiting_item["face"],
                )

                if initial_intersection is not None:
                    interior_signed_distance = float(
                        np.dot(limiting_normal, internal_coordinates)
                        - limiting_constant
                    )

                    # If the outward motion crosses the analytical-face plane away
                    # from the cell interior, the existing contact is blocking. If
                    # it moves back towards the interior side, the face is separating
                    # from the limiter and may continue.
                    if interior_signed_distance * normal_speed < -tolerance:
                        return 0.0, limiting_item
                    continue

                # Skip a limiter when every point of the moving face is already on
                # one side of its plane and the motion increases that separation.
                if all(value > tolerance for value in signed_distances):
                    if normal_speed > 0.0:
                        continue
                elif all(value < -tolerance for value in signed_distances):
                    if normal_speed < 0.0:
                        continue

                swept_intersection = _collision(
                    swept_cell,
                    limiting_item["face"],
                )
                if swept_intersection is None:
                    continue

                try:
                    intersection_vertices = Topology.Vertices(
                        swept_intersection,
                        silent=True,
                    ) or []
                except Exception:
                    intersection_vertices = []

                candidate_distances = []
                for intersection_vertex in intersection_vertices:
                    point = _coordinates(intersection_vertex)
                    if point is None:
                        continue
                    distance = _projection_distance(
                        point,
                        source_origin,
                        direction,
                    )
                    if tolerance < distance <= sweep_distance + tolerance:
                        candidate_distances.append(distance)

                if len(candidate_distances) == 0:
                    continue

                distance = min(candidate_distances)
                if maxDistance is not None and distance > maxDistance + tolerance:
                    continue

                if best_distance is None or distance < best_distance - tolerance:
                    best_distance = distance
                    best_limiter = limiting_item

            return best_distance, best_limiter

        def _copy_dictionary(source, target):
            if not Topology.IsInstance(target, "Topology"):
                return target
            try:
                dictionary = Topology.Dictionary(source, silent=True)
            except TypeError:
                try:
                    dictionary = Topology.Dictionary(source)
                except Exception:
                    dictionary = None
            except Exception:
                dictionary = None

            if dictionary is None:
                return target

            try:
                keys = Dictionary.Keys(dictionary)
            except Exception:
                keys = []

            if not keys:
                return target

            try:
                return Topology.SetDictionary(target, dictionary, silent=True)
            except TypeError:
                try:
                    return Topology.SetDictionary(target, dictionary)
                except Exception:
                    return target
            except Exception:
                return target

        def _solve_vertices(plane_constants):
            """
            Recomputes vertices while preserving unconstrained coordinates.

            Coplanar incident face segments are first reduced to one plane
            constraint. This is essential for IFC cells in which a straight wall
            is split into multiple coplanar faces. Tiny numerical differences in
            their normals must not be interpreted as independent planes.
            """
            positions = []
            residual_tolerance = max(
                tolerance * 10.0,
                10.0 ** (-mantissa),
            )

            # Angular comparison expressed as the magnitude of the cross product
            # of two unit normals. Keep this deliberately much tighter than the
            # user-facing angular tolerance used for sliding collision tests.
            plane_parallel_tolerance = max(
                1.0e-10,
                min(abs(float(tolerance)), 1.0e-6),
            )
            plane_offset_tolerance = residual_tolerance

            def _unique_constraints(incident_indices):
                constraints = []

                for face_index in incident_indices:
                    normal = np.asarray(
                        cell_planes[face_index]["normal"],
                        dtype=float,
                    )
                    constant = float(plane_constants[face_index])

                    duplicate = False
                    for existing in constraints:
                        existing_normal = existing["normal"]
                        existing_constant = existing["constant"]

                        alignment = float(np.dot(normal, existing_normal))
                        aligned_normal = normal
                        aligned_constant = constant

                        if alignment < 0.0:
                            alignment = -alignment
                            aligned_normal = -normal
                            aligned_constant = -constant

                        cross_magnitude = float(
                            np.linalg.norm(
                                np.cross(aligned_normal, existing_normal)
                            )
                        )

                        if (
                            cross_magnitude <= plane_parallel_tolerance
                            and abs(
                                aligned_constant - existing_constant
                            ) <= plane_offset_tolerance
                        ):
                            duplicate = True
                            break

                    if not duplicate:
                        constraints.append(
                            {
                                "normal": normal,
                                "constant": constant,
                            }
                        )

                return constraints

            for vertex_index, incident_indices in enumerate(vertex_faces):
                if len(incident_indices) == 0:
                    _message(
                        "Error",
                        f"Vertex {vertex_index} is not incident to any cell faces. "
                        "Returning None.",
                    )
                    return None

                constraints = _unique_constraints(incident_indices)
                if len(constraints) == 0:
                    _message(
                        "Error",
                        f"Vertex {vertex_index} has no valid independent plane "
                        "constraints. Returning None.",
                    )
                    return None

                matrix = np.asarray(
                    [item["normal"] for item in constraints],
                    dtype=float,
                )
                values = np.asarray(
                    [item["constant"] for item in constraints],
                    dtype=float,
                )
                original_position = np.asarray(
                    original_positions[vertex_index],
                    dtype=float,
                )

                try:
                    singular_values = np.linalg.svd(
                        matrix,
                        compute_uv=False,
                    )
                    maximum_singular_value = (
                        float(np.max(singular_values))
                        if len(singular_values) > 0
                        else 0.0
                    )
                    singular_tolerance = max(
                        np.finfo(float).eps
                        * max(matrix.shape)
                        * maximum_singular_value,
                        plane_parallel_tolerance
                        * maximum_singular_value,
                    )
                    rank = int(
                        np.sum(singular_values > singular_tolerance)
                    )
                except Exception:
                    rank = 0

                if rank < 1:
                    _message(
                        "Error",
                        f"The incident planes at vertex {vertex_index} do not define "
                        "a valid geometric constraint. Returning None.",
                    )
                    return None

                try:
                    difference = values - matrix @ original_position
                    correction = np.linalg.pinv(
                        matrix,
                        rcond=plane_parallel_tolerance,
                    ) @ difference
                    position = original_position + correction
                except Exception:
                    _message(
                        "Error",
                        f"Could not solve the incident planes at vertex "
                        f"{vertex_index}. Returning None.",
                    )
                    return None

                if not np.all(np.isfinite(position)):
                    _message(
                        "Error",
                        f"Could not compute finite coordinates for vertex "
                        f"{vertex_index}. Returning None.",
                    )
                    return None

                residual = float(
                    np.max(np.abs(matrix @ position - values))
                )
                if (
                    not np.isfinite(residual)
                    or residual > residual_tolerance
                ):
                    _message(
                        "Error",
                        f"The translated incident planes at vertex {vertex_index} "
                        "are mutually inconsistent. The requested inflation changes "
                        "the incidence geometry. Returning None.",
                    )
                    return None

                positions.append(position)

            return positions

        def _vertices_by_positions(positions):
            """Create one shared Vertex pool for a solved position set."""
            if not isinstance(positions, (list, tuple)):
                return None

            result = []
            for position in positions:
                try:
                    coordinates = np.asarray(position, dtype=float).reshape(3)
                except Exception:
                    return None

                if not np.all(np.isfinite(coordinates)):
                    return None

                try:
                    vertex = Vertex.ByCoordinates(
                        round(float(coordinates[0]), mantissa),
                        round(float(coordinates[1]), mantissa),
                        round(float(coordinates[2]), mantissa),
                    )
                except Exception:
                    vertex = None

                if not Topology.IsInstance(vertex, "Vertex"):
                    return None
                result.append(vertex)

            return result

        def _wire_by_indices(indices, vertex_pool):
            """Build a closed polygonal Wire from the shared Vertex pool."""
            if (
                not isinstance(indices, list)
                or len(indices) < 3
                or not isinstance(vertex_pool, list)
            ):
                return None

            try:
                vertices = [vertex_pool[index] for index in indices]
            except Exception:
                return None

            if not all(
                Topology.IsInstance(vertex, "Vertex")
                for vertex in vertices
            ):
                return None

            try:
                wire = Wire.ByVertices(
                    vertices,
                    close=True,
                    tolerance=tolerance,
                    silent=True,
                )
            except Exception:
                wire = None

            if not Topology.IsInstance(wire, "Wire"):
                return None

            try:
                closed = Wire.IsClosed(
                    wire,
                    tolerance=tolerance,
                    silent=True,
                )
            except Exception:
                closed = False

            return wire if closed else None

        def _current_face(face_index, vertex_pool):
            boundary = face_boundaries[face_index]
            external_wire = _wire_by_indices(
                boundary["external"],
                vertex_pool,
            )
            if not Topology.IsInstance(external_wire, "Wire"):
                return None

            internal_wires = []
            for indices in boundary["internal"]:
                wire = _wire_by_indices(indices, vertex_pool)
                if not Topology.IsInstance(wire, "Wire"):
                    return None
                internal_wires.append(wire)

            try:
                rebuilt_face = Face.ByWires(
                    external_wire,
                    internal_wires,
                    tolerance=tolerance,
                    silent=True,
                )
            except TypeError:
                try:
                    rebuilt_face = Face.ByWires(
                        external_wire,
                        internal_wires,
                        tolerance=tolerance,
                    )
                except Exception:
                    rebuilt_face = None
            except Exception:
                rebuilt_face = None

            if not Topology.IsInstance(rebuilt_face, "Face"):
                return None

            return _copy_dictionary(
                cell_faces[face_index],
                rebuilt_face,
            )

        def _faces_by_positions(positions):
            vertex_pool = _vertices_by_positions(positions)
            if (
                not isinstance(vertex_pool, list)
                or len(vertex_pool) != len(cell_vertices)
            ):
                return None, None

            rebuilt_faces = []
            for face_index in range(len(cell_faces)):
                rebuilt_face = _current_face(face_index, vertex_pool)
                if not Topology.IsInstance(rebuilt_face, "Face"):
                    _message(
                        "Warning",
                        f"Could not rebuild cell face {face_index} from its ordered "
                        "boundary loops.",
                    )
                    return None, None
                rebuilt_faces.append(rebuilt_face)

            return rebuilt_faces, vertex_pool

        def _topology_by_positions(positions):
            rebuilt_faces, _ = _faces_by_positions(positions)
            if not isinstance(rebuilt_faces, list):
                return None

            # Prefer native backend sewing and solid construction. On the
            # PythonOCC backend Cell.ByFaces delegates this work to OCCT.
            try:
                topology = Cell.ByFaces(
                    rebuilt_faces,
                    planarize=False,
                    transferDictionaries=False,
                    tolerance=tolerance,
                    silent=True,
                )
            except TypeError:
                try:
                    topology = Cell.ByFaces(
                        rebuilt_faces,
                        tolerance=tolerance,
                        silent=True,
                    )
                except Exception:
                    topology = None
            except Exception:
                topology = None

            if Topology.IsInstance(topology, "Cell"):
                return topology

            try:
                topology = Cluster.ByTopologies(rebuilt_faces, silent=True)
            except TypeError:
                try:
                    topology = Cluster.ByTopologies(rebuilt_faces)
                except Exception:
                    topology = None
            except Exception:
                topology = None

            if not Topology.IsInstance(topology, "Topology"):
                return None

            try:
                check_faces = Topology.Faces(topology, silent=True) or []
            except Exception:
                check_faces = []

            if len(check_faces) != len(cell_faces):
                _message(
                    "Warning",
                    f"The rebuilt topology contains {len(check_faces)} faces instead "
                    f"of the expected {len(cell_faces)} faces.",
                )
                return None

            return topology

        # ------------------------------------------------------------------
        # Validate inputs.
        # ------------------------------------------------------------------
        if not Topology.IsInstance(cell, "Cell"):
            _message(
                "Error",
                "The input cell parameter is not a valid cell. Returning None.",
            )
            return None

        if not isinstance(faces, (list, tuple)):
            _message(
                "Error",
                "The input faces parameter is not a valid list. Returning None.",
            )
            return None

        limiting_faces = [
            face for face in faces
            if Topology.IsInstance(face, "Face")
        ]
        if len(limiting_faces) == 0:
            _message(
                "Error",
                "The input faces parameter contains no valid faces. Returning None.",
            )
            return None

        try:
            tolerance = abs(float(tolerance))
        except Exception:
            tolerance = 0.0001
        if tolerance <= 0:
            tolerance = 0.0001

        try:
            angTolerance = abs(float(angTolerance))
        except Exception:
            angTolerance = 1.0
        if angTolerance > 90.0:
            angTolerance = 90.0

        if maxDistance is not None:
            try:
                maxDistance = abs(float(maxDistance))
            except Exception:
                _message(
                    "Error",
                    "The input maxDistance parameter is not a valid number. "
                    "Returning None.",
                )
                return None
            if maxDistance <= tolerance:
                _message(
                    "Error",
                    "The input maxDistance parameter must be greater than the "
                    "input tolerance. Returning None.",
                )
                return None


        # ------------------------------------------------------------------
        # Extract the original cell topology and determine outward face planes.
        # ------------------------------------------------------------------
        cell_faces = Cell.Faces(cell) or []
        cell_vertices = Topology.Vertices(cell, silent=True) or []

        if len(cell_faces) < 4 or len(cell_vertices) < 4:
            _message(
                "Error",
                "The input cell does not contain enough faces or vertices. "
                "Returning None.",
            )
            return None

        try:
            internal_vertex = Cell.InternalVertex(
                cell,
                tolerance=tolerance,
                silent=True,
            )
        except Exception:
            internal_vertex = None

        if not Topology.IsInstance(internal_vertex, "Vertex"):
            _message(
                "Error",
                "Could not compute an internal vertex for the input cell. "
                "Returning None.",
            )
            return None

        internal_coordinates = _coordinates(internal_vertex)
        if internal_coordinates is None:
            _message(
                "Error",
                "Could not retrieve the coordinates of the cell's internal "
                "vertex. Returning None.",
            )
            return None

        original_positions = []
        for vertex in cell_vertices:
            position = _coordinates(vertex)
            if position is None:
                _message(
                    "Error",
                    "Could not retrieve the coordinates of a cell vertex. "
                    "Returning None.",
                )
                return None
            original_positions.append(position)

        cell_planes = []
        face_boundaries = []
        vertex_faces = [[] for _ in cell_vertices]

        for face_index, cell_face in enumerate(cell_faces):
            try:
                normal = Face.Normal(
                    cell_face,
                    outputType="xyz",
                    mantissa=max(mantissa, 8),
                )
            except Exception:
                normal = None

            normal = _unit(normal)
            if normal is None:
                _message(
                    "Error",
                    f"Could not compute a valid normal for cell face "
                    f"{face_index}. Returning None.",
                )
                return None

            face_centroid = Topology.Centroid(cell_face, silent=True)
            face_point = _coordinates(face_centroid)
            if face_point is None:
                _message(
                    "Error",
                    f"Could not compute the centroid of cell face "
                    f"{face_index}. Returning None.",
                )
                return None

            # Orient the normal away from the cell interior.
            if float(np.dot(normal, internal_coordinates - face_point)) > 0.0:
                normal = -normal

            constant = float(np.dot(normal, face_point))

            external_boundary = Face.ExternalBoundary(
                cell_face,
                tolerance=tolerance,
                silent=True,
            )
            internal_boundaries = Face.InternalBoundaries(cell_face) or []

            if not Topology.IsInstance(external_boundary, "Wire"):
                _message(
                    "Error",
                    f"Could not extract the external boundary of cell face "
                    f"{face_index}. Returning None.",
                )
                return None

            boundary_wires = [external_boundary] + internal_boundaries
            boundary_indices = []
            current_indices = []

            def ordered_wire_indices(boundary_wire):
                """Returns a closed wire's vertices in edge-connected order."""
                try:
                    wire_edges = Topology.Edges(
                        boundary_wire,
                        silent=True,
                    ) or []
                except Exception:
                    wire_edges = []

                if len(wire_edges) < 3:
                    return None

                edge_pairs = []
                adjacency = {}

                for edge_index, wire_edge in enumerate(wire_edges):
                    try:
                        start_vertex = Edge.StartVertex(
                            wire_edge,
                            silent=True,
                        )
                    except TypeError:
                        start_vertex = Edge.StartVertex(wire_edge)
                    except Exception:
                        start_vertex = None

                    try:
                        end_vertex = Edge.EndVertex(
                            wire_edge,
                            silent=True,
                        )
                    except TypeError:
                        end_vertex = Edge.EndVertex(wire_edge)
                    except Exception:
                        end_vertex = None

                    if (
                        not Topology.IsInstance(start_vertex, "Vertex")
                        or not Topology.IsInstance(end_vertex, "Vertex")
                    ):
                        return None

                    try:
                        start_index = Vertex.Index(
                            start_vertex,
                            cell_vertices,
                            tolerance=tolerance,
                        )
                        end_index = Vertex.Index(
                            end_vertex,
                            cell_vertices,
                            tolerance=tolerance,
                        )
                    except Exception:
                        return None

                    if (
                        start_index is None
                        or end_index is None
                        or start_index == end_index
                    ):
                        return None

                    edge_pairs.append((start_index, end_index))
                    adjacency.setdefault(start_index, []).append(
                        (edge_index, end_index)
                    )
                    adjacency.setdefault(end_index, []).append(
                        (edge_index, start_index)
                    )

                # A simple closed boundary wire must have degree two at every
                # vertex. This permits collinear subdivision vertices while
                # rejecting branched or disconnected edge sets.
                if any(len(records) != 2 for records in adjacency.values()):
                    return None

                start_index, current_index = edge_pairs[0]
                ordered = [start_index, current_index]
                used_edges = {0}

                while len(used_edges) < len(edge_pairs):
                    candidates = [
                        (edge_index, next_index)
                        for edge_index, next_index in adjacency[current_index]
                        if edge_index not in used_edges
                    ]

                    if len(candidates) != 1:
                        return None

                    edge_index, next_index = candidates[0]
                    used_edges.add(edge_index)

                    if next_index == start_index:
                        if len(used_edges) != len(edge_pairs):
                            return None
                        break

                    if next_index in ordered:
                        return None

                    ordered.append(next_index)
                    current_index = next_index

                if len(used_edges) != len(edge_pairs) or len(ordered) < 3:
                    return None

                return ordered

            for boundary_wire in boundary_wires:
                loop_indices = ordered_wire_indices(boundary_wire)
                if not isinstance(loop_indices, list) or len(loop_indices) < 3:
                    _message(
                        "Error",
                        f"Could not traverse a boundary loop of cell face "
                        f"{face_index} in edge-connected order. Returning None.",
                    )
                    return None

                boundary_indices.append(loop_indices)

                for vertex_index in loop_indices:
                    if vertex_index not in current_indices:
                        current_indices.append(vertex_index)
                        vertex_faces[vertex_index].append(face_index)

            if len(current_indices) < 3:
                _message(
                    "Error",
                    f"Cell face {face_index} has fewer than three distinct "
                    "vertices. Returning None.",
                )
                return None

            cell_planes.append({
                "normal": normal,
                "constant": constant,
            })
            face_boundaries.append({
                "external": boundary_indices[0],
                "internal": boundary_indices[1:],
            })

        # Verify that the cached incidence data can reproduce every original
        # face before attempting any inflation. This separates input-boundary
        # traversal failures from failures caused by translated geometry.
        original_vertex_pool = _vertices_by_positions(original_positions)
        if not isinstance(original_vertex_pool, list):
            _message(
                "Error",
                "Could not create the original shared vertex pool. Returning None.",
            )
            return None

        for face_index in range(len(cell_faces)):
            test_face = _current_face(face_index, original_vertex_pool)
            if not Topology.IsInstance(test_face, "Face"):
                _message(
                    "Error",
                    f"Could not reconstruct original cell face {face_index} "
                    "from its edge-connected boundary loop. Returning None.",
                )
                return None

        # ------------------------------------------------------------------
        # Cache limiting-face geometry. No parallelism is required.
        # ------------------------------------------------------------------
        limiting_data = []
        for limiting_index, limiting_face in enumerate(limiting_faces):
            try:
                limiting_vertices = Topology.Vertices(
                    limiting_face,
                    silent=True,
                ) or []
            except Exception:
                limiting_vertices = []

            positions = []
            for limiting_vertex in limiting_vertices:
                position = _coordinates(limiting_vertex)
                if position is not None:
                    positions.append(position)

            if len(positions) == 0:
                centroid = Topology.Centroid(
                    limiting_face,
                    silent=True,
                )
                position = _coordinates(centroid)
                if position is not None:
                    positions.append(position)

            if len(positions) == 0:
                continue

            try:
                limiting_normal = Face.Normal(
                    limiting_face,
                    outputType="xyz",
                    mantissa=max(mantissa, 8),
                )
            except Exception:
                limiting_normal = None
            limiting_normal = _unit(limiting_normal)
            if limiting_normal is None:
                continue

            limiting_centroid = Topology.Centroid(
                limiting_face,
                silent=True,
            )
            limiting_point = _coordinates(limiting_centroid)
            if limiting_point is None:
                continue

            limiting_data.append({
                "index": limiting_index,
                "face": limiting_face,
                "positions": positions,
                "normal": limiting_normal,
                "constant": float(np.dot(limiting_normal, limiting_point)),
            })

        if len(limiting_data) == 0:
            _message(
                "Error",
                "Could not extract valid geometry from the limiting faces. "
                "Returning None.",
            )
            return None

        plane_constants = [
            plane["constant"] for plane in cell_planes
        ]
        current_positions = list(original_positions)
        working_topology = cell
        matched_faces = 0

        # ------------------------------------------------------------------
        # Move one supporting plane at a time. After each successful movement,
        # recompute all vertices and rebuild every face from its ordered boundary
        # loops before processing the next face.
        # ------------------------------------------------------------------
        for face_index, plane in enumerate(cell_planes):
            normal = plane["normal"]
            current_constant = plane_constants[face_index]

            current_vertex_pool = _vertices_by_positions(current_positions)
            if not isinstance(current_vertex_pool, list):
                _message(
                    "Warning",
                    f"Could not create the current shared vertex pool for "
                    f"cell face {face_index}. Skipping this face.",
                )
                continue

            source_face = _current_face(face_index, current_vertex_pool)
            if not Topology.IsInstance(source_face, "Face"):
                _message(
                    "Warning",
                    f"Could not rebuild the current polygon of cell face "
                    f"{face_index}. Skipping this face.",
                )
                continue

            best_distance, best_limiter = _collision_distance(
                source_face,
                normal,
            )

            if best_distance is None:
                continue
            if best_distance <= tolerance:
                if not silent:
                    _message(
                        "Information",
                        f"Cell face {face_index} already collides with limiting "
                        f"face {best_limiter['index']} and was not moved.",
                    )
                continue

            previous_constant = plane_constants[face_index]
            plane_constants[face_index] = (
                previous_constant + best_distance
            )

            solved_positions = _solve_vertices(plane_constants)
            if solved_positions is None:
                plane_constants[face_index] = previous_constant
                _message(
                    "Warning",
                    f"Could not move cell face {face_index} without changing "
                    "the cell topology. This face was left in place.",
                )
                continue

            candidate_topology = _topology_by_positions(
                solved_positions,
            )

            if not Topology.IsInstance(candidate_topology, "Topology"):
                plane_constants[face_index] = previous_constant
                _message(
                    "Warning",
                    f"Could not rebuild all cell faces after moving cell face "
                    f"{face_index}. This face was left in place.",
                )
                continue

            current_positions = solved_positions
            working_topology = candidate_topology
            matched_faces += 1

            if not silent:
                _message(
                    "Information",
                    f"Moved cell face {face_index} by "
                    f"{round(best_distance, mantissa)} to limiting face "
                    f"{best_limiter['index']}.",
                )

        if matched_faces == 0:
            _message(
                "Warning",
                "No cell faces reached a valid limiting face. Returning the "
                "input cell.",
            )
            return cell

        # Attempt to self-merge only once, after all supporting planes have moved.
        # Keep the unmerged topology when the result is not a Cell.
        result_topology = working_topology
        try:
            merged_topology = Topology.SelfMerge(
                working_topology,
                transferDictionaries=False,
                tolerance=tolerance,
                silent=True,
            )
        except TypeError:
            try:
                merged_topology = Topology.SelfMerge(
                    working_topology,
                    tolerance=tolerance,
                )
            except Exception:
                merged_topology = None
        except Exception:
            merged_topology = None

        if Topology.IsInstance(merged_topology, "Cell"):
            result_topology = merged_topology
            _message(
                "Information",
                "The final inflated topology was self-merged into a Cell.",
            )
        elif not silent:
            _message(
                "Information",
                "The final inflated topology could not be self-merged into a "
                "Cell. Returning the rebuilt topology as-is.",
            )

        # Preserve the input cell dictionary.
        result_topology = _copy_dictionary(cell, result_topology)

        # Preserve face dictionaries when the rebuilt topology retains the same
        # face count and correspondence.
        try:
            result_faces = Topology.Faces(
                result_topology,
                silent=True,
            ) or []
        except Exception:
            result_faces = []

        if len(result_faces) == len(cell_faces):
            for source_face, result_face in zip(cell_faces, result_faces):
                _copy_dictionary(source_face, result_face)

        _message(
            "Information",
            f"Inflated {matched_faces} of {len(cell_faces)} cell faces.",
        )
        return result_topology

    @staticmethod
    def InternalBoundaries(cell) -> list:
        """
        Returns the internal boundaries of the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.

        Returns
        -------
        list
            The list of internal boundaries ([topologic_core.Shell]).

        """
        shells = []
        # _ = cell.InternalBoundaries(shells) # H to Core
        try:
            Core.InstanceCall(cell, "InternalBoundaries", shells)
        except Exception:
            shells = []
        return shells
    
    @staticmethod
    def InternalVertex(cell, tolerance: float = 0.0001, silent: bool = False):
        """
        Creates a vertex that is guaranteed to be inside the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Vertex
            The internal vertex.

        """
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(cell, "Cell"):
            if not silent:
                print("Cell.InternalVertex - Error: The input cell parameter is not a valid topologic cell. Returning None.")
            return None
        try:
            return Core.CellUtility.InternalVertex(cell, tolerance)
        except:
            if not silent:
                print("Cell.InternalVertex - Error: Could not create an internal vertex. Returning None.")
            return None
    
    @staticmethod
    def IShape(origin=None,
            width: float = 1,
            length: float = 1,
            height: float = 1,
            wSides: int = 1,
            a: float = 0.25,
            b: float = 0.25,
            c: float = 0.25,
            flipHorizontal: bool = False,
            flipVertical: bool = False,
            direction: list = [0,0,1],
            placement: str = "center",
            mantissa: int = 6,
            tolerance: float = 0.0001,
            silent: bool = False):
        """
        Creates an I-shape cell.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The location of the origin of the I-shape. Default is None which results in the I-shape being placed at (0, 0, 0).
        width : float , optional
            The overall width of the I-shape. Default is 1.0.
        length : float , optional
            The overall length of the I-shape. Default is 1.0.
        height : float , optional
            The overall height of the I-shape. Default is 1.0.
        wSides : int , optional
            The desired number of sides along the Z-Axis. Default is 1.
        a : float , optional
            The hortizontal thickness of the central vertical arm of the I-shape. Default is 0.25.
        b : float , optional
            The vertical thickness of the bottom horizontal arm of the I-shape. Default is 0.25.
        c : float , optional
            The vertical thickness of the top horizontal arm of the I-shape. Default is 0.25.
        flipHorizontal : bool , optional
            if set to True, the shape is flipped horizontally. Default is False.
        flipVertical : bool , optional
            if set to True, the shape is flipped vertically. Default is False.
        direction : list , optional
            The vector representing the up direction of the I-shape. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the I-shape. This can be "center", "bottom", "top", "lowerleft", "upperleft", "lowerright", "upperright". It is case insensitive. Default is "center".
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created I-shape cell.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.Topology import Topology

        if not isinstance(width, int) and not isinstance(width, float):
            if not silent:
                print("Cell.IShape - Error: The width input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(length, int) and not isinstance(length, float):
            if not silent:
                print("Cell.IShape - Error: The length input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(a, int) and not isinstance(a, float):
            if not silent:
                print("Cell.IShape - Error: The a input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(b, int) and not isinstance(b, float):
            if not silent:
                print("Cell.IShape - Error: The b input parameter is not a valid number. Returning None.")
            return None
        if width <= tolerance:
            if not silent:
                print("Cell.IShape - Error: The width input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if length <= tolerance:
            if not silent:
                print("Cell.IShape - Error: The length input parameter must be a positive number  greater than the tolerance input parameter. Returning None.")
            return None
        if a <= tolerance:
            if not silent:
                print("Cell.IShape - Error: The a input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if b <= tolerance:
            if not silent:
                print("Cell.IShape - Error: The b input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if a >= (width - tolerance):
            if not silent:
                print("Cell.IShape - Error: The a input parameter must be less than the width input parameter. Returning None.")
            return None
        if b+c >= (length - tolerance):
            if not silent:
                print("Cell.IShape - Error: The b and c input parameters must add to less than the length input parameter. Returning None.")
            return None
        if origin == None:
            origin = Vertex.Origin()
        if not Topology.IsInstance(origin, "vertex"):
            if not silent:
                print("Cell.IShape - Error: The origin input parameter is not a valid topologic vertex. Returning None.")
            return None
        if not isinstance(direction, list):
            if not silent:
                print("Cell.IShape - Error: The direction input parameter is not a valid list. Returning None.")
            return None
        if not len(direction) == 3:
            if not silent:
                print("Cell.IShape - Error: The direction input parameter is not a valid vector. Returning None.")
            return None
        i_shape_wire = Wire.IShape(origin=origin,
                                   width=width,
                                   length=length,
                                   a=a,
                                   b=b,
                                   c=c,
                                   flipHorizontal=flipHorizontal,
                                   flipVertical=flipVertical,
                                   direction=[0,0,1],
                                   placement="center",
                                   tolerance=tolerance,
                                   silent=silent)
        distance = height/wSides
        wires = [i_shape_wire]
        for i in range(wSides):
            i_shape_wire = Topology.Translate(i_shape_wire, 0, 0, distance)
            wires.append(i_shape_wire)
        return_cell = Cell.ByWires(wires, triangulate=False, mantissa=mantissa, tolerance=tolerance, silent=silent)
        # move down to center
        return_cell = Topology.Translate(return_cell, 0, 0, -height*0.5)
        xOffset = 0
        yOffset = 0
        zOffset = 0
        
        if placement.lower() == "bottom":
            zOffset = height*0.5
        elif placement.lower() == "top":
            zOffset = -height*0.5
        elif placement.lower() == "lowerleft":
            xOffset = width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperleft":
            xOffset = width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        elif placement.lower() == "lowerright":
            xOffset = -width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperright":
            xOffset = -width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        return_cell = Topology.OrientAndPlace(return_cell,
                                              originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                              originB=origin,
                                              dirA=[0, 0, 1],
                                              dirB=direction,
                                              transferDictionaries = False,
                                              tolerance = tolerance,
                                              silent = silent)
        return return_cell
        
    @staticmethod
    def IsOnBoundary(cell, vertex, tolerance: float = 0.0001) -> bool:
        """
        Returns True if the input vertex is on the boundary of the input cell. Returns False otherwise.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.
        vertex : topologic_core.Vertex
            The input vertex.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.

        Returns
        -------
        bool
            Returns True if the input vertex is inside the input cell. Returns False otherwise.

        """
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(cell, "Cell"):
            print("Cell.IsOnBoundary - Error: The input cell parameter is not a valid topologic cell. Returning None.")
            return None
        if not Topology.IsInstance(vertex, "Vertex"):
            print("Cell.IsOnBoundary - Error: The input vertex parameter is not a valid topologic vertex. Returning None.")
            return None
        try:
            return (Cell.ContainmentStatus(cell, vertex, tolerance = tolerance) == 1)
        except:
            print("Cell.IsOnBoundary - Error: Could not determine if the input vertex is on the boundary of the input cell. Returning None.")
            return None
    
    @staticmethod
    def LShape(origin=None,
            width=1,
            length=1,
            height=1,
            wSides=1,
            a=0.25,
            b=0.25,
            flipHorizontal = False,
            flipVertical = False,
            direction=[0,0,1],
            placement="center",
            mantissa=6,
            tolerance=0.0001,
            silent=False):
        """
        Creates an L-shape.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The location of the origin of the L-shape. Default is None which results in the L-shape being placed at (0, 0, 0).
        width : float , optional
            The overall width of the L-shape. Default is 1.0.
        length : float , optional
            The overall length of the L-shape. Default is 1.0.
        height : float , optional
            The overall height of the L-shape. Default is 1.0.
        wSides : int , optional
            The desired number of sides along the Z-axis. Default is 1.
        a : float , optional
            The hortizontal thickness of the vertical arm of the L-shape. Default is 0.25.
        b : float , optional
            The vertical thickness of the horizontal arm of the L-shape. Default is 0.25.
        flipHorizontal : bool , optional
            if set to True, the shape is flipped horizontally. Default is False.
        flipVertical : bool , optional
            if set to True, the shape is flipped vertically. Default is False.
        direction : list , optional
            The vector representing the up direction of the L-shape. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the L-shape. This can be "center", "bottom", "top", "lowerleft", "upperleft", "lowerright", "upperright". It is case insensitive. Default is "center".
        manitssa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created L-shape cell.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.Topology import Topology

        if not isinstance(width, int) and not isinstance(width, float):
            if not silent:
                print("Cell.LShape - Error: The width input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(length, int) and not isinstance(length, float):
            if not silent:
                print("Cell.LShape - Error: The length input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(height, int) and not isinstance(height, float):
            if not silent:
                print("Cell.LShape - Error: The height input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(a, int) and not isinstance(a, float):
            if not silent:
                print("Cell.LShape - Error: The a input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(b, int) and not isinstance(b, float):
            if not silent:
                print("Cell.LShape - Error: The b input parameter is not a valid number. Returning None.")
            return None
        if width <= tolerance:
            if not silent:
                print("Cell.LShape - Error: The width input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if length <= tolerance:
            if not silent:
                print("Cell.LShape - Error: The length input parameter must be a positive number  greater than the tolerance input parameter. Returning None.")
            return None
        if height <= tolerance:
            if not silent:
                print("Cell.LShape - Error: The height input parameter must be a positive number  greater than the tolerance input parameter. Returning None.")
            return None
        if a <= tolerance:
            if not silent:
                print("Cell.LShape - Error: The a input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if b <= tolerance:
            if not silent:
                print("Cell.LShape - Error: The b input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if a >= (width - tolerance):
            if not silent:
                print("Cell.LShape - Error: The a input parameter must be less than the width input parameter. Returning None.")
            return None
        if b >= (length - tolerance):
            if not silent:
                print("Cell.LShape - Error: The b input parameter must be less than the length input parameter. Returning None.")
            return None
        if origin == None:
            origin = Vertex.Origin()
        if not Topology.IsInstance(origin, "vertex"):
            if not silent:
                print("Cell.LShape - Error: The origin input parameter is not a valid topologic vertex. Returning None.")
            return None
        if not isinstance(direction, list):
            if not silent:
                print("Cell.LShape - Error: The direction input parameter is not a valid list. Returning None.")
            return None
        if not len(direction) == 3:
            if not silent:
                print("Cell.LShape - Error: The direction input parameter is not a valid vector. Returning None.")
            return None
        l_shape_wire = Wire.LShape(origin=origin,
                                   width=width,
                                   length=length,
                                   a=a,
                                   b=b,
                                   flipHorizontal=flipHorizontal,
                                   flipVertical=flipVertical,
                                   direction=[0,0,1],
                                   placement="center",
                                   tolerance=tolerance,
                                   silent=silent)
        distance = height/wSides
        wires = [l_shape_wire]
        for i in range(wSides):
            l_shape_wire = Topology.Translate(l_shape_wire, 0, 0, distance)
            wires.append(l_shape_wire)
        return_cell = Cell.ByWires(wires, triangulate=False, mantissa=mantissa, tolerance=tolerance, silent=silent)
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "center":
            zOffset = -height*0.5
        elif placement.lower() == "bottom":
            zOffset = 0
        elif placement.lower() == "top":
            zOffset = -height
        elif placement.lower() == "lowerleft":
            xOffset = width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperleft":
            xOffset = width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        elif placement.lower() == "lowerright":
            xOffset = -width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperright":
            xOffset = -width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        return_cell = Topology.OrientAndPlace(return_cell,
                                           originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                           originB=origin,
                                           dirA=[0, 0, 1],
                                           dirB=direction,
                                           transferDictionaries = False,
                                           tolerance = tolerance,
                                           silent = silent)
        return return_cell
    
    @staticmethod
    def Noperthedron(origin= None, radius: float = 0.5, direction: list = [0, 0, 1],
                   placement: str = "center", tolerance: float = 0.0001, silent: bool = False):
        """
        Creates a Noperthedron. A noperthedron is a convex polyhedron without Rupert's property. See: https://arxiv.org/pdf/2508.18475

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the sphere. Default is None which results in the sphere being placed at (0, 0, 0).
        radius : float , optional
            The radius of the sphere. Default is 0.5.
        uSides : int , optional
            The number of sides along the longitude of the sphere. Default is 16.
        vSides : int , optional
            The number of sides along the latitude of the sphere. Default is 8.
        direction : list , optional
            The vector representing the up direction of the sphere. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the sphere. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool, optional
            If set to True, suppresses warning and error messages. Default is False.
        

        Returns
        -------
        topologic_core.Cell
            The created Noperthedron polyhedron.

        """

        from topologicpy.Vertex import Vertex
        from topologicpy.Cluster import Cluster
        from topologicpy.Topology import Topology
        from topologicpy.Dictionary import Dictionary
        from topologicpy.Helper import Helper
        from math import cos, sin, pi

        # Validate inputs
        if radius <= 0:
            if not silent:
                print("Cell.Polyhedron - Error: radius must be > 0. Returning None.")
            return None

        # Center
        if origin is None:
            origin = Vertex.ByCoordinates(0, 0, 0)
        
        if not Topology.IsInstance(origin, "vertex"):
            if not silent:
                print("Cell.Noperthedron - Error: The input origin parameter is not a valid vertex. Returning None.")
            return None
        

    # defaults:
        scale = 1.0
        rotateZ_radians = 0.0
        dedup_dp = 14

        # Correct seeds per paper:
        C1 = (152024884/259375205, 0.0, 210152163/259375205)
        DEN = 10_000_000_000  # 10^10
        C2 = (6632738028/DEN, 6106948881/DEN, 3980949609/DEN)
        C3 = (8193990033/DEN, 5298215096/DEN, 1230614493/DEN)
        seeds = [C1, C2, C3]

        def rotz(p, a):
            x, y, z = p
            ca, sa = cos(a), sin(a)
            return (ca*x - sa*y, sa*x + ca*y, z)

        # Generate 30-element orbit for each seed: (-I)^ℓ · Rz(2πk/15)
        pts = []
        for (x, y, z) in seeds:
            x, y, z = rotz((x, y, z), rotateZ_radians)
            for k in range(15):
                th = 2*pi*k/15
                X, Y, Z = rotz((x, y, z), th)
                pts.append(( X,  Y,  Z))
                pts.append((-X, -Y, -Z))

        # Deduplicate robustly (should keep all 90)
        seen, verts = set(), []
        for p in pts:
            key = (round(p[0], dedup_dp), round(p[1], dedup_dp), round(p[2], dedup_dp))
            if key in seen: 
                continue
            seen.add(key)
            verts.append(Vertex.ByCoordinates(p[0]*scale, p[1]*scale, p[2]*scale))

        hull = Topology.ConvexHull(Cluster.ByTopologies(verts))
        if not Topology.IsInstance(hull, "cell"):
            if not silent:
                print("Cell.Noperthedron - Error: could not create the cell. Returning None.")
            return None

        # Cleanup top and bottom
        cell_dict = Cell.Decompose(hull)
        h_faces = Helper.Flatten([cell_dict['topHorizontalFaces'] + cell_dict['bottomHorizontalFaces']])
        other_faces = [cell_dict['verticalFaces']+ cell_dict['inclinedFaces']]
        caps_cluster = Topology.SelfMerge(Cluster.ByTopologies(h_faces))
        caps_cluster = Topology.RemoveCoplanarFaces(caps_cluster)
        all_faces = other_faces + Topology.Faces(caps_cluster)
        all_faces = Helper.Flatten(all_faces)
        
        # Sew faces into a cell
        try:
            tol = tolerance
            for i in range(3):
                hull = Cell.ByFaces(all_faces, tolerance=tol)
                if Topology.IsInstance(hull, "Cell"):
                    break
                tol = tol*10
            hull = Topology.Scale(hull, origin=Topology.Centroid(hull), x=1/1.949062, y=1/1.949062, z=1/1.949062)
            # Scale by the radius amount:
            hull = Topology.Scale(hull, origin=Topology.Centroid(hull), x=radius*2, y=radius*2, z=radius*2)
        except Exception:
            if not silent:
                print("Cell.Noperthedron - Error: could not create the cell. Returning None.")
            return None
        if placement.lower() != "center":
            bb = Topology.BoundingBox(hull)
            d = Topology.Dictionary(bb)
            width = Dictionary.ValueAtKey(d, "width")
            length = Dictionary.ValueAtKey(d, "length")
            height = Dictionary.ValueAtKey(d, "height")
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "bottom":
            zOffset = height*0.5
        elif placement.lower() == "lowerleft":
            xOffset = width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        hull = Topology.OrientAndPlace(hull,
                                       originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                       originB=origin,
                                       dirA=[0, 0, 1],
                                       dirB=direction,
                                       transferDictionaries = True,
                                       tolerance = tolerance,
                                       silent = silent)
        return hull

    @staticmethod
    def Octahedron(origin= None,
                   radius: float = 0.5,
                  direction: list = [0, 0, 1],
                  placement: str ="center",
                  tolerance: float = 0.0001,
                  silent: bool = False):
        """
        Creates an octahedron. See https://en.wikipedia.org/wiki/Octahedron.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the octahedron. Default is None which results in the octahedron being placed at (0, 0, 0).
        radius : float , optional
            The radius of the octahedron's circumscribed sphere. Default is 0.5.
        direction : list , optional
            The vector representing the up direction of the octahedron. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the octahedron. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool, optional
            If set to True, suppresses warning and error messages. Default is False.
        
        Returns
        -------
        topologic_core.Cell
            The created octahedron.

        """
        
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)
        if not Topology.IsInstance(origin, "Vertex"):
            print("Cell.Octahedron - Error: The input origin parameter is not a valid topologic vertex. Returning None.")
            return None
        
        vb1 = Vertex.ByCoordinates(-0.5, 0, 0)
        vb2 = Vertex.ByCoordinates(0, -0.5, 0)
        vb3 = Vertex.ByCoordinates(0.5, 0, 0)
        vb4 = Vertex.ByCoordinates(0, 0.5, 0)
        top = Vertex.ByCoordinates(0, 0, 0.5)
        bottom = Vertex.ByCoordinates(0, 0, -0.5)
        f1 = Face.ByVertices([top, vb1, vb2])
        f2 = Face.ByVertices([top, vb2, vb3])
        f3 = Face.ByVertices([top, vb3, vb4])
        f4 = Face.ByVertices([top, vb4, vb1])
        f5 = Face.ByVertices([bottom, vb1, vb2])
        f6 = Face.ByVertices([bottom, vb2, vb3])
        f7 = Face.ByVertices([bottom, vb3, vb4])
        f8 = Face.ByVertices([bottom, vb4, vb1])

        octahedron = Cell.ByFaces([f1, f2, f3, f4, f5, f6, f7, f8], tolerance=tolerance, silent=silent)
        if not Topology.IsInstance(octahedron, "cell"):
            if not silent:
                print("Cell.Octahedron - Error: Could not create the cell. Returning None.")
            return None
        octahedron = Topology.Scale(octahedron, origin=Vertex.Origin(), x=radius/0.5, y=radius/0.5, z=radius/0.5)
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement == "bottom":
            zOffset = radius
        elif placement == "lowerleft":
            xOffset = yOffset = zOffset = radius
        octahedron = Topology.OrientAndPlace(octahedron,
                                             originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                             dirA=[0, 0, 1],
                                             dirB=direction,
                                             transferDictionaries = False,
                                             tolerance = tolerance,
                                             silent = silent)
        return octahedron
    
    @staticmethod
    def Paraboloid(origin= None, focalLength=0.125, width: float = 1, length: float = 1, height: float = 0, uSides: int = 16, vSides: int = 16,
                        direction: list = [0, 0, 1], placement: str ="center", mantissa: int = 6, tolerance: float = 0.0001, silent=False):
        """
        Creates a paraboloid cell. See https://en.wikipedia.org/wiki/Paraboloid

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the parabolic surface. Default is None which results in the parabolic surface being placed at (0, 0, 0).
        focalLength : float , optional
            The focal length of the parabola. Default is 0.125.
        width : float , optional
            The width of the parabolic surface. Default is 1.
        length : float , optional
            The length of the parabolic surface. Default is 1.
        height : float , optional
            The additional height of the parabolic surface. Please note this is not the height from the spring point to the apex. It is in addition to that to form a base. Default is 0.
        uSides : int , optional
            The number of sides along the width. Default is 16.
        vSides : int , optional
            The number of sides along the length. Default is 16.
        direction : list , optional
            The vector representing the up direction of the parabolic surface. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the parabolic surface. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        topologic_core.Shell
            The created paraboloid.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Topology import Topology
        from topologicpy.Face import Face
        from topologicpy.Wire import Wire
        from topologicpy.Shell import Shell

        if origin == None:
            origin = Vertex.Origin()
        
        if not Topology.IsInstance(origin, "Vertex"):
            if not silent:
                print("Cell.Paraboloid - Error: The origin input parameter is not a valid vertex. Returning None.")
            return None
        if width <= 0:
            if not silent:
                print("Cell.Paraboloid - Error: The width input parameter cannot be less than or equal to zero. Returning None.")
            return None
        if length <= 0:
            if not silent:
                print("Cell.Paraboloid - Error: The length input parameter cannot be less than or equal to zero. Returning None.")
            return None
        if height < 0:
            if not silent:
                print("Cell.Paraboloid - Error: The height input parameter cannot be negative. Returning None.")
            return None
        
        para = Shell.Paraboloid(focalLength=focalLength, width=width, length=length, uSides=uSides, vSides=vSides,
                        direction=[0,0,1], placement="center", mantissa=mantissa, tolerance=tolerance)
        if not Topology.IsInstance(para, "Shell"):
            if not silent:
                print("Cell.Paraboloid - Error: Could not create paraboloid. Returning None.")
            return None
        eb = Shell.ExternalBoundary(para)
        vertices = Topology.Vertices(eb)
        z_list = [Vertex.Z(v) for v in vertices]
        if focalLength > 0:
            z = max(z_list) + height
        else:
            z = min(z_list) - height
        f = Face.Rectangle(origin=Vertex.ByCoordinates(0,0,z), width=width*1.1, length=length*1.1)
        proj_vertices = []
        for v in vertices:
            proj_vertices.append(Vertex.Project(v, f))
        w = Wire.ByVertices(proj_vertices, close=True)
        sleeve = Shell.ByWires([eb, w], triangulate=False, silent=True)
        if sleeve == None:
            if not silent:
                print("Cell.Paraboloid - Error: Could not create paraboloid. Returning None.")
            return None
        f = Face.ByWire(w, tolerance=tolerance)
        faces = Topology.Faces(sleeve) + [f] + Topology.Faces(para)
        cell = Cell.ByFaces(faces, tolerance=tolerance)
        if cell == None:
            if not silent:
                print("Cell.Paraboloid - Error: Could not create paraboloid. Returning None.")
            return None
        vertices = Topology.Vertices(cell)
        x_list = [Vertex.X(v, mantissa=mantissa) for v in vertices]
        y_list = [Vertex.Y(v, mantissa=mantissa) for v in vertices]
        z_list = [Vertex.Z(v, mantissa=mantissa) for v in vertices]
        min_x = min(x_list)
        max_x = max(x_list)
        mid_x = min_x + (max_x - min_x)/2
        min_y = min(y_list)
        max_y = max(y_list)
        mid_y = min_y + (max_y - min_y)/2
        min_z = min(z_list)
        max_z = max(z_list)
        mid_z = min_z + (max_z - min_z)/2
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "center":
            xOffset = -mid_x
            yOffset = -mid_y
            zOffset = -mid_z
        elif placement.lower() == "bottom":
            xOffset = -mid_x
            yOffset = -mid_y
            zOffset = -min_z
        elif placement.lower() == "lowerleft":
            xOffset = -min_x
            yOffset = -min_y
            zOffset = -min_z

        cell = Topology.OrientAndPlace(cell,
                                       originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                       dirA=[0, 0, 1],
                                       dirB=direction,
                                       transferDictionaries = False,
                                       tolerance = tolerance,
                                       silent = silent)
        return cell

    @staticmethod
    def Pipe(edge, profile = None, radius: float = 0.5, sides: int = 16, startOffset: float = 0, endOffset: float = 0, endcapA = None, endcapB = None, mantissa: int = 6) -> dict:
        """
        Creates a pipe along the input edge.

        Parameters
        ----------
        edge : topologic_core.Edge
            The centerline of the pipe.
        profile : topologic_core.Wire , optional
            The profile of the pipe. It is assumed that the profile is in the XY plane. If set to None, a circle of radius 0.5 will be used. Default is None.
        radius : float , optional
            The radius of the pipe. Default is 0.5.
        sides : int , optional
            The number of sides of the pipe. Default is 16.
        startOffset : float , optional
            The offset distance from the start vertex of the centerline edge. Default is 0.
        endOffset : float , optional
            The offset distance from the end vertex of the centerline edge. Default is 0.
        endcapA, optional
            The topology to place at the start vertex of the centerline edge. The positive Z direction of the end cap will be oriented in the direction of the centerline edge.
        endcapB, optional
            The topology to place at the end vertex of the centerline edge. The positive Z direction of the end cap will be oriented in the inverse direction of the centerline edge.
        mantissa : int , optional
            The desired length of the mantissa. Default is 6
        
        Returns
        -------
        dict
            A dictionary containing the pipe, the start endcap, and the end endcap if they have been specified. The dictionary has the following keys:
            'pipe'
            'endcapA'
            'endcapB'

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Edge import Edge
        from topologicpy.Wire import Wire
        from topologicpy.Topology import Topology
        import math

        if not Topology.IsInstance(edge, "Edge"):
            print("Cell.Pipe - Error: The input edge parameter is not a valid topologic edge. Returning None.")
            return None
        length = Edge.Length(edge)
        origin = Edge.StartVertex(edge)
        startU = startOffset / length
        endU = 1.0 - (endOffset / length)
        sv = Edge.VertexByParameter(edge, startU)
        ev = Edge.VertexByParameter(edge, endU)
        x1 = Vertex.X(sv, mantissa=mantissa)
        y1 = Vertex.Y(sv, mantissa=mantissa)
        z1 = Vertex.Z(sv, mantissa=mantissa)
        x2 = Vertex.X(ev, mantissa=mantissa)
        y2 = Vertex.Y(ev, mantissa=mantissa)
        z2 = Vertex.Z(ev, mantissa=mantissa)
        dx = x2 - x1
        dy = y2 - y1
        dz = z2 - z1
        dist = math.sqrt(dx**2 + dy**2 + dz**2)
        baseV = []
        topV = []

        if Topology.IsInstance(profile, "Wire"):
            baseWire = Topology.Translate(profile, 0 , 0, Vertex.Z(sv))
            topWire = Topology.Translate(profile, 0 , 0, Vertex.Z(sv)+dist)
        else:
            for i in range(sides):
                angle = math.radians(360/sides)*i
                x = math.sin(angle)*radius + Vertex.X(sv, mantissa=mantissa)
                y = math.cos(angle)*radius + Vertex.Y(sv, mantissa=mantissa)
                z = Vertex.Z(sv, mantissa=mantissa)
                baseV.append(Vertex.ByCoordinates(x, y, z))
                topV.append(Vertex.ByCoordinates(x, y, z+dist))

            baseWire = Wire.ByVertices(baseV)
            topWire = Wire.ByVertices(topV)
        wires = [baseWire, topWire]
        pipe = Cell.ByWires(wires)
        phi = math.degrees(math.atan2(dy, dx)) # Rotation around Y-Axis
        if dist < 0.0001:
            theta = 0
        else:
            theta = math.degrees(math.acos(dz/dist)) # Rotation around Z-Axis
        pipe = Topology.Rotate(pipe, origin=sv, axis=[0, 1, 0], angle=theta)
        pipe = Topology.Rotate(pipe, origin=sv, axis=[0, 0, 1], angle=phi)
        zzz = Vertex.ByCoordinates(0, 0, 0)
        if endcapA:
            origin = Edge.StartVertex(edge)
            x1 = Vertex.X(origin, mantissa=mantissa)
            y1 = Vertex.Y(origin, mantissa=mantissa)
            z1 = Vertex.Z(origin, mantissa=mantissa)
            x2 = Vertex.X(Edge.EndVertex(edge), mantissa=mantissa)
            y2 = Vertex.Y(Edge.EndVertex(edge), mantissa=mantissa)
            z2 = Vertex.Z(Edge.EndVertex(edge), mantissa=mantissa)
            dx = x2 - x1
            dy = y2 - y1
            dz = z2 - z1    
            dist = math.sqrt(dx**2 + dy**2 + dz**2)
            phi = math.degrees(math.atan2(dy, dx)) # Rotation around Y-Axis
            if dist < 0.0001:
                theta = 0
            else:
                theta = math.degrees(math.acos(dz/dist)) # Rotation around Z-Axis
            endcapA = Topology.Copy(endcapA)
            endcapA = Topology.Rotate(endcapA, origin=zzz, axis=[0, 1, 0], angle=theta)
            endcapA = Topology.Rotate(endcapA, origin=zzz, axis=[0, 0, 1], angle=phi+180)
            endcapA = Topology.Translate(endcapA, Vertex.X(origin, mantissa=mantissa), Vertex.Y(origin, mantissa=mantissa), Vertex.Z(origin, mantissa=mantissa))
        if endcapB:
            origin = Edge.EndVertex(edge)
            x1 = Vertex.X(origin, mantissa=mantissa)
            y1 = Vertex.Y(origin, mantissa=mantissa)
            z1 = Vertex.Z(origin, mantissa=mantissa)
            x2 = Vertex.X(Edge.StartVertex(edge), mantissa=mantissa)
            y2 = Vertex.Y(Edge.StartVertex(edge), mantissa=mantissa)
            z2 = Vertex.Z(Edge.StartVertex(edge), mantissa=mantissa)
            dx = x2 - x1
            dy = y2 - y1
            dz = z2 - z1    
            dist = math.sqrt(dx**2 + dy**2 + dz**2)
            phi = math.degrees(math.atan2(dy, dx)) # Rotation around Y-Axis
            if dist < 0.0001:
                theta = 0
            else:
                theta = math.degrees(math.acos(dz/dist)) # Rotation around Z-Axis
            endcapB = Topology.Copy(endcapB)
            endcapB = Topology.Rotate(endcapB, origin=zzz, axis=[0, 1, 0], angle=theta)
            endcapB = Topology.Rotate(endcapB, origin=zzz, axis=[0, 0, 1], angle=phi+180)
            endcapB = Topology.Translate(endcapB, Vertex.X(origin, mantissa=mantissa), Vertex.Y(origin, mantissa=mantissa), Vertex.Z(origin, mantissa=mantissa))
        return {'pipe': pipe, 'endcapA': endcapA, 'endcapB': endcapB}
    
    @staticmethod
    def Prism(origin= None,
              width: float = 1,
              length: float = 1,
              height: float = 1,
              uSides: int = 1,
              vSides: int = 1,
              wSides: int = 1,
              direction: list = [0, 0, 1],
              placement: str ="center",
              mantissa: int = 6,
              tolerance: float = 0.0001,
              silent: bool = False):
        """
        Creates a prism.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the prism. Default is None which results in the prism being placed at (0, 0, 0).
        width : float , optional
            The width of the prism. Default is 1.
        length : float , optional
            The length of the prism. Default is 1.
        height : float , optional
            The height of the prism.
        uSides : int , optional
            The number of sides along the width. Default is 1.
        vSides : int , optional
            The number of sides along the length. Default is 1.
        wSides : int , optional
            The number of sides along the height. Default is 1.
        direction : list , optional
            The vector representing the up direction of the prism. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the prism. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.
        
        Returns
        -------
        topologic_core.Cell
            The created prism.

        """
        from topologicpy.Wire import Wire
        from topologicpy.Cluster import Cluster
        from topologicpy.Topology import Topology

        def sliceCell(cell, width, length, height, uSides, vSides, wSides):
            origin = Topology.Centroid(cell)
            shells = Topology.Shells(cell)
            shell = shells[0]
            wRect = Wire.Rectangle(origin=origin, width=width*1.2, length=length*1.2, direction=[0, 0, 1], placement="center")
            sliceFaces = []
            for i in range(1, wSides):
                sliceFaces.append(Topology.Translate(Face.ByWire(wRect, tolerance=tolerance), 0, 0, height/wSides*i - height*0.5))
            uRect = Wire.Rectangle(origin=origin, width=height*1.2, length=length*1.2, direction=[1, 0, 0], placement="center")
            for i in range(1, uSides):
                sliceFaces.append(Topology.Translate(Face.ByWire(uRect, tolerance=tolerance), width/uSides*i - width*0.5, 0, 0))
            vRect = Wire.Rectangle(origin=origin, length=height*1.2, width=width*1.2, direction=[0, 1, 0], placement="center")
            for i in range(1, vSides):
                sliceFaces.append(Topology.Translate(Face.ByWire(vRect, tolerance=tolerance), 0, length/vSides*i - length*0.5, 0))
            if len(sliceFaces) > 0:
                sliceCluster = Cluster.ByTopologies(sliceFaces)
                shell = Topology.Slice(topologyA=shell, topologyB=sliceCluster, tranDict=False, tolerance=tolerance)
                return Cell.ByShell(shell)
            return cell
        
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(origin, "Vertex"):
            origin = Vertex.ByCoordinates(0, 0, 0)
        if not Topology.IsInstance(origin, "Vertex"):
            if not silent:
                print("Cell.Prism - Error: The input origin parameter is not a valid topologic vertex. Returning None.")
            return None
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "center":
            zOffset = -height*0.5
        elif placement.lower() == "lowerleft":
            xOffset = width*0.5
            yOffset = length*0.5
        
        vb1 = Vertex.ByCoordinates(Vertex.X(origin, mantissa=mantissa)-width*0.5+xOffset,Vertex.Y(origin, mantissa=mantissa)+length*0.5+yOffset,Vertex.Z(origin, mantissa=mantissa)+zOffset)
        vb2 = Vertex.ByCoordinates(Vertex.X(origin, mantissa=mantissa)+width*0.5+xOffset,Vertex.Y(origin, mantissa=mantissa)+length*0.5+yOffset,Vertex.Z(origin, mantissa=mantissa)+zOffset)
        vb3 = Vertex.ByCoordinates(Vertex.X(origin, mantissa=mantissa)+width*0.5+xOffset,Vertex.Y(origin, mantissa=mantissa)-length*0.5+yOffset,Vertex.Z(origin, mantissa=mantissa)+zOffset)
        vb4 = Vertex.ByCoordinates(Vertex.X(origin, mantissa=mantissa)-width*0.5+xOffset,Vertex.Y(origin, mantissa=mantissa)-length*0.5+yOffset,Vertex.Z(origin, mantissa=mantissa)+zOffset)

        baseWire = Wire.ByVertices([vb1, vb2, vb3, vb4], close=True)
        baseFace = Face.ByWire(baseWire, tolerance=tolerance)

        prism = Cell.ByThickenedFace(baseFace, thickness=height, bothSides = False, reverse=True)
        if not Topology.IsInstance(prism, "Cell"):
            if not silent:
                print("Cell.Prism - Error: Could not create the cell. Returning None.")
            return None

        if uSides > 1 or vSides > 1 or wSides > 1:
            prism = sliceCell(prism, width, length, height, uSides, vSides, wSides)
            if not Topology.IsInstance(prism, "Cell"):
                if not silent:
                    print("Cell.Prism - Error: Could not slice the cell. Returning None.")
                return None
        prism = Topology.Orient(prism, origin=origin, dirA=[0, 0, 1], dirB=direction, tolerance=tolerance)
        return prism

    @staticmethod
    def RemoveCollinearEdges(cell, angTolerance: float = 0.1, tolerance: float = 0.0001, silent: bool = False):
        """
        Removes any collinear edges in the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.
        angTolerance : float , optional
            The desired angular tolerance. Default is 0.1.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created cell without any collinear edges.

        """
        from topologicpy.Topology import Topology
        
        if not Topology.IsInstance(cell, "Cell"):
            if not silent:
                print("Cell.RemoveCollinearEdges - Error: The input cell parameter is not a valid cell. Returning None.")
            return None
        faces = Cell.Faces(cell)
        clean_faces = []
        for face in faces:
            clean_face = Topology.RemoveCollinearEdges(
                face,
                angTolerance=angTolerance,
                polyhedron=True,
                tolerance=tolerance,
                silent=True,
            )
            if not Topology.IsInstance(clean_face, "Face"):
                if not silent:
                    print("Cell.RemoveCollinearEdges - Error: Could not simplify one or more Faces. Returning None.")
                return None
            clean_faces.append(clean_face)
        return Cell.ByFaces(clean_faces, tolerance=tolerance, silent=silent)
    
    @staticmethod
    def RHS(origin= None, width: float = 1.0, length: float = 1.0, height: float = 1.0, thickness: float = 0.25, outerFillet: float = 0.0, innerFillet: float = 0.0, sides: int = 16, direction: list = [0, 0, 1], placement: str = "center", tolerance: float = 0.0001, silent: bool = False):
        """
        Creates a rectangluar hollow section (RHS).

        Parameters
        ----------
        origin : topologic_core.Vertex, optional
            The location of the origin of the RHS. Default is None which results in the RHS being placed at (0, 0, 0).
        width : float , optional
            The width of the RHS. Default is 1.0.
        length : float , optional
            The length of the RHS. Default is 1.0.
        thickness : float , optional
            The thickness of the RHS. Default is 0.25.
        height : float , optional
            The height of the RHS. Default is 1.0.
        outerFillet : float , optional
            The outer fillet multiplication factor based on the thickness (e.g. 1t). Default is 0.
        innerFillet : float , optional
            The inner fillet multiplication factor based on the thickness (e.g. 1.5t). Default is 0.
        sides : int , optional
            The desired number of sides of the fillets. Default is 16.
        direction : list , optional
            The vector representing the up direction of the RHS. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the RHS. This can be "center", "bottom", "top", "lowerleft", "upperleft", "lowerright", "upperright". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created cell.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology

        if 2*thickness >= width:
            if not silent:
                print("Cell.RHS - Error: Twice the thickness value is larger than or equal to the width value. Returning None.")
            return None
        if 2*thickness >= width:
            if not silent:
                print("Cell.RHS - Error: Twice the thickness value is larger than or equal to the length value. Returning None.")
            return None
        outer_dimension = min(width, length)
        fillet_dimension = 2*outerFillet*thickness
        if  fillet_dimension > outer_dimension:
            if not silent:
                print("Cell.RHS = Error: The outer fillet radius input value is too large given the desired dimensions of the RHS. Returning None.")
            return None
        inner_dimension = min(width, length) - 2*thickness
        fillet_dimension = 2*innerFillet*thickness
        if fillet_dimension > inner_dimension:
            if not silent:
                print("Cell.RHS = Error: The inner fillet radius input value is too large given the desired dimensions of the RHS. Returning None.")
            return None
        if origin == None:
            origin = Vertex.Origin()
        bottom_face = Face.RHS(origin = Vertex.Origin(), width=width, length=length, thickness=thickness, outerFillet=outerFillet, innerFillet=innerFillet, sides=sides, direction=[0,0,1], placement="center", tolerance=tolerance, silent=silent)
        return_cell = Cell.ByThickenedFace(bottom_face, thickness=height, bothSides=True, reverse=False,
                            tolerance=tolerance, silent=silent)
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "bottom":
            zOffset = height*0.5
        elif placement.lower() == "top":
            zOffset = -height*0.5
        elif placement.lower() == "lowerleft":
            xOffset = width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperleft":
            xOffset = width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        elif placement.lower() == "lowerright":
            xOffset = -width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperright":
            xOffset = -width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        
        return_cell = Topology.OrientAndPlace(return_cell,
                                           originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                           originB=origin,
                                           dirA=[0, 0, 1],
                                           dirB=direction,
                                           transferDictionaries = False,
                                           tolerance = tolerance,
                                           silent = silent)
        return return_cell

    @staticmethod
    def Roof(face, angle: float = 45, epsilon: float = 0.01 , tolerance: float = 0.001):
        """
            Creates a hipped roof through a straight skeleton. This method is contributed by 高熙鹏 xipeng gao <gaoxipeng1998@gmail.com>
            This algorithm depends on the polyskel code which is included in the library. Polyskel code is found at: https://github.com/Botffy/polyskel

        Parameters
        ----------
        face : topologic_core.Face
            The input face.
        angle : float , optional
            The desired angle in degrees of the roof. Default is 45.
        epsilon : float , optional
            The desired epsilon (another form of tolerance for distance from plane). Default is 0.01. (This is set to a larger number as it was found to work better)
        tolerance : float , optional
            The desired tolerance. Default is 0.001. (This is set to a larger number as it was found to work better)

        Returns
        -------
        cell
            The created roof.

        """
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell
        from topologicpy.Topology import Topology
        
        shell = Shell.Roof(face=face, angle=angle, epsilon=epsilon, tolerance=tolerance)
        if not Topology.IsInstance(shell, "Shell"):
            print("Cell.Roof - Error: Could not create a roof cell. Returning None.")
            return None
        faces = Topology.Faces(shell) + [face]
        cell = Cell.ByFaces(faces, tolerance=tolerance)
        if not Topology.IsInstance(cell, "Cell"):
            print("Cell.Roof - Error: Could not create a roof cell. Returning None.")
            return None
        return cell

    @staticmethod
    def Sets(cells: list, superCells: list, tolerance: float = 0.0001) -> list:
        """
            Classifies the input cells into sets based on their enclosure within the input list of super cells. The order of the sets follows the order of the input list of super cells.

        Parameters
        ----------
        inputCells : list
            The list of input cells.
        superCells : list
            The list of super cells.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.

        Returns
        -------
        list
            The classified list of input cells based on their enclosure within the input list of super cells.

        """

        from topologicpy.Vertex import Vertex
        from topologicpy.Topology import Topology

        if not isinstance(cells, list):
            print("Cell.Sets - Error: The input cells parameter is not a valid list. Returning None.")
            return None
        if not isinstance(superCells, list):
            print("Cell.Sets - Error: The input superCells parameter is not a valid list. Returning None.")
            return None
        cells = [c for c in cells if Topology.IsInstance(c, "Cell")]
        if len(cells) < 1:
            print("Cell.Sets - Error: The input cells parameter does not contain any valid cells. Returning None.")
            return None
        superCells = [c for c in superCells if Topology.IsInstance(c, "Cell")]
        if len(cells) < 1:
            print("Cell.Sets - Error: The input cells parameter does not contain any valid cells. Returning None.")
            return None
        if len(superCells) == 0:
            cluster = cells[0]
            for i in range(1, len(cells)):
                oldCluster = cluster
                cluster = Topology.Union(cluster, cells[i])
                del oldCluster
            superCells = Topology.Cells(cluster)
        unused = []
        for i in range(len(cells)):
            unused.append(True)
        sets = []
        for i in range(len(superCells)):
            sets.append([])
        for i in range(len(cells)):
            if unused[i]:
                iv = Topology.InternalVertex(cells[i], tolerance=tolerance)
                for j in range(len(superCells)):
                    if (Vertex.IsInternal(iv, superCells[j], tolerance=tolerance)):
                        sets[j].append(cells[i])
                        unused[i] = False
        return sets
    
    @staticmethod
    def Shells(cell) -> list:
        """
        Returns the shells of the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.

        Returns
        -------
        list
            The list of shells.

        """
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(cell, "Cell"):
            print("Cell.Shells - Error: The input cell parameter is not a valid topologic cell. Returning None.")
            return None
        shells = []
        # _ = cell.Shells(None, shells) # H to Core
        try:
            _ = Core.InstanceCall(cell, "Shells", None, shells)
        except Exception:
            shells = []
        return shells

    @staticmethod
    def SHS(origin= None, size: float = 1.0, height: float = 1.0, thickness: float = 0.25, outerFillet: float = 0.0, innerFillet: float = 0.0, sides: int = 16, direction: list = [0, 0, 1], placement: str = "center", tolerance: float = 0.0001, silent: bool = False):
        """
        Creates a square hollow section (SHS).

        Parameters
        ----------
        origin : topologic_core.Vertex, optional
            The location of the origin of the SHS. Default is None which results in the SHS being placed at (0, 0, 0).
        size : float , optional
            The size of the SHS. Default is 1.0.
        length : float , optional
            The length of the SHS. Default is 1.0.
        thickness : float , optional
            The thickness of the SHS. Default is 0.25.
        height : float , optional
            The height of the SHS. Default is 1.0.
        outerFillet : float , optional
            The outer fillet multiplication factor based on the thickness (e.g. 1t). Default is 0.
        innerFillet : float , optional
            The inner fillet multiplication factor based on the thickness (e.g. 1.5t). Default is 0.
        sides : int , optional
            The desired number of sides of the fillets. Default is 16.
        direction : list , optional
            The vector representing the up direction of the SHS. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the RHS. This can be "center", "bottom", "top", "lowerleft", "upperleft", "lowerright", "upperright". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created cell.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology

        if 2*thickness >= size:
            if not silent:
                print("Cell.SHS - Error: Twice the thickness value is larger than or equal to the size value. Returning None.")
            return None
        fillet_dimension = 2*outerFillet*thickness
        if  fillet_dimension > size:
            if not silent:
                print("Cell.SHS = Error: The outer fillet radius input value is too large given the desired dimensions of the RHS. Returning None.")
            return None
        inner_dimension = size - 2*thickness
        fillet_dimension = 2*innerFillet*thickness
        if fillet_dimension > inner_dimension:
            if not silent:
                print("Cell.SHS = Error: The inner fillet radius input value is too large given the desired dimensions of the RHS. Returning None.")
            return None
        return Cell.RHS(origin= origin,
                        width = size,
                        length = size,
                        height = height,
                        thickness = thickness,
                        outerFillet = outerFillet,
                        innerFillet = innerFillet,
                        sides = sides,
                        direction = direction,
                        placement = placement,
                        tolerance = tolerance,
                        silent = silent)
    
    @staticmethod
    def Sphere(origin= None, radius: float = 0.5, uSides: int = 16, vSides: int = 8, direction: list = [0, 0, 1],
                   placement: str = "center", tolerance: float = 0.0001, silent: bool = False, polyhedron: bool = True):
        """
        Creates an approximation of a sphere using a UV grid of triangular faces.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the sphere. Default is None which results in the sphere being placed at (0, 0, 0).
        radius : float , optional
            The radius of the sphere. Default is 0.5.
        uSides : int , optional
            The number of sides along the longitude of the sphere. Default is 16.
        vSides : int , optional
            The number of sides along the latitude of the sphere. Default is 8.
        direction : list , optional
            The vector representing the up direction of the sphere. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the sphere. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool, optional
            If set to True, suppresses warning and error messages. Default is False.
        

        Returns
        -------
        topologic_core.Cell
            The created sphere.

        """
    
        import math
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Cell import Cell
        from topologicpy.Topology import Topology

        if not polyhedron:
            if not Topology.IsInstance(origin, "Vertex"):
                origin = Vertex.Origin()
            sphere = Cell._NativeCell("BySphere", radius=radius, tolerance=tolerance, silent=silent)
            if not Topology.IsInstance(sphere, "Cell"):
                return None
            p = str(placement).lower().strip()
            r = abs(float(radius))
            source = [0.0, 0.0, 0.0]
            if p == "bottom":
                source = [0.0, 0.0, -r]
            elif p == "lowerleft":
                source = [-r, -r, -r]
            elif p != "center":
                if not silent:
                    print('Cell.Sphere - Error: placement must be "center", "bottom", or "lowerleft". Returning None.')
                return None
            return Cell._PlaceNativeCell(sphere, origin, direction, source, tolerance, silent)

        # Validate inputs
        if radius <= 0 or uSides < 3 or vSides < 2:
            if not silent:
                print("Cell.Sphere - Error: radius must be > 0, uSides >= 3, vSides >= 2. Returning None.")
            return None

        # Center
        if origin is None:
            origin = Vertex.ByCoordinates(0, 0, 0)
        ox = Vertex.X(origin)
        oy = Vertex.Y(origin)
        oz = Vertex.Z(origin)

        # Poles
        top_pole = Vertex.ByCoordinates(ox, oy, oz + radius)
        bottom_pole = Vertex.ByCoordinates(ox, oy, oz - radius)

        # Latitude rings (exclude poles)
        rings = []  # list of list[Vertex]
        for vi in range(1, vSides):
            phi = math.pi * vi / vSides  # 0..pi
            sin_phi = math.sin(phi)
            cos_phi = math.cos(phi)
            ring = []
            for ui in range(uSides):
                theta = 2.0 * math.pi * ui / uSides
                x = ox + radius * sin_phi * math.cos(theta)
                y = oy + radius * sin_phi * math.sin(theta)
                z = oz + radius * cos_phi
                ring.append(Vertex.ByCoordinates(x, y, z))
            rings.append(ring)

        faces = []

        # Top cap: triangles from top pole to first ring
        first_ring = rings[0]
        for u in range(uSides):
            v1 = first_ring[u]
            v2 = first_ring[(u + 1) % uSides]
            f = Face.ByVertices([top_pole, v1, v2], tolerance=tolerance)
            if f:
                faces.append(f)

        # Middle bands: split quads into two triangles
        for i in range(len(rings) - 1):
            curr = rings[i]
            nxt = rings[i + 1]
            for u in range(uSides):
                a = curr[u]
                b = nxt[u]
                c = nxt[(u + 1) % uSides]
                d = curr[(u + 1) % uSides]
                f1 = Face.ByVertices([a, b, c], tolerance=tolerance)
                if f1:
                    faces.append(f1)
                f2 = Face.ByVertices([a, c, d], tolerance=tolerance)
                if f2:
                    faces.append(f2)

        # Bottom cap: triangles from last ring to bottom pole
        last_ring = rings[-1]
        for u in range(uSides):
            v1 = last_ring[(u + 1) % uSides]
            v2 = last_ring[u]
            f = Face.ByVertices([bottom_pole, v1, v2], tolerance=tolerance)
            if f:
                faces.append(f)

        # Sew faces into a shell
        sphere = None
        try:
            sphere = Cell.ByFaces(faces, tolerance=tolerance)
        except Exception:
            if not silent:
                print("Cell.Sphere - Error: could not create a sphere. Returning None.")
            return None
        if placement.lower() == "bottom":
            sphere = Topology.Translate(sphere, 0, 0, radius)
        elif placement.lower() == "lowerleft":
            sphere = Topology.Translate(sphere, radius, radius, radius)
        
        if not direction == [0,0,1]:
            sphere = Topology.Orient(sphere, origin=origin, dirA=[0, 0, 1], dirB=direction)
        return sphere
    
    @staticmethod
    def SurfaceArea(cell, mantissa: int = 6) -> float:
        """
        Returns the surface area of the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The cell.
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.

        Returns
        -------
        area : float
            The surface area of the input cell.

        """
        return Cell.Area(cell=cell, mantissa=mantissa)
    
    @staticmethod
    def Tetrahedron(origin = None,
                    length: float = 1,
                    depth: int = 1,
                    direction=[0,0,1],
                    placement="center",
                    mantissa: int = 6,
                    tolerance: float = 0.0001,
                    silent: bool = False):
        """
        Creates a recursive tetrahedron cell.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the tetrahedron. Default is None which results in the tetrahedron being placed at (0, 0, 0).
        length : float , optional
            The length of the edge of the tetrahedron. Default is 1.
        depth : int , optional
            The desired maximum number of recrusive subdivision levels.
        direction : list , optional
            The vector representing the up direction of the tetrahedron. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the tetrahedron. This can be "bottom", "center", or "lowerleft". It is case insensitive. Default is "center".
        mantissa : int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool, optional
            If set to True, suppresses warning and error messages. Default is False.
        
        Returns
        -------
        topologic_core.CellComplex
            The created tetrahedron.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Cell import Cell
        from topologicpy.CellComplex import CellComplex
        from topologicpy.Cluster import Cluster
        from topologicpy.Topology import Topology
        from topologicpy.Dictionary import Dictionary

        from math import sqrt

        def subdivide_tetrahedron(tetrahedron, depth):
            """
            Recursively subdivides a tetrahedron into smaller tetrahedra.

            Parameters:
                tetrahedron (Cell): The tetrahedron to subdivide.
                depth (int): Recursion depth for the subdivision.

            Returns:
                list: List of smaller tetrahedral cells.
            """
            if depth == 0:
                return [tetrahedron]

            # Extract the vertices of the tetrahedron
            vertices = Topology.Vertices(tetrahedron)
            v0, v1, v2, v3 = vertices

            # Calculate midpoints of the edges
            m01 = Vertex.ByCoordinates((Vertex.X(v0) + Vertex.X(v1)) / 2, (Vertex.Y(v0) + Vertex.Y(v1)) / 2, (Vertex.Z(v0) + Vertex.Z(v1)) / 2)
            m02 = Vertex.ByCoordinates((Vertex.X(v0) + Vertex.X(v2)) / 2, (Vertex.Y(v0) + Vertex.Y(v2)) / 2, (Vertex.Z(v0) + Vertex.Z(v2)) / 2)
            m03 = Vertex.ByCoordinates((Vertex.X(v0) + Vertex.X(v3)) / 2, (Vertex.Y(v0) + Vertex.Y(v3)) / 2, (Vertex.Z(v0) + Vertex.Z(v3)) / 2)
            m12 = Vertex.ByCoordinates((Vertex.X(v1) + Vertex.X(v2)) / 2, (Vertex.Y(v1) + Vertex.Y(v2)) / 2, (Vertex.Z(v1) + Vertex.Z(v2)) / 2)
            m13 = Vertex.ByCoordinates((Vertex.X(v1) + Vertex.X(v3)) / 2, (Vertex.Y(v1) + Vertex.Y(v3)) / 2, (Vertex.Z(v1) + Vertex.Z(v3)) / 2)
            m23 = Vertex.ByCoordinates((Vertex.X(v2) + Vertex.X(v3)) / 2, (Vertex.Y(v2) + Vertex.Y(v3)) / 2, (Vertex.Z(v2) + Vertex.Z(v3)) / 2)

            # Create smaller tetrahedra
            tetrahedra = [
                Cell.ByFaces([
                    Face.ByVertices([v0, m01, m02]),
                    Face.ByVertices([v0, m01, m03]),
                    Face.ByVertices([v0, m02, m03]),
                    Face.ByVertices([m01, m02, m03])
                ]),
                Cell.ByFaces([
                    Face.ByVertices([m01, v1, m12]),
                    Face.ByVertices([m01, v1, m13]),
                    Face.ByVertices([m01, m12, m13]),
                    Face.ByVertices([v1, m12, m13])
                ]),
                Cell.ByFaces([
                    Face.ByVertices([m02, m12, v2]),
                    Face.ByVertices([m02, m12, m23]),
                    Face.ByVertices([m02, v2, m23]),
                    Face.ByVertices([m12, v2, m23])
                ]),
                Cell.ByFaces([
                    Face.ByVertices([m03, m13, m23]),
                    Face.ByVertices([m03, v3, m13]),
                    Face.ByVertices([m03, v3, m23]),
                    Face.ByVertices([m13, v3, m23])
                ])
            ]

            # Recursively subdivide the smaller tetrahedra
            result = []
            for t in tetrahedra:
                result.extend(subdivide_tetrahedron(t, depth - 1))
            return result

        if not Topology.IsInstance(origin, "vertex"):
            origin = Vertex.Origin()
        
        # Define the four vertices of the tetrahedron
        v0 = Vertex.ByCoordinates(0, 0, 0)
        v1 = Vertex.ByCoordinates(length, 0, 0)
        v2 = Vertex.ByCoordinates(length/2, sqrt(3)/2*length, 0)
        v3 = Vertex.ByCoordinates(length/2, sqrt(3)/2*length/3, sqrt(2/3)*length)

        # Create the initial tetrahedron
        tetrahedron = Cell.ByFaces([
            Face.ByVertices([v0, v1, v2]),
            Face.ByVertices([v0, v1, v3]),
            Face.ByVertices([v1, v2, v3]),
            Face.ByVertices([v2, v0, v3]),
        ])

        bbox = Topology.BoundingBox(tetrahedron)
        d = Topology.Dictionary(bbox)
        bb_width = Dictionary.ValueAtKey(d, "width")
        bb_length = Dictionary.ValueAtKey(d, "length")
        bb_height = Dictionary.ValueAtKey(d, "height")
        
        centroid = Topology.Centroid(tetrahedron)
        c_x, c_y, c_z = Vertex.Coordinates(centroid, mantissa=mantissa)

        xOffset = 0
        yOffset = 0
        zOffset = 0

        if placement.lower() == "center":
            xOffset = -c_x
            yOffset = -c_y
            zOffset = -c_z
        elif placement.lower() == "bottom":
            xOffset = -c_x
            yOffset = -c_y
        elif placement.lower() == "upperleft":
            zOffset = -bb_height
        elif placement.lower() == "upperright":
            xOffset = -bb_width
            yOffset = -bb_length
            zOffset = -bb_height
        elif placement.lower() == "bottomright":
            xOffset = -bb_width
            yOffset = -bb_length
        elif placement.lower() == "top":
            xOffset = -c_x
            yOffset = -c_y
            zOffset = -bb_height
        
        tetrahedron = Topology.OrientAndPlace(tetrahedron,
                                              originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                              dirB=direction,
                                              transferDictionaries = False,
                                              tolerance = tolerance,
                                              silent = silent)

        depth = max(depth, 0)
        if depth == 0:
            return tetrahedron
        else:
            # Recursively subdivide the tetrahedron
            subdivided_tetrahedra = subdivide_tetrahedron(tetrahedron, depth)
            # Create a cell complex from the subdivided tetrahedra
            return CellComplex.ExternalBoundary(CellComplex.ByCells([tetrahedron]+subdivided_tetrahedra))

    @staticmethod
    def Torus(origin=None,
              majorRadius: float = 0.5,
              minorRadius: float = 0.125,
              uSides: int = 16,
              vSides: int = 8,
              direction: list = [0, 0, 1],
              placement: str = "center",
              tolerance: float = 0.0001,
              silent: bool = False,
              polyhedron: bool = True):
        """
        Creates a torus.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The origin location of the torus. Default is None which results in the torus being placed at (0, 0, 0).
        majorRadius : float , optional
            The major radius of the torus. Default is 0.5.
        minorRadius : float , optional
            The minor radius of the torus. Default is 0.125.
        uSides : int , optional
            The number of sides along the longitude of the torus (around the hole). Default is 16.
        vSides : int , optional
            The number of sides along the latitude of the torus (tube direction). Default is 8.
        direction : list , optional
            The vector representing the up direction of the torus. Default is [0, 0, 1].
        placement : str , optional
            Placement of the input origin relative to the torus. One of:
            - "center": origin is at the torus' geometric center (default)
            - "bottom": origin lies on the lowest point along the up direction
            - "lowerleft": origin is at x/y lower-left and bottom in z of the torus' local bbox
            Comparison is case-insensitive.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool, optional
            If set to True, suppresses warning and error messages. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created torus.
        """
        # --- Imports kept inside to avoid cyclic dependencies in TopologicPy ---
        from math import cos, sin, pi, sqrt
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Shell import Shell
        from topologicpy.Cell import Cell
        from topologicpy.Topology import Topology
        if not polyhedron:
            if not Topology.IsInstance(origin, "Vertex"):
                origin = Vertex.Origin()
            torus = Cell._NativeCell("ByTorus", majorRadius=majorRadius, minorRadius=minorRadius, tolerance=tolerance, silent=silent)
            if not Topology.IsInstance(torus, "Cell"):
                return None
            p = str(placement).lower().strip()
            extent = abs(float(majorRadius)) + abs(float(minorRadius))
            minor = abs(float(minorRadius))
            source = [0.0, 0.0, 0.0]
            if p == "bottom":
                source = [0.0, 0.0, -minor]
            elif p == "lowerleft":
                source = [-extent, -extent, -minor]
            elif p != "center":
                if not silent:
                    print('Cell.Torus - Error: placement must be "center", "bottom", or "lowerleft". Returning None.')
                return None
            return Cell._PlaceNativeCell(torus, origin, direction, source, tolerance, silent)

        

        # --- Validation ---
        if majorRadius <= 0 or minorRadius <= 0:
            raise ValueError("majorRadius and minorRadius must be > 0.")
        if uSides < 3 or vSides < 3:
            raise ValueError("uSides and vSides must be >= 3.")
        if minorRadius >= majorRadius:
            # Geometrically valid but unusual; keep strict to avoid self-intersections at low resolution
            raise ValueError("minorRadius must be smaller than majorRadius for a clean torus.")

        # --- Helpers ---
        def _norm(v):
            x, y, z = v
            m = sqrt(x*x + y*y + z*z)
            if m == 0:
                return (0.0, 0.0, 1.0)
            return (x/m, y/m, z/m)

        def _dot(a, b):
            return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]

        def _cross(a, b):
            return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])

        def _rot_matrix_from_z(to_dir):
            """
            Build a rotation matrix that maps +Z to 'to_dir' using Rodrigues' formula.
            """
            z = (0.0, 0.0, 1.0)
            t = _norm(to_dir)
            c = _dot(z, t)  # cos(theta)
            if abs(c - 1.0) < 1e-12:
                # Already aligned
                return ((1.0,0.0,0.0),
                        (0.0,1.0,0.0),
                        (0.0,0.0,1.0))
            if abs(c + 1.0) < 1e-12:
                # 180 degrees: rotate around any axis perpendicular to z (e.g., x-axis)
                return ((1.0, 0.0, 0.0),
                        (0.0,-1.0, 0.0),
                        (0.0, 0.0,-1.0))
            k = _cross(z, t)
            kx, ky, kz = _norm(k)
            s = sqrt(max(0.0, 1.0 - c*c))
            # Skew-symmetric K
            K = ((0.0, -kz,  ky),
                (kz,  0.0, -kx),
                (-ky, kx,  0.0))
            # I + K*s + K^2*(1-c)
            # First compute K^2
            K2 = (
                (K[0][0]*K[0][0] + K[0][1]*K[1][0] + K[0][2]*K[2][0],
                K[0][0]*K[0][1] + K[0][1]*K[1][1] + K[0][2]*K[2][1],
                K[0][0]*K[0][2] + K[0][1]*K[1][2] + K[0][2]*K[2][2]),
                (K[1][0]*K[0][0] + K[1][1]*K[1][0] + K[1][2]*K[2][0],
                K[1][0]*K[0][1] + K[1][1]*K[1][1] + K[1][2]*K[2][1],
                K[1][0]*K[0][2] + K[1][1]*K[1][2] + K[1][2]*K[2][2]),
                (K[2][0]*K[0][0] + K[2][1]*K[1][0] + K[2][2]*K[2][0],
                K[2][0]*K[0][1] + K[2][1]*K[1][1] + K[2][2]*K[2][1],
                K[2][0]*K[0][2] + K[2][1]*K[1][2] + K[2][2]*K[2][2]),
            )
            I = ((1.0,0.0,0.0),(0.0,1.0,0.0),(0.0,0.0,1.0))

            def _madd(A, B, s=1.0):
                return tuple(tuple(A[i][j] + s*B[i][j] for j in range(3)) for i in range(3))

            R = I
            R = _madd(R, K, s)           # I + s*K
            R = _madd(R, K2, (1.0 - c))  # + (1-c)*K^2
            return R

        def _apply_R(p, R):
            return (
                R[0][0]*p[0] + R[0][1]*p[1] + R[0][2]*p[2],
                R[1][0]*p[0] + R[1][1]*p[1] + R[1][2]*p[2],
                R[2][0]*p[0] + R[2][1]*p[1] + R[2][2]*p[2],
            )

        def _add(a, b):
            return (a[0]+b[0], a[1]+b[1], a[2]+b[2])

        def _scale(v, s):
            return (v[0]*s, v[1]*s, v[2]*s)

        # --- Parametric grid in local coordinates (+Z is up) ---
        # u: around the main ring (longitude), v: around the tube (latitude)
        du = 2.0*pi / uSides
        dv = 2.0*pi / vSides

        # Precompute angles to avoid repeated trig
        cosu = [cos(i*du) for i in range(uSides)]
        sinu = [sin(i*du) for i in range(uSides)]
        cosv = [cos(j*dv) for j in range(vSides)]
        sinv = [sin(j*dv) for j in range(vSides)]

        # Vertex grid (uSides x vSides)
        grid = [[None for _ in range(vSides)] for _ in range(uSides)]
        points = [[None for _ in range(vSides)] for _ in range(uSides)]  # store tuples for transforms

        for i in range(uSides):
            cu, su = cosu[i], sinu[i]
            for j in range(vSides):
                cv, sv = cosv[j], sinv[j]
                x = (majorRadius + minorRadius * cv) * cu
                y = (majorRadius + minorRadius * cv) * su
                z =  minorRadius * sv
                points[i][j] = (x, y, z)

        # --- Orientation: rotate local +Z to requested direction ---
        R = _rot_matrix_from_z(direction if isinstance(direction, (list, tuple)) else [0,0,1])
        points = [[_apply_R(points[i][j], R) for j in range(vSides)] for i in range(uSides)]

        # --- Placement: translate relative to the given origin point ---
        # Determine placement offset in *local* frame, then rotate it by R, then add origin.
        placement_lc = placement.lower().strip()
        if placement_lc not in ("center", "bottom", "lowerleft"):
            raise ValueError('placement must be one of: "center", "bottom", "lowerleft".')

        # In local frame, bbox extents are:
        #   x,y in [- (R + r), + (R + r)]
        #   z in [ -r, +r ]
        # So:
        # - "center"   : no extra shift (center at (0,0,0))
        # - "bottom"   : shift up by r along +Z so the lowest point touches z=0 (then move to origin)
        # - "lowerleft": put min x,y at 0 and bottom at z=0, i.e. shift by (R+r, R+r, r)
        if placement_lc == "center":
            placement_local_offset = (0.0, 0.0, 0.0)
        elif placement_lc == "bottom":
            placement_local_offset = (0.0, 0.0, minorRadius)
        else:  # "lowerleft"
            placement_local_offset = (majorRadius + minorRadius, majorRadius + minorRadius, minorRadius)

        # Rotate the local placement offset into world frame
        placement_world_offset = _apply_R(placement_local_offset, R)

        # Determine origin position
        if origin is None:
            ox, oy, oz = (0.0, 0.0, 0.0)
        else:
            try:
                ox = Vertex.X(origin)
                oy = Vertex.Y(origin)
                oz = Vertex.Z(origin)
            except Exception:
                # Accept a plain (x,y,z) tuple/list as a convenience
                ox, oy, oz = origin  # type: ignore

        origin_pt = (ox, oy, oz)
        base_translation = _add(origin_pt, placement_world_offset)

        # Apply final translation
        points = [[_add(points[i][j], base_translation) for j in range(vSides)] for i in range(uSides)]

        # --- Build Topologic vertices (reuse grid references) ---
        for i in range(uSides):
            for j in range(vSides):
                x, y, z = points[i][j]
                grid[i][j] = Vertex.ByCoordinates(x, y, z)

        # --- Triangulate the quad grid into faces (2 triangles per quad) ---
        faces = []
        # Wind triangles so that normals generally point outward
        for i in range(uSides):
            i1 = (i + 1) % uSides
            for j in range(vSides):
                j1 = (j + 1) % vSides
                v00 = grid[i][j]
                v10 = grid[i1][j]
                v11 = grid[i1][j1]
                v01 = grid[i][j1]
                # Two triangles per cell:
                f1 = Face.ByVertices([v00, v10, v11], tolerance)  # triangle
                f2 = Face.ByVertices([v00, v11, v01], tolerance)  # triangle
                if f1 is None or f2 is None:
                    raise RuntimeError("Failed to create torus facets (Face.ByVertices returned None).")
                faces.append(f1)
                faces.append(f2)

        # --- Stitch into a closed shell, then a cell ---
        shell = Shell.ByFaces(faces, tolerance)
        if shell is None:
            # As a fallback, try slight relaxation on tolerance (if environment is finicky)
            shell = Shell.ByFaces(faces, tolerance * 10.0)
        if shell is None:
            raise RuntimeError("Failed to stitch torus shell from facets.")

        # Try common constructors to obtain a solid Cell
        cell = None
        # 1) Common signature: Cell.ByShell(shell)
        try:
            cell = Cell.ByShell(shell)
        except Exception:
            cell = None
        # 2) Sometimes requires tolerance
        if cell is None:
            try:
                cell = Cell.ByShell(shell, tolerance)
            except Exception:
                cell = None
        # 3) Some builds expect a list of shells (external only)
        if cell is None:
            try:
                cell = Cell.ByShells([shell], tolerance)
            except Exception:
                cell = None
        # 4) Rare builds: stitch directly from faces
        if cell is None:
            try:
                cell = Cell.ByFaces(faces, tolerance, silent=silent)
            except Exception:
                cell = None

        if cell is None:
            # As a last resort, return the stitched shell so the caller still gets usable geometry.
            # But the contract says Cell; better to error explicitly so issues are caught early.
            raise RuntimeError("Failed to create a solid Cell from the torus shell. Check tolerances and resolution (uSides/vSides).")

        # Clean up small topological defects if available
        try:
            cell = Topology.Clean(cell, tolerance, silent=silent)  # optional: no-op if not available
        except Exception:
            pass

        return cell
    
    @staticmethod
    def TShape(origin=None,
            width=1,
            length=1,
            height=1,
            wSides=1,
            a=0.25,
            b=0.25,
            flipHorizontal = False,
            flipVertical = False,
            direction=[0,0,1],
            placement="center",
            mantissa=6,
            tolerance=0.0001,
            silent=False):
        """
        Creates a T-shape cell.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The location of the origin of the T-shape. Default is None which results in the T-shape being placed at (0, 0, 0).
        width : float , optional
            The overall width of the T-shape. Default is 1.0.
        length : float , optional
            The overall length of the T-shape. Default is 1.0.
        height : float , optional
            the overall height of the T-shape. Default is 1.0.
        wSides : int , optional
            The desired number of sides along the Z-axis. Default is 1.
        a : float , optional
            The hortizontal thickness of the vertical arm of the T-shape. Default is 0.25.
        b : float , optional
            The vertical thickness of the horizontal arm of the T-shape. Default is 0.25.
        flipHorizontal : bool , optional
            if set to True, the shape is flipped horizontally. Default is False.
        flipVertical : bool , optional
            if set to True, the shape is flipped vertically. Default is False.
        direction : list , optional
            The vector representing the up direction of the T-shape. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the T-shape. This can be "center", "lowerleft", "upperleft", "lowerright", "upperright". It is case insensitive. Default is "center".
        mantissa: int , optional
            The number of decimal places to round the result to. Default is 6.
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Face
            The created T-shape.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Wire import Wire
        from topologicpy.Topology import Topology

        if not isinstance(width, int) and not isinstance(width, float):
            if not silent:
                print("Cell.TShape - Error: The width input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(length, int) and not isinstance(length, float):
            if not silent:
                print("Cell.TShape - Error: The length input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(a, int) and not isinstance(a, float):
            if not silent:
                print("Cell.TShape - Error: The a input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(b, int) and not isinstance(b, float):
            if not silent:
                print("Cell.LShape - Error: The b input parameter is not a valid number. Returning None.")
            return None
        if width <= tolerance:
            if not silent:
                print("Cell.TShape - Error: The width input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if length <= tolerance:
            if not silent:
                print("Cell.TShape - Error: The length input parameter must be a positive number  greater than the tolerance input parameter. Returning None.")
            return None
        if a <= tolerance:
            if not silent:
                print("Cell.TShape - Error: The a input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if b <= tolerance:
            if not silent:
                print("Cell.TShape - Error: The b input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if a >= (width - tolerance):
            if not silent:
                print("Cell.TShape - Error: The a input parameter must be less than the width input parameter. Returning None.")
            return None
        if b >= (length - tolerance):
            if not silent:
                print("Cell.TShape - Error: The b input parameter must be less than the length input parameter. Returning None.")
            return None
        if origin == None:
            origin = Vertex.Origin()
        if not Topology.IsInstance(origin, "vertex"):
            if not silent:
                print("Cell.TShape - Error: The origin input parameter is not a valid topologic vertex. Returning None.")
            return None
        if not isinstance(direction, list):
            if not silent:
                print("Cell.TShape - Error: The direction input parameter is not a valid list. Returning None.")
            return None
        if not len(direction) == 3:
            if not silent:
                print("Cell.TShape - Error: The direction input parameter is not a valid vector. Returning None.")
            return None
        t_shape_wire = Wire.TShape(origin=origin,
                                   width=width,
                                   length=length,
                                   a=a,
                                   b=b,
                                   flipHorizontal=flipHorizontal,
                                   flipVertical=flipVertical,
                                   direction=[0,0,1],
                                   placement="center",
                                   tolerance=tolerance,
                                   silent=silent)

        distance = height/wSides
        wires = [t_shape_wire]
        for i in range(wSides):
            t_shape_wire = Topology.Translate(t_shape_wire, 0, 0, distance)
            wires.append(t_shape_wire)
        return_cell = Cell.ByWires(wires, triangulate=False, mantissa=mantissa, tolerance=tolerance, silent=silent)
        # move down to center
        return_cell = Topology.Translate(return_cell, 0, 0, -height*0.5)
        xOffset = 0
        yOffset = 0
        zOffset = 0
        if placement.lower() == "bottom":
            zOffset = height*0.5
        elif placement.lower() == "top":
            zOffset = -height*0.5
        elif placement.lower() == "lowerleft":
            xOffset = width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperleft":
            xOffset = width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        elif placement.lower() == "lowerright":
            xOffset = -width*0.5
            yOffset = length*0.5
            zOffset = height*0.5
        elif placement.lower() == "upperright":
            xOffset = -width*0.5
            yOffset = -length*0.5
            zOffset = -height*0.5
        
        return_cell = Topology.OrientAndPlace(return_cell,
                                           originA=Vertex.ByCoordinates(xOffset, yOffset, zOffset),
                                           originB=origin,
                                           dirA=[0, 0, 1],
                                           dirB=direction,
                                           transferDictionaries = False,
                                           tolerance = tolerance,
                                           silent = silent)
        return return_cell
    
    @staticmethod
    def Tube(origin= None, radius: float = 1.0, height: float = 1.0, thickness: float = 0.25, sides: int = 16, direction: list = [0, 0, 1], placement: str = "center", tolerance: float = 0.0001, silent: bool = False):
        """
        Creates a Tube. This method is an alias for the circular hollow section (CHS).

        Parameters
        ----------
        origin : topologic_core.Vertex, optional
            The location of the origin of the CHS. Default is None which results in the CHS being placed at (0, 0, 0).
        radius : float , optional
            The outer radius of the CHS. Default is 1.0.
        thickness : float , optional
            The thickness of the CHS. Default is 0.25.
        height : float , optional
            The height of the CHS. Default is 1.0.
        sides : int , optional
            The desired number of sides of the CSH. Default is 16.
        direction : list , optional
            The vector representing the up direction of the RHS. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the RHS. This can be "center", "bottom", "top", "lowerleft", "upperleft", "lowerright", "upperright". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created cell.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology

        if thickness >= radius:
            if not silent:
                print("Cell.Tube - Error: The thickness value is larger than or equal to the outer radius value. Returning None.")
            return None
        if origin == None:
            origin = Vertex.Origin()
        return Cell.CHS(origin=origin,
                        radius=radius,
                        height=height,
                        thickness=thickness,
                        sides=sides,
                        direction=direction,
                        placement=placement,
                        tolerance=tolerance,
                        silent=silent)
        
    @staticmethod
    def Vertices(cell) -> list:
        """
        Returns the vertices of the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.

        Returns
        -------
        list
            The list of vertices.

        """
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(cell, "Cell"):
            print("Cell.Vertices - Error: The input cell parameter is not a valid topologic cell. Returning None.")
            return None
        vertices = []
        # _ = cell.Vertices(None, vertices) # H to Core
        try:
            _ = Core.InstanceCall(cell, "Vertices", None, vertices)
        except Exception:
            vertices = None
        return vertices

    @staticmethod
    def Volume(cell, mantissa: int = 6, silent: bool = False) -> float:
        """
        Returns the volume of the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.
        manitssa: int , optional
            The number of decimal places to round the result to. Default is 6.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        float
            The volume of the input cell.

        """
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(cell, "Cell"):
            if not silent:
                print("Cell.Volume - Error: The input cell parameter is not a valid topologic cell. Returning None.")
            return None
        volume = None
        try:
            raw_volume = Core.CellUtility.Volume(cell)
            volume = float(raw_volume) if mantissa is None else round(float(raw_volume), int(mantissa))
        except:
            if not silent:
                print("Cell.Volume - Error: Could not compute the volume of the input cell. Returning None.")
            volume = None
        return volume

    @staticmethod
    def Wedge(origin=None,
            width=1,
            length=1,
            height=1,
            flipHorizontal = False,
            flipVertical = False,
            direction=[0,0,1],
            placement="center",
            tolerance=0.0001,
            silent=False):
        """
        Creates a Wedge.

        Parameters
        ----------
        origin : topologic_core.Vertex , optional
            The location of the origin of the Wedge. Default is None which results in the Wedge being placed at (0, 0, 0).
        width : float , optional
            The overall width of the Wedge. Default is 1.0.
        length : float , optional
            The overall length of the Wedge. Default is 1.0.
        height : float , optional
            The overall height of the Wedge. Default is 1.0.
        direction : list , optional
            The vector representing the up direction of the Wedge. Default is [0, 0, 1].
        placement : str , optional
            The description of the placement of the origin of the Wedge. This can be "center", "lowerleft", "upperleft", "lowerright", "upperright". It is case insensitive. Default is "center".
        tolerance : float , optional
            The desired tolerance. Default is 0.0001.
        silent : bool , optional
            If set to True, error and warning messages are suppressed. Default is False.

        Returns
        -------
        topologic_core.Cell
            The created Wedge.

        """
        from topologicpy.Vertex import Vertex
        from topologicpy.Face import Face
        from topologicpy.Topology import Topology

        if not isinstance(width, int) and not isinstance(width, float):
            if not silent:
                print("Cell.Wedge - Error: The width input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(length, int) and not isinstance(length, float):
            if not silent:
                print("Cell.Wedge - Error: The length input parameter is not a valid number. Returning None.")
            return None
        if not isinstance(height, int) and not isinstance(height, float):
            if not silent:
                print("Cell.Wedge - Error: The height input parameter is not a valid number. Returning None.")
            return None
        if width <= tolerance:
            if not silent:
                print("Cell.Wedge - Error: The width input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if length <= tolerance:
            if not silent:
                print("Cell.Wedge - Error: The length input parameter must be a positive number  greater than the tolerance input parameter. Returning None.")
            return None
        if height <= tolerance:
            if not silent:
                print("Cell.Wedge - Error: The a input parameter must be a positive number greater than the tolerance input parameter. Returning None.")
            return None
        if origin == None:
            origin = Vertex.Origin()
        if not Topology.IsInstance(origin, "vertex"):
            if not silent:
                print("Cell.Wedge - Error: The origin input parameter is not a valid topologic vertex. Returning None.")
            return None
        if not isinstance(direction, list):
            if not silent:
                print("Cell.Wedge - Error: The direction input parameter is not a valid list. Returning None.")
            return None
        if not len(direction) == 3:
            if not silent:
                print("Cell.Wedge - Error: The direction input parameter is not a valid vector. Returning None.")
            return None
        
        # Define the vertices of the T-shape (counterclockwise)
        v1 = Vertex.ByCoordinates(0,0,0)
        v2 = Vertex.ByCoordinates(width, 0, 0)
        v3 = Vertex.ByCoordinates(width, length, 0)
        v4 = Vertex.ByCoordinates(0, length, 0)
        v5 = Vertex.ByCoordinates(0, length, height)
        v6 = Vertex.ByCoordinates(0, 0, height)

        f1 = Face.ByVertices([v1, v2, v3, v4], tolerance=tolerance)
        f2 = Face.ByVertices([v1, v2, v6], tolerance=tolerance)
        f3 = Face.ByVertices([v4, v5, v3], tolerance=tolerance)
        f4 = Face.ByVertices([v1, v6, v5, v4], tolerance=tolerance)
        f5 = Face.ByVertices([v2, v3, v5, v6], tolerance=tolerance)
        cell = Cell.ByFaces([f1, f2, f3, f4, f5])
        cell = Topology.Translate(cell, -width/2, -length/2, -height/2)
        cell = Topology.Translate(cell, Vertex.X(origin), Vertex.Y(origin), Vertex.Z(origin))
        if flipHorizontal == True:
            xScale = -1
        else:
            xScale = 1
        if flipVertical == True:
            zScale = -1
        else:
            zScale = 1
        if xScale == -1 or zScale == -1:
            cell = Topology.Scale(cell, origin=origin, x=xScale, y=1, z=zScale)
        if placement.lower() == "lowerleft":
            cell = Topology.Translate(cell, origin=origin, x=width/2, y=length/2, z=height/2)
        elif placement.lower() == "upperright":
            cell = Topology.Translate(cell, origin=origin, x=-width/2, y=-length/2, z=-height/2)
        elif placement.lower() == "upperleft":
            cell = Topology.Translate(cell, origin=origin, x=width/2, y=-length/2, z=-height/2)
        elif placement.lower() == "lowerright":
            cell = Topology.Translate(cell, origin=origin, x=-width/2, y=length/2, z=height/2)
        
        if direction != [0, 0, 1]:
            cell = Topology.Orient(cell, origin=origin, dirA=[0, 0, 1], dirB=direction)
        
        return cell

    @staticmethod
    def Wires(cell) -> list:
        """
        Returns the wires of the input cell.

        Parameters
        ----------
        cell : topologic_core.Cell
            The input cell.

        Returns
        -------
        list
            The list of wires.

        """
        from topologicpy.Topology import Topology

        if not Topology.IsInstance(cell, "Cell"):
            print("Cell.Wires - Error: The input cell parameter is not a valid topologic cell. Returning None.")
            return None
        wires = []
        # _ = cell.Wires(None, wires) # H to Core
        try:
            _ = Core.InstanceCall(cell, "Wires", None, wires)
        except Exception:
            wires = None
        return wires
